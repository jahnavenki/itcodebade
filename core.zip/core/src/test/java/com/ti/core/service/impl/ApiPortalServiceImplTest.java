package com.ti.core.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.osgi.framework.FrameworkUtil;

import com.ti.core.service.ApiPortalService;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.util.PathBrowserHelper;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
public class ApiPortalServiceImplTest {
	@BeforeEach
	public void setUp(AemContext aemContext) {
		aemContext.registerInjectActivateService(ApiPortalServiceImpl.class);
	}

	@Test
	public void isSecureUrl(AemContext aemContext) {
		final var subject = aemContext.getService(ApiPortalService.class);
		assertFalse(subject.isSecureUrl("/content/texas-instruments/en-us/api/portal"));
		assertFalse(subject.isSecureUrl("https://www.ti.com/api/portal.html"));
		assertTrue(subject.isSecureUrl("/content/texas-instruments/en-us/developer-apis/portal"));
		assertTrue(subject.isSecureUrl("https://www.ti.com/swc/developer-apis/portal.html"));
	}

	@Test
	public void getUrl(AemContext aemContext) {
		final var seoUrlFactoryConfigs = mock(SeoUrlFactoryConfigs.class);
		final var seoUrlTagging = mock(SeoUrlTagging.class);
		when(seoUrlFactoryConfigs.getConfigs()).thenReturn(List.of(seoUrlTagging));
		when(seoUrlTagging.getContentPath()).thenReturn("/content/texas-instruments/en-us");
		when(seoUrlTagging.getDomainName()).thenReturn("www.ti.com");
		aemContext.registerService(SeoUrlFactoryConfigs.class, seoUrlFactoryConfigs);
		try(final var frameworkUtilMock = mockStatic(FrameworkUtil.class)) {
			frameworkUtilMock.when(() -> FrameworkUtil.getBundle(PathBrowserHelper.class)).thenReturn(aemContext.bundleContext().getBundle());
			aemContext.runMode("publish");
			final var subject = aemContext.getService(ApiPortalService.class);
			assertEquals("https://www.ti.com/content/texas-instruments/en-us/api/portal.html", subject.getUrl("/content/texas-instruments/en-us/api/portal"));
			assertEquals("https://www.ti.com/api/portal.html", subject.getUrl("https://www.ti.com/api/portal.html"));
			assertEquals("https://www.ti.com/api/portal.html", subject.getUrl("https://www.ti.com/swc/api/portal.html"));
			assertEquals("https://www.ti.com/swc/content/texas-instruments/en-us/developer-apis/portal.html", subject.getUrl("/content/texas-instruments/en-us/developer-apis/portal"));
			assertEquals("https://www.ti.com/swc/developer-apis/portal.html", subject.getUrl("https://www.ti.com/developer-apis/portal.html"));
			assertEquals("https://www.ti.com/swc/developer-apis/portal.html", subject.getUrl("https://www.ti.com/swc/developer-apis/portal.html"));
		}
	}
}
