package com.ti.core.components.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ti.core.service.ApiPortalService;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
public class ApiPortalSideNavigationLevel2Test {
	@Mock
	private ApiPortalService apiPortalService;

	@BeforeEach
	public void setUp(AemContext aemContext) {
		aemContext.load().json("/jcr/api-portal.json", "/content/texas-instruments");
		aemContext.registerService(ApiPortalService.class, apiPortalService);
	}

	@Test
	public void getTitle(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsidenavigat/level1Links/item1/level2Links/item0";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiPortalSideNavigationLevel2.class);
		assertEquals("Getting started", subject.getTitle());
	}

	@Test
	public void getUrl(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsidenavigat/level1Links/item1/level2Links/item0";
		final var CONTENT_PATH = "/content/texas-instruments/en-us/developer-api/store-api/getting-started";
		final var URL = "https://www.ti.com/developer-api/store-api/getting-started.html";
		when(apiPortalService.getUrl(CONTENT_PATH)).thenReturn(URL);
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiPortalSideNavigationLevel2.class);
		assertEquals(URL, subject.getUrl());
	}

	@Test
	public void isSecure(AemContext aemContext) {
		{
			final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsidenavigat/level1Links/item1/level2Links/item0";
			final var CONTENT_PATH = "/content/texas-instruments/en-us/developer-api/store-api/getting-started";
			when(apiPortalService.isSecureUrl(CONTENT_PATH)).thenReturn(false);
			final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
			final var subject = resource.adaptTo(ApiPortalSideNavigationLevel2.class);
			assertFalse(subject.isSecure());
		}
		{
			final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsidenavigat/level1Links/item10/level2Links/item0";
			final var CONTENT_PATH = "/content/texas-instruments/en-us/developer-apis/backlog/backlog-order-api/getting-started";
			when(apiPortalService.isSecureUrl(CONTENT_PATH)).thenReturn(true);
			final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
			final var subject = resource.adaptTo(ApiPortalSideNavigationLevel2.class);
			assertTrue(subject.isSecure());
		}
	}
}
