package com.ti.core.components.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ti.core.service.ApiPortalService;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
public class ApiCardTest {
	@Mock
	private ApiPortalService apiPortalService;

	@BeforeEach
	public void setUp(AemContext aemContext) {
		aemContext.load().json("/jcr/api-portal.json", "/content/texas-instruments");
		aemContext.registerService(ApiPortalService.class, apiPortalService);
	}

	@Test
	public void getTitle(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/overview/jcr:content/root/responsivegrid_464739278/apicards/apiCards/item0";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiCard.class);
		assertEquals("TI store API suite", subject.getTitle());
	}

	@Test
	public void getDesc(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/overview/jcr:content/root/responsivegrid_464739278/apicards/apiCards/item0";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiCard.class);
		assertEquals("<p>Manage your orders with ease. Place orders, track shipments and get real-time inventory and pricing data. Request financial documents.</p>", subject.getDesc());
	}

	@Test
	public void getImage(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/overview/jcr:content/root/responsivegrid_464739278/apicards/apiCards/item0";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiCard.class);
		assertEquals("/content/dam/ticom/images/icons/illustrative-icons/resources/cloud-gear-ordering-icon.png", subject.getImage());
	}

	@Test
	public void getUrl(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/overview/jcr:content/root/responsivegrid_464739278/apicards/apiCards/item0";
		final var CONTENT_PATH = "/content/texas-instruments/en-us/developer-api/store-api/getting-started";
		final var URL = "https://www.ti.com/developer-api/store-api/getting-started.html";
		when(apiPortalService.getUrl(CONTENT_PATH)).thenReturn(URL);
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiCard.class);
		assertEquals(URL, subject.getUrl());
	}

	@Test
	public void getCtaLabel(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/overview/jcr:content/root/responsivegrid_464739278/apicards/apiCards/item0";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(ApiCard.class);
		assertEquals("View documentation", subject.getCtaLabel());
	}
}
