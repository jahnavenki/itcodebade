package com.ti.core.components.models;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ti.core.service.ApiPortalService;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
public class SubsiteHeaderTest {
	@Mock
	private ApiPortalService apiPortalService;

	@BeforeEach
	public void setUp(AemContext aemContext) {
		aemContext.load().json("/jcr/api-portal.json", "/content/texas-instruments");
		aemContext.registerService(ApiPortalService.class, apiPortalService);
	}

	@Test
	public void getLinks(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsubsiteheader";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(SubsiteHeader.class);
		assertTrue(subject.getLinks().size() > 0);
	}

	@Test
	public void isNeedsAuthoring(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsubsiteheader";
		final var resource = aemContext.resourceResolver().resolve(RESOURCE_PATH);
		final var subject = resource.adaptTo(SubsiteHeader.class);
		assertFalse(subject.isNeedsAuthoring());
	}

	@Test
	public void isSelected(AemContext aemContext) {
		final var RESOURCE_PATH = "/content/texas-instruments/en-us/developer-api/jcr:content/apiportalsubsiteheader";
		final var CONTENT_PATH = "/content/texas-instruments/en-us/developer-api/store-api/getting-started";
		aemContext.currentPage(CONTENT_PATH);
		aemContext.currentResource(RESOURCE_PATH);
		when(apiPortalService.getUrl(anyString())).thenAnswer( invocation -> {
			String path = invocation.getArgument(0);
			return path.replace( "/content/texas-instruments/en-us/", "https://www.ti.com/" ) + ".html";
		} );
		final var subject = aemContext.request().adaptTo(SubsiteHeader.class);
		final var level1Links = subject.getLinks().toArray(new SubsiteHeaderLevel1[] {});
		{
			final var level1Link = level1Links[0];
			assertFalse(level1Link.isSelected());
		}
		{
			final var level1Link = level1Links[1];
			final var level2Links = level1Link.getChildren().toArray(new SubsiteHeaderLevel2[] {});
			assertTrue(level1Link.isSelected());
			assertTrue(level2Links[0].isSelected());
			assertFalse(level2Links[1].isSelected());
			assertFalse(level2Links[2].isSelected());
		}
		{
			final var level1Link = level1Links[2];
			assertFalse(level1Link.isSelected());
		}
		{
			final var level1Link = level1Links[3];
			final var level2Links = level1Link.getChildren().toArray(new SubsiteHeaderLevel2[] {});
			assertFalse(level1Link.isSelected());
			assertFalse(level2Links[0].isSelected());
			assertFalse(level2Links[1].isSelected());
		}
	}

}
