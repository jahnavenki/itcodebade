package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import com.ti.core.util.PathBrowserHelper;
import com.day.cq.dam.api.Asset;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Large Diagram & Patners Logo Teasers WCMUsePojo.
 */
public class LargeDiagramTeaser extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private String sectionTitle;
	private String subTitle;
	private String description;

    private static final String TEASER_SECTION_TITLE = "sectionTitle";
    private static final String TEASER_SUB_TITLE = "subTitle";
	private static final String TEASER_DESCRIPTION = "description";
	private static final String TEASER_CTAS = "ctas";
	private static final String TEASER_BUTTONCTAS = "buttonctas";
	private static final String TEASER_IMAGESET = "imageSet";
	private final List<CtaViewModel> ctas = new ArrayList<>();
	private final List<ButtonCtaViewModel> buttonctas = new ArrayList<>();
	private final List<ImageSetViewModel> imagesSet = new ArrayList<>();
    
	public List<ImageSetViewModel> getImagesSet() {
		return imagesSet;
	}
	public List<CtaViewModel> getCtas() {
		return ctas;
	}
	public List<ButtonCtaViewModel> getButtonCtas() {
		return buttonctas;
	}

    public String getSectionTitle() {
        return sectionTitle;
    }

	public String getSubTitle() {
        return subTitle;
    }

    public String getDescription() {
        return description;
    }

	public static class CtaViewModel {
		private String ctaLabel;
		private String ctaUrl;
		private String ctaIcon;

		public String getCtaLabel() {
			return ctaLabel;
		}

		public String getCtaUrl() {
			return ctaUrl;
		}

		public String getCtaIcon() {
			return ctaIcon;
		}

		public void setCtaLabel( String ctaLabel ) {
			this.ctaLabel = ctaLabel;
		}

		public void setCtaUrl( String ctaUrl ) {
			this.ctaUrl = ctaUrl;
		}

		public void setCtaIcon( String ctaIcon ) {
			this.ctaIcon = ctaIcon;
		}
	}
	public static class ButtonCtaViewModel {
		private String buttonCtaLabel;
		private String buttonCtaURL;

		public void setButtonCtaLabel( String buttonCtaLabel ) {
			this.buttonCtaLabel = buttonCtaLabel;
		}

		public String getButtonCtaLabel() {
			return buttonCtaLabel;
		}

		public void setButtonCtaURL( String buttonCtaURL ) {
			this.buttonCtaURL = buttonCtaURL;
		}

		public String getButtonCtaURL() {
			return buttonCtaURL;
		}
	}
	public static class ImageSetViewModel {
		private String imageSrc;
	    private String imagePath;
	    private String imageAlt;

		public String getImageSrc() {
			return imageSrc;
		}
	    
		public String getImagePath() {
			return imagePath;
		}

		public String getImageAlt() {
			return imageAlt;
		}

		public void setImageSrc( String imageSrc ) {
			this.imageSrc = imageSrc;
		}

		public void setImagePath( String imagePath ) {
			this.imagePath = imagePath;
		}

		public void setImageAlt( String imageAlt ) {
			this.imageAlt = imageAlt;
		}
	}
	
	private String getImageAltText( String imageSrc ) {
		final var resource = getResourceResolver().getResource(imageSrc);
		if(null == resource) return "";
		final var asset = resource.adaptTo(Asset.class);
		if(null == asset) return "";
		return asset.getMetadataValue("dc:title");
	}

	private CtaViewModel buildCtaViewModel( Resource ctaResource ) {
		final var valueMap = ctaResource.getValueMap();
		final var cta = new CtaViewModel();
		cta.setCtaLabel( valueMap.get( "ctaLabel", "" ) );
		var ctaUrl = valueMap.get( "ctaUrl", "" );
		cta.setCtaUrl( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), ctaUrl) );
		cta.setCtaIcon( ctaUrl.endsWith( "/products" ) ? "parametric-filter" : "arrow-right" );
		return cta;
	}
	private ButtonCtaViewModel buildButtonCtaViewModel( Resource buttonctaResource ) {
		final var valueMap = buttonctaResource.getValueMap();
		final var buttoncta = new ButtonCtaViewModel();
		buttoncta.setButtonCtaLabel( valueMap.get( "buttonctaLabel", "" ) );
		var buttonctaURL = valueMap.get( "buttonctaURL", "" );
		buttoncta.setButtonCtaURL( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), buttonctaURL) );
		return buttoncta;
	}
	private ImageSetViewModel imageSetViewModel( Resource imageResource ) {
		final var valueMap = imageResource.getValueMap();
		final var imagesList = new ImageSetViewModel();
		final var imageSrc = valueMap.get("imageSrc", "");
		imagesList.setImageSrc( imageSrc );
		imagesList.setImageAlt( getImageAltText(imageSrc) );
		final var imagePath = valueMap.get("imagePath", "");
		imagesList.setImagePath(PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),imagePath ));
		
		return imagesList;
	}

    @Override
    public void activate() throws JSONException {
		try {
			this.sectionTitle = getProperties().get(TEASER_SECTION_TITLE, String.class);
			this.subTitle = getProperties().get(TEASER_SUB_TITLE, String.class);
			this.description = getProperties().get(TEASER_DESCRIPTION, String.class);
			final var catsResource = getResourceResolver().getResource(getResource(), TEASER_CTAS);
			if( null != catsResource ) {
				for( var cataResource : catsResource.getChildren() ) {
					ctas.add( buildCtaViewModel( cataResource ) );
				}
			}
			final var buttonCtasResource = getResourceResolver().getResource(getResource(),TEASER_BUTTONCTAS);
			if( null != buttonCtasResource ) {
				for( var buttonCtaResource : buttonCtasResource.getChildren() ) {
					buttonctas.add( buildButtonCtaViewModel( buttonCtaResource ) );
				}
			}
			final var imagesResource = getResourceResolver().getResource(getResource(),TEASER_IMAGESET);
			if( null != imagesResource ) {
				for( var imageResource : imagesResource.getChildren() ) {
					imagesSet.add( imageSetViewModel( imageResource ) );
				}
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
        
}