package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.ApiPortalService;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ApiPortalSideNavigationLevel2 {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ApiPortalService apiPortalService;

	@ValueMapValue(name = "level2Title")
	private String title;

	@ValueMapValue(name = "level2URL")
	private String url;

	private Boolean secure;
	private Boolean selected;

	@PostConstruct
	public void init() {
		try {
			secure = apiPortalService.isSecureUrl(url);
			url = apiPortalService.getUrl(url);
			selected = false;
		} catch(Exception ex) {
			log.error( "Exception in ApiPortalSideNavigationLevel2", ex );
		}
	}

	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}

	public Boolean isSecure() {
		return secure;
	}

	public Boolean isSelected() {
		return selected;
	}

	public void setSelected(Boolean value) {
		selected = value;
	}
}
