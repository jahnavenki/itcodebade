package com.ti.core.components.models;

import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;

import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = {SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ApiPortalDataSource {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ProductNavigationTabsOrdering productNavigationTabsOrdering;

	@ScriptVariable
	private Page currentPage;

	private String apiPortalSideNavigationDataSource;
	private String subsiteHeaderDataSource;

	public String getApiPortalSideNavigationDataSource() {
		return apiPortalSideNavigationDataSource;
	}

	public String getSubsiteHeaderDataSource() {
		return subsiteHeaderDataSource;
	}

	private static final Set<String> ROOT_PAGE_NAMES = Set.of( "developer-api", "developer-apis" );

	private Page findSideNavigationDataSourcePage(Page page) {
		if (ROOT_PAGE_NAMES.contains(page.getName())) {
			return page;
		}
		final var parentPage = page.getParent();
		if (null == parentPage) {
			log.error("Did not find root page");
			return null;
		}
		if (ROOT_PAGE_NAMES.contains(parentPage.getName())) {
			return page;
		}
		return findSideNavigationDataSourcePage(parentPage);
	}

	@PostConstruct
	public void init() {
		try {
			final var pageLanguage = productNavigationTabsOrdering.getPageLanguage(currentPage);
			final var sideNavigationDataSourcePage = findSideNavigationDataSourcePage(currentPage);
			if (null != sideNavigationDataSourcePage) {
				apiPortalSideNavigationDataSource = sideNavigationDataSourcePage.getPath() + "/jcr:content/apiportalsidenavigat";
			}
			subsiteHeaderDataSource = String.format("/content/texas-instruments/%s/developer-api/jcr:content/subsiteheader", pageLanguage);
		} catch(Exception ex) {
			log.error("Exception in ApiPortalDataSource", ex);
		}
	}
}
