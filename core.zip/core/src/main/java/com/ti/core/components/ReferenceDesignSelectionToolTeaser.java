package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.xfa.ut.StringUtils;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReferenceDesignSelectionToolTeaser extends WCMUsePojo {

	private static final String FAMILY_ID = "familyId";
	private static final String SILO_ID = "siloId";
	private static final String JSON_KEY_APP_HIERARCHY_LIST = "AppHierarchyList";
	private static final String JSON_KEY_FAMILY_NAME = "familyName";
	private static final String JSON_KEY_EN_FAMILY_NAME = "enFamilyName";
	private static final String APPLICATION_ID = "applicationId";
	private static final String CATEGORY_ID = "categoryId";
	private static final String MARKET_ID = "marketId";
	private static final String SECTOR_ID = "sectorId";
	private static final String JSON_KEY_APPLICATION_NAME = "appAreaName";
	private static final String JSON_KEY_IS_TOP_LEVEL_FAMILY = "isTopLevelFamily";
	private static final String JSON_KEY_CHILD_ID = "childId";
	private static final String JSON_KEY_PARENT_ID = "parentId";
	private static final String JSON_KEY_EN_SECTION_NAME = "enSectionName";
	private static final String SEARCH_QUERY_APPLICATION_ID = "#search?applid=";
	private static final String SEARCH_QUERY_FAMILY_ID = "#search?famid=";

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String title;
	private String imgAlt;
	private String imgSrc;
	private String description;
	private String cta;
	private String lid;
	private String ctaUrl;
	private String name;
	private String nameEn;

	public String getTitle() {
		return title;
	}

	public String getImgAlt() {
		return imgAlt;
	}

	public String getImgSrc() {
		return imgSrc;
	}

	public String getDescription() {
		return description;
	}

	public String getCta() {
		return cta;
	}

	public String getLid() {
		return lid;
	}

	public String getCtaUrl() {
		return ctaUrl;
	}

	private String getBaseUrl(String domainName, String language) {
		String baseUrl = "https://" + domainName;
		if ("zh-cn".equals(language)) {
			baseUrl += "/cn/reference-designs/index.html";
		} else if ("ja-jp".equals(language)) {
			baseUrl += "/jp/reference-designs/index.html";
		} else {
			baseUrl += "/reference-designs/index.html";
		}
		return baseUrl;
	}

	@Override
	public void activate() {
		try {  
			final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if(null == tabsService) return;
			final SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
			if(null == factoryConfigs) return;
			final Page currentPage = getCurrentPage();
			final ResourceResolver resourceResolver = getResourceResolver();
			final String language = tabsService.getPageLanguage(currentPage);
			final WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if(null == wcmComponents) return;
			final SlingHttpServletRequest req = getRequest();
			final LanguageUtils langUtils = new LanguageUtils(req);
			final ValueMap pageProperties = getPageProperties();
			imgSrc = "/content/dam/ticom/images/icons/illustrative-icons/software/reference-designs-icon.png";
			final Resource img = resourceResolver.resolve(imgSrc);
			final Asset asset = img.adaptTo(Asset.class);
			if(null != asset) {
				imgAlt = asset.getMetadataValue("dc:title");
			}
			description = langUtils.getI18nStr("Use our reference design selection tool to find designs that best match your application and parameters.");
			cta = langUtils.getI18nStr("View reference designs");
			final String domainName = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
			final String baseUrl = getBaseUrl(domainName, language);
			setNameAndCtaUrl(baseUrl, language, pageProperties, wcmComponents);
			lid = "referencedesign-" + nameEn;
			title = langUtils.getI18nStr("Reference designs related to {}", name);
		} catch (Exception e) {
			log.error("Error setting metadata: ", e);
		}
	}
	
	private void setNameAndCtaUrl(String baseUrl, String language, ValueMap pageProperties, WCMComponents wcmComponents) throws JSONException {
		final String familyId = (String) pageProperties.get(FAMILY_ID);
		final String siloId = (String) pageProperties.get(SILO_ID);
		final String applicationId = (String) pageProperties.get(APPLICATION_ID);
		final String marketId = (String) pageProperties.get(MARKET_ID);
		final String sectorId = (String) pageProperties.get(SECTOR_ID);
		final String categoryId = (String) pageProperties.get(CATEGORY_ID);
		if (!StringUtils.isEmpty(familyId)) {
			final var prodData = wcmComponents.getAllProductService(getRequest(), Integer.parseInt(familyId), language);
			name = prodData.getString(JSON_KEY_FAMILY_NAME);
			nameEn = prodData.getString(JSON_KEY_EN_FAMILY_NAME);
			final String parentId = prodData.getString(JSON_KEY_PARENT_ID);
			final boolean isTopLevel = "Y".equals(prodData.getString(JSON_KEY_IS_TOP_LEVEL_FAMILY));
			if (StringUtils.isEmpty(siloId) || siloId.equals(familyId)) {
				ctaUrl = baseUrl + SEARCH_QUERY_FAMILY_ID + familyId;
			} else if(isTopLevel || siloId.equals(parentId)) {
				ctaUrl = baseUrl + SEARCH_QUERY_FAMILY_ID + siloId + "," + familyId;
			} else {
				ctaUrl = baseUrl + SEARCH_QUERY_FAMILY_ID + siloId + "," + parentId + "," + familyId;
			}
		} else if (!StringUtils.isEmpty(applicationId)) {
			final var prodData = wcmComponents.getAllApplicationService(getRequest(), Integer.parseInt(applicationId), language);
			name = prodData.getString(JSON_KEY_APPLICATION_NAME);
			final var appHierarchyList = prodData.getJSONArray(JSON_KEY_APP_HIERARCHY_LIST);
			for (var i = 0; i < appHierarchyList.length(); ++i) {
				final var app = appHierarchyList.getJSONObject( i );
				final String childId = app.getString(JSON_KEY_CHILD_ID);
				if (applicationId.equals(childId)) {
					nameEn = app.getString(JSON_KEY_EN_SECTION_NAME);
					break;
				}
			}
			if (StringUtils.isEmpty(categoryId)) {
				if (StringUtils.isEmpty(sectorId)) {
					ctaUrl = baseUrl + SEARCH_QUERY_APPLICATION_ID + marketId;
				} else {
					ctaUrl = baseUrl + SEARCH_QUERY_APPLICATION_ID + marketId + "," + sectorId;
				}
			} else {
				ctaUrl = baseUrl + SEARCH_QUERY_APPLICATION_ID + marketId + "," + sectorId + "," + categoryId;
			}
		}
	}
}
