package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.LoggerFactory;

import com.ti.core.service.ApiPortalService;

import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class, Resource.class},
	resourceType = CtaWithIcon.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class CtaWithIcon {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/ctaWithIcon";

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ApiPortalService apiPortalService;

	@ValueMapValue
	private String label;

	@ValueMapValue
	private String url;

	@PostConstruct
	public void init(){
		try {
			label = StringUtils.defaultString(label);
			url = apiPortalService.getUrl(url);
		} catch (Exception e) {
			log.error("Exception in CtaWithIcon", e);
		}
	}

	public String getLabel() {
		return label;
	}

	public String getUrl() {
		return url;
	}
}
