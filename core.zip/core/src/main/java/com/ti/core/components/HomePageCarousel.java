package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Overview WCMUsePojo.
 */
public class HomePageCarousel extends WCMUsePojo {
	protected static final Logger log = LoggerFactory.getLogger(HomePageCarousel.class);

	private static final String PROPERTY_BANNERS_PAGE_URL = "homePageBannersUrl";

	@Override
	public void activate() {
		try {
			// TO DO 
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}

	public String getBannersPageUrl() {
		return getProperties().get(PROPERTY_BANNERS_PAGE_URL, String.class);
	}
	
	public Page getBannersPage() {
		String bannersPageUrl = getBannersPageUrl();
		
		if (StringUtils.isNotEmpty(bannersPageUrl)) {
			ResourceResolver resolver = getRequest().getResourceResolver();
 		    Resource resource = resolver.resolve(bannersPageUrl);
			
			return resource.adaptTo(Page.class);		
		}
		else
			return null;
	}

}
