package com.ti.core.models;


public class AdditionalResourceModel {
    private String categoryTitle;
    private String resourceType;
    private String title;
    private String url;

    public String getCategoryTitle() {
        return categoryTitle;
    }

      public String getResourceType() {
        return resourceType;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public void setCategoryTitle(String categoryTitle) {
        this.categoryTitle = categoryTitle;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
}