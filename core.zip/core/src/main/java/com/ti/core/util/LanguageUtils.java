package com.ti.core.util;

import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.i18n.I18n;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * LanguageUtils WCMUsePojo.
 *
 */
public class LanguageUtils extends WCMUsePojo {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private SlingHttpServletRequest request;
	private Page page;
	private Locale locale;
	private I18n i18n;
	private I18n i18nEn;
	/**
	 * Constructor (non-WCMUsePojo) mode.
	 *
	 */
	public LanguageUtils() {
	}

	/**
	 * Constructor (non-WCMUsePojo) mode.
	 *
	 * @param req
	 *            - pass in the current request object
	 */
	public LanguageUtils(SlingHttpServletRequest req) {
		request = req;

		if (request != null) {
			i18nEn = new I18n(request.getResourceBundle(Locale.US));
			String pagePath = request.getRequestPathInfo().getResourcePath();
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);

			if (!pagePath.isEmpty() && pageManager != null) {
				page = pageManager.getPage(pagePath);
				if (page == null)
					page = pageManager.getContainingPage(pagePath);
			}
			if (page != null) {
				setLocaleHelper(page.getLanguage(true));
			}
		}
	}

	@Override
	public void activate() {
		try {
			request = getRequest();
			page = getCurrentPage();

			if (request != null) {
				i18nEn = new I18n(request.getResourceBundle(Locale.US));
				if (page != null) {
					setLocaleHelper(page.getLanguage(true));
				}
			}
		} catch (Exception e) {
			log.error("Error in LanguageUtils.activate()", e);
		}
	}

	/**
	 * Change/set the locale setting - typically no need to call this method
	 * unless you intentionally want to switch to a different language than the
	 * current one
	 *
	 * @param loc
	 *            - Locale to change to
	 */

	public void setLocale(Locale loc) {
		setLocaleHelper(loc);
	}

	private void setLocaleHelper(Locale loc) {
		if (request != null && loc != null) {
			locale = loc;
			ResourceBundle resourceBundle = request.getResourceBundle(locale);

			if (resourceBundle != null) {
				i18n = new I18n(resourceBundle);
			}
		}
	}

	/**
	 * Returns the page "language" - which is the 2-letter ISO language code +
	 * 2-letter ISO country code. Returns empty string if error.
	 *
	 */
	public String getPageLanguage() {
		if (page != null) {
			Locale loc = page.getLanguage(true);
			if (loc != null) {
				return loc.getLanguage().toLowerCase() + "-" + loc.getCountry().toLowerCase();
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Returns the page "language", using product folder convention - which is the 2-letter ISO language code (in LOWER CASE) +
	 * 2-letter ISO country code (IN UPPER CASE). Also note that  not all languages are currently supported by product folders.  Returns empty string if error.
	 *
	 */
	public String getPageLanguageForProductFolder() {
		String lang = getPageLanguage();
		if (Constants.CN_LANG.equalsIgnoreCase(lang))
			lang = Constants.CN_LANG;
		else if (Constants.JP_LANG.equalsIgnoreCase(lang))
			lang = Constants.JP_LANG;
		else
			lang = Constants.EN_LANG;

		return lang;
	}

	/**
	 * Returns the i18n string found in \apps\ti\i18n\ string tables, based on
	 * the current locale/lang setting
	 *
	 * @param keystring
	 *            - the key used to lookup strings in the i18n resource table
	 *            (for TI the key is just the complete English text itself)
	 * @return looked up string in the i18n resource table
	 */
	public String getI18nStr(String keystring) {
		if (i18n == null) {
			return keystring;
		} else {
			return i18n.get(keystring);
		}
	}

	public String getI18nStr(String keystring, Page currentPage, SlingHttpServletRequest request) {
		Locale pageLang = currentPage.getLanguage(false);
		ResourceBundle resourceBundle = request.getResourceBundle(pageLang);
		I18n resBundleI18N  = new I18n(resourceBundle);
		return resBundleI18N .get(keystring);
	}

	public String getI18nStr(String keystring, String ...params) {
		var str = getI18nStr(keystring);
		if(null == str || params.length == 0) return str;
		str = str.replace("{}", params[0]);
		for(var i = 0; i < params.length; ++i) {
			str = str.replace("{" + i + "}", params[i]);
		}
		return str;
	}

	public String getI18nStrEn(String keystring) {
		if (i18nEn == null) {
			return keystring;
		} else {
			return i18nEn.get(keystring);
		}
	}

	public String getI18nStrEn(String keystring, String ...params) {
		var str = getI18nStrEn(keystring);
		if(null == str || params.length == 0) return str;
		str = str.replace("{}", params[0]);
		for(var i = 0; i < params.length; ++i) {
			str = str.replace("{" + i + "}", params[i]);
		}
		return str;
	}

	public static String GetCountryCodeFromLangCode(String languageCode) {
		HashMap<String, String> countryCode = new HashMap<>();
		countryCode.put("en-us", "en");
		countryCode.put("zh-cn", "cn");
		countryCode.put("ja-jp", "jp");
		countryCode.put("ko-kr", "ko");
		countryCode.put("de-de", "de");
		countryCode.put("ru-ru", "ru");
		countryCode.put("zh-tw", "tw");
		countryCode.put("es-mx", "mx");
		if (countryCode.containsKey(languageCode)) {
			return countryCode.get(languageCode);
		} else {
			return Constants.EN_LANG_CODE;
		}

	}

	/**
	 * Returns a string with the date format to use depending on region
	 *
	 * @param language string with language-country code info
	 * @return date format to use
	 */
	public static String getRegionDateFormat(String language) {
		switch (language.toLowerCase()) {
			case "zh-cn":
			case "ja-jp":
			case "zh-tw":
				return "yyyy'年'M'月'd'日'";
			case "ko-kr":
				return "yyyy'년'M'월'd'일'";
			case "de-de":
			case "ru-ru":
				return "dd MMMM, yyyy";
			default:
				return "dd MMM yyyy";
		}
	}

}
