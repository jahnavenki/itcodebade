package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import java.util.Collections;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class PartnerResourceFilter {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService
	private org.apache.sling.models.factory.ModelFactory modelFactory;

	@ScriptVariable
	protected Page currentPage;

	@Self
	private SlingHttpServletRequest request;

	@ValueMapValue
	private String title;

	private final List<String> productCategory = new ArrayList<>();

	private String productCategoryLabels;
	private String productCategoryValues;

	@ValueMapValue
	private List<String> resourceCategory;

	private String resourceCategoryLabels;
	private String resourceCategoryValues;

	@ValueMapValue
	private List<String> region;

	private String regionLabels;
	private String regionValues;

	@OSGiService
	private WCMComponents wcm;

	@OSGiService
	private ProductNavigationTabsOrdering tabsService;

	@PostConstruct
	private void init() {
		try {
			var lang = "en-us";
			if (null != tabsService) lang = tabsService.getPageLanguage(currentPage);
			final var siloFamilies = new JSONObject(wcm.getSilo(lang)).getJSONArray("content");
			for (var i = 0; i < siloFamilies.length(); ++i) {
				final var app = siloFamilies.getJSONObject( i );
				final String familyName = app.getString("familyName");
				productCategory.add(familyName);
			}
			Collections.sort(productCategory);
			if (null == region) region = Collections.emptyList();
			if (null == resourceCategory) resourceCategory = Collections.emptyList();
			final var languageUtils = new LanguageUtils(request);
			final var select = languageUtils.getI18nStr("Select");
			productCategoryLabels = getCsvList(select, productCategory);
			productCategoryValues = getCsvList("", productCategory);
			resourceCategoryLabels = getCsvList(select, resourceCategory);
			resourceCategoryValues = getCsvList("", resourceCategory);
			regionLabels = getCsvList(select, region);
			regionValues = getCsvList("", region);
		} catch(Exception e) {
			log.error("Exception in Partner Resource Filter: {}", e);
		}
	}

	public String getTitle() {
		return title;
	}

	public List<String> getProductCategory() {
		return productCategory;
	}

	public String getProductCategoryLabels() {
		return productCategoryLabels;
	}

	public String getProductCategoryValues() {
		return productCategoryValues;
	}

	public List<String> getResourceCategory() {
		return resourceCategory;
	}

	public String getResourceCategoryLabels() {
		return resourceCategoryLabels;
	}

	public String getResourceCategoryValues() {
		return resourceCategoryValues;
	}

	public List<String> getRegion() {
		return region;
	}

	public String getRegionLabels() {
		return regionLabels;
	}

	public String getRegionValues() {
		return regionValues;
	}

	// web components use proprietary CSV algorithm, doesn't support quoting
	public String escapeCsvValue(String value) {
		return value.replace( ",", "\\," );
	}

	public String getCsvList(String firstOption, List<String> values) {
		return String.join(",",
			Stream.concat(
				Stream.of(firstOption),
				values.stream()
			).map(s -> escapeCsvValue(s))
			.collect(Collectors.toList())
		);
	}
}
