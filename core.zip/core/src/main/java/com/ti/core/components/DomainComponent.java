package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.util.Constants;

import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DomainComponent extends WCMUsePojo {
	protected final static Logger log = LoggerFactory.getLogger(DomainComponent.class);
	private String domain;
	private String language;
	private String pagelanguage;
	private List<SeoUrlTagging> listConfig;
	private String legalDomain;

	@Override
	public void activate() throws Exception {
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		String pagePath = getCurrentPage().getPath();
		pagePath = pagePath.toUpperCase();
		if (tabsService != null) {
			this.language = tabsService.getLanguageCodeForPage(getCurrentPage()).toLowerCase();
			this.pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
			if (!this.language.matches("cn|jp|fr|de|in|it|kr|mx|ru|es|tw|vi")) {
				this.language = "en";
			}
		}
		if (null != factoryConfigs) {
			listConfig = factoryConfigs.getConfigs();

			try {

				this.domain = getDomainFromConfig(factoryConfigs, pagePath);
				if (this.language.matches("cn|jp")) {
					this.legalDomain = this.domain.concat("/ww");
				} else {
					this.legalDomain = this.domain;
				}

			} catch (Exception e) {
				if (StringUtils.isEmpty(domain)) {
					log.error("setting default domain due to below exception {} " , domain);
					this.domain = "www.ti.com";
				}
				log.error("Error generating domain urls due to {} " , e);
			}

		}
	}

	public String getPagelanguage() {
		return pagelanguage;
	}

	public void setPagelanguage(String pagelanguage) {
		this.pagelanguage = pagelanguage;
	}

	/**
	 * This static function and be used to get the domain for a given page path
	 * 
	 * @param factoryConfigs
	 *            The SeoUrlFactoryConfigs service.
	 * @param pagePath
	 */
	public static String getDomainFromConfig(SeoUrlFactoryConfigs factoryConfigs, String pagePath) {
		List<SeoUrlTagging> listConfig = null;
		String domain = StringUtils.EMPTY;
		try {
			listConfig = factoryConfigs.getConfigs();
			for (SeoUrlTagging seoUrlTagging : listConfig) {
				if (StringUtils.containsIgnoreCase(pagePath, seoUrlTagging.getContentPath())) {
					domain = seoUrlTagging.getDomainName();

					break;
				}

			}
			return domain;
		} catch (Exception e) {
			log.error("Error in getting domain configs {} " , e);
			return "www.ti.com";
		}

	}

	/**
	 * Returns the domain.
	 * 
	 * @return domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * Setting the Domain.
	 * 
	 * @param Domain.
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * Returns the domain, but assumes QA is unavailable and references UAT instead
	 * 
	 * @return domain
	 */
	public String getDomainNoQA() {
		return domain.replaceAll("(?i)qa", "uat");
	}

	/**
	 * Returns the Language.
	 * 
	 * @return Language : the second part of pageLanguge string (e.g.
	 *         pagelanguage = zh-cn -> language = cn)
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Setting the Language.
	 * 
	 * @param Language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * Returns the pagelang.
	 * 
	 * @return pagelang : the second part of pageLanguge string (e.g.
	 *         pagelanguage = zh-cn -> pagelang = zh)
	 */
	public String getPagelang() {
		String[] splitLanguage;
		if (this.pagelanguage != null) {
			splitLanguage = this.pagelanguage.split("-");
		} else {
			return "en";
		}

		if (splitLanguage[0] != null && Constants.LANG_CODES_ALL.contains(splitLanguage[0])) {
			return splitLanguage[0];
		} else {
			return "en";
		}
	}

	/**
	 * Returns the PageLanguage.
	 * 
	 * @return PageLanguage : language-region string (e.g. zh-cn)
	 */

	/**
	 * Return the configuration list.
	 * 
	 * @return list of SeoUrlTagging containing configurations of domain name
	 *         and content path.
	 */
	public List<SeoUrlTagging> getListConfig() {
		return listConfig;
	}

	public String getLegalDomain() {
		return legalDomain;
	}

}