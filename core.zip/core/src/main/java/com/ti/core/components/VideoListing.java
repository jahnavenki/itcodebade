package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VideoListing extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private final List<VideoViewModel> videosList = new ArrayList<>();

    public List<VideoViewModel> getVideosList() {
        return videosList;
    }

    @Override
    public void activate() {
        try {
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("videosList")) {
                    for (Resource resourceChild : nodeChild.getChildren()) {
                        VideoViewModel videoViewModel = buildVideoViewModel(resourceChild);
                        videosList.add(videoViewModel);
                        }
                    }
                }
		    } 

         catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    public static class VideoViewModel {
        private String videoId;
        private String videoTitle;
        private String videoDescription;
        private String videoThumbnailUrl;
       
        public String getVideoId() {
            return videoId;
        }

        public String getVideoTitle() {
            return videoTitle;
        }

        public String getVideoDescription() {
            return videoDescription;
        }

        public void setVideoTitle(String videoTitle) {
            this.videoTitle = videoTitle;
        }

        public String getVideoThumbnailUrl() {
            return videoThumbnailUrl;
        }

        public void setVideoDescription(String videoDescription) {
            this.videoDescription = videoDescription;
        }
        
        public void setVideoId(String videoId) {
            this.videoId = videoId;
        }

        public void setVideoThumbnailUrl(String videoThumbnailUrl) {
            this.videoThumbnailUrl = videoThumbnailUrl;
        }
        
    }

    private VideoViewModel buildVideoViewModel( Resource videoResource ) throws JSONException {
        ValueMap properties = videoResource.adaptTo(ValueMap.class);
        if (null == properties) {
            log.debug("Video properties are null");
            return null;
        }
        var videoId = properties.get( "videoId", "" );
            
        VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            log.debug("Video config null or Path not found");
            return null;
        }
		Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
		if (damRes == null) {
			log.debug("Video resource is null for videoid {}", videoId);
			return null;
		}

        final var map = AssetUtils.getMetadata(damRes);
        String videoStatus  = map.get("dam:status", String.class);
        log.info("map is     "+map+" videoStatus is   "+videoStatus);
        if("unpublished".equalsIgnoreCase(videoStatus) || null == map){
            log.error("Metadata not found for video id: {} ", videoId);
         return null;
        }

        Resource thumbnailResource = damRes.getChild("jcr:content/renditions/brc_thumbnail.png");
            if (thumbnailResource == null) {
                log.error("Thumbnail resource not found for video id: {}", videoId);
                return null;
            }
    
        String videoTitle = map.get("dc:title", String.class);
        String videoDescription = map.get("brc_description", String.class); 

        final var videoModel = new VideoViewModel();
        videoModel.setVideoTitle(videoTitle);
        videoModel.setVideoDescription(videoDescription);
        videoModel.setVideoId(videoId);   
        videoModel.setVideoThumbnailUrl(thumbnailResource.getPath()); 
        return videoModel;
    }

}