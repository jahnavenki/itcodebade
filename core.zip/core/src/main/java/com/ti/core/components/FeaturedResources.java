package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.FeaturedToolModel;
import com.ti.core.models.HomePageFeaturedProduct;
import com.ti.core.models.TechnicalResourcesModel;
import com.ti.core.models.AdditionalResourceModel;
import com.ti.core.models.productfamilyapplications.EndEquipment;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FeaturedResources extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(FeaturedResources.class);

    private static final String TECHNICAL_DOCS = "technicalDocs";
    private static final String RESOURCE_TYPE = "resourceType";
    private static final String DOCUMENT_CATEGORY = "documentCategory";
    private static final String DOC_CATEGORY = "docCategory";
	private static final String TITLE = "title";
    private String categoryTitle;

    public String getCategoryTitle() {
		return categoryTitle;
	}
	private final List<EndEquipment> endEquipmentList = new ArrayList<>();
    private final List<HomePageFeaturedProduct> productsList = new ArrayList<>();
    private final List<FeaturedToolModel> softwareDevelopmentList = new ArrayList<>();
    private final List<FeaturedToolModel> referenceDesignstList = new ArrayList<>();
    private final List<FeaturedToolModel> hardwareDevelopmentList = new ArrayList<>();
    private final List<FeaturedToolModel> desginToolSimulationList = new ArrayList<>();
    private final List<TechnicalResourcesModel> technicalResourceList = new ArrayList<>();
    private final List<AdditionalResourceModel> additionalResourceList = new ArrayList<>();

    public List<EndEquipment> getEndEquipmentList() {
        return endEquipmentList;
    }

    public List<HomePageFeaturedProduct> getProductsList() {
        return productsList;
    }

    public List<FeaturedToolModel> getSoftwareDevelopmentList() {
        return softwareDevelopmentList;
    }

    public List<FeaturedToolModel> getReferenceDesignstList() {
        return referenceDesignstList;
    }

    public List<FeaturedToolModel> getHardwareDevelopmentList() {
        return hardwareDevelopmentList;
    }

    public List<FeaturedToolModel> getDesginToolSimulationList() {
        return desginToolSimulationList;
    }

    public List<TechnicalResourcesModel> getTechnicalResourceList() {
        return technicalResourceList;
    }
    
    public List<AdditionalResourceModel> getAdditionalResourceList() {
        return additionalResourceList;
    }

    @Override
    public void activate() {
        try {
        	categoryTitle =  getProperties().get("categoryTitle", "");
            WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("endEquipmentSubsystemList")) {
                    addEndEquipmentSubSystemToList(nodeChild);
                }
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("productsList")) {
                    addProductToList(nodeChild, wcmService);
                }
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("technicalResourceList")) {
                    addTechnicalResourceToList(nodeChild, wcmService);
                } 
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("additionalResourceList")) {
                    addAdditionalResourceToList(nodeChild);
                }else {
                    addGenericFeaturedToolToList(nodeChild, wcmService);
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    private void addEndEquipmentSubSystemToList(Resource nodeChild) {
        for (Resource resourceChild : nodeChild.getChildren()) {
            ValueMap properties = resourceChild.adaptTo(ValueMap.class);
            EndEquipment endEquipmentModelObject = new EndEquipment();
            if(properties!=null) {
	            endEquipmentModelObject.setEeqName(properties.get("endEquipment", String.class));
	            endEquipmentModelObject.setSubsystem(properties.get("subSystem", String.class));
	            endEquipmentModelObject.setEeqUrl(properties.get("endequipmentUrl", String.class));
	            endEquipmentList.add(endEquipmentModelObject);
            }
        }
    }

    private void addProductToList(Resource nodeChild, WCMComponents wcmService) throws JSONException {
        try {
            LanguageUtils langUtils = new LanguageUtils(getRequest());
            String language = langUtils.getPageLanguageForProductFolder();
            for (Resource resourceChild : nodeChild.getChildren()) {
                ValueMap properties = resourceChild.adaptTo(ValueMap.class);
                if (null != properties) {
                    JSONObject data = wcmService.getFeaturedProduct(properties.get("gpn", String.class), language);
                    if (data != null) {
                        HomePageFeaturedProduct product = new HomePageFeaturedProduct();
                        product.setGenericPartNumber(data.getString("genericPartNumber"));
                        product.setDeviceDescription(data.getString("deviceDescription"));
                        productsList.add(product);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception in Featured resources addProductToList: ", e);

        }
    }

    private void addGenericFeaturedToolToList(Resource nodeChild, WCMComponents wcmService) throws JSONException {
        try {
            for (Resource resourceChild : nodeChild.getChildren()) {
                ValueMap properties = resourceChild.adaptTo(ValueMap.class);
                if (null != properties) {
                    String toolPartNumber = properties.get("tpn", String.class);
                    final var langUtils = new LanguageUtils(getRequest());
                    final var language = langUtils.getPageLanguageForProductFolder();
                    JSONObject data = wcmService.getToolDetails(toolPartNumber, language);
                    if (data != null) {
                        FeaturedToolModel genericFeaturedToolModelObject = new FeaturedToolModel();
                        genericFeaturedToolModelObject.setToolPartNumber(toolPartNumber);
                        genericFeaturedToolModelObject.setToolTitle(data.getString(TITLE));
                        if (nodeChild.getName().equalsIgnoreCase("softwareDevelopmentList")) {
                            softwareDevelopmentList.add(genericFeaturedToolModelObject);
                        } else if (nodeChild.getName().equalsIgnoreCase("referenceDesignstList")) {
                            referenceDesignstList.add(genericFeaturedToolModelObject);
                        } else if (nodeChild.getName().equalsIgnoreCase("hardwareDevelopmentList")) {
                            hardwareDevelopmentList.add(genericFeaturedToolModelObject);
                        } else {
                            desginToolSimulationList.add(genericFeaturedToolModelObject);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception in Featured resources addGenericFeaturedToolToList: ", e);
        }
    }

    /**
     * Fetch technical resource fields and add to list.
     *
     * @param properties - parameter
     */
    private void addTechnicalResourceToList(Resource nodeChild, WCMComponents wcmService) {
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        for (Resource resourceChild : nodeChild.getChildren()) {
            ValueMap properties = resourceChild.adaptTo(ValueMap.class);
            if (null != properties) {
                String resourceType = properties.get(RESOURCE_TYPE, String.class);
                if (TECHNICAL_DOCS.equals(resourceType)) {
                    fetchLiteratureResponse(properties, wcmService);
                } else {
                    TechnicalResourcesModel technicalResourcesModelObject = new TechnicalResourcesModel();
                    technicalResourcesModelObject.setDialogResourceType(resourceType);
                    technicalResourcesModelObject.setResourceType(langUtils.getI18nStr("resourceType:" + resourceType));
                    technicalResourcesModelObject.setTitle(properties.get(TITLE, String.class));
                    technicalResourcesModelObject.setResourceUrl(properties.get("resourceUrl", String.class));
                    technicalResourceList.add(technicalResourcesModelObject);
                }
            }
        }
    }

    /**
     * Fetch Literature service response and set technical resource fields.
     *
     * @param properties - parameter
     */
    private void fetchLiteratureResponse(ValueMap properties, WCMComponents wcmService) {
        JSONObject jsonLiterature;
        String pagelanguage = "en-us";
        ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                .getService(ProductNavigationTabsOrdering.class);
        if (tabsService != null) {
            pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
        }
        LanguageUtils langUtils = new LanguageUtils(getRequest());

        String litNumber = properties.get("litnumber", String.class);
        try {
            String litResponse = wcmService.getFeaturedliterature(litNumber, pagelanguage);
            TechnicalResourcesModel technicalResourcesModelObject = new TechnicalResourcesModel();
            if (StringUtils.isNotEmpty(litResponse)) {
                jsonLiterature = new JSONObject(litResponse);
                String litNumberFromDB = jsonLiterature.getString("literatureNumber").substring(0,7);
                boolean hasHtml = jsonLiterature.getBoolean("htmlPackageAvailability");
                // get the literature number from json response, as it is different for regions
                String resourceUrl = langUtils.getI18nStr("https://www.ti.com/lit/") + litNumberFromDB;
                String resourceType = properties.get(RESOURCE_TYPE, String.class);
                technicalResourcesModelObject.setLitNumber(litNumberFromDB);
                technicalResourcesModelObject.setDialogResourceType(resourceType);
                technicalResourcesModelObject.setResourceType(getTechnicalDocCategory(resourceType, jsonLiterature, langUtils));
                technicalResourcesModelObject.setTitle(jsonLiterature.getString("conciseDescription"));
                technicalResourcesModelObject.setResourceUrl(resourceUrl);
                if (hasHtml) {
                    String htmlUrl = langUtils.getI18nStr("https://www.ti.com/document-viewer/lit/html/") + litNumberFromDB;
                    technicalResourcesModelObject.setHtmlUrl(htmlUrl);
                }

            } else {
                log.debug("Json response is empty or null");
            }
            technicalResourceList.add(technicalResourcesModelObject);
        } catch (Exception e) {
            log.error("Exception in Featured resources fetchLiteratureResponse: ", e);
        }

    }
    private String getTechnicalDocCategory(String resourceType, JSONObject jsonLiterature, LanguageUtils langUtils) throws JSONException {
    	if(TECHNICAL_DOCS.equals(resourceType)) {
        	resourceType = jsonLiterature.getJSONObject(DOCUMENT_CATEGORY) != null ? jsonLiterature.getJSONObject(DOCUMENT_CATEGORY).getString(DOC_CATEGORY) : resourceType;
        	return langUtils.getI18nStr(resourceType);
        }                    
        else {
        	return langUtils.getI18nStr( "resourceType:" + resourceType );
        }
    }
    private void addAdditionalResourceToList(Resource nodeChild) {
        for (Resource resourceChild : nodeChild.getChildren()) {
            ValueMap properties = resourceChild.adaptTo(ValueMap.class);
            AdditionalResourceModel additionalResourceModelObject = new AdditionalResourceModel();
            if(properties!=null) {
	            additionalResourceModelObject.setResourceType(properties.get(RESOURCE_TYPE, String.class));
	            additionalResourceModelObject.setTitle(properties.get(TITLE, String.class));
                additionalResourceModelObject.setUrl(properties.get("url", String.class));
	            additionalResourceList.add(additionalResourceModelObject);
            }
        }
    }
}
