package com.ti.core.models.productfamilyapplications;

import java.util.List;

public class Sector {
  
  private String sectorName;
  private List<EndEquipment> endEquimentsList;

  public String getSectorName() {
    return sectorName;
  }

  public void setSectorName(String sectorName) {
    this.sectorName = sectorName;
  }

  public List<EndEquipment> getEndEquimentsList() {
    return endEquimentsList;
  }

  public void setEndEquimentsList(List<EndEquipment> endEquimentsList) {
    this.endEquimentsList = endEquimentsList;
  }
  
}
