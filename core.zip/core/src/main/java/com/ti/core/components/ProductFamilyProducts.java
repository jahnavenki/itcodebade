package com.ti.core.components;

import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

/**
 * BE model for pages under Product family -> Products tab (Selection tool)
 */
public class ProductFamilyProducts extends WCMUsePojo {

	private static final String FAMILY_ID = "familyId";
	private static final String FAMILY_NAME = "familyName";
    protected static final Logger log = LoggerFactory.getLogger(ProductFamilyProducts.class);
	private String browserTitle;
	private String metaDescription;
	private String keywords;
	private String familyName;

    @Override
    public void activate() throws Exception {       
        try {  
            if (null != getPageProperties().get(FAMILY_ID)) {   
                String language = "en-us";
                ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                    ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    language = tabsService.getPageLanguage(getCurrentPage());
                }
				WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
				if (wcmComponents != null) {
					JSONObject prodData = wcmComponents.getAllProductService(this.getRequest(), 
						Integer.parseInt(getPageProperties().get(FAMILY_ID).toString()), language);
					if (prodData != null) {
						familyName = prodData.getString(FAMILY_NAME);   
						setMetadata(familyName);
					}
				}          
            }
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }    
    }

    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = <Family name> + "product selection + “|” + “TI.com”
                                For CN, it should be <Family name> + “|” + “TI.com.cn”
            2. Meta description = "Select from TI's <family name> family of devices. 
                                <family name> parameters, data sheets, and design resources."
            3. Keywords: <Family name> + "product selection"
    */
    private void setMetadata(String familyName) {   
        LanguageUtils langUtils = new LanguageUtils(getRequest());
		browserTitle = langUtils.getI18nStr("{} product selection | TI.com").replace("{}", familyName);
		metaDescription = langUtils.getI18nStr(
			"Select from TI's {} family of devices. {} parameters, data sheets, and design resources.")
			.replace("{}", familyName);
		keywords = langUtils.getI18nStr("{} product selection").replace("{}", familyName);
    }

	/**
	 * This method calls the service for Family and returns the associated family
	 * name for provided family id.
	 * 
	 * @param familyId family id set from page properties.
	 * @return family name.
	 */
	public String getFamilyName() {
		return familyName;
	}
    
	public String getBrowserTitle() {
		return browserTitle;
	}

	public void setBrowserTitle(String browserTitle) {
		this.browserTitle = browserTitle;
	}

    public String getMetaDescription() {
		return metaDescription;
	}

	public void setMetaDescription(String metaDescription) {
		this.metaDescription = metaDescription;
	}
    public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
    
}
