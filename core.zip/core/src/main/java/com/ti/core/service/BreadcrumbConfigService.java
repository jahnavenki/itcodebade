package com.ti.core.service;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * PortalConfigService to get the portals of texas instruments.
 *
 */

@Component(immediate = true, 
//name="BreadcrumbConfigService" , 
//descripiton = "Texas Instruments constructive breadcrumb Config Service", 
service = BreadcrumbConfigService.class)
@Designate(ocd = BreadcrumbConfiguration.class)

public class BreadcrumbConfigService {

	protected BreadcrumbConfiguration breadcrumbConfiguration;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String breadcrumbtype;
	private String breadcrumburl = null;
	private String homepageurl = null;
	private String designbreadcrumburl = null;

	public String getBreadcrumbtype() {
		return breadcrumbtype;
	}

	public String getBreadcrumburl() {
		log.debug("Breadcrumburl: {}", breadcrumburl);
		return breadcrumburl;
	}

	public String gethomepageurl() {
		log.debug("homepageurl: {}", homepageurl);
		return homepageurl;
	}

	public String getDesignbreadcrumburl() {
		log.debug("designbreadcrumburl: {}", designbreadcrumburl);
		return designbreadcrumburl;
	}

	/**
	 * Activate method.
	 * 
	 * @param config
	 *            config
	 */
	@Activate
	public void activate(BreadcrumbConfiguration config) {
		setbreadcrumb(config);
	}

	private synchronized void setbreadcrumb(BreadcrumbConfiguration config) {
		log.debug("type of breadcrumbs: ", config);
		this.breadcrumbtype = config.breadcrumbtype();
		this.breadcrumburl = config.breadcrumburl();
		this.homepageurl = config.homepageurl();
		this.designbreadcrumburl = config.designbreadcrumburl();
	}

}
