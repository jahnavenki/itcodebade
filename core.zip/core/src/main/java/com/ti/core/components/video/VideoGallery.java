package com.ti.core.components.video;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;
import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.config.VideoConfigService;

public class VideoGallery extends WCMUsePojo {
    
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    private String bcAccountId;
    
    public String getBcAccountId() {
        return bcAccountId;
    }

    @Override
    public void activate() {
        try {	
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
            bcAccountId=videoService.getAccountId();
            if (StringUtils.isEmpty(bcAccountId)) {
				log.warn("config not set");
				return;
			}
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    } 
}