package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.SectionTitleAccordion;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Class Accordion WCMUsePojo.
 *
 * @author abhishek.bhusari
 */
public class Accordion extends WCMUsePojo {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    private static final String PAR = "sectionTitlePar";
    private static final String SECTION_TITLES = "sectionTitles";
    private static final String SECTION_TITLE = "sectionTitle";
    private boolean listExist;
    private final List<SectionTitleAccordion> listSectionTitleAccordion = new ArrayList<>();

    public List<SectionTitleAccordion> getListSectionTitleAccordion() {
        return listSectionTitleAccordion;
    }

    private boolean shouldShowSection(final String nodeName) {
        Resource resource = this.getResource().getChild(nodeName);
        return !this.getWcmMode().isDisabled() || resource != null;
    }

    @Override
    public void activate() {
        try {
            for (Resource nodeChild : getResource().getChildren()) {
                int parsysCount = 1;
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(SECTION_TITLES)) {
                    for (Resource sectionTitle : nodeChild.getChildren()) {
                        SectionTitleAccordion sectionTitleAccordionPojo = new SectionTitleAccordion();

                        ValueMap properties = sectionTitle.adaptTo(ValueMap.class);
                        if (null != properties) {
                            sectionTitleAccordionPojo.setSectionTitle(properties.get(SECTION_TITLE, String.class));
                            boolean displaySection = shouldShowSection(PAR + parsysCount);
                            sectionTitleAccordionPojo.setDisplay(displaySection);
                            sectionTitleAccordionPojo.setParsysName(PAR + parsysCount);
                            listSectionTitleAccordion.add(sectionTitleAccordionPojo);
                            parsysCount++;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception : " + e);
        }

    }

    public boolean isListExist() {
        if(!listSectionTitleAccordion.isEmpty())
        {
            listExist = true;
        }
        return listExist;
    }
}
