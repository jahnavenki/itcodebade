package com.ti.core.service.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.config.SeoUrlTaggingConfiguration;

@Component(service = SeoUrlTagging.class, immediate = true)
@Designate(ocd = SeoUrlTaggingConfiguration.class, factory=true)
public class SeoUrlTaggingImpl implements SeoUrlTagging {

	private String contentPath = null;

	private String domainName = null;

	private String selectorLabel = null;

	private Boolean checkExistingPage = false;

	
	private int order = 0;
	
	public String getContentPath() {
		return contentPath;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setContentPath(String contentPath) {
		this.contentPath = contentPath;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @param selectorLabel the selectorLabel to set
	 */
	public void setSelectorLabel(String selectorLabel) {
		this.selectorLabel = selectorLabel;
	}

	/**
	 * @param checkExistingPage the checkExistingPage to set
	 */
	public void setCheckExistingPage(Boolean checkExistingPage) {
		this.checkExistingPage = checkExistingPage;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	@Activate
	@Modified
	public void activate(SeoUrlTaggingConfiguration config) {

		this.domainName = config.domainName();
		this.contentPath = config.contentPath();
		this.selectorLabel = config.selectorLabel();
		this.checkExistingPage = config.checkExistingPage();
		this.order = config.order();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ti.core.service.PageLanguageSelector#getSelectorLabel()
	 */
	@Override
	public String getSelectorLabel() {

		return selectorLabel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ti.core.service.PageLanguageSelector#getCheckExistingPage()
	 */
	@Override
	public Boolean getCheckExistingPage() {

		return checkExistingPage;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ti.core.service.SeoUrlTagging#getOrder()
	 */
	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return order;
	}
}
