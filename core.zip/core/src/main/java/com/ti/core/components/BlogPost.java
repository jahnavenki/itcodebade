package com.ti.core.components;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.LanguageUtils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class BlogPost extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private String date;
	private String title;
	private String description;
	private String imageUrl;
	private String ctaUrl;

	public String getDate() {
		return date;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public String getCtaUrl() {
		return ctaUrl;
	}

	private Element getFirstElement(Element parent, String tagName) {
		final var elements = parent.getElementsByTagName(tagName);
		final var count = elements.getLength();
		if(count < 1) return null;
		return (Element)elements.item(0);
	}

	private String getElementText(Element parent, String tagName) {
		final var element = getFirstElement(parent, tagName);
		if(null == element) return "";
		return element.getTextContent();
	}

	@Override
	public void activate() {
		try {
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			final var language = null != tabsService ? tabsService.getPageLanguage(getCurrentPage()) : null;
			final var langCode = null != language ? StringUtils.substringBefore(language, "-") : null;
			final var feedFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z");
			final var myFormat = new SimpleDateFormat(LanguageUtils.getRegionDateFormat(language), new Locale(langCode));

			final var langUtils = new LanguageUtils(getRequest());
			final var properties = getProperties();
			ctaUrl = properties.get("ctaUrl", "");
			if(StringUtils.isEmpty(ctaUrl)) return;
			final var rssUrlEn = "https://news.ti.com/feeds/blog.xml";
			final var rssUrlLocale = langUtils.getI18nStr(rssUrlEn);
			final var rssUrls = new ArrayList<String>();
			rssUrls.add(rssUrlLocale);
			if(!rssUrlEn.equals(rssUrlLocale)) {
				rssUrls.add(rssUrlEn);
			}
			Element rssItem = null;
			for(final var rssUrl : rssUrls) {
				final var rssXml = readRss(rssUrl);
				rssItem = getRssItem(rssXml, ctaUrl);
				if(null != rssItem) break;
			}
			if(null == rssItem) return;
			title = getElementText(rssItem, "title");
			final var pubDate = getElementText(rssItem, "pubDate");
			date = myFormat.format(feedFormat.parse(pubDate));
			description = getElementText(rssItem, "description");
			final var enclosure = getFirstElement(rssItem, "enclosure");
			if(null != enclosure) {
				imageUrl = enclosure.getAttribute("url");
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}

	private static final String FEATURE_LOAD_DTD = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
	private static final String FEATURE_DISABLE_DOCTYPE_DECL = "http://apache.org/xml/features/disallow-doctype-decl";

	private Element getRssItem(String rssXml, String ctaUrl) throws ParserConfigurationException, SAXException, IOException {
		final var factory = DocumentBuilderFactory.newInstance();
		factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
		factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
		factory.setFeature(FEATURE_DISABLE_DOCTYPE_DECL, true);
		factory.setFeature(FEATURE_LOAD_DTD, false);
		final var builder = factory.newDocumentBuilder();
		final var doc = builder.parse(new InputSource(new StringReader(rssXml)));
		var rssItems = doc.getElementsByTagName("item");
		for(var i = 0; i < rssItems.getLength(); ++i ) {
			final var rssItem = (Element)rssItems.item(i);
			final String link = getElementText(rssItem, "link");
			if(ctaUrl.equals(link)) return rssItem;
		}
		return null;
	}

	private static final String PROXY_HOST = "webproxy.ext.ti.com";
	private String readRss(String rssUrl) throws IOException {
		final var proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
		final var connection = (HttpURLConnection) new URL( rssUrl ).openConnection(proxy);
		connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
		try( final var in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)) ) {
			String line;
			final var res = new StringBuilder();
			while(null != (line = in.readLine())) {
				res.append(line);
				res.append("\n");
			}
			return res.toString();
		}
	}
}
