package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;
import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;

/**
 * ProductServlet returns details for GPN
 * 
 */
@SuppressWarnings("serial")
@Component(name = "ProductDetailsServlet", immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_PATHS + "=/bin/ti/productdetails", 
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_EXTENSIONS+"=json"})
public class ProductServlet extends SlingSafeMethodsServlet {
	private static final Logger log = LoggerFactory.getLogger(ProductServlet.class);

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		try {
			response.setContentType("text/x-json;charset=UTF-8");
			
			String gpn = request.getParameter("gpn");
			if (!StringUtils.isEmpty(gpn)) {
				String locale = request.getParameter("locale");
				if (StringUtils.isEmpty(locale))
					locale = "en-US";

				JSONObject obj = wcmService.getFeaturedProduct(gpn, locale);
				if (obj != null) 				
					response.getWriter().write(StringEscapeUtils.unescapeHtml4(obj.toString()));
			}
		}
		catch (IOException e) {
			log.error("Exception in product details response", e);
		}
	}
}