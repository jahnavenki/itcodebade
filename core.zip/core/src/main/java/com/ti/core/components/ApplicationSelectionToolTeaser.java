package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.xfa.ut.StringUtils;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationSelectionToolTeaser extends WCMUsePojo {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String title;
	private String imgAlt;
	private String imgSrc;
	private String description;
	private String cta;
	private String lid;
	private String ctaUrl;
	private String name;
	private String nameEn;

	public String getTitle() {
		return title;
	}

	public String getImgAlt() {
		return imgAlt;
	}

	public String getImgSrc() {
		return imgSrc;
	}

	public String getDescription() {
		return description;
	}

	public String getCta() {
		return cta;
	}

	public String getLid() {
		return lid;
	}

	public String getCtaUrl() {
		return ctaUrl;
	}

	@Override
	public void activate() {
		try {
			final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if(null == tabsService) return;
			final SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
			if(null == factoryConfigs) return;
			final Page currentPage = getCurrentPage();
			final String pagePath = currentPage.getPath();
			final boolean isTechnology = pagePath.contains("/technologies/");
			final ResourceResolver resourceResolver = getResourceResolver();
			final String language = tabsService.getPageLanguage(currentPage);
			final WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if (null == wcmComponents) return;
			final SlingHttpServletRequest req = getRequest();
			final LanguageUtils langUtils = new LanguageUtils(req);
			final ValueMap pageProperties = getPageProperties();
			final String applicationId = (String) pageProperties.get("applicationId");
			if ((null == applicationId || StringUtils.isEmpty(applicationId)) && !isTechnology) return;

			// set cta url
			ctaUrl = "products.html";

			// set name and nameEN
			if (isTechnology) {
				name = (String) pageProperties.get("jcr:title");
				nameEn = "Functional safety";
				ctaUrl = "functional-safety/" + ctaUrl;
			} else {
				final var appData = wcmComponents.getAllApplicationService(getRequest(), Integer.parseInt(applicationId), language);
				name = appData.getString("appAreaName");
				// set nameEn (for lid)
				final var appHierarchyList = appData.getJSONArray("AppHierarchyList");
				for (var i = 0; i < appHierarchyList.length(); ++i) {
					final var app = appHierarchyList.getJSONObject( i );
					final String childId = app.getString("childId");
					if (applicationId.equals(childId)) {
						nameEn = app.getString("enSectionName");
						break;
					}
				}
			}
			
			// set title
			title = langUtils.getI18nStr("View all {} products", name);

			// set cta text
			cta = langUtils.getI18nStr("View all products");

			// set description
			description = langUtils.getI18nStr("Filter, compare and select the right device for your {} design with our selection tool.", name);
			
			// set image
			imgSrc = "/content/dam/ticom/images/icons/illustrative-icons/products/processor-chip-icon.png";

			// set img alt text
			final Resource img = resourceResolver.resolve(imgSrc);
			final Asset asset = img.adaptTo(Asset.class);
			if(null != asset) {
				imgAlt = asset.getMetadataValue("dc:title");
			}

			// set lid
			lid = "application-" + nameEn;
		} catch (Exception e) {
			log.error("Error setting metadata: ", e);
		}
	}
}
