package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.engine.SlingRequestProcessor;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.contentsync.handler.util.RequestResponseFactory;
import com.day.cq.wcm.api.WCMMode;
import com.ti.core.util.ReportingUtils;

@SuppressWarnings("serial")
@Component(service = Servlet.class, name = "HomePageBannerJson", immediate = true, property = {
		SLING_SERVLET_PATHS + "=/bin/ti/homepagebanner", SLING_SERVLET_METHODS + "=GET" })
public class HomePageBannerJson extends SlingSafeMethodsServlet {

	private static final String TEMPLATE_PATH = "/apps/ti/templates/homePageBanner";
	private static final String COMP_PATH = "ti/components/homePageBanner";
	private static final String REQ_PARAM_LANG = "language";
	private transient Session session;
	private transient ResourceResolver resourceResolver;
	private static final String EXCEPTION_MESSAGE = "Exception: ";

	/** The log. */
	protected static final Logger log = LoggerFactory.getLogger(HomePageBannerJson.class);
	/** Service to create HTTP Servlet requests and responses */
	@Reference
	private transient RequestResponseFactory requestResponseFactory;

	/** Service to process requests through Sling */
	@Reference
	private transient SlingRequestProcessor requestProcessor;

	/*
	 * (non-Javadoc)
	 *
	 * @see org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		resourceResolver = request.getResourceResolver();
		session = resourceResolver.adaptTo(Session.class);

		String CONTENT_PATH = "/content/texas-instruments";
		String language = request.getParameter(REQ_PARAM_LANG);

		if (language != null)
			CONTENT_PATH = CONTENT_PATH + "/" + language;

		String sqlStatement = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s,'" + CONTENT_PATH
				+ "') AND [cq:template] ='" + TEMPLATE_PATH + "'";
		log.debug("first query: {}", sqlStatement);
		JSONArray BannercompJSONArray = new JSONArray();
		try {
			NodeIterator nodeIter = ReportingUtils.executeQuery(sqlStatement, session);
			while (null != nodeIter && nodeIter.hasNext()) {

				// For each node-- get the path of the node
				Node node = nodeIter.nextNode();
				String nodePath = node.getPath();// jcr path
				String parentNodename = node.getParent().getName();
				Resource resource = resourceResolver.getResource(nodePath);
				ValueMap jcrproperties = null != resource ? resource.getValueMap() : null;

				String jcrTitle = null;
				String jcrCreated = null;
				String jcrmodified = null;
				String lastReplicated = null;

				if (null != jcrproperties) {

					jcrTitle = jcrproperties.get("jcr:title", String.class);
					jcrCreated = jcrproperties.get("jcr:created", String.class);
					jcrmodified = jcrproperties.get("cq:lastModified", String.class);
					lastReplicated = jcrproperties.get("cq:lastReplicated", String.class);

				}

				Date today = Calendar.getInstance().getTime();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
				String date = sdf.format(today);

				String sqlStatement2 = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s,'" + nodePath
						+ "') AND [sling:resourceType] ='" + COMP_PATH + "'" + " AND endTime < '" + date
						+ "' AND jackExpirationTime > '" + date + "'";
				log.debug("second query: {}", sqlStatement2);

				NodeIterator componentNodeIter = ReportingUtils.executeQuery(sqlStatement2, session);
				while (null != componentNodeIter && componentNodeIter.hasNext()) {
					// For each node-- get the path of the node
					JSONObject BannercompJSON = new JSONObject();

					Node componentNode = componentNodeIter.nextNode();
					log.debug("Have listing: {}", componentNode.getPath());

					HttpServletRequest req = requestResponseFactory.createRequest("GET",
							componentNode.getPath() + ".jackws.html");
					WCMMode.DISABLED.toRequest(req);
					/* Setup response */
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					HttpServletResponse resp = requestResponseFactory.createResponse(out);

					/* Process request through Sling */
					requestProcessor.processRequest(req, resp, request.getResourceResolver());
					String html = out.toString().trim();

					BannercompJSON.put("jcrTitle", jcrTitle);
					BannercompJSON.put("jcrCreated", jcrCreated);
					BannercompJSON.put("jcrmodified", jcrmodified);
					BannercompJSON.put("lastReplicated", lastReplicated);
					BannercompJSON.put("jcrName", parentNodename);

					// Getting the resource in order to retrieve the Value Map
					Resource resource1 = resourceResolver.getResource(componentNode.getPath());
					ValueMap compproperties = null != resource1 ? resource1.getValueMap() : null;
					if (null != compproperties) {
						BannercompJSON = createBannerComponentJSON(BannercompJSON, compproperties);
						BannercompJSON.put("renderedHTML", html);

					}
					BannercompJSONArray.put(BannercompJSON);
				}

			}

			response.setContentType("text/x-json;charset=UTF-8");
			response.getWriter().write(BannercompJSONArray.toString());
		} catch (RepositoryException | JSONException | NullPointerException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}

	}

	public static JSONObject createBannerComponentJSON(JSONObject BannercompJSON, ValueMap compproperties) {

		String startTime = null;
		String fileReference2 = null;
		String altGraphical = null;
		String endTime = null;
		String fileReference = null;
		String descGraphical = null;
		String title = null;
		String primaryCtaLabel = null;
		String jackExpirationTime = null;
		String tagline = null;
		String primaryCtaUrl = null;
		String campaignAlias = null;

		if (null != compproperties) {

			startTime = compproperties.get("startTime", String.class);
			fileReference2 = compproperties.get("fileReference2", String.class);
			altGraphical = compproperties.get("altGraphical", String.class);
			endTime = compproperties.get("endTime", String.class);
			fileReference = compproperties.get("fileReference", String.class);
			descGraphical = compproperties.get("descGraphical", String.class);
			title = compproperties.get("title", String.class);
			primaryCtaLabel = compproperties.get("primaryCtaLabel", String.class);
			jackExpirationTime = compproperties.get("jackExpirationTime", String.class);
			tagline = compproperties.get("tagLine", String.class);
			primaryCtaUrl = compproperties.get("primaryCtaUrl", String.class);
			campaignAlias = compproperties.get("campaignAlias", String.class);

		}

		try {

			BannercompJSON.put("startTime", startTime);
			BannercompJSON.put("fileReference2", fileReference2);
			BannercompJSON.put("altGraphical", altGraphical);
			BannercompJSON.put("endTime", endTime);
			BannercompJSON.put("fileReference", fileReference);
			BannercompJSON.put("descGraphical", descGraphical);
			BannercompJSON.put("title", title);
			BannercompJSON.put("primaryCtaLabel", primaryCtaLabel);
			BannercompJSON.put("jackExpirationTime", jackExpirationTime);
			BannercompJSON.put("tagline", tagline);
			BannercompJSON.put("primaryCtaUrl", primaryCtaUrl);
			BannercompJSON.put("campaignAlias", campaignAlias);

		} catch (JSONException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}

		return BannercompJSON;

	}

}