package com.ti.core.components.video;

import java.util.*;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;
/**
 * Class SeoVideoUrlComponent WCMUsePojo.
 *
 */
public class SeoVideoUrlComponent  extends WCMUsePojo {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());   

    // url Map containing Alternate URLs mapped with respective language code
    private Map<String, String> urlMap = new HashMap<>();
    private String canonicalVideoUrl;
    private static final String ENGLISH_CODE = "en-us";
    private static final String DEFAULT_ALTERNATE_URL_CODE = "en";
    private static final String CHINA_LANG_CODE = "zh-cn";
    private static final String CHINA_TAIWAN_LANG_CODE = "zh-tw";
    private static final String CHINA_LANG_CODE_EXPECTED = "zh-Hans";
    private static final String CHINA_TAIWAN_LANG_CODE_EXPECTED= "zh-Hant";
    private static final String DEFAULT_LANG_CODE = "x-default";
    private static final String HTTP = "http://";
    private static final String HTTPS = "https://";
    private static final String SINGLE = "single";
    private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

    public Map<String, String> getUrlMap() {
        return urlMap;
    }

    public void setUrlMap(Map<String, String> urlMap) {
        this.urlMap = urlMap;
    }
    /**
     * Returns the Canonical url.
     *
     * @return configUrl
     */
    public String getCanonicalVideoUrl() {
        return canonicalVideoUrl;
    }

    /**
     * Setting the Canonical Url.
     *
     * @param canonicalUrl current url.
     */
    public void setCanonicalVideoUrl(String canonicalVideoUrl) {
        this.canonicalVideoUrl = canonicalVideoUrl;
    }
    
    @Override
    public void activate() {
		final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
		final String videoIdPage = matcher.find() ? matcher.group(1) : null;
        VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            log.debug("Video config null or Path not found");
            return;
        }
		Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoIdPage);
		if (damRes == null) {
			log.debug("Video resource is null for videoid {}", videoIdPage);
			return;
		}
        final var map = AssetUtils.getMetadata(damRes);
        if (null == map)  {   
            log.error("Metadata not found for video id: {} ", videoIdPage);
            return;
        }
        SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
        String pagePath = getCurrentPage().getPath(); 
        if (pagePath.endsWith(SINGLE)){ 
            pagePath=pagePath.replace(SINGLE, videoIdPage);
        }
        String videoSpokenLanguage= map.get("videoSpokenLanguage",String.class);
        if (null != factoryConfigs) {
            List<SeoUrlTagging> listConfig = factoryConfigs.getConfigs();
            try {
                // Add domain and .html suffix but suffix not requried for single video page 
                canonicalVideoUrl = PathBrowserHelper.addHtmlIfContentPath(this.getResourceResolver(), pagePath);
                if(canonicalVideoUrl.endsWith(".html")){
                    canonicalVideoUrl = canonicalVideoUrl.substring(0, canonicalVideoUrl.lastIndexOf('.'));
                }
                // Return url with https.
                canonicalVideoUrl = getHttpsUrl(canonicalVideoUrl);
                // Construct Alternate Urls                
                for (SeoUrlTagging seoUrlTagging : listConfig) {
                    /* 
                     * Alt URLs are to be only added for valid locales and "en" spoken lang videos
                     * For each config(locale) a path is constructed to verify the presence of "single" video page resource
                     * The final URL is similar to this path but the suffix has to be replaced with video ID(.html not needed) instead of "single"
                     */
                    if (!StringUtils.isEmpty(seoUrlTagging.getContentPath())
                            && !StringUtils.isEmpty(seoUrlTagging.getDomainName()) && videoSpokenLanguage.equals(DEFAULT_ALTERNATE_URL_CODE)) {
                        String targetPath = seoUrlTagging.getContentPath();
                        String targetPathSingle = targetPath + "/video/" + SINGLE;
                        ResourceResolver resolver = getRequest().getResourceResolver();
                        boolean isResourceExist = checkIsResourceExist(targetPathSingle, resolver);
                        // Check if in the target lang folder if we have a single video page or not
                        if (isResourceExist && null != getSpecificPage(resolver, targetPath)) {
                            Page languageVideoPageObject = getSpecificPage(resolver, targetPath);
                            ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                            
                                    .getService(ProductNavigationTabsOrdering.class);
                            if (null != tabsService) {
                                /*
                                 * Language code is used to map the alt URLs to respective language in the URL map
                                 * with some exceptions for lang code, string manipulation is needed to get language code
                                 */
                                String languageCode = tabsService.getPageLanguage(languageVideoPageObject);
                                if (! CHINA_LANG_CODE.equals(languageCode) && ! CHINA_TAIWAN_LANG_CODE.equals(languageCode) ) {
                                    languageCode = StringUtils.substringBefore(languageCode, "-");
                                }
                                String videoId = videoIdPage;
                                if (!"".equals(videoId)) {
                                    // construct the alt URL for this targert lang path, we need to construct it as content path has "single" as suffix but URL should have the video ID instead
                                    String alternateUrl = targetPath + "/video/" + videoId;
                                    String alternateVideourl = PathBrowserHelper.addHtmlIfContentPath(this.getResourceResolver(), alternateUrl);
                                    if(alternateVideourl.endsWith(".html")){
                                        alternateVideourl = alternateVideourl.substring(0, alternateVideourl.lastIndexOf('.'));
                                    }
                                    alternateVideourl = getHttpsUrl(alternateVideourl);
                                    addAlternateUrlToMap(languageCode, alternateVideourl);
                                }
                            }
                        }
                    }
                    addDefaultUrlToMap();
               }
            } catch (Exception e) {
                log.error("Error generating SEO Urls due to ", e);
            }
        }
    }

    /**
     * Add alternate urls to Map to be used on html for iteration.
     *
     * @param languageCode valid language code
     * @param alternateUrl alternate url containing host and content path
     */
    private void addAlternateUrlToMap(String languageCode, String alternateUrl) {
        String mapLang;
        mapLang = languageCode;
        if (ENGLISH_CODE.equals(languageCode)) {
            mapLang = DEFAULT_ALTERNATE_URL_CODE;
        } else if (CHINA_LANG_CODE.equals(languageCode)) {
            mapLang = CHINA_LANG_CODE_EXPECTED;
        }  else if (CHINA_TAIWAN_LANG_CODE.equals(languageCode)) {
            mapLang = CHINA_TAIWAN_LANG_CODE_EXPECTED;
        }
        else {
            mapLang = StringUtils.substringBefore(mapLang, "-");
        }
        urlMap.put(mapLang, alternateUrl);
    }
     /**
     * Add default alternate url to Map to be used on html for iteration.
     *
     */
    private void addDefaultUrlToMap() {
        String mapLang;
        mapLang = DEFAULT_LANG_CODE;
        String altUrl = null;
        altUrl = urlMap.get(DEFAULT_ALTERNATE_URL_CODE);
        if (altUrl != null) {
            urlMap.put(mapLang, altUrl);
        }
    }

    /**
     * This method accepts the url as a parameter, adds https irrespective it
     * has https or not.
     *
     * @param url url containing host and content path
     * @return url with https
     */

    private String getHttpsUrl(String url) {
        if (!url.contains(HTTP) && !url.contains(HTTPS)) {
            return HTTPS + url;
        } else {
             return URLHelper.toHttps(url);
        }
    }        

     /**
     * Method is used to check if resource exist for the given path.
     *
     * @param resourcePath Page Path for a language specified in osgi
     * configuration
     * @param resolver Resource Resolver Object
     * @return boolean value
     */
    private boolean checkIsResourceExist(String resourcePath, ResourceResolver resolver) {
        try {
            Resource resource = resolver.getResource(resourcePath);
            if (resource != null) {
                return true;
            }
        } catch (Exception e) {
            log.error("Error while testing if resource exist due to ", e);
        }
        return false;
    }

    /**
     * Return Page Object by PageURI.
     *
     * @param resourceResolver ResourceResolver
     * @param pageUri page URI
     * @return Page Object
     */
    public Page getSpecificPage(ResourceResolver resourceResolver, String pageUri) {
        Resource resource = resourceResolver.resolve(pageUri);
        return resource.adaptTo(Page.class);
    } 
    
}