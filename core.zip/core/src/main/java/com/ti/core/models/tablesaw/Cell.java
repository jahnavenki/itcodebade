/**
 * 
 */
package com.ti.core.models.tablesaw;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * @author Andy
 *
 */
@Model(adaptables=Resource.class)
public class Cell {
  @ValueMapValue @Optional @Default(values=StringUtils.EMPTY)
  private String richText;

  @ValueMapValue @Optional @Default(longValues=1)
  private long colspan;

  @ValueMapValue @Optional @Default(longValues=1)
  private long rowspan;

  @ValueMapValue @Optional @Default(booleanValues=false)
  private boolean subHeaderRow;

  @Self
  private Resource resource;
  
  private String name;

  private String columnNumber;
  
  public Resource getResource() {
    return resource;
  }
  
  public void setResource(Resource resource) {
    this.resource = resource;
  } 
  
  public String getText() {
    return richText;
  }


  public void setText(String richText) {
    this.richText = richText;
  }

  public long getColspan() {
    return colspan;
  }

  public void setColspan(long colspan) {
    this.colspan = colspan;
  }

  public long getRowspan() {
    return rowspan;
  }

  public String getColumnNumber(){
    return columnNumber;
  }

  public void setColumnNumber(String columnNumber){
    this.columnNumber = columnNumber;
  }

  public void setRowspan(long colspan) {
    this.rowspan = colspan;
  }

  public String getName()
  {
    if (resource != null)
      return resource.getName();
    else
      return this.name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public boolean getSubHeaderRow(){
    return subHeaderRow;
  }

  public void setSubHeaderRow(boolean subHeaderRow){
    this.subHeaderRow = subHeaderRow;
  }

  public String getHtmlText(){
    final String stripHTMLTagsRegex = "<.*?>";
    final String htmlSpace = "&nbsp;";
    if(StringUtils.isNotBlank(richText)){
      String strippedText = richText.replaceAll(stripHTMLTagsRegex,"").replaceAll(htmlSpace,"").trim().toLowerCase();

      if("true".equals(strippedText))
    	  return richText.replaceAll("(?i:true)", "<div class=\"ti_icon mod-size-s mod-color1\"><span class=\"ti_icon-readerText\">yes</span><svg role=\"img\"><use xlink:href=\"/etc/designs/ti/images/icons/svg/ti_icons-objects.svg#checkmark\"></use></svg></div>");
      else if("false".equals(strippedText))
    	  return richText.replaceAll("(?i:false)", "<div class=\"ti_icon mod-size-s mod-color1\"><span class=\"ti_icon-readerText\">no</span><svg role=\"img\"><use xlink:href=\"/etc/designs/ti/images/icons/svg/ti_icons-objects.svg#dash\"></use></svg></div>");
    }

    return richText;
  }

    }
