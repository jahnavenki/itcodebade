package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;
import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;

/**
 * LiteratureServlet returns details for lit number
 * 
 */
@SuppressWarnings("serial")
@Component(name = "LiteratureServlet", immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_PATHS + "=/bin/ti/literature", 
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_EXTENSIONS+"=json"})
public class LiteratureServlet extends SlingSafeMethodsServlet {
	private static final Logger log = LoggerFactory.getLogger(LiteratureServlet.class);

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		try {
			response.setContentType("text/x-json;charset=UTF-8");
			
			String litNum = request.getParameter("litnum");
			if (!StringUtils.isEmpty(litNum)) {
				String locale = request.getParameter("locale");
				if (StringUtils.isEmpty(locale))
					locale = "en-US";

				String str = wcmService.getFeaturedliterature(litNum, locale);
				if (str != null) 				
					response.getWriter().write(StringEscapeUtils.unescapeHtml4(str));
			}
		}
		catch (IOException e) {
			log.error("Exception in literature details response", e);
		}
	}
}