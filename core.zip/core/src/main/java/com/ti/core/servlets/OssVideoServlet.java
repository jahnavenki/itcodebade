package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.ReportingUtils;

@Component(service = Servlet.class, immediate=true, property = {
	SLING_SERVLET_PATHS + "=/bin/ti/oss/video", 
	SLING_SERVLET_METHODS + "=GET" })
public class OssVideoServlet extends SlingSafeMethodsServlet {
	protected static final Logger log = LoggerFactory.getLogger(OssVideoServlet.class);

	@Reference
	private transient WCMComponents wcmService;

	private transient ResourceResolver resourceResolver;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		try {
			resourceResolver = request.getResourceResolver();
			final var session = resourceResolver.adaptTo(Session.class);
			final var languageQuery = request.getParameter("language");
			final var query = "select * from [dam:Asset] where isdescendantnode('/content/dam/videos/external-videos')";
			final var nodeIter = ReportingUtils.executeQuery(query, session);
			if (null == nodeIter) {
				return;
			}
			final var jsonResponse = new JSONArray();
			while (nodeIter.hasNext()) {		
				final var node = nodeIter.nextNode();
				final var jsonObj = getJson( node.getPath(), languageQuery );
				if (null != jsonObj) { 
					jsonResponse.put(jsonObj);
				}
			}
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			jsonResponse.write(response.getWriter());
		} catch (Exception ex) {
			log.error( "Exception", ex );
		}
	}

	private JSONObject getJson( String path, String languageQuery ) throws JSONException {
		final var metadataRes = resourceResolver.getResource(path + "/jcr:content/metadata");
		if (null == metadataRes) {
			return null;
		}
		final var metadataMap = metadataRes.getValueMap();
		final var videoId = metadataMap.get("brc_id", "");
		if (StringUtils.isEmpty(videoId)) {
			return null;
		}
		final var damStatus = metadataMap.get("dam:status", "");
		if (!"published".equalsIgnoreCase(damStatus)) {
			return null;
		}
		String language = metadataMap.get("videoSpokenLanguage", "");
		if (StringUtils.isNotEmpty(languageQuery) && !languageQuery.equals(language)) {
			return null;
		}
		final var jsonObj = new JSONObject();
		final var pageLanguage = pageLanguageFromVideoSpokenLanguage(language);
		jsonObj.put("title", metadataMap.get("dc:title", ""));
		jsonObj.put("short_description", metadataMap.get("shortDescription", ""));
		jsonObj.put("duration", getSeconds(metadataMap.get("brc_duration", "")));
		jsonObj.put("duration_converted", metadataMap.get("brc_duration", ""));
		jsonObj.put("last_published_revision", metadataMap.get("dam:published", ""));
		jsonObj.put("video_category", getVideoCategory(metadataMap.get("taxonomyField", "")));
		jsonObj.put("product_tree_id", getTagNames(metadataMap.get("dam:tagsProducts", String[].class)));
		jsonObj.put("applications_designs_tree_id", getTagNames(metadataMap.get("dam:tagsApplications", String[].class)));
		jsonObj.put("tools_software_tree_id", getTagNames(metadataMap.get("dam:tagsTools", String[].class)));
		jsonObj.put("url", getVideoUrl(videoId, pageLanguage));
		jsonObj.put("thumbnail_url", getThumbnailUrl(path, pageLanguage));
		return jsonObj;
	}

	private String getTagNames(String[] tags) {
		if (null == tags) return "";
		final var tagNames = new ArrayList<String>();
		for (final var t : tags) {
			final var tagParts = t.split("/");
			final var tagName = tagParts[tagParts.length - 1];
			tagNames.add(tagName);
		}
		return String.join(",", tagNames);
	}

	private String getVideoCategory(String taxonomy) {
		if ("product_ovw".equals(taxonomy)) {
			return "Product and technology overview";
		}
		if ("product_app_demo".equals(taxonomy)) {
			return "Product application demo";
		}
		if ("mse_ovw".equals(taxonomy)) {
			return "Market or sector or end application overview";
		}
		if ("corp_careers".equals(taxonomy)) {
			return "About TI careers";
		}
		if ("corp_citizen".equals(taxonomy)) {
			return "About TI citizenship";
		}
		if ("corp_ir".equals(taxonomy)) {
			return "About TI investor relations";
		}
		if ("corp_passion".equals(taxonomy)) {
			return "About TI passion";
		}
		if ("oob".equals(taxonomy)) {
			return "Out of the box or setup";
		}
		if ("product_tut".equals(taxonomy)) {
			return "Product and technology technical tutorial";
		}
		if ("mse_tut".equals(taxonomy)) {
			return "Market or sector or end application technical tutorial";
		}
		if ("ticom_tut".equals(taxonomy)) {
			return "TI.com functionality tutorial";
		}
		if ("webinar_rec".equals(taxonomy)) {
			return "Recorded webinars";
		}
		if ("seminar_rec".equals(taxonomy)) {
			return "Recorded seminars";
		}
		if ("tradeshow_conf".equals(taxonomy)) {
			return "Trade shows & conferences";
		}
		return "";
	}

	private static final Pattern DURATION_PATTERN = Pattern.compile("^(\\d{2}):(\\d{2}):(\\d{2})$");
	private int getSeconds(String duration) {
		final var matcher = DURATION_PATTERN.matcher(duration);
		if (!matcher.find()) {
			return 0;
		}
		final var hours = Integer.parseInt(matcher.group(1));
		final var minutes = Integer.parseInt(matcher.group(2));
		final var seconds = Integer.parseInt(matcher.group(3));
		return (hours * 60 * 60) + (minutes * 60) + seconds;
	}

	private String pageLanguageFromVideoSpokenLanguage(String videoSpokenLanguage) {
		if ("en".equalsIgnoreCase(videoSpokenLanguage)) {
			return "en-us";
		}
		if ("zh-cn".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-cn";
		}
		if ("zh-tw".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-tw";
		}
		if ("ja".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ja-jp";
		}
		if ("ko".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ko-kr";
		}
		if ("de".equalsIgnoreCase(videoSpokenLanguage)) {
			return "de-de";
		}
		return "en-us";
	}

	private String getThumbnailUrl(String path, String pageLanguage) {
		return PathBrowserHelper.setCorrectDomain(path + "/jcr:content/renditions/brc_thumbnail.png", pageLanguage);
	}

	private String getVideoUrl(String videoId, String pageLanguage) {
		var path = "/video/" + videoId;
		if (!"en-us".equalsIgnoreCase(pageLanguage)) {
			path = "/" + pageLanguage + path;
		}
		return PathBrowserHelper.setCorrectDomain(path, pageLanguage);
	}
}
