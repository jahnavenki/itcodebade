package com.ti.core.components;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.models.productfamilyapplications.EndEquipment;
import com.ti.core.models.productfamilyapplications.KeyProduct;
import com.ti.core.models.productfamilyapplications.Market;
import com.ti.core.models.productfamilyapplications.ReferenceDesign;
import com.ti.core.models.productfamilyapplications.Sector;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.URLHelper;

/**
 * Class to read the Product Family Applications
 * @author saryu.sukumar
 *
 */
public class ProductFamilyApplications extends WCMUsePojo {


  private final Logger log = LoggerFactory.getLogger(ProductFamilyApplications.class);

  /* The constant Family Id */
  private static final String FAMILY_ID = "familyId";

  /* The constant data for JSON Object */
  private static final String DATA = "data";

  /* JCR SQL2 Query to find images with tags

  /* The constant RECOMMENDATIONS_OBJECT for JSON Object */
  private static final String RECOMMENDATIONS_OBJECT = "rdProductRecommendations";

  /* The constant familyName from the JSON Object */
  private static final String KEY_FAMILY_NAME = "familyName";

  /* The constant familyId from the JSON Object */
  private static final String KEY_FAMILY_ID = "familyId";

  /* The constants for markets object in JSON */
  private static final String KEY_MARKETS = "markets";
  private static final String KEY_MARKET_NAME = "marketName";
  private static final String KEY_MARKET_ID = "marketId";

  /* The constants for Sectors object in JSON */
  private static final String KEY_SECTORS = "sectors";
  private static final String KEY_SECTOR_NAME = "sectorName";

  /* The constants for End Equipment object in JSON */
  private static final String KEY_EEQS = "eeqs";
  private static final String KEY_EEQ_NAME = "eeqName";
  private static final String KEY_EEQ_URL = "eeqURL";

  /* The constants for Reference Designs object in JSON */
  private static final String KEY_RDS = "rds";
  private static final String KEY_RD_NAME = "rdName";
  private static final String KEY_RD_TITLE = "rdTitle";
  private static final String KEY_RD_URL = "rdURL";

  /* The constants for Key Products object in JSON */
  private static final String KEY_GPN = "gpns";
  private static final String KEY_GPN_NAME = "gpnName";
  private static final String KEY_GPN_DESC = "gpnDesc";
  private static final String KEY_GPN_URL = "gpnURL";

  /* The constants for Application Hierarchy tree object in JSON */
  private static final String JSON_NODE_APPLICATION_TREE = "AppHierarchyList";
  private static final String KEY_PARENT_APP_ID = "parentAppId";
  private static final String KEY_SECTION_NAME = "sectionName";
  private static final String KEY_APP_URL = "appUrl";

  /* The constant for JSON Exception message */
  private static final String EXCEPTION_JSON_MESSAGE = "JSONException: ";

  /* The constants for generating domain from SEO */
  private static final String COLON_SLASH = "://";
  private static final String HTTP = "http";
  private static final String HTTPS = "https";

  /* The constants for reading assets and filter using tags */
  private static final String KEY_DAM_ASSET = "dam:Asset";
  private static final String TAGS_MARKET_ID = "imported:markets";
  private static final String IMPORTED_MARKET = "dam:importedMarket";
  private static final String IMAGE_ALT_TEXT = "imageAltText";
  private static final String IMAGE_ALT = "dam:imageAlt";
  /* The constants for symbols */
  private static final String WHITESPACE = "\\s";
  private static final String COMMA = ",";
  private static final String SLASH = "/";
  private static final int APPLICATION_ID = 209;
  /*Constants for /content/dam paths*/
  private static final String CONTENT_IMAGES_PATH = "/content/dam/ticom/images";
  private static final String CONTENT_FRAGMENT_PATH = "/content/dam/ticom/content-fragments";

  private static final String CONNECTION_TIMEDOUT = "connectionTimedOut";


  private static final String JCR_SQL2_QUERY_ASSETS = "SELECT * FROM [" + KEY_DAM_ASSET + "] AS s WHERE "
													+ "ISDESCENDANTNODE([{0}])"
													+" and s.[jcr:content/metadata/dam:importedProduct] like '%/{1}'";

  private String componentName;
  private String familyId;
  private String pageLanguage;
  private String familyName;
  private String encodedfamilyName;
  private boolean hasRecommendedApps;

  Session session;
  QueryManager queryManager;
  WCMComponents wcmService;

  /* List thats contains list of market objects */
  List<Market> marketList;

  /* List thats contains list of end equipment objects */
  List<EndEquipment> endEquipmentList;

  /* List thats contains list of reference design objects */
  List<ReferenceDesign> referenceDesignList;

  /* List thats contains list of key product objects */
  List<KeyProduct> keyProductList;

  /* Map - key - marketId, value - content fragment path in dam */
  Map<String, String> contentFragmentsMap;

  /* Map - key - marketId, value - image path in dam */
  Map<String, String> imagesMap;

  /* Map - key - Application Design Section Name, value - Application URL */
  Map<String, String> applicationDesignsMap;

  /**
   * Activate method
   */
  @Override
  public void activate() {

	String resourcetype = getResource().getResourceType();
	componentName = resourcetype.substring(resourcetype.lastIndexOf("/")+1);
    ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
        .getService(ProductNavigationTabsOrdering.class);
    if (tabsService != null) {
      pageLanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
      }

    // Read the family ID
    familyId = (String) getPageProperties().get(FAMILY_ID);
    if (StringUtils.isNotEmpty(familyId) && StringUtils.isNotEmpty(pageLanguage)) {
      //Read all the resources(content fragments) that are of type dam:Asset inside this path
      contentFragmentsMap = new LinkedHashMap<>();
      String cfQuery = JCR_SQL2_QUERY_ASSETS;
      //add language to fragment path
      cfQuery = cfQuery.replace("{0}", CONTENT_FRAGMENT_PATH + "/" + pageLanguage).replace("{1}", familyId);
      contentFragmentsMap = this.buildAssetMap(getResourceResolver(), cfQuery, Query.JCR_SQL2);

      //Read all the resources(images) that are of type dam:Asset inside this path
      String imgQuery = JCR_SQL2_QUERY_ASSETS;
      imgQuery = imgQuery.replace("{0}", CONTENT_IMAGES_PATH).replace("{1}", familyId);
      imagesMap = this.buildAssetMap(getResourceResolver(), imgQuery, Query.JCR_SQL2);

      //Read JSON and populate respective models
      getRecommendedApps();

      getEncodedfamilyandmarketnames();

    }
  }


  /**
   * Read JSON to get the recommended apps
   */
  private void getRecommendedApps() {
    wcmService = getSlingScriptHelper().getService(WCMComponents.class);
    try {
      if (wcmService == null) {
        log.error("ProductFamilyApplications: could not get wcmService");
      }
      if (null != wcmService) {
        String jsonResponse = wcmService.getRecommendedAppsForProductFamily(familyId,
            pageLanguage);
        if (StringUtils.isNotEmpty(jsonResponse)) {
        	if(jsonResponse.equalsIgnoreCase(CONNECTION_TIMEDOUT)){
        		getApplicationDesigns();
        	}else{
		          JSONObject jsonObject = new JSONObject(jsonResponse);
		          JSONArray jsonArray = jsonObject.getJSONArray(DATA);
		          for (int i = 0; i < jsonArray.length(); i++) {
		            JSONObject recommendationsObject = jsonArray.getJSONObject(i)
		                .getJSONObject(RECOMMENDATIONS_OBJECT);
		            readRecommendationsObject(recommendationsObject);
		          }
        	}
        }
      }
    } catch (JSONException e) {
      log.error(EXCEPTION_JSON_MESSAGE + e);
    }
  }
  private void getEncodedfamilyandmarketnames() {

	  if (familyName !=null){
			  encodedfamilyName = familyName.replace("&gt;", "\\u003E");
			  encodedfamilyName = encodedfamilyName.replace("&lt;", "\\u003C");
			  log.debug("before encoding " + encodedfamilyName);
			  encodedfamilyName = encodedfamilyName.replace("+", "\\u002B");
			  encodedfamilyName = encodedfamilyName.replace("<", "\\u003C");
			  encodedfamilyName = encodedfamilyName.replace("=", "\\u003D");
			  encodedfamilyName = encodedfamilyName.replace(">", "\\u003E");
			  encodedfamilyName = encodedfamilyName.replace("(", "\\u0028");
			  encodedfamilyName = encodedfamilyName.replace(")", "\\u0029");
			  encodedfamilyName = encodedfamilyName.replace("\"", "\\u0022");
			  encodedfamilyName = encodedfamilyName.replace("& ", "\\u0026 ");
	  }
}

  private void readRecommendationsObject(JSONObject recommendationsObject) throws JSONException {
    //Read familyId and length of markets array to check if there are recommended apps
    int jsonFamilyId = recommendationsObject.getInt(KEY_FAMILY_ID);
    JSONArray marketsArray = recommendationsObject.getJSONArray(KEY_MARKETS);

    log.debug("Family Id: ",jsonFamilyId);
    log.debug("Has Recommeded Apps?: {}",(jsonFamilyId > 0 && marketsArray.length() > 0));

    if(jsonFamilyId > 0 && marketsArray.length() > 0){
      hasRecommendedApps = true;
      familyName = recommendationsObject.getString(KEY_FAMILY_NAME);
      readMarketsJSON(marketsArray);
    } else{
      hasRecommendedApps = false;
      familyName = recommendationsObject.getString(KEY_FAMILY_NAME);
      //Read the EMSG Applications service to display the 2nd level Application Designs Sections
      getApplicationDesigns();
    }
  }



  /**
   * When Recommended apps is empty, service call to load all the applications design pages
   */
  private void getApplicationDesigns(){
    applicationDesignsMap = new LinkedHashMap<>();
    wcmService = getSlingScriptHelper().getService(WCMComponents.class);
    if (wcmService == null) {
      log.error("ProductFamilyApplications: could not get wcmService");
       }
    if (null != wcmService) {
      int applicationId = APPLICATION_ID;
      JSONObject jsonObject = wcmService.getAllApplicationService(getRequest(), applicationId, pageLanguage);
      try {
        if(null != jsonObject){
          JSONArray jsonarr = jsonObject.getJSONArray(DATA).getJSONObject(0).getJSONArray(JSON_NODE_APPLICATION_TREE);
          for(int i=0; i<jsonarr.length();i++){
            JSONObject json = jsonarr.getJSONObject(i);
            int parentAppId = json.getInt(KEY_PARENT_APP_ID);
            String sectionName = json.getString(KEY_SECTION_NAME);
            String appUrl = URLHelper.toScheme(json.getString(KEY_APP_URL), URLHelper.getScheme(getRequest()));
            if(parentAppId == 0){
              applicationDesignsMap.put(sectionName, appUrl);
            }
          }
          log.debug("applicationDesignsMap: {}", applicationDesignsMap.size());
        }
      } catch (JSONException e) {
        log.error(EXCEPTION_JSON_MESSAGE + e);
      }
    }
  }

  /**
   * Iterate through markets and add them to model
   * @param recommendationsObject
   */
  private void readMarketsJSON(JSONArray marketsArray) {
    try {
      marketList = new ArrayList<>();
      for (int j = 0; j < marketsArray.length(); j++) {
        JSONObject marketObject = marketsArray.getJSONObject(j);
        Market market = new Market();
        market.setMarketId(String.valueOf(marketObject.getInt(KEY_MARKET_ID)));
        market.setMarketName(marketObject.getString(KEY_MARKET_NAME));
        market.setAnchorId(createAnchorLinkId(market.getMarketName()));
        String cfString = StringUtils.EMPTY;
        if(null != contentFragmentsMap && contentFragmentsMap.containsKey(market.getMarketId())){
          Resource cf = getResourceResolver().getResource(contentFragmentsMap.get(String.valueOf(market.getMarketId())));
          if (cf != null)
          {
        	  Asset cfAsset = cf.adaptTo(Asset.class);
    		  cfString = readContentFragmentAsset(cfAsset);
          }
        }
        market.setContentFragment(cfString);
        if(null != imagesMap && imagesMap.containsKey(market.getMarketId())){
          market.setMarketImagePath(imagesMap.get(String.valueOf(market.getMarketId())));
          market.setMarketImageAltText(imagesMap.get(String.valueOf(IMAGE_ALT_TEXT)));
        }
        market = readSectorsJSON(marketObject, market);
        marketList.add(market);
      }
    } catch (JSONException e) {
      log.error(EXCEPTION_JSON_MESSAGE, e);
    }
  }



/**
 * @param cfAsset
 */
private String readContentFragmentAsset(Asset cfAsset) {
	String retval = StringUtils.EMPTY;
	if (cfAsset != null)
	  {
		  try (InputStream source = cfAsset.getOriginal().getStream())
		  {
			  retval = IOUtils.toString(source, "UTF-8");
			  if(retval.length()>450){
				  retval = retval.substring(0, 449);
			  }
		  }
		  catch (IOException io)
		  {
			  log.debug("Error using asset string", io);
		  }

	  }
	return retval;
}

  /**
   * Iterate through Sectors and add to model
   * @param marketObject
   * @param market
   * @return
   */
  private Market readSectorsJSON(JSONObject marketObject, Market market) {
    try {
      JSONArray sectorsArray = marketObject.getJSONArray(KEY_SECTORS);
      List<Sector> sectorList = new ArrayList<>();
      for (int j = 0; j < sectorsArray.length(); j++) {
        JSONObject sectorObject = sectorsArray.getJSONObject(j);
        String sectorName = sectorObject.getString(KEY_SECTOR_NAME);
        Sector sector = new Sector();
        sector.setSectorName(sectorName);
        sector = readEndEquimentsJSON(sectorObject, sector);
        sectorList.add(sector);
      }
      market.setSectorList(sectorList);
    } catch (JSONException e) {
      log.error(EXCEPTION_JSON_MESSAGE, e);
    }
    return market;
  }

  /**
   * Iterate through End Equipments and add to model
   * @param sectorObject
   * @param sector
   * @return
   */
  private Sector readEndEquimentsJSON(JSONObject sectorObject, Sector sector) {
    try {
      JSONArray endEquimentsArray = sectorObject.getJSONArray(KEY_EEQS);
      endEquipmentList = new ArrayList<>();
      for (int j = 0; j < endEquimentsArray.length(); j++) {
        JSONObject eeqObject = endEquimentsArray.getJSONObject(j);
        EndEquipment endEquiment = new EndEquipment();
        endEquiment.setEeqName(eeqObject.getString(KEY_EEQ_NAME));
        String eeqUrl = eeqObject.getString(KEY_EEQ_URL);
        if(!eeqUrl.startsWith(HTTP) && !eeqUrl.startsWith(HTTPS)){
          String domain = generateDomain();
          eeqUrl = domain + eeqUrl;
        }

        endEquiment.setEeqUrl(URLHelper.toScheme(eeqUrl, URLHelper.getScheme(getRequest())));
        endEquiment = readReferenceDesignsJSON(eeqObject, endEquiment);
        endEquipmentList.add(endEquiment);
      }
      sector.setEndEquimentsList(endEquipmentList);
    } catch (JSONException e) {
      log.error(EXCEPTION_JSON_MESSAGE, e);
    }
    return sector;
  }

  /**
   * Iterate through Reference Designs and add to model
   * @param eeqObject
   * @param endEquiment
   * @return
   */
  private EndEquipment readReferenceDesignsJSON(JSONObject eeqObject, EndEquipment endEquiment) {
    try {
      JSONArray referenceDesignsArray = eeqObject.getJSONArray(KEY_RDS);
      referenceDesignList = new ArrayList<>();
      for (int j = 0; j < referenceDesignsArray.length(); j++) {
        JSONObject referenceDesignObject = referenceDesignsArray.getJSONObject(j);
        ReferenceDesign referenceDesign = new ReferenceDesign();
        referenceDesign.setRdName(referenceDesignObject.getString(KEY_RD_NAME));
        String rdTitle = "";
        if(StringUtils.isNotBlank(referenceDesignObject.getString(KEY_RD_TITLE))){
        	rdTitle = referenceDesignObject.getString(KEY_RD_TITLE);
        }
        if (("null").equalsIgnoreCase(rdTitle)){
        	referenceDesign.setRdTitle(rdTitle);
        }else{
        	referenceDesign.setRdTitle("");
        }
        String rdUrl = referenceDesignObject.getString(KEY_RD_URL);
        if(!rdUrl.startsWith(HTTP) && !rdUrl.startsWith(HTTPS)){
          String domain = generateDomain();
          rdUrl = domain + rdUrl;
        }
        referenceDesign.setRdUrl(URLHelper.toScheme(rdUrl, URLHelper.getScheme(getRequest())));
        referenceDesign.setIsFirst(j == 0);
        referenceDesign = readKeyProductsJSON(referenceDesignObject, referenceDesign);
        referenceDesignList.add(referenceDesign);
      }
      endEquiment.setReferenceDesignsList(referenceDesignList);
    } catch (JSONException e) {
      log.error("Exception: ", e);
    }
    return endEquiment;
  }

  /**
   * Iterate through Key products and add to model
   * @param referenceDesignObject
   * @param referenceDesign
   * @return
   */
  private ReferenceDesign readKeyProductsJSON(JSONObject referenceDesignObject,
      ReferenceDesign referenceDesign) {
    try {
      JSONArray keyProductsArray = referenceDesignObject.getJSONArray(KEY_GPN);
      keyProductList = new ArrayList<>();
      for (int j = 0; j < keyProductsArray.length(); j++) {
        JSONObject keyProductsObject = keyProductsArray.getJSONObject(j);
        KeyProduct keyProduct = new KeyProduct();
        keyProduct.setGpnName(keyProductsObject.getString(KEY_GPN_NAME));
        keyProduct.setGpnDesc(keyProductsObject.getString(KEY_GPN_DESC));
        String gpnUrl = keyProductsObject.getString(KEY_GPN_URL);
        if(!gpnUrl.startsWith(HTTP) && !gpnUrl.startsWith(HTTPS)){
          String domain = generateDomain();
          gpnUrl = domain + gpnUrl;
        }
        keyProduct.setGpnUrl(URLHelper.toScheme(gpnUrl, URLHelper.getScheme(getRequest())));
        keyProductList.add(keyProduct);
      }
      referenceDesign.setKeyProductsList(keyProductList);
    } catch (JSONException e) {
      log.error("Exception: ", e);
    }
    return referenceDesign;
  }

  /**
   * Read all assets under the specified resource filter based on tags
   * @param resolver the resource resolver for this page/request
   * @param query Resource query to use
   * @param language the lanuage type of the query string (xpath, sql, sql2 etc)
   * @return
   */
  private Map<String, String> buildAssetMap(ResourceResolver resolver, String query, String language)
  {
	  Map<String, String> assetMap = new LinkedHashMap<>();
	  Iterator<Resource> results = resolver.findResources(query, language);
	  while(results.hasNext())
	  {
		  Asset asset = results.next().adaptTo(Asset.class);
		  if (asset != null)
		  {
			  String tags = asset.getMetadataValue(IMPORTED_MARKET);

			if (tags == null)
				tags = StringUtils.EMPTY;


			assetMap = addByMarketTag(asset, tags, assetMap);
		  }
	  }
	  return assetMap;
  }

  /**
   * Split the tags property value and add to map
   * @param asset
   * @param tags
   * @param assetsMap
   * @return
   */
  private Map<String, String> addByMarketTag(Asset asset, String tags, Map<String, String> assetsMap) {
    String[] tagsArray = tags.split(COMMA);
	if(tagsArray.length >= 1){
		String[] marketTags = tagsArray[0].replace(TAGS_MARKET_ID, StringUtils.EMPTY).split(SLASH);
		String marketId = marketTags[marketTags.length-1];
		if(StringUtils.isNumeric(marketId))
        assetsMap.put(marketId, asset.getPath());
		assetsMap.put(IMAGE_ALT_TEXT, asset.getMetadataValue(IMAGE_ALT));
	}
    return assetsMap;
  }

  /**
   * Create anchor id from market name
   * @param anchorName
   * @return
   */
  public String createAnchorLinkId(String anchorName) {
    String anchorId;
    anchorId = anchorName.toLowerCase().replaceAll(WHITESPACE, "");
    return anchorId;
  }

  private String generateDomain() {
    String domain = "";
    SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper()
        .getService(SeoUrlFactoryConfigs.class);
    if (null != factoryConfigs) {
      List<SeoUrlTagging>listConfig = factoryConfigs.getConfigs();
      for (SeoUrlTagging seoUrlTagging : listConfig) {
        if(StringUtils.containsIgnoreCase(getCurrentPage().getPath(),seoUrlTagging.getContentPath())){
          domain = seoUrlTagging.getDomainName();
          domain = HTTP.concat(COLON_SLASH).concat(domain);
          break;
        }
      }
    }
    return domain;
  }

  public List<Market> getMarketList() {
    return marketList;
  }

  public String getFamilyName() {
    return familyName;
  }

  public String getEncodedfamilyName() {
	    return encodedfamilyName;
	  }

  public Map<String, String> getContentFragmentsMap(){
    return contentFragmentsMap;
  }

  public Map<String, String> getApplicationDesignsMap(){
    return applicationDesignsMap;
  }

  public boolean getHasRecommendedApps(){
    return hasRecommendedApps;
  }

  public String getComponentName(){
    return componentName;
  }

}