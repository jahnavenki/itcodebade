package com.ti.core.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.sightly.WCMUsePojo;

public class FeaturedTool extends WCMUsePojo {

	private List<String> listItems;

	private boolean listNotEmpty;

	@Override
	public void activate() throws Exception {
		Resource listItemsRes = getResource().getChild("listItems");
		if (Objects.nonNull(listItemsRes) && listItemsRes.hasChildren()) {
			listItems = new ArrayList<>();
			Iterator<Resource> iterator = listItemsRes.listChildren();
			while (iterator.hasNext()) {
				ValueMap map = iterator.next().getValueMap();
				String value = map.get("itemValue", StringUtils.EMPTY);
				if (StringUtils.isNotBlank(value)) {
					listItems.add(value);
				}
			}
		}
		if (Objects.nonNull(listItems) && !listItems.isEmpty()) {
			listNotEmpty = true;
		}
	}

	public List<String> getListItems() {
		return listItems;
	}

	public boolean isListNotEmpty() {
		return listNotEmpty;
	}
}