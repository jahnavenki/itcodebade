package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.ti.core.service.ProductNavigationTabsOrdering;

/**
 * Update the embed header by pulling the latest com.TI.header.js content 

 */
@SuppressWarnings("serial")
@Component( immediate=true, service = Servlet.class,   property = {
		SLING_SERVLET_PATHS + "=/bin/ti/updateTIcomheader", 
		SLING_SERVLET_METHODS + "=GET"})
@Designate(ocd=UpdateTIcomHeader.Config.class)
public class UpdateTIcomHeader extends SlingSafeMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(UpdateTIcomHeader.class);
	
	private static final String ROOTPATH = "/content/texas-instruments/";
	private static final String HEADER_HTML_PROPERTY = "ticomHeaderHtml";
	private static final String PROXY_HOST = "webproxy.ext.ti.com";
	private String tiComHeaderJSUrl;
	protected transient Config  config;
	
	@ObjectClassDefinition(name =  "TI update header", description = "TI update header")
	public @interface Config {

		
		@AttributeDefinition(name = "comtiheaderUrl", description = "Description for comtiheaderUrl ")
		String comtiheaderUrl();

		
		
	}

	@Reference
	private transient Replicator replicator;
	
	@Reference
	private transient ProductNavigationTabsOrdering tabsService;
	
	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		if (tabsService == null) {
			log.error("Unable to get ProductNavigationTabsOrderingImpl service");
			return;
		}
		try {
			
			// Get all the regions, format expected: en-us/EN,zh-cn/CN,zh-tw/TW,en-in/IN,it-it/IT,ja-jp/JP,....
			String[] regionList = StringUtils.stripAll(StringUtils.split(tabsService.getAnalyticsPagename(), ','));
				
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection connection;
			
			response.setContentType("text/plain");
			URL url;
			String inputLine, result;
			for (int i = 0; i < regionList.length; i++) {		
				String[] region = StringUtils.stripAll(StringUtils.split(regionList[i],'/'));

				// region[] first index is region, second is country.  Both should not be empty
				if (StringUtils.isEmpty(region[0]) || StringUtils.isEmpty(region[1]))
					continue;
				
				// Replace {region} in the header URL with the country code
				url = new URL(this.tiComHeaderJSUrl.replace("{region}",region[1].toLowerCase()));

				connection = (HttpURLConnection) url.openConnection(proxy);			
							
				// Read the content
				BufferedReader in = new BufferedReader(
		                new InputStreamReader(
		                    connection.getInputStream(), "UTF8"));

				StringBuilder res = new StringBuilder();
				
				while ((inputLine = in.readLine()) != null)
					res.append(inputLine + '\n');
				
				in.close();
							
				// Set header HTML for language root.  Note on removing the last line for including header-portal.js.
				String langRootPath = ROOTPATH + region[0].toLowerCase() + "/jcr:content";
							
				result = setHeaderHtmlForLangRoot(request, 
						res.toString().replaceAll("<script[^>]*/assets/.+portal.*.js[^>]*>(.*?)</script[^>]*>",""), langRootPath);
				
				if (!StringUtils.isEmpty(result)) {
					log.info(result); 
					response.getWriter().write(result);
				}
			}
		}
		catch (Exception e) {
			log.error("Error in UpdateTIcomHeader.doGet: ", e);
		}
	}
		
	@Activate
	protected void activate(Config config) {
		this.tiComHeaderJSUrl = config.comtiheaderUrl();
	}
	
	private String setHeaderHtmlForLangRoot(SlingHttpServletRequest request, String headerHtml, String langRootPath) {
		if (request == null || StringUtils.isBlank(headerHtml) || StringUtils.isBlank(langRootPath))
			return "setHeaderHtmlForLangRoot failed - invalid or null/empty parameter(s)!\r\n";
						
		if (!"1".equals(request.getParameter("ignorevalidationcheck")) && !isValidHeaderHtml(headerHtml))
			return "setHeaderHtmlForLangRoot: " + langRootPath + " downloaded header html is invalid!\r\n";
		
		try {
			Resource resource = request.getResourceResolver().getResource(langRootPath);

			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					node.setProperty(HEADER_HTML_PROPERTY, headerHtml);
					node.getSession().save();
					
					Session jcrSession = request.getResourceResolver().adaptTo(Session.class);
					replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE, langRootPath);
					
					return "setHeaderHtmlForLangRoot: " + langRootPath + " success!\r\n"; 
				}
			}
		} 
		catch (RepositoryException | ReplicationException e) {
			log.error("Error in UpdateTIcomHeader.setHeaderHtmlForLangRoot: ", e);
		} 

		return "setHeaderHtmlForLangRoot failed!\r\n"; 
	}
	
	private boolean isValidHeaderHtml(String headerHtml) {
		// Verify that string is not null/empty/blank
		// Verify that the string size must be over 5KB
		// Verify that the word "TI" (case-sensitive) must be in the header
		// Verify that the word "products" must be in the header
		// Verify that the word "support" must be in the header
		if (StringUtils.isBlank(headerHtml) || headerHtml.length() < 5000)
			return false;
		
		// Note: couldn't put all the conditions in one line due to Sonar...
        return (headerHtml.contains("TI") && headerHtml.toLowerCase().contains("products") && headerHtml.toLowerCase().contains("support"));
	}
}