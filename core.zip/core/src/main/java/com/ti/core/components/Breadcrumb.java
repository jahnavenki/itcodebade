package com.ti.core.components;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.models.BreadcrumbLink;
import com.ti.core.service.BreadcrumbConfigService;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.URLHelper;

/**
 * Breadcrumb WCMUsePojo.
 *
 * @author saryu.sukumar
 *
 */
public class Breadcrumb extends WCMUsePojo {
	private static class ApplicationTreeNode {
		public ApplicationTreeNode( JSONObject json ) throws JSONException {
			childId = json.getInt( "childId" );
			parentAppId = getInteger( json, "parentAppId" );
			appUrl = json.getString( "appUrl" );
			if ("null".equals( appUrl ) ) appUrl = null;
			sectionName = json.getString( "sectionName" );
			enSectionName = json.getString( "enSectionName" );
		}

		private int childId;
		private Integer parentAppId;
		private String appUrl;
		private String sectionName;
		private String enSectionName;
		private ApplicationTreeNode parent;
		private final List<ApplicationTreeNode> children = new ArrayList<>();

		private static Integer getInteger( JSONObject json, String key ) throws JSONException {
			if( json.isNull( key ) ) return null;
			else return json.getInt( key );
		}

		public int getChildId() {
			return childId;
		}

		public Integer getParentAppId() {
			return parentAppId;
		}

		public String getAppUrl() {
			return appUrl;
		}

		public String getSectionName() {
			return sectionName;
		}
		public String getEnSectionName() {
			return enSectionName;
		}

		public ApplicationTreeNode getParent() {
			return parent;
		}

		public void setParent( ApplicationTreeNode parent ) {
			this.parent = parent;
		}

		public List<ApplicationTreeNode> getChildren() {
			return children;
		}

		public boolean hasChildren() {
			return !children.isEmpty();
		}
	}

	private static final String ROOT_PATH = "/";
	private static final String NODE_URL = "productNodeUrl";
	private static final String NODE_NAME = "familyName";
	private static final String NODE_NAME_EN = "enFamilyName";
	private static final String FAMILY_ID = "familyId";
	private static final String TREE_LEVEL = "treelevel";
	private static final String PARENT_ID = "parentId";
	private static final String APPLICATION_ID = "applicationId";
	private static final String PAGE_TITLE = "pageTitle";
	private static final String HTTP = "http://";
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private LanguageUtils languageUtils;
	private List<SeoUrlTagging> listConfig;
	private Map<Integer, Map<String, String>> breadcrumbMap = null;
	private Map<Integer, List<BreadcrumbLink>> breadcrumbSiblings = null;
	private String nodeName;
	private String nodeNameEn;
	private String componentName;
	private String webSite = null;
	private String productsURL = null;
	private static final Set<String> languagelist = new HashSet<>(Arrays.asList("JP", "KR", "DE", "RU", "MX", "TW"));
	private static final String DASH = "-";
	private int metricsCounter1 = 0;
	private int metricsCounter2 = 0;


	@Override
	public void activate() {
		Resource resource = null ;
		try {
			 resource = this.getResource();
			setComponentName(resource.getName());
			this.nodeName = null;
			this.breadcrumbMap = new LinkedHashMap<>();
			this.breadcrumbSiblings = new LinkedHashMap<>();
			this.languageUtils = new LanguageUtils(getRequest());
			String language = null, languageCode = null;
			WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			BreadcrumbConfigService breadcrumbService = getSlingScriptHelper()
					.getService(BreadcrumbConfigService.class);
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);
			if (wcmService == null)
				log.error("Breadcrumb: could not get wcmService");

			if (null != tabsService) {
				language = tabsService.getPageLanguage(getCurrentPage());
				languageCode = StringUtils.substringAfter(language, DASH);
			}
			if (null != languageCode && languagelist.contains(languageCode.toUpperCase())) {
				buildtihome(breadcrumbService, language);
			} else {
				buildWebSite();
			}
			buildProductsURL();
			ValueMap pageProps = getPageProperties();

			if (pageProps != null) {
				generateBreadCrumb(wcmService, pageProps, tabsService);
			}
		} catch (Exception e) {
			log.error("Could not create breadcrumb: {} {} ", e, resource != null ? resource.getPath():"");
		}
	}

	/**
	 * @param wcmService
	 * @param pageProps
	 * @throws JSONException
	 */
	private void generateBreadCrumb(WCMComponents wcmService, ValueMap pageProps,
			ProductNavigationTabsOrdering tabsService) throws JSONException {
		var selector = "";
		final var selectors = getRequest().getRequestPathInfo().getSelectors();
		if (selectors.length > 0) {
			selector = selectors[0];
		}
		String language = tabsService.getPageLanguage(getCurrentPage());
		if (wcmService != null && pageProps.containsKey(FAMILY_ID)) {
			buildBreadCrumbFromFamilyId(wcmService, language);
		} else if (wcmService != null && pageProps.containsKey(APPLICATION_ID)) {
			buildBreadCrumbFromApplicationId(wcmService, language);
		} else if (selector.equals("product portfolio")) {
			buildBreadCrumbForProductPortfolio();
		} else if (selector.equals("new products selection")) {
			buildBreadCrumbForNewProductsSelection();
		} else {
			// No family set so lets just get the name of the page

			// Start with Page Title - Overide they set
			if (pageProps.containsKey(PAGE_TITLE))
				this.nodeName = pageProps.get(PAGE_TITLE, String.class);

			// If none is set lets use the tab title
			if (this.nodeName == null)
				this.nodeName = this.getCurrentPage().getNavigationTitle();

			// If none is set then just get the aem page title.
			if (this.nodeName == null)
				this.nodeName = this.getCurrentPage().getPageTitle();

		}
	}

	/**
	 * @param wcmService
	 * @throws JSONException
	 */
	private void buildBreadCrumbFromFamilyId(WCMComponents wcmService, String language) throws JSONException {
		int familyId = Integer.parseInt((String)getPageProperties().get(FAMILY_ID));
		JSONObject jsonObject = wcmService.getAllProductService(getRequest(), familyId, language);
		JSONArray breadcrumbJson = jsonObject.getJSONArray("ancestors");
		JSONArray treeJson = jsonObject.getJSONArray("tree");
		JSONArray siloJson = new JSONObject(wcmService.getSilo(language)).getJSONArray("content");
		List<Integer> ancestorsList = new ArrayList<>();
		Comparator<BreadcrumbLink> sortByLink = (BreadcrumbLink l1, BreadcrumbLink l2) -> l1.getLink()
				.compareTo(l2.getLink());
		JSONObject node;
		Integer baseModifier = 0; // base modifier to accommodate for treelevel
									// with either 0 or 1 as the silo level

		// Add the main breadcrumbs (Silo, family, sub-family, excluding Home)
		for (int i = breadcrumbJson.length() - 1; i >= 0; i--) {
			node = breadcrumbJson.getJSONObject(i);
			String nodeUrl = URLHelper.toScheme(node.getString(NODE_URL), URLHelper.getScheme(getRequest()));
			nodeName = node.getString(NODE_NAME);
			nodeNameEn = node.getString(NODE_NAME_EN);
			Map<String, String> tempMap = new LinkedHashMap<>();
			tempMap.put(nodeName, nodeUrl);
			tempMap.put("enSectionName",nodeNameEn);
			breadcrumbMap.put(breadcrumbMap.size(), tempMap);
			if (i > 0)
				ancestorsList.add(node.getInt(FAMILY_ID));
			breadcrumbSiblings.put(i, new ArrayList<>());
			if (i == breadcrumbJson.length() - 1)
				baseModifier = -(node.getInt(TREE_LEVEL));
		}

		// Siblings for family/subfamily sections
		for (int j = 0; j < treeJson.length(); j++) {
			node = treeJson.getJSONObject(j);
			if (ancestorsList.contains(node.getInt(PARENT_ID)))
				breadcrumbSiblings.get(node.getInt(TREE_LEVEL) + baseModifier)
						.add(new BreadcrumbLink(node.getString(NODE_NAME),
								URLHelper.toScheme(node.getString(NODE_URL), URLHelper.getScheme(getRequest())),
								node.getString(NODE_NAME_EN)));
		}

		final List<JSONObject> silos = new ArrayList<>(siloJson.length());
		for (int k = 0; k < siloJson.length(); k++) {
			silos.add(siloJson.getJSONObject(k));
		}

		final Set<Integer> familyIds =
			silos.stream()
			.map(s -> s.optInt(FAMILY_ID))
			.filter(s -> s != 0)
			.collect(Collectors.toSet());

		final List<BreadcrumbLink> siloBreadcrumbLinks =
			silos.stream()
			.filter(s -> !familyIds.contains(s.optInt(PARENT_ID)))
			.map(s -> {
				final String breadcrumbTitle = s.optString(NODE_NAME);
				final String breadcrumbTitleEn = s.optString(NODE_NAME_EN);
				final String breadcrumbUrl = URLHelper.toScheme(s.optString("familyUrl"), URLHelper.getScheme(getRequest()));
				return new BreadcrumbLink(breadcrumbTitle, breadcrumbUrl, breadcrumbTitleEn);
			})
			.collect(Collectors.toList());
		
		breadcrumbSiblings.get(0).addAll(siloBreadcrumbLinks);
		Collections.sort(breadcrumbSiblings.get(0), sortByLink);
	}

	/**
	 * This method is used to construct breadcrumb based on what application id
	 * is set in page properies.
	 *
	 * @param wcmService
	 * @throws JSONException
	 */
	private void buildBreadCrumbFromApplicationId(WCMComponents wcmService, String language) throws JSONException {
		final var applicationId = (String) getPageProperties().get(APPLICATION_ID);
		// temporary fix, this will be moved to osgi config later
		final var languageMap = new HashMap<String, String>();
		languageMap.put("zh-cn", "应用");
		languageMap.put("ja-jp", "アプリケーション");
		languageMap.put("ko-kr", "응용 분야");
		languageMap.put("de-de", "Anwendungen");
		languageMap.put("ru-ru", "Приложения");
		languageMap.put("zh-tw", "應用領域");
		languageMap.put("es-mx", "Aplicaciones");

		String apphome;
		if (languageMap.containsKey(language)) {
			apphome = languageMap.get(language);
		} else {
			apphome = "Applications";
		}
		log.debug("apphome" + apphome);
		final var apphomepageurl = URLHelper.toScheme(getApplicationsHomePageUrl(wcmService, language),
				URLHelper.getScheme(getRequest()));
		final var jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(applicationId),
				language);
		final var jsonAppHierarchyList = jsonObject.getJSONArray( "AppHierarchyList" );
		final var appNodeList = new ArrayList<ApplicationTreeNode>();
		final var appNodeMap = new HashMap<Integer, ApplicationTreeNode>();
		for (var i = 0; i < jsonAppHierarchyList.length(); ++i) {
			final var node = new ApplicationTreeNode( jsonAppHierarchyList.getJSONObject(i) );
			appNodeList.add( node );
			appNodeMap.put( node.getChildId(), node );
		}
		for (final var node : appNodeList) {
			final var parentId = node.getParentAppId();
			final var parent = appNodeMap.get( parentId );
			node.setParent( parent );
			if (null != parent) {
				parent.getChildren().add( node );
			}
		}

		final var jsonAncestors = jsonObject.getJSONArray("ancestors");
		var tempMap = new LinkedHashMap<String, String>();
		tempMap.put(apphome, apphomepageurl);
		tempMap.put("enSectionName","Applications");
		breadcrumbMap.put(breadcrumbMap.size(), tempMap);
		for (int i = jsonAncestors.length() - 1; i >= 0; i--) {
			final var node = appNodeMap.get( jsonAncestors.getJSONObject(i).getInt("childId") );
			tempMap = new LinkedHashMap<>();
			tempMap.put(node.getSectionName(), node.getAppUrl());
			tempMap.put("enSectionName",node.getEnSectionName());
			final var parent = node.getParent();
			final var siblings = new ArrayList<BreadcrumbLink>();
			if (null == parent) {
				for (final var rootNode : appNodeList) {
					if (null != rootNode.getParent() || StringUtils.isEmpty(rootNode.getAppUrl())) continue;
					siblings.add( new BreadcrumbLink(rootNode.getSectionName(), rootNode.getAppUrl()) );
				}
			} else {
				for (final var childNode : parent.getChildren()) {
					if (StringUtils.isEmpty(childNode.getAppUrl())) continue;
					siblings.add( new BreadcrumbLink(childNode.getSectionName(), childNode.getAppUrl()) );
				}
			}
			if( siblings.size() > 1 ) {
				breadcrumbSiblings.put(breadcrumbMap.size(), siblings);
			}
			breadcrumbMap.put(breadcrumbMap.size(), tempMap);
			nodeName = node.getSectionName();
		}
	}

	private void buildBreadCrumbForProductPortfolio() {
		this.nodeName = languageUtils.getI18nStr("Products");
	}

	private void buildBreadCrumbForNewProductsSelection() {
		final var currentPage = this.getCurrentPage();
		final var factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		final var domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		final var tempMap = new LinkedHashMap<String, String>();
		final var products = languageUtils.getI18nStr("Products");
		final var productsUrl = languageUtils.getI18nStr("https://{}/product-category/overview.html", domain);
		tempMap.put(products, productsUrl);
		tempMap.put("enSectionName","Products");
		breadcrumbMap.put(breadcrumbMap.size(), tempMap);
		this.nodeName = languageUtils.getI18nStr("New products");
	}

	private String getApplicationsHomePageUrl(WCMComponents wcmService, String language) {
		String domain = "";

		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		if (null != factoryConfigs) {
			listConfig = factoryConfigs.getConfigs();
			for (SeoUrlTagging seoUrlTagging : listConfig) {
				if (StringUtils.containsIgnoreCase(getCurrentPage().getPath(), seoUrlTagging.getContentPath())) {
					domain = seoUrlTagging.getDomainName();
					if ("en-us".equals(language)) {
						domain = HTTP.concat(domain).concat(wcmService.getApphomepageurl());
					} else {
						domain = HTTP.concat(domain) + "/" + language + wcmService.getApphomepageurl();
					}
					break;
				}
			}
		}
		return domain;
	}

	private void buildWebSite() {
		Page currentPage = this.getCurrentPage();

		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);

		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		try {
			URI requestUrl = new URI(this.getRequest().getRequestURL().toString());
			URI targetUrl = new URI(requestUrl.getScheme(), domain, null, null);
			this.webSite = URLHelper.toScheme(targetUrl.toString(), URLHelper.getScheme(getRequest()));
		} catch (URISyntaxException ex) {
			log.error("Could not read uri from page request {}", this.getRequest().getRequestURI(), ex);
			this.webSite = ROOT_PATH;
		}
	}

	private void buildtihome(BreadcrumbConfigService breadcrumbService, String languageCode) {
		Page currentPage = this.getCurrentPage();

		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);

		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String homepageconfig = breadcrumbService.gethomepageurl();
		log.debug("homepageconfig: {}", homepageconfig);
		String[] homepageArray = StringUtils.split(homepageconfig, ",");
		String homepageURL = null;
		for (int i = 0;  i <  homepageArray.length; i++) {
			if (StringUtils.equalsIgnoreCase(languageCode,
					StringUtils.substringBefore(StringUtils.trim(homepageArray[i]), "|"))) {
				homepageURL = HTTP.concat(domain)
						.concat(StringUtils.substringAfter(StringUtils.trim(homepageArray[i]), "|"));
				log.debug("home page url = {} ", homepageURL);
			}

		}

		this.webSite = URLHelper.toScheme(homepageURL, URLHelper.getScheme(getRequest()));

	}

	private void buildProductsURL() {
		final var currentPage = this.getCurrentPage();
		final var factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		final var domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		productsURL = languageUtils.getI18nStr("https://{}/product-category/overview.html", domain);
	}

	public String getNodeName() {
		return nodeName;
	}

	public Map<Integer, Map<String, String>> getBreadcrumbMap() {
		return breadcrumbMap;
	}

	public Map<Integer, List<BreadcrumbLink>> getBreadcrumbSiblings() {
		return breadcrumbSiblings;
	}

	public String getWebSite() {
		return this.webSite;
	}

	public String getProductsURL() {
		return this.productsURL;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	//There are 2 loops in the html file. One for desktop and one for smaller screens.
	//So one counter variable has to be made for each loop's sectionCount.
	public int getMetricsCounter1() { //desktop counter
		return ++metricsCounter1;
	}

	public int getMetricsCounter2() { //mobile counter
		return ++metricsCounter2;
	}

}