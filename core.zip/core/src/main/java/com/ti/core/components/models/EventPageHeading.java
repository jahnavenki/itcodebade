package com.ti.core.components.models;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import javax.annotation.PostConstruct;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = {Resource.class},
	resourceType = { EventPageHeading.RESOURCE_TYPE },
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class EventPageHeading {
	public static final String RESOURCE_TYPE = "ti/components/eventPageHeading";
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Self
	Resource resource;

	@SlingObject
	private ResourceResolver resourceResolver;

	@ValueMapValue
	private String imageSrc;

	private String pageTemplate;
	public String getPageTemplate(){
		return pageTemplate;
	}
	
	private boolean isVideo;
	
	public boolean getIsVideo() {
		return isVideo;
	}

	private String imageAltText;

	public String getImageAltText() {
		return imageAltText;
	}

	private String videoTitle;
	public String getVideoTitle() {
		return videoTitle;
	}
	
	@PostConstruct
	public void init() {
		try {
			getDamResources(imageSrc);
			PageManager pm = resourceResolver.adaptTo(PageManager.class);
			Page currentPage = pm.getContainingPage(resource.getPath());
			pageTemplate = currentPage.getProperties().get("cq:template", String.class);
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
	private void getDamResources(String imageSrc) {
        try {    
			if (StringUtils.isNotEmpty(imageSrc)) {
				final var resource = resourceResolver.getResource(imageSrc);
				if (null != resource) {
					final var asset = resource.adaptTo(Asset.class);
					if (null != asset) {
						isVideo = asset.getMimeType().startsWith("video/");
						imageAltText = asset.getMetadataValue("dc:title");
					}
				}
			}
		} catch (Exception e) {
		log.error("Exception:", e);
		}
	}
}