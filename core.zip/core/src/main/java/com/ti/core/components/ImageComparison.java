package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageComparison extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private String leftImageAlt;
	private String leftImageMetricsName;
	private String rightImageAlt;
	private String rightImageMetricsName;

	public String getLeftImageAlt() {
		return leftImageAlt;
	}

	public String getLeftImageMetricsName() {
		return leftImageMetricsName;
	}

	public String getRightImageAlt() {
		return rightImageAlt;
	}

	public String getRightImageMetricsName() {
		return rightImageMetricsName;
	}

	private String getImageAltText( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		final var asset = resource.adaptTo(Asset.class);
		if(null == asset) return "";
		return asset.getMetadataValue("dc:title");
	}

	private String getImageFilename( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		return resource.getName();
	}

	@Override
	public void activate() {
		try {
			final var properties = getProperties();
			final var leftImageSrc = properties.get("leftImageSrc", "");
			leftImageAlt = getImageAltText(leftImageSrc);
			leftImageMetricsName = getImageFilename(leftImageSrc);
			final var rightImageSrc = properties.get("rightImageSrc", "");
			rightImageAlt = getImageAltText(rightImageSrc);
			rightImageMetricsName = getImageFilename(rightImageSrc);
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
