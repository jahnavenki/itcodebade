package com.ti.core.components.models;

import java.util.Collection;
import javax.annotation.PostConstruct;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	resourceType = FaqsIndex.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class FaqsIndex {
    protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/faqsIndex";

	@ChildResource
	private Collection<Resource> links;

	@PostConstruct
	public void init(){
		try {
			links = CollectionUtils.emptyIfNull(links);
		} catch (Exception e) {
			log.error("Exception in FaqsIndex", e);
		}
	}

	public Collection<Resource> getLinks() {
		return links;
	}

}
