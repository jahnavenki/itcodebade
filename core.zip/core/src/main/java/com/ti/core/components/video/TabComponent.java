package com.ti.core.components.video;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

import java.util.regex.Pattern;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author x1055799
 */
public class TabComponent extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(TabComponent.class);
	
	private String details;
	private String transcript;

	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

	public String getDetails() {
		return details;
	}

	public String getTranscript() {
		return transcript;
	}

	@Override
    public void activate() {
		try {
			final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
			final String videoId = matcher.find() ? matcher.group(1) : null;
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
			Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
				
			if (null == damRes)  {
				log.error("Resource not found for video id: {} ", videoId);
				return;
			}
			final var map = AssetUtils.getMetadata(damRes);
			if (null == map)  {
				log.error("Metadata not found for video id: {} ", videoId);
				return;
			}
			details = map.get("dam:details", String.class);
			transcript = map.get("transcript", String.class);
		} catch (Exception e) {
          log.error("Exception in TabComponent: ", e);
        }
	}	
}
