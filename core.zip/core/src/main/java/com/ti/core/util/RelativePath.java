package com.ti.core.util;

import javax.jcr.Node;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class RelativePath extends WCMUsePojo {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private String url;

	public String getUrl() {
		return url;
	}

	@Override
	public void activate() throws Exception {
		try {
			final var page = getCurrentPage();
			final var pageNode = page.adaptTo(Node.class);
			final var path = get("path", String.class);
			if (StringUtils.isEmpty(path)) return;
			final var relNode = pageNode.getNode(path);
			if (null == relNode) return;
			url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), relNode.getPath());
		} catch(Exception ex) {
			log.error("RelativePath Exception : ", ex);
		}
	}
}
