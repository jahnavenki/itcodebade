package com.ti.core.service.workflow;

import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.dam.api.Rendition;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to create video asset from excel.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Create Dam Asset From Excel" })
public class CreateDamAssetFromExcel implements WorkflowProcess {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private WCMComponents wcmService;
	@Reference
	private VideoConfigService videoService;

	private ResourceResolver resourceResolver;

	private String videoPath;
	private String accountId;
	private int partitionSize;
	private int partitionStartIndex;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
				throw new NullPointerException("resourceResolver");
			}
			final var resource = resourceResolver.getResource(payload);
			if (null == resource) {
				return;
			}
			videoPath = videoService.getVideoPath();
			accountId = videoService.getAccountId();
			partitionSize = videoService.getPartitionSize();
			partitionStartIndex = videoService.getPartitionStartIndex();
			if (StringUtils.isEmpty(videoPath) || StringUtils.isEmpty(accountId) || partitionSize == 0) {
				log.warn("config not set");
				return;
			}
			final var stream = createInputStreamFromResource(resource);
			readExcelAndCreateVideo(stream); 
		} catch (Exception e) {
			log.error("Error occurred in CreateDamAssetFromExcel", e);
		}
	}    

	private InputStream createInputStreamFromResource(Resource resource) {
		try {
			Asset asset = resource.adaptTo(Asset.class);
			InputStream stream = null;
			if (asset != null) {
				Rendition original = asset.getOriginal();
				if (original != null) {
					stream = original.getStream();
				}
			}
			return stream;
		} catch (Exception e) {
			log.error("Error occurred in CreateDamAssetFromExcel createInputStreamFromResource", e);
		  } 
		return null;   
	}

	private void readExcelAndCreateVideo(InputStream stream) {
		var i = 0;
		try (final var workbook = new XSSFWorkbook(stream)) {
			final var sheet = workbook.getSheetAt(0);
			final var dataFormatter = new DataFormatter();
			final var rowIterator = sheet.iterator();			
			// First row is header, so import data from second row onwards
			rowIterator.next();
			while (rowIterator.hasNext()) {
				final var row = rowIterator.next();
				var videoId = StringUtils.EMPTY;
				if (row.getCell(0) != null) {
					videoId = dataFormatter.formatCellValue(row.getCell(0));
				}
				if (StringUtils.isNotEmpty(videoId)) {
					final var partition = (int)(Math.floor(i++ / (double)partitionSize)) + partitionStartIndex;
					addVideoAssetToDam(partition, videoId);
				}
			} 
		} catch (Exception e) {
			log.error("Error occurred in CreateDamAssetFromExcel readExcelAndCreateVideo", e);
		}
	}

	private void addVideoAssetToDam(int partition, String videoId) {
		try {
			// check if the asset with video id already exists
			if (AssetUtils.getDamResource(resourceResolver, videoPath, videoId) == null) {
				final var assetManager = resourceResolver.adaptTo(AssetManager.class);
				if (null == assetManager) {
					return;
				}
				final var fullVideoPath = videoPath + partition + "/" + accountId + "/" + videoId + ".mp4";
				final var asset = assetManager.createAsset(fullVideoPath, InputStream.nullInputStream(), "video/mp4", true);
				final var video = asset.adaptTo(Resource.class);
				final var map = AssetUtils.getModifiableMetadata(video);
				if (null == map) {
					log.warn("unable to update metadata for {}", fullVideoPath);
				} else {
					map.put("brc_id", videoId);
				}
			}			
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}
}
