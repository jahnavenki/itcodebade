package com.ti.core.models;

public class TextModel {

  private String itemValue;

  public String getItemValue() {
    return itemValue;
  }
}
