package com.ti.core.components.video;

import java.util.regex.Pattern;

import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.config.VideoConfigService;

public class VideoPlayer extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(VideoPlayer.class);

	@OSGiService
	private VideoConfigService videoService;

	private String videoId;
	private String accountId;
	private String playerId;

	public String getVideoId() {
		return videoId;
	}

	public String getAccountId() {
		return accountId;
	}

	public String getPlayerId() {
		return playerId;
	}

	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

	@Override
	public void activate() {
		try {
			final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
			videoId = matcher.find() ? matcher.group(1) : null;

			videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null ) {
				log.debug("Video service not found");
				return;
			}
			accountId = videoService.getAccountId();
			if (accountId == null || accountId.length() <= 0) {
				log.debug("Brightcove account ID not found in the config");
				return;
			}
			playerId = videoService.getPlayerId();
			if (playerId == null || playerId.length() <= 0) {
				log.debug("Brightcove account ID not found in the config");
				return;
			}
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}
}
