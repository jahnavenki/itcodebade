/**
 * 
 */
package com.ti.core.models;

/**
 * @author x0265123
 *
 */
public class MigrationContentModel {
	private String path;
	private String destinationUrl;
	private String sourceUrl;
	private String targetTemplate;
	private String pageTitle;
	private String description;
	private String hideInNav;
	private String webPM;
	private String dmPM;
	private String migrationStatus;
	private String type;
	
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getDestinationUrl() {
		return destinationUrl;
	}
	public void setDestinationUrl(String destinationUrl) {
		this.destinationUrl = destinationUrl;
	}
	public String getSourceUrl() {
		return sourceUrl;
	}
	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}
	public String getTargetTemplate() {
		return targetTemplate;
	}
	public void setTargetTemplate(String targetTemplate) {
		this.targetTemplate = targetTemplate;
	}
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHideInNav() {
		return hideInNav;
	}
	public void setHideInNav(String hideInNav) {
		this.hideInNav = hideInNav;
	}
	public String getWebPM() {
		return webPM;
	}
	public void setWebPM(String webPM) {
		this.webPM = webPM;
	}
	public String getDmPM() {
		return dmPM;
	}
	public void setDmPM(String dmPM) {
		this.dmPM = dmPM;
	}
	public String getMigrationStatus() {
		return migrationStatus;
	}
	public void setMigrationStatus(String migrationStatus) {
		this.migrationStatus = migrationStatus;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
