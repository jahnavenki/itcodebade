package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.AssetManager;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.tagging.TagManager;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

import java.text.ParseException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

@Component(service = Servlet.class, immediate=true, property = {
    SLING_SERVLET_PATHS + "=/bin/ti/GalleryReportServlet", 
    SLING_SERVLET_METHODS + "=GET" })
public class GalleryReportServlet extends SlingSafeMethodsServlet  {
    protected static final Logger log = LoggerFactory.getLogger(FolderVideoServlet.class);

    @Reference
    private transient WCMComponents wcmService;

    private transient ResourceResolver resourceResolver;
    private static String EXCEL_PATH = "/content/dam/videos/";
    private TagManager tagManager;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        try {
            resourceResolver = request.getResourceResolver();
            final var session = resourceResolver.adaptTo(Session.class);
            if (null == session) throw new NullPointerException("session");
            final var queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
            if (null == queryBuilder) throw new NullPointerException("queryBuilder");
            final var folder = request.getParameter("folder");
            var jsonResponse = new JSONArray();
            var hasResults = false;
            String tagField = null;
            String taxonomyField = null;
            if ("product".equalsIgnoreCase(folder)) {
                tagField = "dam:tagsProducts";
                taxonomyField="product_ovw";
            } else if ("solution".equalsIgnoreCase(folder)) {
                tagField = "dam:tagsApplications";
                taxonomyField="mse_ovw";
            } else if ("tool".equalsIgnoreCase(folder)) {
                tagField = "dam:tagsTools";
                taxonomyField="oob";
            }
            final var predicates = new HashMap<String, String>();
            predicates.put("path", "/content/dam/videos/external-videos");
            predicates.put("type", "dam:Asset");
            predicates.put("1_property", "jcr:content/metadata/brc_id");
            predicates.put("1_property.operation", "exists");
            predicates.put("2_property", "jcr:content/metadata/dam:status");
            predicates.put("2_property.value", "published");
            predicates.put("3_property", "jcr:content/metadata/"+tagField);
            predicates.put("3_property.operation", "exists");
            predicates.put("4_property", "jcr:content/metadata/taxonomyField");
            predicates.put("4_property.value", taxonomyField);
            final var query = queryBuilder.createQuery(PredicateGroup.create(predicates), session);
            final var result = query.getResult();
            
            Map<String, List<Hit>> groupedResults = new HashMap<>();
            for (Hit hit : result.getHits()) {
                String queryPath = hit.getPath();
                Resource resource = resourceResolver.getResource(queryPath);
                if(resource!=null){
                    ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
                    String[] groupValues = map.get(tagField, String[].class);
                    for (String groupValue : groupValues) {
                        List<Hit> group = groupedResults.computeIfAbsent(groupValue, k -> new ArrayList<>());
                        group.add(hit);
                    } 
                }
            }
            
            for (Map.Entry<String, List<Hit>> entry : groupedResults.entrySet()) {
                String groupValue = entry.getKey();
                List<Hit> group = entry.getValue();
                Collections.sort(group,  new PublishedDateComparator());
                String path= group.get(group.size()-1).getPath();
                final var jsonObj = getJson(path,groupValue);
                if (null != jsonObj) { 
                    jsonResponse.put(jsonObj);
                    hasResults = true;
                }
            }
            if (hasResults) {
                exportToExcel(jsonResponse,folder);
                String message = "Folder created successfully ";
                response.setContentType("text/plain;charset=UTF-8");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(message);
            } else {
                String errorMessage = "No results found.";
                response.setContentType("text/plain;charset=UTF-8");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(errorMessage);
            }
        }
        catch (Exception ex) {
            log.error("Exception", ex);
        }
    }
    private JSONObject getJson(String path,String groupValue) throws JSONException {
        final var metadataRes = resourceResolver.getResource(path + "/jcr:content/metadata");
        if (null == metadataRes) {
            return null;
        }
        final var metadataMap = metadataRes.getValueMap();
        final var jsonObj = new JSONObject();
        tagManager = resourceResolver.adaptTo(TagManager.class);
        final var tag = tagManager.resolve(groupValue);
        if(null == tag) return null;
        String tagName=getTagName(groupValue);
        jsonObj.put("tag", tagName);
		jsonObj.put("id", metadataMap.get("brc_id", ""));
		jsonObj.put("toxonomy", metadataMap.get("taxonomyField", ""));
		return jsonObj;
    }

    private void exportToExcel(JSONArray data,String folder) throws IOException, JSONException {
        String fileName;
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Data");
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("id");
        headerRow.createCell(1).setCellValue("toxonomy");
        headerRow.createCell(2).setCellValue("folder");
        headerRow.createCell(3).setCellValue("Tag");
        for (int i = 0; i < data.length(); i++) {
            JSONObject jsonObject = data.getJSONObject(i);
            Row dataRow = sheet.createRow(i + 1);
            dataRow.createCell(0).setCellValue(jsonObject.getString("id"));
            dataRow.createCell(1).setCellValue(jsonObject.getString("toxonomy"));
            dataRow.createCell(2).setCellValue(folder);
            dataRow.createCell(3).setCellValue(jsonObject.getString("tag"));
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        byte[] byteArray = outputStream.toByteArray();
        InputStream inputStream = new ByteArrayInputStream(byteArray);
        AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);
        if (assetManager !=null) {
            fileName = "MultimediaGalleryReport_"+folder;
            assetManager.createAsset(EXCEL_PATH + fileName + ".xlsx", inputStream, "", true);
        }
        outputStream.close();
    }

    private static class PublishedDateComparator implements Comparator<Hit> {
        private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
        @Override
        public int compare(Hit hit1, Hit hit2) {
            Date publishedDate1 = getPublishedDate(hit1);
            Date publishedDate2 = getPublishedDate(hit2);
    
            if (publishedDate1 == null && publishedDate2 == null) {
                return 0;
            } else if (publishedDate1 == null) {
                return 1;
            } else if (publishedDate2 == null) {
                return -1;
            } else {
                return publishedDate1.compareTo(publishedDate2);
            }
        }
        private Date getPublishedDate(Hit hit) {
            try {
                Object publishedObj = hit.getProperties().get("dam:published");
                if (publishedObj instanceof String) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
                    return dateFormat.parse((String) publishedObj);
                }
            } catch (ParseException | RepositoryException e) {
                e.printStackTrace();
            }
            return null;
        }
    } 
    private  String getTagName(String tagId) {
        try {
            tagManager = resourceResolver.adaptTo(TagManager.class);
            final var tag = tagManager.resolve(tagId);
            if (null != tag) {
                final var tagTitle = tag.getTitle();
                return tagTitle;
            }
            
        } catch (Exception ex) {
            log.error("Exception", ex);
        }
        return null;
    }
}