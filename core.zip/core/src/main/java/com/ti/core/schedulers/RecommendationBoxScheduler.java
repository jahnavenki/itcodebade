package com.ti.core.schedulers;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.ti.core.components.HomePageFeaturedProducts;
import com.ti.core.service.WCMComponents;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Designate(ocd = RecommendationBoxScheduler.Config.class)
@Component(service = Runnable.class)

public class RecommendationBoxScheduler implements Runnable {
    private static final Logger log = LoggerFactory.getLogger(RecommendationBoxScheduler.class);
    private static final String JSON_PROPERTY = HomePageFeaturedProducts.JSON_PROPERTY;
    private static final String RESOURCE_NAME = HomePageFeaturedProducts.RESOURCE_NAME;
    private static final int MINIMUM_RECORDS = 1;

    @Reference
    private WCMComponents wcmService;

    @Reference
    private ResourceResolverFactory rrFactory;

    @Reference
    private SlingSettingsService slingSettings;

    @Reference
    Replicator replicator;

    private int schedulerID;

    @Reference
    protected Scheduler scheduler;

    @ObjectClassDefinition(name = "A Recommendation Box Scheduler", description = "Update the homepage featured products.")
    public @interface Config {
        @AttributeDefinition(name = "schedulerExpression", description = "Scheduler will apply the current renditions mappings for Next run time (in cron expression)")
        String scheduler_expression() default "0 1 0 * * ?";

        @AttributeDefinition(name = "Language Codes", description = "Language codes (Should be added in the osgi)", type = AttributeType.STRING)
        String[] languageCode() default {"de-de", "en-us", "ja-jp", "ko-kr", "zh-cn", "ru-ru", "zh-tw", "es-mx"};

        @AttributeDefinition(name = "Resource Parent Path", description = "Resource parent path ({language} is replaced with language code)", type = AttributeType.STRING)
        String resourceParentPath() default "/content/texas-instruments/{language}/homepage";

    }

    private String[] languageCode;

    public String[] getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String[] languageCode) {
        this.languageCode = languageCode;
    }
    private String resourceParentPath;

    @Activate
    public void activate(Config config) {
        this.languageCode = config.languageCode();
        this.resourceParentPath = config.resourceParentPath();
        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        addScheduler(config);
    }

    private void processLanguage(String language, ResourceResolver resourceResolver, Session jcrSession) {
        try {
            final JSONObject jsonResponse = wcmService.getHomePageFeaturedProducts(language);
            if (null == jsonResponse) throw new NullPointerException("jsonResponse");
            final JSONObject jsonFeaturedProductInfo = jsonResponse.getJSONObject("featuredProductInfo");
            final JSONArray jsonErrorList = jsonFeaturedProductInfo.getJSONArray("errorList");
            for (int i = 0; i < jsonErrorList.length(); ++i) {
                log.error("Error: {}", jsonErrorList.getString(i));
            }
            // remove error list before saving JSON (may contain sensitive info)
            jsonFeaturedProductInfo.remove("errorList");
            final JSONArray jsonPartNumberInformation = jsonFeaturedProductInfo.getJSONArray("partNumberInformation");
            if (jsonPartNumberInformation.length() < MINIMUM_RECORDS) {
                log.error("Received {} record(s), required {}", jsonPartNumberInformation.length(), MINIMUM_RECORDS);
                return;
            }
            final String value = jsonResponse.toString();
            final String parentPath = this.resourceParentPath.replace("{language}", language.toLowerCase());
            final Resource parentResource = resourceResolver.getResource(parentPath);
            if (null == parentResource) throw new NullPointerException("parentResource is null");
            Resource resource = resourceResolver.getResource(parentResource, RESOURCE_NAME);
            boolean hasChanges = false;
            if (null == resource) {
                Map<String, Object> properties = new HashMap<>();
                properties.put("jcr:primaryType", "nt:unstructured");
                resource = resourceResolver.create(parentResource, RESOURCE_NAME, properties);
                hasChanges = true;
            }
            final ModifiableValueMap valueMap = resource.adaptTo(ModifiableValueMap.class);
            if (null == valueMap) throw new NullPointerException("valueMap is null");
            final String oldValue = valueMap.containsKey(JSON_PROPERTY) ? valueMap.get(JSON_PROPERTY).toString() : null;
            if (!value.equals(oldValue)) {
                valueMap.put(JSON_PROPERTY, value);
                hasChanges = true;
            }
            if (hasChanges) {
                resourceResolver.commit();
                replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE, resource.getPath());
            }
        } catch (Exception ex) {
            log.error("processLanguage(" + language + ")", ex);
        }
    }
    @Modified
    protected void modified(RecommendationBoxScheduler.Config config) {

        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        removeScheduler();
        addScheduler(config);
    }
    @Deactivate
    protected void deactivate(RecommendationBoxScheduler.Config config) {
        removeScheduler();
    }

    /**
     * Remove a scheduler based on the scheduler ID
     */
    private void removeScheduler() {
        log.debug("Removing Scheduler Job '{}'", schedulerID);
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    /**
     * Add a scheduler based on the scheduler ID
     */
    private void addScheduler(RecommendationBoxScheduler.Config config) {
        ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
        sopts.name(String.valueOf(schedulerID));
        sopts.canRunConcurrently(false);
        scheduler.schedule(this, sopts);
        log.debug("Scheduler added succesfully");
    }
    @Override
    public void run() {
        try {
            if (null == slingSettings) return;
            final Set<String> runModes = slingSettings.getRunModes();
            if (null == runModes || !runModes.contains("author") || null == languageCode) return;
            final Map<String, Object> authInfo = new HashMap<>();
            authInfo.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            try (final ResourceResolver resourceResolver = rrFactory.getServiceResourceResolver(authInfo)) {
                Session jcrSession = resourceResolver.adaptTo(Session.class);
                for (final String language : languageCode) {
                    processLanguage(language, resourceResolver, jcrSession);
                }
            }
        } catch (Exception e) {
            log.error("Exception", e);
        }
    }
}
