/*
 * #%L
 * ACS AEM Commons Bundle
 * %%
 * Copyright (C) 2014 Adobe
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
package com.ti.core.service.impl;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.PageManager;
import com.ti.core.util.PathBrowserHelper;

/**
 * Site Map Servlet - ACS AEM Commons Bundle Removed the Externalizer and used
 * the Path Browser Util to return the current domain
 * 
 * @author saryu.sukumar
 *
 */

@Component(service = Servlet.class, configurationPolicy = ConfigurationPolicy.REQUIRE, property = {
		SLING_SERVLET_RESOURCE_TYPES + "=sling/servlet/default", SLING_SERVLET_EXTENSIONS + "=xml",
		SLING_SERVLET_METHODS + "=GET", SLING_SERVLET_SELECTORS + "=sitemap",
		"webconsole.configurationFactory.nameHint" + "="
				+ "Site Map for: {externalizer.domain}, on resource types: [{sling.servlet.resourceTypes}]" })
@Designate(ocd = SiteMapServlet.Config.class, factory=true)
@SuppressWarnings("serial")
public final class SiteMapServlet extends SlingSafeMethodsServlet {

	private static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance("yyyy-MM-dd");

	private static final boolean DEFAULT_EXTENSIONLESS_URLS = false;

	private static final boolean DEFAULT_REMOVE_TRAILING_SLASH = false;

	private static final boolean DEFAULT_INCLUDE_LAST_MODIFIED = false;

	private static final boolean DEFAULT_INCLUDE_INHERITANCE_VALUE = false;

	private static final String DEFAULT_EXTERNALIZER_DOMAIN = "publish";

	private static final String PROP_CHANGE_FREQUENCY = "changefreq";
	private static final String PROP_PRIORITY = "priority";

	@ObjectClassDefinition(name = "TI - Site Map Servlet", description = "Page and Asset Site Map Servlet")
	public @interface Config {

		@AttributeDefinition(name = "Sling Resource Type", description = "Sling Resource Type for the Home Page component or components.", type = AttributeType.STRING )
		String[] sling_servlet_resourceType();

		@AttributeDefinition( name = "Externalizer Domain", description = "Must correspond to a configuration of the Externalizer component.", type = AttributeType.STRING)
		String externalizer_domain() default DEFAULT_EXTERNALIZER_DOMAIN;

		@AttributeDefinition( name = "Include Last Modified", description = "If true, the last modified value will be included in the sitemap.", type = AttributeType.BOOLEAN)
		boolean include_lastmod() default  DEFAULT_INCLUDE_LAST_MODIFIED;

		@AttributeDefinition(name = "Change Frequency Properties", description = "The set of JCR property names which will contain the change frequency value.", type = AttributeType.STRING)
		String[] changefreq_properties();

		@AttributeDefinition(name = "Priority Properties", description = "The set of JCR property names which will contain the priority value.", type = AttributeType.STRING)
		String[] priority_properties();

		@AttributeDefinition(name = "DAM Folder Property", description = "The JCR property name which will contain DAM folders to include in the sitemap.", type = AttributeType.STRING)
		String damassets_property();

		@AttributeDefinition(name = "DAM Asset MIME Types", description = "MIME types allowed for DAM assets.", type = AttributeType.STRING)
		String[] damassets_types();

		@AttributeDefinition( name = "Exclude from Sitemap Property", description = "The boolean [cq:Page]/jcr:content property name which indicates if the Page should be hidden from the Sitemap. Default value: hideInNav", type = AttributeType.STRING)
		String exclude_property() default NameConstants.PN_HIDE_IN_NAV;

		@AttributeDefinition( name = "Include Inherit Value", description = "If true searches for the frequency and priority attribute in the current page if null looks in the parent.", type = AttributeType.BOOLEAN)
		boolean include_inherit() default DEFAULT_INCLUDE_INHERITANCE_VALUE;

		@AttributeDefinition( name = "Extensionless URLs", description = "If true, page links included in sitemap are generated without .html extension and the path is included with a trailing slash, e.g. /content/geometrixx/en/.", type = AttributeType.BOOLEAN)
		boolean extensionless_urls() default DEFAULT_EXTENSIONLESS_URLS;

		@AttributeDefinition( name = "Remove Trailing Slash from Extensionless URLs", description = "Only relevant if Extensionless URLs is selected.  If true, the trailing slash is removed from extensionless page links, e.g. /content/geometrixx/en.", type = AttributeType.BOOLEAN)
		boolean remove_slash() default DEFAULT_REMOVE_TRAILING_SLASH;

		@AttributeDefinition(name = "Character Encoding", description = "If not set, the container's default is used (ISO-8859-1 for Jetty)", type = AttributeType.STRING)
		String character_encoding();
	}

	private static final String DEFAULT_ENCODING = "UTF-8";

	private static final String NS = "http://www.sitemaps.org/schemas/sitemap/0.9";



	private boolean includeInheritValue;

	private boolean includeLastModified;

	private String[] changefreqProperties;

	private String[] priorityProperties;

	private String damAssetProperty;

	private List<String> damAssetTypes;

	private String excludeFromSiteMapProperty;

	private String characterEncoding;

	

	private static final Logger log = LoggerFactory.getLogger(SiteMapServlet.class);

	private String currentDomain;

	@Activate
	protected void activate(Config config) {
		

		
		this.includeLastModified = config.include_lastmod();
		this.includeInheritValue = config.include_inherit();
		this.changefreqProperties = config.changefreq_properties() == null ? ArrayUtils.EMPTY_STRING_ARRAY
				: config.changefreq_properties();
		this.priorityProperties = config.priority_properties() == null ? ArrayUtils.EMPTY_STRING_ARRAY
				: config.priority_properties();
		this.damAssetProperty = config.damassets_property() == null ? StringUtils.EMPTY : config.damassets_property();
		this.damAssetTypes = config.damassets_types() == null ? Collections.emptyList()
				: Arrays.asList(config.damassets_types());
		this.excludeFromSiteMapProperty = config.exclude_property();
		this.characterEncoding = config.character_encoding();

	}

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType(request.getResponseContentType());
		if (StringUtils.isNotBlank(characterEncoding)) {
			response.setCharacterEncoding(characterEncoding);
		} else {
			response.setCharacterEncoding(DEFAULT_ENCODING);
		}
		ResourceResolver resourceResolver = request.getResourceResolver();
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page page = null != pageManager ? pageManager.getContainingPage(request.getResource()) : null;

		// Read the current domain
		try {
			URI currentUri = new URI(request.getRequestURL().toString());
			log.debug("Request URL: {}", currentUri);
			currentDomain = currentUri.getHost();
			log.debug("Current Domain: {}", currentDomain);
		} catch (URISyntaxException e1) {
			log.error("URISyntaxException: ", e1);
		}

		XMLOutputFactory outputFactory = XMLOutputFactory.newFactory();
		try {
			XMLStreamWriter stream = outputFactory.createXMLStreamWriter(response.getWriter());
			stream.writeStartDocument("1.0");

			stream.writeStartElement("", "urlset", NS);
			stream.writeNamespace("", NS);

			// first do the current page
			write(page, stream, resourceResolver);

			for (Iterator<Page> children = page.listChildren(new PageFilter(false, true), true); children.hasNext();) {
				write(children.next(), stream, resourceResolver);
			}

			if (!damAssetTypes.isEmpty() && !damAssetProperty.isEmpty()) {
				for (Resource assetFolder : getAssetFolders(page, resourceResolver)) {
					writeAssets(stream, assetFolder, resourceResolver);
				}
			}

			stream.writeEndElement();

			stream.writeEndDocument();
		} catch (XMLStreamException e) {
			throw new IOException(e);
		}
	}

	private Collection<Resource> getAssetFolders(Page page, ResourceResolver resolver) {
		List<Resource> allAssetFolders = new ArrayList<>();
		ValueMap properties = page.getProperties();
		String[] configuredAssetFolderPaths = properties.get(damAssetProperty, String[].class);
		if (configuredAssetFolderPaths != null) {
			// Sort to aid in removal of duplicate paths.
			Arrays.sort(configuredAssetFolderPaths);
			String prevPath = "#";
			for (String configuredAssetFolderPath : configuredAssetFolderPaths) {
				// Ensure that this folder is not a child folder of another
				// configured folder, since it will already be included when
				// the parent folder is traversed.
				if (StringUtils.isNotBlank(configuredAssetFolderPath) && !configuredAssetFolderPath.equals(prevPath)
						&& !StringUtils.startsWith(configuredAssetFolderPath, prevPath + "/")) {
					Resource assetFolder = resolver.getResource(configuredAssetFolderPath);
					if (assetFolder != null) {
						prevPath = configuredAssetFolderPath;
						allAssetFolders.add(assetFolder);
					}
				}
			}
		}
		return allAssetFolders;
	}

	private void write(Page page, XMLStreamWriter stream, ResourceResolver resourceResolver) throws XMLStreamException {
		if (isHidden(page)) {
			return;
		}
		stream.writeStartElement(NS, "url");
		String path = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, page.getPath());
		String loc = "";
		log.debug("Path: {}", path);
		try {
			URI uriPath = new URI(path);
			if (log.isDebugEnabled())
				log.debug("URI Path: {}", uriPath);
			loc = uriPath.toString();
		} catch (URISyntaxException e) {
			log.error("MalformedURLException: ", e);
		}
		log.debug("Replaced resolver map to current domain: {}", loc);
		writeElement(stream, "loc", loc);

		if (includeLastModified) {
			Calendar cal = page.getLastModified();
			if (cal != null) {
				writeElement(stream, "lastmod", DATE_FORMAT.format(cal));
			}
		}

		if (includeInheritValue) {
			HierarchyNodeInheritanceValueMap hierarchyNodeInheritanceValueMap = new HierarchyNodeInheritanceValueMap(
					page.getContentResource());
			writeFirstPropertyValue(stream, PROP_CHANGE_FREQUENCY, changefreqProperties,
					hierarchyNodeInheritanceValueMap);
			writeFirstPropertyValue(stream, PROP_PRIORITY, priorityProperties, hierarchyNodeInheritanceValueMap);
		} else {
			ValueMap properties = page.getProperties();
			writeFirstPropertyValue(stream, PROP_CHANGE_FREQUENCY, changefreqProperties, properties);
			writeFirstPropertyValue(stream, PROP_PRIORITY, priorityProperties, properties);
		}

		stream.writeEndElement();
	}

	private boolean isHidden(final Page page) {
		return page.getProperties().get(this.excludeFromSiteMapProperty, false);
	}

	private void writeAsset(Asset asset, XMLStreamWriter stream, ResourceResolver resourceResolver)
			throws XMLStreamException {
		stream.writeStartElement(NS, "url");

		String path = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, asset.getPath());
		String loc = "";
		log.debug("Path: {}", path);
		try {
			URI uriPath = new URI(path);
			if (log.isDebugEnabled())
				log.debug("URI Path: {}", uriPath);
			loc = uriPath.toString().replace(uriPath.getHost(), currentDomain);
			log.debug("Replaced resolver map to current domain: {}", loc);
		} catch (URISyntaxException e) {
			log.error("MalformedURLException: ", e);
		}
		writeElement(stream, "loc", loc);

		if (includeLastModified) {
			long lastModified = asset.getLastModified();
			if (lastModified > 0) {
				writeElement(stream, "lastmod", DATE_FORMAT.format(lastModified));
			}
		}

		Resource parentResource = asset.adaptTo(Resource.class);
		if (parentResource != null) {

			Resource contentResource = parentResource.getChild(JcrConstants.JCR_CONTENT);
			if (contentResource != null) {
				if (includeInheritValue) {
					HierarchyNodeInheritanceValueMap hierarchyNodeInheritanceValueMap = new HierarchyNodeInheritanceValueMap(
							contentResource);
					writeFirstPropertyValue(stream, PROP_CHANGE_FREQUENCY, changefreqProperties,
							hierarchyNodeInheritanceValueMap);
					writeFirstPropertyValue(stream, PROP_PRIORITY, priorityProperties,
							hierarchyNodeInheritanceValueMap);
				} else {
					ValueMap properties = contentResource.getValueMap();
					writeFirstPropertyValue(stream, PROP_CHANGE_FREQUENCY, changefreqProperties, properties);
					writeFirstPropertyValue(stream, PROP_PRIORITY, priorityProperties, properties);
				}
			}
		}
		stream.writeEndElement();
	}

	private void writeAssets(final XMLStreamWriter stream, final Resource assetFolder,
			final ResourceResolver resourceResolver) throws XMLStreamException {
		for (Iterator<Resource> children = assetFolder.listChildren(); children.hasNext();) {
			Resource assetFolderChild = children.next();
			if (assetFolderChild.isResourceType(DamConstants.NT_DAM_ASSET)) {
				Asset asset = assetFolderChild.adaptTo(Asset.class);

				if (null != asset && damAssetTypes.contains(asset.getMimeType())) {
					writeAsset(asset, stream, resourceResolver);
				}
			} else {
				writeAssets(stream, assetFolderChild, resourceResolver);
			}
		}
	}

	private void writeFirstPropertyValue(final XMLStreamWriter stream, final String elementName,
			final String[] propertyNames, final ValueMap properties) throws XMLStreamException {
		for (String prop : propertyNames) {
			String value = properties.get(prop, String.class);
			if (value != null) {
				writeElement(stream, elementName, value);
				break;
			}
		}
	}

	private void writeFirstPropertyValue(final XMLStreamWriter stream, final String elementName,
			final String[] propertyNames, final InheritanceValueMap properties) throws XMLStreamException {
		for (String prop : propertyNames) {
			String value = properties.get(prop, String.class);
			if (value == null) {
				value = properties.getInherited(prop, String.class);
			}
			if (value != null) {
				writeElement(stream, elementName, value);
				break;
			}
		}
	}

	private void writeElement(final XMLStreamWriter stream, final String elementName, final String text)
			throws XMLStreamException {
		stream.writeStartElement(NS, elementName);
		stream.writeCharacters(text);
		stream.writeEndElement();
	}

}