package com.ti.core.util;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.SlingHttpServletRequest;
import javax.jcr.Node;
import javax.jcr.Session;
import javax.jcr.security.AccessControlManager;
import javax.jcr.security.Privilege;

import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.replication.Replicator;
import com.day.cq.replication.ReplicationStatus;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * LanguageUtils WCMUsePojo.
 *
 */
public class JcrUtils extends WCMUsePojo {
	private static final Logger log = LoggerFactory.getLogger(JcrUtils.class);
	
	private Node currentNode;
	private String nodePath;
	private Boolean nodePathExists; 
	private Session jcrSession;
	
	@Override
	public void activate() {
		try {
			SlingHttpServletRequest request = getRequest();
			if (request == null)
				return;

			// If node path is provided as parameter, attempt to get node from path 
			nodePath = get("nodePath", String.class);			
			nodePathExists = false;
			if (nodePath != null) {
				Resource res = getResourceResolver().getResource(nodePath);
				if (res != null) {
					currentNode = res.adaptTo(Node.class);
					nodePathExists = true;
				}
			}

			// If node path is not provided, or attempt to get node from path failed, the current node is default
			if (currentNode == null)
				currentNode = request.getResource().adaptTo(Node.class);

			// Get JCR session object from node
			if (currentNode != null) {
				nodePath = currentNode.getPath();
				jcrSession = currentNode.getSession();
			}
		}
		catch (Exception e) {
			log.error("Error in JcrUtils.activate()", e);
		}
	}

  /**
   * Attempts to returns resource for node specified, if available 
   * 
   * @return resource specified by the node.  Null possible.
   */	
	public Resource getRes() {
		try {
			return getResourceResolver().getResource(nodePath);
		}
		catch (Exception e) {
			log.error("Error in JcrUtils.getRes", e);
		}
		return null;
	}
	
  /**
   * Returns true if user provided a "nodePath" parameter, *and* the nodePath resolves to a valid node (not 404) 
   * 
   * @return true if user has publish rights in the current resource node
   */
	public Boolean nodePathExists() {
		return nodePathExists;
	}
	
  /**
   * Returns true if user has publish rights in the current resource node
   * 
   * @return true if user has publish rights in the current resource node
   */
	public boolean canPublishNode() {
		try {
			if (jcrSession != null && !StringUtils.isEmpty(nodePath)) {
				AccessControlManager acMgr = jcrSession.getAccessControlManager();
				return jcrSession.getAccessControlManager().hasPrivileges(nodePath, new Privilege[] {acMgr.privilegeFromName(Replicator.REPLICATE_PRIVILEGE)});
			}
		}
		catch (Exception e) {
			log.error("Error in JcrUtils.canPublishNode", e);
		}
		return false;
	}	

  /**
   * Returns true if node is published.  (Note: authoring site you need to check for Replication Status, but on published site only check for its existence)
   * 
   * @return true if node is published
   */
	public boolean isNodePublished() {
		try {
			Resource res = getResourceResolver().getResource(nodePath);
			if (res != null) {
				if (this.getWcmMode().isDisabled())
					return true;
				else {
					ReplicationStatus replicationStatus;
					replicationStatus = res.adaptTo(ReplicationStatus.class);
					return (replicationStatus != null && replicationStatus.isActivated()); 
				}
			}				
		}
		catch (Exception e) {
			log.error("Error in JcrUtils.isNodePublished", e);
		}
		return false;
	}	

  /**
   * Returns true if node is expired (prism:expirationDate is not null and it is earlier than current time)
   * 
   * @return true if node is expired
   */
	public boolean isNodeExpired() {
		try {
			Resource res = getResourceResolver().getResource(nodePath);
			if (res != null)
				return DamUtil.isExpiredAsset(res);
		}
		catch (Exception e) {
			log.error("Error in JcrUtils.isNodeExpired", e);
		}
		return false;
	}
}