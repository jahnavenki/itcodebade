package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// TODO: Auto-generated Javadoc
/**
 * The Class WSApiWrapper.
 *
 * @author Richard Chan This is a proxy/passthrough wrapper servlet for http://www.ti.com/wsapi
 *         service calls. Note: this is a makeshift solution to resolve cross-domain ajax issues. Do
 *         not use if you do not experience cross-domain issues.

@SuppressWarnings("serial")
@SlingServlet(paths = { "/bin/ti/wsapi" })
 */
@Component(immediate=true, service = Servlet.class, property = {
		SLING_SERVLET_PATHS + "=/bin/ti/wsapi", 
		SLING_SERVLET_METHODS + "=GET" })
public class WSApiWrapper extends SlingSafeMethodsServlet {
  private static final String PARAM_API = "api";
  private static final String PARAMDATA_FAMILY_URL = 
      "!!domain!!/wsapi/paramdata/family/!!familyId!!/!!type!!?lang=!!lang!!&output=json";

  /** The log. */
  private static final Logger log = LoggerFactory.getLogger(WSApiWrapper.class);

  /*
   * (non-Javadoc)
   *
   * @see org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
   * sling.api.SlingHttpServletRequest, org.apache.sling.api.SlingHttpServletResponse)
   */
  @Override
  protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
      throws ServletException, IOException {

    processRequest(request, response);
  }

  private void processRequest(SlingHttpServletRequest request, SlingHttpServletResponse response)
      throws ServletException, IOException {
    try {

      // /wsapi/paramdata/
      if ("paramdata".equals(request.getParameter(PARAM_API))) {
        Integer familyId = Integer.parseInt(request.getParameter("familyid"));
        String dataType = request.getParameter("type");
        String domain = "http://www.ti.com";
        String lang = "en";

        if (familyId > 0 && ("criteria".equals(dataType) || "results".equals(dataType))) {
          HttpURLConnection connection = null;

          String url = PARAMDATA_FAMILY_URL.replace("!!domain!!", domain)
              .replace("!!familyId!!", familyId.toString()).replace("!!type!!", dataType)
              .replace("!!lang!!", lang);
          URL newUrl = new URL(url);

          log.debug(" WSApi URL =" + url);

          connection = (HttpURLConnection) newUrl.openConnection();
          connection.setDoOutput(true);
          connection.setRequestMethod("GET");

          String result = readStream(connection.getInputStream());

          response.setContentType("text/x-json;charset=UTF-8");
          response.getWriter().write(result);
        }
      }
    } catch (Exception e) {
      log.error("Error in WSApiWrapper: ", e);
    }
  }

  private String readStream(InputStream inputStream) {
    StringBuilder sb = new StringBuilder();
    try {
      BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
      String nextLine = "";
      while ((nextLine = reader.readLine()) != null) {
        sb.append(nextLine);
      }
    } catch (IOException e) {
      log.error("IO Exception: " + e);
    }
    return sb.toString();
  }
}