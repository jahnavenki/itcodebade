package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = { SlingHttpServletRequest.class, Resource.class },
	resourceType = TabbedTable.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class TabbedTable {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/tabbedTable";

	@ChildResource
	private Collection<TabbedTableTab> tabs;

	@PostConstruct
	public void init(){
		try {
			tabs = CollectionUtils.emptyIfNull(tabs);
		} catch (Exception e) {
			log.error("Exception in TabbedTable", e);
		}
	}

	public Collection<TabbedTableTab> getTabs() {
		return tabs;
	}
}
