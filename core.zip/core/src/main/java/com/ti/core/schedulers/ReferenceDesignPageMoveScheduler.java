package com.ti.core.schedulers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.commons.ReferenceSearch;

/**
 * This scheduler will move the old reference design page to new reference
 * design page and delete the old node
 */
@Component(name="ReferenceDesignPageMoveScheduler", 
service = {  Runnable.class }, property = { "schedulerExpression=", "name=Cron-job expression",
"description=example 0 0 12 1/1 * ? *  for every day at midnight" })
@Designate(ocd=ReferenceDesignPageMoveScheduler.Config.class)
public class ReferenceDesignPageMoveScheduler implements Runnable {

	private final Logger log = LoggerFactory.getLogger(getClass());
	private static final String REFERENCE_DESIGN_SUB_TAB = "reference-designs/reference-designs-selection";
	private static final String JCR_CONTENT = "jcr:content";
	private static final String REFERENCE_DESIGN = "reference-designs-selection";
	private static final String REFERENCE_DESIGN_COMPONENT = "ti/components/referenceDesignSelection";
	private static final String POWER_DESIGN_COMPONENT = "ti/components/powerReferenceDesignSelectionTool";
	private static final String NAV_TITLE = "navTitle";
	private static final String JCR_TITLE = "jcr:title";

	@Reference
	private ResourceResolverFactory resourceFactory;

	@Reference
	Replicator replicator;
	
	@ObjectClassDefinition(name = "A Reference Design Page Move Scheduler ", description = "This scheduler will move the old reference design page to new reference design page and delete the old node")
	public @interface Config {

		@AttributeDefinition(
							name = "Reference Design Query", description = "Reference Design Query description", type = AttributeType.STRING )
		String selectQuery() default "SELECT * FROM [nt:unstructured] AS s WHERE ISDESCENDANTNODE([/content/texas-instruments/en-us/applications/industrial/appliances/reference-designs]) and s.[sling:resourceType]='ti/components/referenceDesignSelection'";
		@AttributeDefinition( name = "Delete Node and Publish Page", description = "Checking this checkbox will exclude the move operation and remove the old reference design and power design component from the page and publish the pages)", type = AttributeType.STRING )
		boolean deleteAndPubishPage() default false;

	}
	
	private String selectQuery;

		private boolean deleteAndPubishPage;

	@Activate
	public void activate(Config config) {
		this.selectQuery = config.selectQuery();
		this.deleteAndPubishPage = config.deleteAndPubishPage();
	}

	@Override
	public void run() {
		if (this.deleteAndPubishPage) {
			log.debug("\n\n inside delete and publish");
			deleteAndPublishPage();
		} else {
			log.debug("\n\n inside page move");
			int pagesModified = moveReferenceDesignPages();
			log.debug("\n\n Total pages modified : " + pagesModified);
		}
	}

	/**
	 * This function is used to move the child reference design nodes to parent,
	 * delete the old node and rename the newly copied node to reference design
	 * .This method also updates the references of the deleted nodes.
	 * 
	 * @return - int
	 */
	public int moveReferenceDesignPages() {
		int pageCount = 0;
		try {

			String path = null;
			ResourceResolver resourceResolver;
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = resourceFactory.getServiceResourceResolver(param);
			String parentNavTitle = null;
			String parentJcrTitle = null;
			Session session = resourceResolver.adaptTo(Session.class);

			String destination = null;

			String queryString = this.selectQuery;

			QueryManager queryManager = session.getWorkspace().getQueryManager();

			Query query = queryManager.createQuery(queryString, Query.JCR_SQL2);

			QueryResult result = query.execute();
			NodeIterator nodes = result.getNodes();
			String parentReferenceDesign = null;
			while (nodes.hasNext()) {
				Node node = nodes.nextNode();
				path = node.getPath();
				log.debug("\n\n path >>>>>>>>>>>>>>> " + path);
				path = path.substring(0, path.indexOf(JCR_CONTENT));
				if (null != resourceResolver) {

					replicator.replicate(session, ReplicationActionType.DEACTIVATE, path);

					if (path.contains(REFERENCE_DESIGN_SUB_TAB)) {
						parentReferenceDesign = path.substring(0, path.indexOf(REFERENCE_DESIGN)) + JCR_CONTENT;
						log.debug("\n\n parentReferenceDesign >>>>>>>>>>>>>>> " + parentReferenceDesign);
						Resource currentResource = resourceResolver.getResource(parentReferenceDesign);
						if (null != currentResource) {
							Node currentNode = currentResource.adaptTo(Node.class);
							destination = path.substring(0, path.indexOf(REFERENCE_DESIGN_SUB_TAB));
							if (null != currentNode) {
								parentNavTitle = currentNode.getProperty(NAV_TITLE).getValue().getString();
								log.debug("\n\n parentNavTitle >>>>>>>>>>>>>>> " + parentNavTitle);
								parentJcrTitle = currentNode.getProperty(JCR_TITLE).getValue().getString();
								log.debug("\n\n parentJcrTitle >>>>>>>>>>>>>>> " + parentJcrTitle);
							}
						}
						PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
						if (null != pageManager) {
							Page page = pageManager.getPage(path);
							log.debug("\n\n before move : " + page.getPath());
							log.debug("\n\n page.getName() :" + page.getName());
							log.debug("\n\n after move :" + destination + page.getName());

							String[] references = getPageRefPaths(page.getPath(), resourceResolver);

							Page newPageAfterMove = pageManager.move(page, destination + page.getName(), page.getName(),
									false, false, references);
							if (newPageAfterMove != null) {
								log.debug("\n\n  moved page" + newPageAfterMove.getPath());
								log.debug("\n\n  page to be deleted" + destination + page.getParent().getName());
								String renamedPageName = page.getParent().getName();
								Page pageToDelete = pageManager.getPage(destination + page.getParent().getName());
								pageManager.delete(pageToDelete, false, true);
								Page pageToRename = pageManager.getPage(newPageAfterMove.getPath());
								log.debug("\n\n  page to be renamed" + pageToRename.getPath());
								log.debug("\n\n  renamedPageName" + renamedPageName);
								if (pageToRename != null) {
									Thread.sleep(10000);
									log.debug("\n\n  page3 is not null" + destination + renamedPageName);
									String[] renamedReferences = getPageRefPaths(pageToRename.getPath(),
											resourceResolver);
									Page renamedPage = pageManager.move(pageToRename, destination + renamedPageName,
											renamedPageName, false, false, renamedReferences);
									if (null != renamedPage) {
										log.debug("\n\n  renamed page" + renamedPage.getPath());
										currentResource = resourceResolver
												.getResource(renamedPage.getPath() + "/" + JCR_CONTENT);
										if (null != currentResource) {
											Node newNode = currentResource.adaptTo(Node.class);
											if (null != newNode) {
												newNode.setProperty(NAV_TITLE, parentNavTitle);
												newNode.setProperty(JCR_TITLE, parentJcrTitle);
												newNode.getSession().refresh(true);
												newNode.getSession().save();
											}
										}
									}
								}
							}

						}
					}

				}
				pageCount++;
				log.debug("pageCount >>" + pageCount);
			}

		} catch (Exception e) {
			log.error("exception >>" + e);
			pageCount = 0;
		}
		return pageCount;
	}

	/**
	 * This function is used to delete the old reference design and power design
	 * component from the reference design and power design pages
	 * 
	 */
	public void deleteAndPublishPage() {

		try {
			ResourceResolver resourceResolver;
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = resourceFactory.getServiceResourceResolver(param);
			Session session = resourceResolver.adaptTo(Session.class);
			String queryString = this.selectQuery;

			QueryManager queryManager = session.getWorkspace().getQueryManager();
			Query query = queryManager.createQuery(queryString, Query.JCR_SQL2);
			QueryResult result = query.execute();
			NodeIterator nodes = result.getNodes();

			while (nodes.hasNext()) {
				Node node = nodes.nextNode();
				String jcrProperty = (String) node.getProperty("sling:resourceType").getValue().getString();
				String path = node.getPath();
				if (jcrProperty.equals(REFERENCE_DESIGN_COMPONENT) || jcrProperty.equals(POWER_DESIGN_COMPONENT)) {
					node.remove();
				}
				log.debug("\n\n path >>" + path);
				Session jcrSession = resourceResolver.adaptTo(Session.class);
				replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE,
						path.substring(0, path.indexOf(JCR_CONTENT)));
			}
		} catch (Exception e) {
			log.error("Exception >>" + e);
		}

	}

	/**
	 * This static function and be used to get the references for a given page
	 * 
	 * @param path
	 *            - parameter
	 * @param resolver
	 *            - parameter
	 * @return Array
	 */

	public String[] getPageRefPaths(String path, ResourceResolver resolver) {

		final ReferenceSearch referenceSearch = new ReferenceSearch();
		referenceSearch.setExact(false);
		referenceSearch.setHollow(false);
		referenceSearch.setMaxReferencesPerPage(-1);
		List<String> refPaths = new ArrayList<>();
		referenceSearch.search(resolver, path).entrySet().forEach(foundRef -> {
			refPaths.add(foundRef.getValue().getPagePath());
			log.debug("\n\n Reference  >>>>" + foundRef.getValue().getPagePath());
		});

		return refPaths.toArray(new String[refPaths.size()]);

	}

	public String getSelectQuery() {
		return selectQuery;
	}

	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}

	public boolean isDeleteAndPubishPage() {
		return deleteAndPubishPage;
	}

	public void setDeleteAndPubishPage(boolean deleteAndPubishPage) {
		this.deleteAndPubishPage = deleteAndPubishPage;
	}

}