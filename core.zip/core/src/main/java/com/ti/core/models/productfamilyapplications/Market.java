package com.ti.core.models.productfamilyapplications;

import java.util.List;

public class Market {
  
  private String marketId;
  private String marketName;
  private String anchorId;
  private List<Sector> sectorList;
  private String contentFragment;
  private String marketImagePath;
  private String marketImageAltText;
  
  public String getMarketId() {
    return marketId;
  }
  
  public void setMarketId(String marketId) {
    this.marketId = marketId;
  }
  
  public String getMarketName() {
    return marketName;
  }
  
  public void setMarketName(String marketName) {
    this.marketName = marketName;
  }
  
  public String getAnchorId() {
    return anchorId;
  }
  
  public void setAnchorId(String anchorId) {
    this.anchorId = anchorId;
  }
  
  public List<Sector> getSectorList() {
    return sectorList;
  }
  
  public void setSectorList(List<Sector> sectorList) {
    this.sectorList = sectorList;
  }

  public String getContentFragment() {
    return contentFragment;
  }
  
  public void setContentFragment(String contentFragment) {
    this.contentFragment = contentFragment;
  }
  
  public String getMarketImagePath() {
    return marketImagePath;
  }
  
  public void setMarketImagePath(String marketImagePath) {
    this.marketImagePath = marketImagePath;
  }

public String getMarketImageAltText() {
	return marketImageAltText;
}

public void setMarketImageAltText(String marketImageAltText) {
	this.marketImageAltText = marketImageAltText;
}
  
  
}
