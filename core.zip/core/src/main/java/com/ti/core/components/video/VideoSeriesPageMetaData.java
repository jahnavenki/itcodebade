package com.ti.core.components.video;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.LanguageUtils;

public class VideoSeriesPageMetaData extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(VideoSeriesPageMetaData.class);
	
    private static final String VIDEO_TITLE_DESCRIPTION = "videoTitleAndDescription";
    private static final String SERIES_TITLE = "title";
    private static final String SERIES_DESCRIPTION = "description";
    private String browserTitle;
    private String metaDescription;
    private String keywords;
    private String videoTitle;

	public String getBrowserTitle() {
		return browserTitle;
	}

	public String getMetaDescription() {
		return metaDescription;
	}

	public String getKeywords() {
		return keywords;
	}

    public String getVideoTitle() {
        return videoTitle;
    }
	
	@Override
    public void activate() throws Exception {
	    try {
            String language = "en-us";
            final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                    ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                language = tabsService.getPageLanguage(getCurrentPage());
            }
            Page page = getCurrentPage();
            Resource videoTitleAndDescription = null;
            if(page != null) {
                //get Video title and description component on page
                videoTitleAndDescription = page.getContentResource(VIDEO_TITLE_DESCRIPTION);
            }
            if(videoTitleAndDescription == null)
                return;
            setVideoSeriesMetaData(videoTitleAndDescription,language); 
            final var map = getInitialVideoMetadata(getResource());
            videoTitle = map.get("dc:title", "");
        }catch (Exception e) {
            log.error("Error setting video series page meta data: ", e);
        }       
    }

    private Resource getFirstChild(Resource res) {
        if (null == res) return null;
        final var iter = res.getChildren().iterator();
        if (!iter.hasNext()) return null;
        return iter.next();
    }

    private ValueMap getInitialVideoMetadata(Resource currentResource) {
        final var videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            log.debug("Video config null or Path not found");
            return ValueMap.EMPTY;
        }
        final var topicsList = currentResource.getChild("videoSeriesNavigation/topics");
        if (null == topicsList) return ValueMap.EMPTY;
        final var topic = getFirstChild(topicsList);
        if (null == topic) return ValueMap.EMPTY;
        final var videosList = topic.getChild("videosList");
        if (null == videosList) return ValueMap.EMPTY;
        final var video = getFirstChild(videosList);
        if (null == video) return ValueMap.EMPTY;
        final var map = video.adaptTo(ValueMap.class);
        if (null == map) return ValueMap.EMPTY;
        final var videoId = map.get("videoId", String.class);
        final var damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
        if (null == damRes) return ValueMap.EMPTY;
        final var metadata = damRes.getChild("jcr:content/metadata");
        if (null == metadata) return ValueMap.EMPTY;
        final var ret = metadata.adaptTo(ValueMap.class);
        if (null == ret) return ValueMap.EMPTY;
        return ret;
    }
    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = <Series Title> + “|” + “TI.com”
			   For CN, it should be <Series Title> + “|” + “TI.com.cn”
            2. Meta description = First 160 characters of series description. 
               If description exceeds 160 characters, it should be cut-off and followed by an ellipses.
            3. Keywords: <Series Title> , "video series", "video tutorials"

    */
    private void setVideoSeriesMetaData(Resource videoTitleAndDescription, String language) {
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        ValueMap map = videoTitleAndDescription.getValueMap();
        String seriesTitle = map.get(SERIES_TITLE).toString();
        seriesTitle = replaceHtmlTags(seriesTitle);
        if("zh-cn".equals(language)) {
            browserTitle = seriesTitle + " | TI.com.cn";
        } else {
            browserTitle = seriesTitle + " | TI.com";
        }
        keywords = seriesTitle + ","+ langUtils.getI18nStr("video series") +","+langUtils.getI18nStr("video tutorials"); 
        metaDescription = map.get(SERIES_DESCRIPTION).toString();
        metaDescription = metaDescription.replaceAll("&nbsp;","");
        metaDescription = StringEscapeUtils.unescapeHtml4(metaDescription);
        metaDescription = replaceHtmlTags(metaDescription);
        if (metaDescription.length() > 160)
            metaDescription = metaDescription.substring(0, 160) + "...";
    }

    private String replaceHtmlTags(String content) {
        // escape html tags
        String[] tags = new String[] { "<i>", "</i>", "<sub>", "</sub>", "<sup>", "</sup>", "<br>", "</br>", "<br />" };
        for (String tag : tags) {
            content = content.replaceAll(tag, "");
        }
        return content;
    }
}