package com.ti.core.service;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.jcr.Node;
import javax.jcr.PropertyType;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.email.EmailService;
import com.adobe.acs.commons.wcm.AuthorUIHelper;
import com.day.cq.commons.Externalizer;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

/**
 * The Class TranslationWorkflowEmailNotificationService. This class will send
 * the email notification to group given in Arguments section of Email
 * notification process step.
 * <p>
 * Arguments are comma separated list. First argument is path of email template
 * and second argument is group id.
 * 
 * @author p.palandurkar
 */

@Component(service = WorkflowProcess.class, property = {
		"process.label=Translation workflow Email notification" })
public class TranslationWorkflowEmailNotificationService implements WorkflowProcess {
	private static final Logger LOG = LoggerFactory.getLogger(TranslationWorkflowEmailNotificationService.class);
	private static final String SUBMISSION_DATE = "submissionDate";
	private static final String JCR_CONTENT = "/jcr:content";
	private static final String PATH = "path";
	private static final String TYPE = "type";
	private static final String PROPERTY = "property";
	private static final String PROPERTY_OPERATION = "property.operation";
	private static final String P_LIMIT = "p.limit";
	private static final String NT_UNSTRUCTURED = "nt:unstructured";
	private static final String EXISTS = "exists";
	private static final String SOURCE_PATH = "sourcePath";
	private static final String DESTINATION_LANG = "destinationLanguage";
	private static final String REPOSITORY_EXCEPTION = "RepositoryException: {} {}";
	private static final String SENT_NOTIFICATION = "sent-notification.html";
	private static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	private static final String TRANSLATED_DATE = "translationsubmissionDate";
	private static final String BANNER_REVIEWER_TEMPLATE = "/conf/global/settings/workflow/notification/email/html/sdl-translation-received-Banner-notification.html";
	private static final String BANNER_FOLDER = "homepagebanners";
	private static final String WCM_PROJECT_URL_TOUCH_DEFAULT = "/projects/details.html";
	@Reference
	ProductNavigationTabsOrdering tabsService;
	@Reference
	private ResourceResolverFactory rrFactory;
	@Reference
	private EmailService emailService;
	@Reference
	private AuthorUIHelper authorUiHelper;
	@Reference
	private Externalizer externalizer;
	ResourceResolver resourceResolver;
	String[] receipients;
	private String submissionDate;
	private String destinationLanguage;
	private Map<String, String> emailParams = new HashMap<>();
	private List<String> members = new ArrayList<>();
	private String sendEmail = null;
	private String receiveEmail = null;
	private String aemFolder = null;

	@Override
	public void execute(WorkItem workItem, WorkflowSession session, MetaDataMap metaDataMap) {
		String processArgs = metaDataMap.get("PROCESS_ARGS", String.class);
		String initiator = null;
		String[] args = processArgs.split(",");
		String templatePath = args[0].trim();
		LOG.debug("template" + templatePath);
		if (!members.isEmpty()) {
			LOG.debug("members size" + members.size());
			members.clear();
		}
		WorkflowData workflowData = workItem.getWorkflowData();
		String payload = workflowData.getPayload().toString();
		LOG.debug("Payload " + payload);

		setResolver();
		Session jcrSession = resourceResolver.adaptTo(Session.class);
		String translationstatus = gettranslationstatus(payload);
		LOG.debug("translation status " + translationstatus);
		if (translationstatus != null
				&& (compareTranslationStatus(translationstatus) || receiveEmailCheck(translationstatus))) {
			LOG.debug("valid trans status");
			if (jcrSession != null) {
				LOG.debug("jcrSession {}" , jcrSession);
				SearchResult results = getResults(payload, jcrSession, SOURCE_PATH);
				if (results != null) {
					LOG.debug("results {}" , results);
					setSourcePath(results);
				}
				boolean banner = false;
				String reviewer = null;
				String jobName = null;
				if (aemFolder.contains(BANNER_FOLDER)) {
					LOG.debug("banner folder " );
					banner = true;
				}
				if (!banner && ("APPROVED".equals(translationstatus))) {
					LOG.debug("Not a banner folder, translationstatus {}  returning ", translationstatus );
					return;
				}
				if (null != translationstatus && banner) {
					if ("READY_FOR_REVIEW".equals(translationstatus)) {
						templatePath = BANNER_REVIEWER_TEMPLATE;
						reviewer = getreviewergroup(payload);
						getEmailRecipentsFromGroup(reviewer);
					}
					jobName = gettranslationjobName(payload);
					String projectnode = payload.substring(0, payload.indexOf(JCR_CONTENT));
					String projecklink = WCM_PROJECT_URL_TOUCH_DEFAULT + projectnode;
					String projectName = StringUtils.substringAfterLast(projectnode, "/");
					projecklink = externalizer.authorLink(resourceResolver, projecklink);
					LOG.debug("project Name and link" + projectName + projecklink);
					emailParams.put("jobName", jobName);
					emailParams.put("projectName", projectName);
					emailParams.put("projectLink", projecklink);
				}
				initiator = getlastmofified(payload);
				if (initiator == null) {
					initiator = getinitiator(payload);
				}
				LOG.debug("initiator {} " ,initiator);
				getAuthorName(initiator);
				getSourceAndDestinationLanguage(payload);
				setSubmissionDate(payload);
				LOG.debug("payload {} " ,payload);
				initiator = getownergroup(payload);
				getEmailRecipentsFromGroup(initiator);
				sendWorkflowEmail(templatePath, payload);
				LOG.debug("emailParams before clear " + emailParams);
				emailParams.clear();
				members.clear();
				LOG.debug("emailParams after clear " + emailParams);
				LOG.debug("after sendWorkflowEmail");
				try {
					jcrSession.save();
				} catch (RepositoryException e) {
					LOG.error("RepositoryException {}", e);
				}
			}

		}
		LOG.debug("Execute Done");
	}

	private void setSourcePath(SearchResult results) {
		List<String> sourcePathList = new ArrayList<>();
		for (Hit hit : results.getHits()) {
			try {
				Node node = hit.getResource().adaptTo(Node.class);
				if (node != null) {
					javax.jcr.Property property = node.getProperty(SOURCE_PATH);
					String sourcePath = property.getValue().toString();
					LOG.debug("Source path" + sourcePath);

					String sourcePathJcrContent = sourcePath.concat(JCR_CONTENT);
					setTranslatedsubProperty(sourcePathJcrContent);

					sourcePathList.add(sourcePath);
				}
			} catch (RepositoryException e) {
				LOG.error(REPOSITORY_EXCEPTION, e);
			}
		}

		addAuthoringUrl(sourcePathList);
	}

	private void setTranslatedsubProperty(String sourcePath) {
		LOG.debug("inside sourcePath" + sourcePath);
		Resource pageResource = resourceResolver.getResource(sourcePath);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
		String timestamp = ZonedDateTime.now().format(formatter);

		try {
			if (pageResource != null) {
				Node node = pageResource.adaptTo(Node.class);
				if (node != null) {
					node.setProperty(TRANSLATED_DATE, timestamp);
					LOG.debug("translated submission Date property is set" + timestamp);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception: {} ", e);
		}

	}

	private void addAuthoringUrl(List<String> sourcePathList2) {
		StringBuilder publishLinks = new StringBuilder();
		StringBuilder authorLinks = new StringBuilder();
		String pageLanguageCode = null;
		String domain = null;

		for (String path : sourcePathList2) {
			Resource pageResource = resourceResolver.getResource(path);
			if (pageResource != null && tabsService != null) {
				Page page = pageResource.adaptTo(Page.class);
				pageLanguageCode = tabsService.getPageLanguage(page);
				domain = tabsService.getDomainFromLanguageCode(pageLanguageCode);
				LOG.debug("pageLanguageCode  & Domain >>>>>>>>>> {}" + pageLanguageCode + domain);
			}
			if (pageResource != null) {
				Page page = pageResource.adaptTo(Page.class);
				if (page != null) {

					String folder = StringUtils.substringAfter(path, "/" + pageLanguageCode);
					String[] rootFamily = folder.split("/");
					aemFolder = rootFamily[1].trim();
					LOG.debug("folder path" + folder + "root name " + aemFolder);
					LOG.debug("page path before it goes to externalizer" + path);
					String pubdomain = "http://" + domain + path + ".html";
					LOG.debug("pub doamin " + pubdomain);
					String authorUrl = authorUiHelper.generateEditPageLink(path, true, resourceResolver);
					LOG.debug("authorUrl" + authorUrl);
					publishLinks.append("<a href=\"").append(pubdomain).append("\">").append(folder).append("</a>")
							.append(System.getProperty("line.separator"));
					authorLinks.append("<a href=\"").append(authorUrl).append("\">").append(folder).append("</a>")
							.append(System.getProperty("line.separator"));
				}
			}
		}

		emailParams.put("aemFolder", aemFolder);
		emailParams.put("publishLinks", publishLinks.toString());
		emailParams.put("authorLinks", authorLinks.toString());
	}

	private SearchResult getResults(String path, Session jcrsession, String property) {
		SearchResult result = null;
		Map<String, String> map = new HashMap<>();

		map.put(PATH, path);
		map.put(TYPE, NT_UNSTRUCTURED);
		map.put(PROPERTY, property);
		map.put(PROPERTY_OPERATION, EXISTS);
		map.put("1_property", "translationFileType");
		map.put("1_property.value", "PAGE");
		map.put(P_LIMIT, "-1");

		QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
		if (builder != null) {
			Query createQuery = builder.createQuery(PredicateGroup.create(map), jcrsession);
			result = createQuery.getResult();
		}
		return result;
	}

	private void getSourceAndDestinationLanguage(String payload) {
		String payloadJcrContentPath = payload.substring(0, payload.indexOf(JCR_CONTENT) + JCR_CONTENT.length());
		LOG.debug("payloadJcrContentPath" + payloadJcrContentPath);
		LOG.debug("testpayloadJcrContentPath" + payload.substring(0, payload.indexOf(JCR_CONTENT)));
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		if (resource != null) {
			Node node = resource.adaptTo(Node.class);
			if (node != null) {
				LOG.debug("setting the lang email params");
				setLanguageEmailParams(node);

			}
		}
	}

	private String gettranslationstatus(String payload) {

		String payloadJcrContentPath = payload;
		LOG.debug("payloadJcrContentPath" + payloadJcrContentPath);
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		String translationstatus = null;
		if (resource != null) {
			Node node = resource.adaptTo(Node.class);
			if (node != null) {

				try {
					translationstatus = node.getProperty("translationStatus").getString();
					if (node.hasProperty("sendEmail")) {
						sendEmail = node.getProperty("sendEmail").getString();
					}
					if (node.hasProperty("receiveEmail")) {
						receiveEmail = node.getProperty("receiveEmail").getString();
					}
					LOG.debug("translationstatus" + translationstatus);
				} catch (RepositoryException e) {
					LOG.error("ReplicationException: {} ", e);
				}
			}
		}
		return translationstatus;
	}

	public String getSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(String sendEmail) {
		this.sendEmail = sendEmail;
	}

	public String getReceiveEmail() {
		return receiveEmail;
	}

	public void setReceiveEmail(String receiveEmail) {
		this.receiveEmail = receiveEmail;
	}

	private void setemailindicator(String payload, String templatePath) {
		String payloadJcrContentPath = payload;
		LOG.debug("payloadJcrContentPath" + payloadJcrContentPath);
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		String typeofaction = null;
		if (templatePath.contains(SENT_NOTIFICATION)) {
			typeofaction = "SEND";

		} else {
			typeofaction = "RECEIVE";
		}
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					if ("SEND".equalsIgnoreCase(typeofaction)) {
						node.setProperty("sendEmail", "true");
						LOG.debug("setting sendEmail as true");
					} else if ("RECEIVE".equalsIgnoreCase(typeofaction)) {
						node.setProperty("receiveEmail", "true");
						LOG.debug("setting receiveEmail  as true");
					}

				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
	}

	private String getownergroup(String payload) {

		String payloadJcrContentPath = payload.substring(0, payload.indexOf(JCR_CONTENT));
		String owner = null;
		LOG.debug("payloadJcrContentPath" + payloadJcrContentPath);
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					LOG.debug("Node is not empty and grabbing role_owner property value");
					owner = node.getProperty("role_owner").getString();
					LOG.debug("role_owner inside getownergroup" + owner);
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
		return owner;
	}

	private String getreviewergroup(String payload) {

		String payloadJcrContentPath = payload.substring(0, payload.indexOf(JCR_CONTENT));
		String reviewer = null;
		LOG.debug("payloadJcrContentPath" + payloadJcrContentPath);
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					LOG.debug("Node is not empty and grabbing role_translationreviewer property value");
					reviewer = node.getProperty("role_translationreviewer").getString();
					LOG.debug("role_translationreviewer inside getreviewergroup" + reviewer);
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
		return reviewer;
	}

	private String gettranslationjobName(String payload) {

		String jobName = null;
		LOG.debug("payload for gettranslationjobName" + payload);
		Resource resource = resourceResolver.getResource(payload);
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					LOG.debug("Node is not empty and grabbing jobname property value");
					jobName = node.getProperty("jcr:title").getString();
					LOG.debug("jobname inside gettranslationjobName" + jobName);
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
		return jobName;
	}

	private String getinitiator(String payload) {
		String payloadJcrContentPath = payload.substring(0, payload.indexOf(JCR_CONTENT));
		String initiator = null;
		LOG.debug("payloadJcrContentPath for getinitiator" + payloadJcrContentPath);
		Resource resource = resourceResolver.getResource(payloadJcrContentPath);
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					LOG.debug("Node is not empty and grabbing initiatorUserId property value");
					initiator = node.getProperty("initiatorUserId").getString();
					LOG.debug("Initiator inside getinitiator" + initiator);
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
		return initiator;
	}

	private String getlastmofified(String payload) {

		String initiator = null;
		LOG.debug("payload path" + payload);
		Resource resource = resourceResolver.getResource(payload);
		try {
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node != null) {
					LOG.debug("Node is not empty and grabbing initiatorUserId property value");
					if (node.hasProperty("jcr:lastModifiedBy"))
						initiator = node.getProperty("jcr:lastModifiedBy").getString();
					LOG.debug("Initiator inside getinitiator" + initiator);
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}
		return initiator;
	}

	private void setLanguageEmailParams(Node node) {
		try {
			destinationLanguage = node.getProperty(DESTINATION_LANG).getString();
			String sourceLanguage = node.getProperty("sourceLanguage").getString();
			LOG.debug("source and destination language" + sourceLanguage + "" + destinationLanguage);
			emailParams.put("destinationLanguageCode", destinationLanguage);
			HashMap<String, String> map = new HashMap<>();
			map.put("cn", "Chinese");
			map.put("jp", "Japanese");
			map.put("kr", "Korean");
			map.put("de", "German");
			map.put("ru", "Russian");
			map.put("tw", "Chinese (Taiwan)");
			map.put("mx", "Spanish (Mexico)");

			Iterator<Entry<String, String>> it = map.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, String> pair = (Map.Entry<String, String>) it.next();
				if (destinationLanguage.contains(pair.getKey().toString())) {
					LOG.debug("going inside DESTINATION_LANG set");
					emailParams.put(DESTINATION_LANG, pair.getValue().toString());
					it.remove();
				}

			}

			emailParams.put("sourceLanguage", sourceLanguage);
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION, e);
		}

	}

	private void getAuthorName(String initiator) {
		try {
			LOG.debug("inside getAuthorName" + initiator);
			UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			if (userManager != null) {
				Authorizable auth = userManager.getAuthorizable(initiator);
				if (auth == null)
					throw new RepositoryException("Could not get authorizable object");
				String lastName = getStringPropertyFromAuthorizable(auth, "./profile/familyName");
				String firstName = getStringPropertyFromAuthorizable(auth, "./profile/givenName");
				String email = getStringPropertyFromAuthorizable(auth, "./profile/email");
				LOG.debug("author first name " + firstName);
				LOG.debug("author lastName name " + lastName);
				LOG.debug("author email " + email);

				emailParams.put("firstName", firstName);
				emailParams.put("lastName", lastName);
				LOG.debug("email ids " + email);

			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION + "Could not get author's name", e);
		}
	}

	/**
	 * @param auth
	 * @param property
	 * @param lastName
	 * @return
	 * @throws ValueFormatException
	 * @throws RepositoryException
	 */
	private String getStringPropertyFromAuthorizable(Authorizable auth, String property) throws RepositoryException {
		String retval = StringUtils.EMPTY;
		LOG.debug("propery values inside getStringPropertyFromAuthorizable" + property);
		Value[] value = auth.getProperty(property);
		if (value.length >= 1 && PropertyType.STRING == value[0].getType()
				&& StringUtils.isNotEmpty(value[0].getString()))
			retval = value[0].getString();

		LOG.debug("retval inside getStringPropertyFromAuthorizable" + retval);
		return retval;
	}

	private void setSubmissionDate(String payload) {
		LOG.debug("inside setSubmissionDate " + payload);
		Resource resource = resourceResolver.getResource(payload);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a");
		String timestamp = LocalDateTime.now().format(formatter);
		LOG.debug("submission date" + timestamp);
		if (resource != null) {
			Node node = resource.adaptTo(Node.class);
			if (node != null) {
				setSubmissionDate(node, timestamp);
			}
		}
	}

	private void setSubmissionDate(Node node, String timestamp) {
		try {
			if (!node.hasProperty(SUBMISSION_DATE)) {
				submissionDate = timestamp;
				node.setProperty(SUBMISSION_DATE, timestamp);
			} else {
				submissionDate = node.getProperty(SUBMISSION_DATE).getString();
			}

		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION + "Could not set submission date", e);
		}
	}

	private void sendWorkflowEmail(String templatePath, String payload) {
		LOG.debug("inside sendWorkflowEmail and the template and the email groups are " + templatePath);

		emailParams.put(SUBMISSION_DATE, submissionDate);
		LOG.debug("list of receipients before sending email" + Arrays.toString(receipients));
		List<String> failureList = emailService.sendEmail(templatePath, emailParams, receipients);
		LOG.debug("after sending email");
		if (failureList.isEmpty()) {
			LOG.debug("---------------Mail delivery successfull---------------");
			setemailindicator(payload, templatePath);
		} else {
			if (LOG.isDebugEnabled()) {
				LOG.debug("---------------Mail delivery failed---------------");
			}
		}
	}

	private void getEmailRecipentsFromGroup(String recipientgroup) {

		UserManager userManager = resourceResolver.adaptTo(UserManager.class);
		LOG.debug("the group" + recipientgroup);
		try {
			if (userManager != null) {
				if (null != recipientgroup) {
					Authorizable auth = userManager.getAuthorizable(recipientgroup);
					if (auth == null)
						throw new RepositoryException("Could not get authorizable object");
					if (auth.isGroup()) {
						Group group = (Group) auth;
						Iterator<Authorizable> iter = group.getMembers();
						receipients = createRecipients(iter);
					}
				} else {
					// addded as a error purposfully to debug things easier with
					LOG.error("No group found for the language " + destinationLanguage);
					if (!members.isEmpty()) {
						receipients = members.toArray(new String[members.size()]);
					}
				}
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION + "Could not get Email Recipients from group:" + recipientgroup, e);
		}
	}

	private String[] createRecipients(Iterator<Authorizable> iter) {
		String email = "";
		List<Authorizable> users = new ArrayList<>();
		while (iter.hasNext()) {
			users.add(iter.next());
		}
		ValueMap profile = null;
		try {
			for (Authorizable user : users) {
				Resource resource = resourceResolver.getResource(user.getPath() + "/profile");
				if (resource != null) {
					profile = resource.adaptTo(ValueMap.class);
				}

				if (profile != null) {
					email = profile.get("email", "");
				}
				if (StringUtils.isEmpty(email)) {
					continue;
				}
				LOG.debug("list of email id" + email);
				members.add(email);
			}
		} catch (RepositoryException e) {
			LOG.error(REPOSITORY_EXCEPTION + "Could not execute creatRecipients", e);
		}
		return members.toArray(new String[members.size()]);
	}

	private void setResolver() {
		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = rrFactory.getServiceResourceResolver(param);
		} catch (LoginException e) {
			LOG.error("LoginException: ", e);
		}
	}

	private boolean compareTranslationStatus(String translationstatus) {
		return "COMMITTED_FOR_TRANSLATION".equals(translationstatus)
				|| "TRANSLATION_IN_PROGRESS".equals(translationstatus) || "APPROVED".equals(translationstatus);
	}

	private boolean receiveEmailCheck(String translationstatus) {
		return "READY_FOR_REVIEW".equals(translationstatus) && "false".equalsIgnoreCase(receiveEmail);
	}

}
