package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Overview WCMUsePojo.
 */
public class Overview extends WCMUsePojo {
  protected final Logger log = LoggerFactory.getLogger(this.getClass());

  private String ctaUrl = "";

  public String getCtaUrl() {
    return ctaUrl;
  }

  @Override
  public void activate() throws Exception {
    try {
      // If there is only one CTA link, then it will be used for the title and image
      for (Resource nodeChild : getResource().getChildren()) {
        if (nodeChild != null && nodeChild.toString().contains("ctaList")) {
          Integer ctaCount = 0;
          for (Resource ctaLink : nodeChild.getChildren()) {
            ValueMap properties = ctaLink.adaptTo(ValueMap.class);
            if(null!=properties){
            ctaUrl = (++ctaCount == 1 ? (String) properties.get("ctaurl") : "");
            }
          }
        }
      }
    } catch (Exception e) {
      log.error("Exception: ", e);
    }
  }
}
