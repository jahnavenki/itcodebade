package com.ti.core.service.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "TI URL Pattern Configuration", description = "TI URL Pattern Configuration for regionalization.")
public @interface TiUrlPatternConfiguration {

	@AttributeDefinition(name = "urlPattern", description = "URL Pattern", type = AttributeType.STRING)
	String urlPattern();

	@AttributeDefinition(name = "replacementPatterns", description = "Replacement patterns e.g. language-code|replacement_pattern", cardinality = 50, type = AttributeType.STRING)
	String[] replacementPatterns() default "en-us|$1www-int.itg.ti.com/$2/";

	@AttributeDefinition(name = "key", description = "Key description", type = AttributeType.STRING)
	String key();

	@AttributeDefinition(name = "Group Number", description = "Group Number", type = AttributeType.INTEGER)
	int groupNumber() default 0;

}
