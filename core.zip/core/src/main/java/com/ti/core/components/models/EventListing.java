package com.ti.core.components.models;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Default;



import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections4.CollectionUtils;


@Model(
	adaptables = { Resource.class },
	resourceType = EventListing.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class EventListing {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/eventListing";

	@ChildResource(name = "eventListingLinks")
	private Collection<EventListingLinks> links;

    @ValueMapValue
    private List<EventListingLinks> upcoming = new ArrayList<EventListingLinks>();

    @ValueMapValue
    private List<EventListingLinks> past = new ArrayList<EventListingLinks>();

    @ValueMapValue
    private List<EventListingLinks> list = new ArrayList<EventListingLinks>();

    @ValueMapValue @Default(booleanValues={false})
    private Boolean sorted;

	@PostConstruct
	public void init() {
        links = CollectionUtils.emptyIfNull(links);
        
		try {
            if(sorted)
            {
                final var currentDate = new Date();

                for (EventListingLinks i : links) {
                    final var date = i.getDate();
                    if(date.after(currentDate)){
                        upcoming.add(i);
                    }else{
                        past.add(i);
                    }
                }

                Collections.sort(upcoming);
                Collections.sort(past);
                Collections.reverse(past);
            }else{
                for (EventListingLinks i : links) {
                    list.add(i);
                }
            }
			
		} catch(Exception ex) {
			log.error( "Exception in EventListing", ex );
		}
	}

	public Collection<EventListingLinks> getLinks() {
		return links;
	}
    public Collection<EventListingLinks> getUpcoming() {
		return upcoming;
	}
    public Collection<EventListingLinks> getPast() {
		return past;
	}
    public Collection<EventListingLinks> getList() {
		return list;
	}
    public Boolean getSorted() {
        return sorted;
    }
    public Boolean isNeedsAuthoring() {
		return links.isEmpty();
	}
}

