package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.util.PathBrowserHelper;

@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	resourceType = CardWithImage.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class CardWithImage {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/cardWithImage";

	@ChildResource
	private Collection<CardWithImageModel> cards;

	@SlingObject
	private ResourceResolver resourceResolver;

    @ValueMapValue
    private String cardSize;

    @ValueMapValue
    private String headingSize;

    @ValueMapValue
    private String contentType;

    @ValueMapValue
    private String sectionHeading;

	@PostConstruct
	public void init(){
		try {
			cards = CollectionUtils.emptyIfNull(cards);
		} catch (Exception e) {
			log.error("Exception in cardWithImage", e);
		}
	}

	public Collection<CardWithImageModel> getCards() {

        for(CardWithImageModel card : cards ){
            String url=card.getUrl();
            url=PathBrowserHelper.addHtmlIfContentPath(resourceResolver, url);
            card.setUrl(url);
            card.setCtaIcon((url.endsWith( "/products" ) || url.endsWith( "/products.html" )) ? "parametric-filter" : "" );
        }
		return cards;
	}

    public String getCardSize(){
        return cardSize;
    }

    public String getContentType(){
        return contentType;
    }

    public String getHeadingSize(){
        return headingSize;
    }
    
    public String getSectionHeading(){
        return sectionHeading;
    }
}
