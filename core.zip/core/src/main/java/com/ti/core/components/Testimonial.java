package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Testimonial extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(Testimonial.class);
    
    private String imageAltText;
    private String testimonialStatement;
    private String testimonialSummary;

    @Override
    public void activate() throws Exception {
        try {
            String pageLanguage;
            ValueMap properties = getProperties();
            // Get title from DAM property and set as alt text for image
            Resource resource = getResourceResolver().getResource(properties.get("fileReference").toString());
            if (resource != null) {
                Asset asset = resource.adaptTo(Asset.class);
                if (asset != null) {
                    this.imageAltText = asset.getMetadataValue("dc:title");
                }
            }
            //add quotation mark to testimonial statement if page language is en_us
            this.testimonialStatement = properties.get("testimonialStatement", "");
            Page page = getCurrentPage();
            pageLanguage = page.getLanguage(true).toString();
            if("en_us".equalsIgnoreCase(pageLanguage)) {
                this.testimonialStatement =  "“" + testimonialStatement + "”";   
            }
            generateTestimonialSummary(properties);
                
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
    private void generateTestimonialSummary(ValueMap properties) {
        String testimonialSourceName = properties.get("testimonialSourceName","");
        String testimonialSourceCompany = properties.get("testimonialSourceCompany","");
        String testimonialSourceTitle = properties.get("testimonialSourceTitle","");
        this.testimonialSummary = testimonialSourceName + " | " + testimonialSourceCompany + " " + testimonialSourceTitle;
    }
    
    public String getImageAltText() {
        return imageAltText;
    }

    public String getTestimonialStatement() {
        return testimonialStatement;
    }

    public String getTestimonialSummary() {
        return testimonialSummary;
    }
    
}
