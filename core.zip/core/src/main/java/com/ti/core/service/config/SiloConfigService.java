package com.ti.core.service.config;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * SiloConfigService to get the portals of texas instruments.
 *
 */



@Component(immediate = true)
@Designate(ocd = SiloConfiguration.class)
public class SiloConfigService {

	
	private String abouttisilourl = null;
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	protected SiloConfiguration siloConfiguration;

	public String getabouttisilourl() {
		log.debug("abouttisilourl: {}", abouttisilourl);
		return abouttisilourl;
	}

	/**
	 * Activate method.
	 * 
	 * @param config
	 *            config
	 */
	@Activate
	@Modified
	public void activate(SiloConfiguration config) {
		resetService(config);
	}

	

	private synchronized void resetService(SiloConfiguration config) {
		log.info("Resetting portal config service using configuration: ", config);
		this.abouttisilourl = config.abouttisilourl();
	}

}
