package com.ti.core.service.workflow;
import org.osgi.framework.Constants;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.ti.core.util.AssetUtils;

/**
 * 
 * GenerateRenditionsFromMetadataProcessStep
 * 
 * @author Richard Chan



 */
@Component(service = WorkflowProcess.class,
			
			property = {Constants.SERVICE_DESCRIPTION + "=Workflow step for generating TI renditions based on the asset's metadata mapping(s)",
					Constants.SERVICE_VENDOR + "=TI","process.label=TI: Generate Renditions From Metadata" })
public class GenerateRenditionsFromMetadataProcessStep implements WorkflowProcess {

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		final WorkflowData workflowData = item.getWorkflowData();
		String payload = workflowData.getPayload().toString();

		ResourceResolver resourceResolver = session.adaptTo(ResourceResolver.class);
		if (resourceResolver == null)
			return;
		
		Resource resource = resourceResolver.getResource(payload);			
		if (resource == null)
			return;

		AssetUtils.generateRenditions(resource.adaptTo(Asset.class), resourceResolver, false);
	}
}
