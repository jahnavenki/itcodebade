package com.ti.core.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.ParticipantStepChooser;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.wcm.api.PageManager;
import com.ti.core.util.EmailUtils;

/**
 * PageApprovalProcessStep ParticipantStepChooser.
 * 
 */



@Component(service = ParticipantStepChooser.class, property = {
		"service.description=age approval participant chooser.",
		"chooser.label=Page Approval Workflow Participant Chooser" })
public class PageApprovalProcessStep implements ParticipantStepChooser {

	private static final String TI_CONTENT_LIMITED_ACCESS = "ti-content-limited-access";

	private static final String IS_LIMITED_USER = "isLimitedUser";

	private static final String FAMILY_ID = "familyId";

	private static final String APPLICATION_ID = "applicationId";

	private static final String APPROVER = "approver";

	private static final String NOT_FOUND = "notFound";

	@Reference
	private ResourceResolverFactory resourceFactory;

	private ResourceResolver resourceResolver;
	protected final Logger log = LoggerFactory.getLogger(PageApprovalProcessStep.class);
	private static final String JCR_METADATA = "/jcr:content";

	public static final String FAMILY_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-family-id-approver-mappings";
	public static final String APPLICATION_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-application-id-approver-mappings";
	public static final String CONTENT_LOCATION_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-path-approver-mappings";
	public static final String DEFAULT_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-default-approver-mappings";

	@Override
	public String getParticipant(WorkItem item, WorkflowSession wfsession, MetaDataMap args) throws WorkflowException {
		final WorkflowData workflowData = item.getWorkflowData();
		String payload = workflowData.getPayload().toString();
		javax.jcr.Session jcrSession = wfsession.adaptTo(javax.jcr.Session.class);
		if (jcrSession == null) {
			log.error("jcrSession was null, returning not found approver");
			return NOT_FOUND;
		}
		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = resourceFactory.getServiceResourceResolver(param);
		} catch (LoginException e1) {
			log.error("Error connecting to repository in PageApprovalProcessStep due to " + e1);
			return NOT_FOUND;
		} catch (Exception e) {
			log.error("Error in PageApprovalProcessStep due to " + e);

		}

		return returnApprover(item, wfsession, payload, jcrSession);
	}

	/**
	 * Method to check if the workflow initiator belongs to limited users group.
	 * 
	 * @param jcrSession
	 *            jcrSession
	 * @param limitedUserGroupName
	 *            limitedUserGroupName
	 * @return true/false
	 * @throws RepositoryException
	 *             e
	 */
	private boolean isLimitedGroupUser(javax.jcr.Session jcrSession, String limitedUserGroupName)
			throws RepositoryException {
		boolean isLimitedGroupUser = false;
		UserManager userManager = resourceResolver.adaptTo(UserManager.class);
		if (userManager != null) {
			Authorizable auth = userManager.getAuthorizable(jcrSession.getUserID());
			if (auth != null) {
				Iterator<Group> groups = auth.memberOf();
				while (groups.hasNext()) {
					Group group = groups.next();
					log.debug("group ID : {}", group.getID());
					if (limitedUserGroupName.equals(group.getID())) {
						log.debug("User belongs to Limited group");
						isLimitedGroupUser = true;
						break;
					}
				}
			}
		}
		return isLimitedGroupUser;
	}

	/**
	 * Return Approver to getParticipant method.
	 * 
	 * @param item
	 *            item
	 * @param wfsession
	 *            wfsession
	 * @param payload
	 *            payload
	 * @param jcrSession
	 *            jcrSession
	 * @return approver group.
	 */
	private String returnApprover(WorkItem item, WorkflowSession wfsession, String payload,
			javax.jcr.Session jcrSession) {
		try {
			Node node;
			PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
			String approver = NOT_FOUND;
			log.debug("payload inside returnApprover" + payload);
			if (jcrSession.getNode(payload + JCR_METADATA) != null) {
				node = jcrSession.getNode(payload + JCR_METADATA);
				EmailUtils emailUtils = new EmailUtils(pageManager);
				if (node.hasProperty(FAMILY_ID)) {
					approver = emailUtils.getApproverForProductFamilyPages(node);
					log.debug("has family id and the approver is " + approver);
				} else if (node.hasProperty(APPLICATION_ID)) {
					approver = emailUtils.getProductForApplicationPages(node);
					log.debug("has App id and the approver is " + approver);
				} else {
					approver = emailUtils.getApproverForPagePath(payload);
				}
				log.debug("Approver is" + approver);
				saveApproverToMetadataMap(item, wfsession, jcrSession, approver);

				if (StringUtils.isNotEmpty(approver) && approver != null) {
					return approver;
				} else {
					approver = emailUtils.getDefaultApprover();
					saveApproverToMetadataMap(item, wfsession, jcrSession, approver);
					return approver;
				}
			}
			log.debug("approver {}", approver);
			return approver;

		} catch (Exception e) {
			log.error("RepositoryException thrown while setting the properties " + "on workflow payload metadata node"
					+ e);
			return NOT_FOUND;
		}
	}

	private void saveApproverToMetadataMap(WorkItem item, WorkflowSession wfsession, javax.jcr.Session jcrSession,
			String approver) throws RepositoryException {
		boolean limitedGroupUser = isLimitedGroupUser(jcrSession, TI_CONTENT_LIMITED_ACCESS);
		log.debug("is limitedGroupUser {}", limitedGroupUser);
		item.getWorkflow().getWorkflowData().getMetaDataMap().put(APPROVER, approver);
		item.getWorkflow().getWorkflowData().getMetaDataMap().put(IS_LIMITED_USER, limitedGroupUser);
		wfsession.updateWorkflowData(item.getWorkflow(), item.getWorkflowData());
		jcrSession.save();
	}
}
