package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.QueryBuilder;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;

@Component(service = Servlet.class, immediate=true, property = {
	SLING_SERVLET_PATHS + "=/bin/ti/folder/video",
	SLING_SERVLET_METHODS + "=GET" })
public class FolderVideoServlet extends SlingSafeMethodsServlet {
	protected static final Logger log = LoggerFactory.getLogger(FolderVideoServlet.class);

	@Reference
	private transient WCMComponents wcmService;

	private transient ResourceResolver resourceResolver;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		try {
			resourceResolver = request.getResourceResolver();
			final var session = resourceResolver.adaptTo(Session.class);
			if (null == session) throw new NullPointerException("session");
			final var queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			if (null == queryBuilder) throw new NullPointerException("queryBuilder");
			var jsonResponse = new JSONArray();
			final var localeQuery = request.getParameter("locale");
			final var typeQuery = request.getParameter("type");
			final var idQuery = request.getParameter("id");
			final var hostTypeQuery = request.getParameter("host_type");
			final var locales = new ArrayList<String>();
			if (StringUtils.isNotEmpty(localeQuery)) {
				locales.add(localeQuery);
			}
			if (!"en-us".equalsIgnoreCase(localeQuery)) {
				locales.add("en-us");
			}
			for (var locale : locales) {
				var hasResults = false;
				final var predicates = new HashMap<String, String>();
				var propIndex = 1;
				predicates.put("path", "/content/dam/videos/external-videos");
				predicates.put("type", "dam:Asset");
				predicates.put(propIndex + "_property", "jcr:content/metadata/brc_id");
				predicates.put(propIndex + "_property.operation", "exists");
				++propIndex;
				predicates.put(propIndex + "_property", "jcr:content/metadata/dam:status");
				predicates.put(propIndex + "_property.value", "published");
				++propIndex;
				predicates.put(propIndex + "_property", "jcr:content/metadata/videoSpokenLanguage");
				predicates.put(propIndex + "_property.value", videoSpokenLanguageFromLocale(locale));
				++propIndex;
				String tagField = null;
				if ("genericpart".equalsIgnoreCase(typeQuery)) {
					tagField = "dam:tagsProducts";
				} else if ("eeqid".equalsIgnoreCase(typeQuery)) {
					tagField = "dam:tagsApplications";
				} else if ("toolname".equalsIgnoreCase(typeQuery)) {
					tagField = "dam:tagsTools";
				}
				if (StringUtils.isNotEmpty(tagField) && StringUtils.isNotEmpty(idQuery)) {
					predicates.put(propIndex + "_property", "jcr:content/metadata/" + tagField);
					predicates.put(propIndex + "_property.value", "%/" + idQuery);
					predicates.put(propIndex + "_property.operation", "like");
					++propIndex;
				}
				final var taxonomies = new ArrayList<String>();
				if ("media-gallery".equalsIgnoreCase(hostTypeQuery)) {
					if ("genericpart".equalsIgnoreCase(typeQuery)) {
						taxonomies.add("product_ovw");
					} else if ("eeqid".equalsIgnoreCase(typeQuery)) {
						taxonomies.add("mse_ovw");
					} else if ("toolname".equalsIgnoreCase(typeQuery)) {
						taxonomies.add("oob");
					}
				} else if ("video-comp".equalsIgnoreCase(hostTypeQuery)) {
					taxonomies.add("product_ovw");
					taxonomies.add("product_app_demo");
					taxonomies.add("mse_ovw");
					taxonomies.add("oob");
					taxonomies.add("product_tut");
					taxonomies.add("mse_tut");
				}
				if (!taxonomies.isEmpty()) {
					for(var groupIndex = 0; groupIndex < taxonomies.size(); ++groupIndex) {
						final var taxonomy = taxonomies.get(groupIndex);
						predicates.put("group." + ( groupIndex + 1 ) + "_property", "jcr:content/metadata/taxonomyField");
						predicates.put("group." + ( groupIndex + 1 ) + "_property.value", taxonomy + "%");
						predicates.put("group." + ( groupIndex + 1 ) + "_property.operation", "like");
					}
					predicates.put("group.p.or", "true");
				}
				if ("media-gallery".equalsIgnoreCase(hostTypeQuery)) {
					predicates.put("orderby", "@jcr:content/metadata/dam:published");
					predicates.put("orderby.sort","desc");
					predicates.put("p.limit", "1");
				} else {
					predicates.put("p.limit", "-1");
				}
				final var query = queryBuilder.createQuery(PredicateGroup.create(predicates), session);
				final var result = query.getResult();
				final var hits = result.getHits();
				for (final var hit : hits) {
					final var jsonObj = getJson(hit.getPath());
					if (null != jsonObj) {
						jsonResponse.put(jsonObj);
						hasResults = true;
					}
				}
				if (hasResults) break;
			}
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			jsonResponse.write(response.getWriter());
		} catch (Exception ex) {
			log.error( "Exception", ex );
		}
	}

	private JSONObject getJson( String path ) throws JSONException {
		final var metadataRes = resourceResolver.getResource(path + "/jcr:content/metadata");
		if (null == metadataRes) {
			return null;
		}
		final var metadataMap = metadataRes.getValueMap();
		final String language = metadataMap.get("videoSpokenLanguage", "");
		final var pageLanguage = pageLanguageFromVideoSpokenLanguage(language);
		final var jsonObj = new JSONObject();
		jsonObj.put("id", metadataMap.get("brc_id", ""));
		jsonObj.put("name", metadataMap.get("dc:title", ""));
		jsonObj.put("description", metadataMap.get("shortDescription", ""));
		jsonObj.put("linkURL", metadataMap.get("brc_link_url", ""));
		jsonObj.put("linkText", metadataMap.get("brc_link_text", ""));
		jsonObj.put("videoStillURL", getPosterUrl(path, pageLanguage));
		jsonObj.put("thumbnailURL", getThumbnailUrl(path, pageLanguage));
		jsonObj.put("length", metadataMap.get("brc_duration", ""));
		jsonObj.put("createdDate", metadataMap.get("brc_created_at", ""));
		jsonObj.put("publishedDate", metadataMap.get("dam:published", ""));
		jsonObj.put("transcript", metadataMap.get("transcript", "requested"));
		jsonObj.put("language", language);
		return jsonObj;
	}

	private String pageLanguageFromVideoSpokenLanguage(String videoSpokenLanguage) {
		if ("en".equalsIgnoreCase(videoSpokenLanguage)) {
			return "en-us";
		}
		if ("zh-cn".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-cn";
		}
		if ("zh-tw".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-tw";
		}
		if ("ja".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ja-jp";
		}
		if ("ko".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ko-kr";
		}
		if ("de".equalsIgnoreCase(videoSpokenLanguage)) {
			return "de-de";
		}
		return "en-us";
	}

	private String videoSpokenLanguageFromLocale(String locale) {
		if ("en-us".equalsIgnoreCase(locale)) {
			return "en";
		}
		if ("zh-cn".equalsIgnoreCase(locale)) {
			return "zh-cn";
		}
		if ("zh-tw".equalsIgnoreCase(locale)) {
			return "zh-tw";
		}
		if ("ja-jp".equalsIgnoreCase(locale)) {
			return "ja";
		}
		if ("ko-kr".equalsIgnoreCase(locale)) {
			return "ko";
		}
		if ("de-de".equalsIgnoreCase(locale)) {
			return "de";
		}
		return "en";
	}

	private String getPosterUrl(String path, String pageLanguage) {
		return PathBrowserHelper.setCorrectDomain(path + "/jcr:content/renditions/brc_poster.png", pageLanguage);
	}

	private String getThumbnailUrl(String path, String pageLanguage) {
		return PathBrowserHelper.setCorrectDomain(path + "/jcr:content/renditions/brc_thumbnail.png", pageLanguage);
	}
}
