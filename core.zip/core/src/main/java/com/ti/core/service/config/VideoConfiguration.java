package com.ti.core.service.config;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(
	name = "Texas Instruments Video Config Service",
	description = "Configuration for video assets in DAM")
public @interface VideoConfiguration {

	@AttributeDefinition(
		name = "Video path", description = "Video assets content path", type = AttributeType.STRING)
	public String videoPath();	  

	@AttributeDefinition(
		name = "Account ID", description = "Brightcove Account ID", type = AttributeType.STRING)
	public String accountId();

	@AttributeDefinition(
		name = "Video player ID", description = "Brightcove video player ID", type = AttributeType.STRING)
	public String playerId();

	@AttributeDefinition(
		name = "Partition size", description = "Partition size (number of videos per folder)", type = AttributeType.STRING)
	public int partitionSize();

	@AttributeDefinition(
		name = "Partition start index", description = "Partition startIndex", type = AttributeType.STRING)
	public int partitionStartIndex();

	@AttributeDefinition(
		name = "3Play API key", description = "3PlayMedia API key - required to call API", type = AttributeType.STRING)
	public String apiKey3play();	  	

}
