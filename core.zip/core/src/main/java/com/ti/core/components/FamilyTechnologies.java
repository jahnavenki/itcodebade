package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.PathBrowserHelper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FamilyTechnologies extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private LanguageUtils langUtils;

	private String sectionTitle;
	private String anchorLinkId;
	private String navTitle;
	private String sectionOverview;

	private final List<TabViewModel> tabs = new ArrayList<>();

	public String getSectionTitle() {
		return sectionTitle;
	}

	public void setSectionTitle( String sectionTitle ) {
		this.sectionTitle = sectionTitle;
	}

	public String getAnchorLinkId() {
		return anchorLinkId;
	}

	public void setAnchorLinkId( String anchorLinkId ) {
		this.anchorLinkId = anchorLinkId;
	}

	public String getNavTitle() {
		return navTitle;
	}

	public void setNavTitle( String navTitle ) {
		this.navTitle = navTitle;
	}

	public String getSectionOverview() {
		return sectionOverview;
	}

	public void setSectionOverview( String sectionOverview ) {
		this.sectionOverview = sectionOverview;
	}

	public List<TabViewModel> getTabs() {
		return tabs;
	}

	public static class TabViewModel {
		private String tabName;
		private String imageOrVideo;
		private String imageSrc;
		private String imageAlt;
		private String leftImageSrc;
		private String damMediaFileReference;
		private String damVideoImageAlt;
		private String leftImageAlt;
		private String leftImageMetricsName;
		private String leftImageCaption;
		private String rightImageSrc;
		private String rightImageAlt;
		private String rightImageMetricsName;
		private String rightImageCaption;
		private String videoId;
		private boolean enlargeImage;
		private String sectionSubTitle;
		private String storyDescription;
		private String thirdPartyLogoSrc;
		private final List<CtaViewModel> ctas = new ArrayList<>();
		private final List<FeaturedResourceViewModel> featuredResources = new ArrayList<>();
		private String featuredProductsHeadline;
		private final List<FeaturedProductViewModel> featuredProducts = new ArrayList<>();
		private final List<ButtonCtaViewModel> buttonctas = new ArrayList<>();

		public String getTabName() {
			return tabName;
		}

		public String getImageOrVideo() {
			return imageOrVideo;
		}

		public String getImageSrc() {
			return imageSrc;
		}

		public String getImageAlt() {
			return imageAlt;
		}

		public String getVideoId() {
			return videoId;
		}

		public boolean getEnlargeImage() {
			return enlargeImage;
		}

		public String getLeftImageSrc() {
			return leftImageSrc;
		}

		public String getDamMediaFileReference() {
			return damMediaFileReference;
		}

		public String getLeftImageAlt() {
			return leftImageAlt;
		}

		public String getDamVideoImageAlt() {
			return damVideoImageAlt;
		}

		public String getLeftImageMetricsName() {
			return leftImageMetricsName;
		}

		public String getLeftImageCaption() {
			return leftImageCaption;
		}

		public String getRightImageSrc() {
			return rightImageSrc;
		}

		public String getRightImageAlt() {
			return rightImageAlt;
		}

		public String getRightImageMetricsName() {
			return rightImageMetricsName;
		}

		public String getRightImageCaption() {
			return rightImageCaption;
		}

		public String getSectionSubTitle() {
			return sectionSubTitle;
		}

		public String getStoryDescription() {
			return storyDescription;
		}

		public String getThirdPartyLogoSrc() {
			return thirdPartyLogoSrc;
		}

		public void setThirdPartyLogoSrc(String thirdPartyLogoSrc) {
			this.thirdPartyLogoSrc = thirdPartyLogoSrc;
		}

		public List<CtaViewModel> getCtas() {
			return ctas;
		}

		public List<FeaturedResourceViewModel> getFeaturedResources() {
			return featuredResources;
		}

		public String getFeaturedProductsHeadline() {
			return featuredProductsHeadline;
		}

		public List<FeaturedProductViewModel> getFeaturedProducts() {
			return featuredProducts;
		}

		public List<ButtonCtaViewModel> getButtonCtas() {
			return buttonctas;
		}

		public void setTabName( String tabName ) {
			this.tabName = tabName;
		}

		public void setImageOrVideo( String imageOrVideo ) {
			this.imageOrVideo = imageOrVideo;
		}

		public void setImageSrc( String imageSrc ) {
			this.imageSrc = imageSrc;
		}

		public void setImageAlt( String imageAlt ) {
			this.imageAlt = imageAlt;
		}

		public void setLeftImageSrc( String leftImageSrc ) {
			this.leftImageSrc = leftImageSrc;
		}

		public void setDamMediaFileReference( String damMediaFileReference ) {
			this.damMediaFileReference = damMediaFileReference;
		}

		public void setLeftImageAlt( String leftImageAlt ) {
			this.leftImageAlt = leftImageAlt;
		}

		public void setDamVideoImageAlt( String damVideoImageAlt ) {
			this.damVideoImageAlt = damVideoImageAlt;
		}

		public void setLeftImageMetricsName( String leftImageMetricsName ) {
			this.leftImageMetricsName = leftImageMetricsName;
		}

		public void setLeftImageCaption( String leftImageCaption ) {
			this.leftImageCaption = leftImageCaption;
		}

		public void setRightImageSrc( String rightImageSrc ) {
			this.rightImageSrc = rightImageSrc;
		}

		public void setRightImageAlt( String rightImageAlt ) {
			this.rightImageAlt = rightImageAlt;
		}

		public void setRightImageMetricsName( String rightImageMetricsName ) {
			this.rightImageMetricsName = rightImageMetricsName;
		}

		public void setRightImageCaption( String rightImageCaption ) {
			this.rightImageCaption = rightImageCaption;
		}

		public void setVideoId( String videoId ) {
			this.videoId = videoId;
		}

		public void setEnlargeImage( boolean enlargeImage ) {
			this.enlargeImage = enlargeImage;
		}

		public void setSectionSubTitle( String sectionSubTitle ) {
			this.sectionSubTitle = sectionSubTitle;
		}

		public void setStoryDescription( String storyDescription ) {
			this.storyDescription = storyDescription;
		}

		public void setFeaturedProductsHeadline( String featuredProductsHeadline ) {
			this.featuredProductsHeadline = featuredProductsHeadline;
		}
	}

	public static class CtaViewModel {
		private String ctaLabel;
		private String ctaUrl;
		private String ctaIcon;

		public String getCtaLabel() {
			return ctaLabel;
		}

		public String getCtaUrl() {
			return ctaUrl;
		}

		public String getCtaIcon() {
			return ctaIcon;
		}

		public void setCtaLabel( String ctaLabel ) {
			this.ctaLabel = ctaLabel;
		}

		public void setCtaUrl( String ctaUrl ) {
			this.ctaUrl = ctaUrl;
		}

		public void setCtaIcon( String ctaIcon ) {
			this.ctaIcon = ctaIcon;
		}
	}

	public static class ButtonCtaViewModel {
		private String buttonCtaLabel;
		private String buttonCtaURL;

		public void setButtonCtaLabel( String buttonCtaLabel ) {
			this.buttonCtaLabel = buttonCtaLabel;
		}

		public String getButtonCtaLabel() {
			return buttonCtaLabel;
		}

		public void setButtonCtaURL( String buttonCtaURL ) {
			this.buttonCtaURL = buttonCtaURL;
		}

		public String getButtonCtaURL() {
			return buttonCtaURL;
		}
	}

	public static class FeaturedResourceViewModel {
		private String resourceType;
		private String resourceTypeDescription;
		private String title;
		private String description;
		private String htmlUrl;
		private String url;

		public String getResourceType() {
			return resourceType;
		}

		public String getResourceTypeDescription() {
			return resourceTypeDescription;
		}

		public String getTitle() {
			return title;
		}

		public String getDescription() {
			return description;
		}

		public String getHtmlUrl() {
			return htmlUrl;
		}

		public String getUrl() {
			return url;
		}

		public void setResourceType( String resourceType ) {
			this.resourceType = resourceType;
		}

		public void setResourceTypeDescription( String resourceTypeDescription ) {
			this.resourceTypeDescription = resourceTypeDescription;
		}

		public void setTitle( String title ) {
			this.title = title;
		}

		public void setDescription( String description ) {
			this.description = description;
		}

		public void setHtmlUrl( String htmlUrl ) {
			this.htmlUrl = htmlUrl;
		}

		public void setUrl( String url ) {
			this.url = url;
		}
	}

	public static class FeaturedProductViewModel {
		private String gpn;
		private String url;
		private String imageSrc;
		private String description;
		private boolean newFlag;
		private Integer marketingStatusId;
		private String marketingStatus;
		private String marketingStatusDescription;

		public String getGpn() {
			return gpn;
		}

		public String getUrl() {
			return url;
		}

		public String getImageSrc() {
			return imageSrc;
		}

		public String getDescription() {
			return description;
		}

		public boolean getNewFlag() {
			return newFlag;
		}

		public Integer getMarketingStatusId() {
			return marketingStatusId;
		}

		public String getMarketingStatus() {
			return marketingStatus;
		}

		public String getMarketingStatusDescription() {
			return marketingStatusDescription;
		}

		public void setGpn( String gpn ) {
			this.gpn = gpn;
		}

		public void setUrl( String url ) {
			this.url = url;
		}

		public void setImageSrc( String imageSrc ) {
			this.imageSrc = imageSrc;
		}

		public void setDescription( String description ) {
			this.description = description;
		}

		public void setNewFlag( boolean newFlag ) {
			this.newFlag = newFlag;
		}

		public void setMarketingStatusId( Integer marketingStatusId ) {
			this.marketingStatusId = marketingStatusId;
		}

		public void setMarketingStatus( String marketingStatus ) {
			this.marketingStatus = marketingStatus;
		}

		public void setMarketingStatusDescription( String marketingStatusDescription ) {
			this.marketingStatusDescription = marketingStatusDescription;
		}
	}

	private static class Literature {
		private String litNumber;
		private String category;
		private String title;
		private String url;
		private String htmlUrl;

		public String getLitNumber() {
			return litNumber;
		}

		public String getCategory() {
			return category;
		}

		public String getTitle() {
			return title;
		}

		public String getUrl() {
			return url;
		}

		public String getHtmlUrl() {
			return htmlUrl;
		}

		public void setLitNumber( String litNumber ) {
			this.litNumber = litNumber;
		}

		public void setCategory( String category ) {
			this.category = category;
		}

		public void setTitle( String title ) {
			this.title = title;
		}

		public void setUrl( String url ) {
			this.url = url;
		}

		public void setHtmlUrl( String htmlUrl ) {
			this.htmlUrl = htmlUrl;
		}
	}

	private String getImageAltText( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		final var asset = resource.adaptTo(Asset.class);
		if(null == asset) return "";
		return asset.getMetadataValue("dc:title");
	}

	private String getImageFilename( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		return resource.getName();
	}

	private String getNavTitle( String anchorLinkId ) {
		var key = anchorLinkId;
		switch(anchorLinkId) {
			case "ti-developer-zone":
				key = "developerZone";
				break;
			case "educational-resources":
				key = "educationalResources";
				break;
			case "optical-modules":
				key = "opticalModules";
				break;
			case "design-tools":
				key = "designTools";
				break;
		}
		return langUtils.getI18nStr("designResources:" + key);
	}

	private Literature getLiterature( String litNumber ) throws JSONException {
		final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		if(null == wcmService) return null;
		var language = "en-us";
		final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
		if(null != tabsService) {
			language = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
		}
		final var langUtils = new LanguageUtils(getRequest());
		final var response = wcmService.getFeaturedliterature(litNumber, language);
		if(StringUtils.isEmpty(response)) return null;
		final var json = new JSONObject(response);
		final var literature = new Literature();
		final var litNumberFromDb = json.getString("literatureNumber").substring(0,7);
		literature.setLitNumber(litNumberFromDb);
		final var documentCategory = json.getJSONObject("documentCategory");
		if(null != documentCategory) {
			literature.setCategory(documentCategory.getString("docCategory"));
		}
		literature.setTitle(json.getString("conciseDescription"));
		literature.setUrl(langUtils.getI18nStr("https://www.ti.com/lit/") + litNumberFromDb);
		if(json.getBoolean("htmlPackageAvailability")) {
			literature.setHtmlUrl(langUtils.getI18nStr("https://www.ti.com/document-viewer/lit/html/") + litNumberFromDb);
		}
		return literature;
	}

	private TabViewModel buildTabViewModel( Resource tabResource ) throws JSONException {
		final var valueMap = tabResource.getValueMap();
		final var languageUtils = new LanguageUtils(getRequest());
		final var tab = new TabViewModel();
		tab.setTabName( valueMap.get("tabName", "") );
		final String imageOrVideo = valueMap.get("imageOrVideo", "");
		tab.setImageOrVideo( imageOrVideo );
		if("image".equals(imageOrVideo)) {
			final var imageSrc = valueMap.get("imageSrc", "");
			tab.setImageSrc( imageSrc );
			tab.setImageAlt( getImageAltText(imageSrc) );
			tab.setEnlargeImage( valueMap.get( "enlargeImage", false ) );
		} else if("video".equals(imageOrVideo)) {
			tab.setVideoId( valueMap.get("videoId", "") );
		} else if("videoFromDam".equals(imageOrVideo)) {
			final var damMediaFileReference = valueMap.get("damMediaFileReference", "");
			tab.setDamVideoImageAlt( getImageAltText(damMediaFileReference) );
			tab.setDamMediaFileReference( damMediaFileReference );
		} else if("imageComparison".equals(imageOrVideo)) {
			final var leftImageSrc = valueMap.get("leftImageSrc", "");
			tab.setLeftImageSrc( leftImageSrc );
			tab.setLeftImageAlt( getImageAltText(leftImageSrc) );
			tab.setLeftImageMetricsName( getImageFilename(leftImageSrc) );
			tab.setLeftImageCaption( valueMap.get("leftImageCaption", "") );
			final var rightImageSrc = valueMap.get("rightImageSrc", "");
			tab.setRightImageSrc( rightImageSrc );
			tab.setRightImageAlt( getImageAltText(rightImageSrc) );
			tab.setRightImageMetricsName( getImageFilename(rightImageSrc) );
			tab.setRightImageCaption( valueMap.get("rightImageCaption", "") );
		}
		tab.setSectionSubTitle( valueMap.get("sectionSubTitle", "") );
		tab.setStoryDescription( valueMap.get("storyDescription", "") );
		tab.setThirdPartyLogoSrc( valueMap.get("thirdPartyLogoSrc","") );
		final var ctasResource = getResourceResolver().getResource(tabResource, "ctas");
		if( null != ctasResource ) {
			for( var ctaResource : ctasResource.getChildren() ) {
				tab.getCtas().add( buildCtaViewModel( ctaResource ) );
			}
		}

		final var featuredResourcesResource = getResourceResolver().getResource(tabResource, "featuredResources");
		if( null != featuredResourcesResource ) {
			for( var featuredResourceResource : featuredResourcesResource.getChildren() ) {
				tab.getFeaturedResources().add( buildFeaturedResourceViewModel( featuredResourceResource ) );
			}
		}

		final var featuredProductsResource = getResourceResolver().getResource(tabResource, "featuredProducts");
		if( null != featuredProductsResource ) {
			for( var featuredProductResource : featuredProductsResource.getChildren() ) {
				tab.getFeaturedProducts().add( buildFeaturedProductViewModel( featuredProductResource ) );
			}
		}

		if( !tab.getFeaturedProducts().isEmpty() ) {
			final var technologyName = valueMap.get( "technologyName", "" );
			tab.setFeaturedProductsHeadline( languageUtils.getI18nStr( "Featured products for {}", technologyName ) );
		}

        final var buttonCtasResource = getResourceResolver().getResource(tabResource, "buttonctas");
	    if( null != buttonCtasResource ) {
		    for( var buttonCtaResource : buttonCtasResource.getChildren() ) {
			    tab.getButtonCtas().add( buildButtonCtaViewModel( buttonCtaResource ) );
		    }
	    }

		return tab;
	}

	private CtaViewModel buildCtaViewModel( Resource ctaResource ) {
		final var valueMap = ctaResource.getValueMap();
		final var cta = new CtaViewModel();
		cta.setCtaLabel( valueMap.get( "ctaLabel", "" ) );
		var ctaUrl = valueMap.get( "ctaUrl", "" );
		cta.setCtaUrl( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), ctaUrl) );
		ctaUrl = ctaUrl.split("#")[0];
		cta.setCtaIcon((ctaUrl.endsWith( "/products" ) || ctaUrl.endsWith( "/products.html" )) ? "parametric-filter" : "arrow-right" );
		return cta;
	}

	private ButtonCtaViewModel buildButtonCtaViewModel( Resource buttonctaResource ) {
		final var valueMap = buttonctaResource.getValueMap();
		final var buttoncta = new ButtonCtaViewModel();
		buttoncta.setButtonCtaLabel( valueMap.get( "buttonctaLabel", "" ) );
		var buttonctaURL = valueMap.get( "buttonctaURL", "" );
		buttoncta.setButtonCtaURL( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), buttonctaURL) );
		return buttoncta;
	}

	private FeaturedResourceViewModel buildFeaturedResourceViewModel( Resource featuredResourceResource ) throws JSONException {
		final var valueMap = featuredResourceResource.getValueMap();
		final var featuredResource = new FeaturedResourceViewModel();
		final String resourceType = valueMap.get( "resourceType", "" );
		featuredResource.setResourceType( resourceType );
		if( "technicalDocs".equals( resourceType ) ) {
			final var literature = getLiterature(valueMap.get( "litNumber", "" ));
			if(null != literature) {
				featuredResource.setResourceTypeDescription( literature.getCategory() );
				featuredResource.setTitle( literature.getTitle() );
				featuredResource.setHtmlUrl( literature.getHtmlUrl() );
				featuredResource.setUrl( literature.getUrl() );
			}
		} else {
			featuredResource.setResourceTypeDescription( langUtils.getI18nStr( "resourceType:" + resourceType ) );
			featuredResource.setTitle( valueMap.get( "title", "" ) );
			var url = valueMap.get( "url", "" );
			featuredResource.setUrl( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), url) );
		}

		featuredResource.setDescription( valueMap.get( "description", "" ) );

		return featuredResource;
	}

	private FeaturedProductViewModel buildFeaturedProductViewModel( Resource featuredProductResource ) throws JSONException {
		final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		if(null == wcmService) return null;
		final var langUtils = new LanguageUtils(getRequest());
		final var language = langUtils.getPageLanguageForProductFolder();
		final var valueMap = featuredProductResource.getValueMap();
		final var featuredProduct = new FeaturedProductViewModel();
		final var json = wcmService.getFeaturedProduct(valueMap.get( "gpn", "" ), language);
		if(null == json) return featuredProduct;
		final var gpn = json.getString("genericPartNumber");
		featuredProduct.setGpn( gpn );
		featuredProduct.setUrl( langUtils.getI18nStr( "https://www.ti.com/product/{0}", gpn ) );
		featuredProduct.setImageSrc( json.getString("partImageUrl") );
		featuredProduct.setDescription( json.getString("deviceDescription") );
		featuredProduct.setNewFlag( json.getBoolean("newFlag") );
		featuredProduct.setMarketingStatusId( json.getInt("marketingStatusId") );
		featuredProduct.setMarketingStatus( json.getString("marketingStatus") );
		featuredProduct.setMarketingStatusDescription( json.getString("marketingStatusDescription") );
		return featuredProduct;
	}

	@Override
	public void activate() {
		try {
			langUtils = new LanguageUtils(getRequest());
			final var properties = getProperties();
			setSectionTitle( properties.get("sectionTitle", "") );
			final var anchorLinkId = properties.get("anchorLinkId", "");
			setNavTitle( getNavTitle( anchorLinkId ) );
			setAnchorLinkId( anchorLinkId );
			setSectionOverview( properties.get("sectionOverview", "") );
			final var tabsResource = getResourceResolver().getResource(getResource(), "tabs");
			if( null != tabsResource ) {
				for( var tabResource : tabsResource.getChildren() ) {
					tabs.add( buildTabViewModel( tabResource ) );
				}
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
