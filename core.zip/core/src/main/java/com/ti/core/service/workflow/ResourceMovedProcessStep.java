package com.ti.core.service.workflow;

import org.apache.commons.io.FilenameUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.components.DomainComponent;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step for resource moved.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Resource Moved" })
public class ResourceMovedProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private SeoUrlFactoryConfigs seoUrlFactoryConfigs;

	@Reference
	private WCMComponents wcmService;

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var metadata = workflowData.getMetaDataMap();
			final var username = metadata.get("username", String.class);
			final var srcAbsPath = metadata.get("srcAbsPath", String.class);
			final var payload = workflowData.getPayload().toString();
			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) throw new NullPointerException("resourceResolver");
			final var resource = resourceResolver.getResource(payload);
			if (null == resource) return;
			final var map = AssetUtils.getModifiableMetadata(resource);
			if (null == map) return;
			final var filename = FilenameUtils.getName(payload);
			map.put("dam:filename", filename);
			resourceResolver.commit();
			final var domain = DomainComponent.getDomainFromConfig( seoUrlFactoryConfigs, "/content/texas-instruments/en-us/homepage" );
			final var market = map.get("dam:importedMarket", String.class);
			final var opn = map.get("dam:sapMaterialName", String.class);
			final var gpn = map.get("dam:gpn", String.class);
			final var variant = map.get("dam:epodOrPackageVariant", String.class);
			final var deletedTimestamp = new Date();
			final var publishUrl = "https://" + domain + srcAbsPath;
			final var assetType = map.get("dam:assetType", String.class);
			wcmService.boomiDamDelete("MOVE", username, market, opn, gpn, variant, deletedTimestamp, publishUrl, assetType);
		} catch (Exception e) {
			log.error("Error occurred in ResourceMovedProcessStep", e);
		}
	}
}
