package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;
import com.ti.core.util.Constants;

/**
 * DocCategoriesServlet is used to read the document categories
 * 
 * @author saryu.sukumar
 *
 */
@SuppressWarnings("serial")
@Component(name = "ToolDetailsServlet", immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_PATHS + "=/bin/ti/tooldetails", 
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_EXTENSIONS+"=json"})
public class ToolServlet extends SlingSafeMethodsServlet {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(ToolServlet.class);
	private static final String TOOL_ORDERABLE_PART_NUMBER = "toolOrderableNumber";
	private static final String TOOL_PART_NUMBER = "toolPartNumber";

	private String tooldetailsResponse = "";

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		executeQuery(response, request);
	}

	/**
	 * Execute query.
	 *
	 * @param response
	 *            the response
	 * @param request
	 *            the request
	 */
	public void executeQuery(SlingHttpServletResponse response, SlingHttpServletRequest request) {
		String orderablepart = request.getParameter(TOOL_ORDERABLE_PART_NUMBER);
		String toolPartNumber = request.getParameter(TOOL_PART_NUMBER);

		String path = request.getRequestURI();
		String[] langList = StringUtils.split(Constants.LANG_REGION_CODES_ALL, "|");
		String language = "en-us";

		for (int i=0; i < langList.length; i++) {
			if (path.contains(langList[i])) {
				language = langList[i];
				break;
			}
		}
		log.debug("language for storepromoServlet " + language + orderablepart);
		if (StringUtils.isNotEmpty(orderablepart)) {

			this.tooldetailsResponse = null != wcmService
					? wcmService.getToolOpnService(request, orderablepart, language) : "";
			log.debug("tool response" + tooldetailsResponse);
			response.setContentType("text/x-json;charset=UTF-8");
			try {
				response.getWriter().write(StringEscapeUtils.unescapeHtml4(tooldetailsResponse));
			} catch (IOException e) {
				log.error("Exception in tool orderable details response", e);
			}
		} else if (StringUtils.isNotEmpty(toolPartNumber)) {
			this.tooldetailsResponse = null != wcmService
					? wcmService.getToolDetailService(request, toolPartNumber, language) : "";
			log.debug("tool response" + tooldetailsResponse);
			response.setContentType("text/x-json;charset=UTF-8");
			try {
				response.getWriter().write(StringEscapeUtils.unescapeHtml4(tooldetailsResponse));
			} catch (IOException e) {
				log.error("Exception in tool details response", e);
			}
		}

	}
}