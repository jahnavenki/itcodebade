package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.LoggerFactory;

import com.ti.core.service.ApiPortalService;

import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class, Resource.class},
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ApiCard {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ApiPortalService apiPortalService;

	@ValueMapValue
	private String title;

	@ValueMapValue
	private String desc;

	@ValueMapValue(name = "fileReference")
	private String image;

	@ValueMapValue
	private String url;

	private Boolean secure;

	@ValueMapValue
	private String ctaLabel;

	@PostConstruct
	public void init(){
		try {
			title = StringUtils.defaultString(title);
			desc = StringUtils.defaultString(desc);
			image = StringUtils.defaultString(image);
			url = apiPortalService.getUrl(url);
			secure = apiPortalService.isSecureUrl(url);
			ctaLabel = StringUtils.defaultString(ctaLabel);
		} catch (Exception e) {
			log.error("Exception in ApiCard", e);
		}
	}

	public String getCtaLabel() {
		return ctaLabel;
	}

	public String getTitle() {
		return title;
	}

	public String getDesc() {
		return desc;
	}

	public String getImage() {
		return image;
	}

	public String getUrl() {
		return url;
	}

	public Boolean isSecure() {
		return secure;
	}
}
