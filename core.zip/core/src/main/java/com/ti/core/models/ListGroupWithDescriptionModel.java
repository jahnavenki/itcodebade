package com.ti.core.models;

/**
* @param linkTitle,linkURL,linkDescription
*          the linkTitle to set.
*          the linkURL to set.
           the linkDescription to set.
*          
*     get linkTitle,linkURL,linkDescription.
* @return the linkTitle,linkURL,linkDescription.
*         
**/

public class ListGroupWithDescriptionModel  {
  private String linkTitle;
  private String linkDescription;
  private String descLinkURL;

  public String getLinkTitle() {
    return linkTitle;
  }
  public void setLinkTitle(final String linkTitle) {
    this.linkTitle = linkTitle;
  }
  public String getDescLinkURL() {
    return descLinkURL;
  }
  public void setDescLinkURL(final String descLinkURL) {
    this.descLinkURL = descLinkURL;
	}

    public String getLinkDescription() {
        return linkDescription;
      }
    
      public void setLinkDescription(final String linkDescription) {
        this.linkDescription = linkDescription;
      }
}
