package com.ti.core.filters;

import static org.apache.sling.engine.EngineConstants.FILTER_SCOPE_REQUEST;
import static org.apache.sling.engine.EngineConstants.SLING_FILTER_PATTERN;
import static org.apache.sling.engine.EngineConstants.SLING_FILTER_SCOPE;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;

/**
 * TI rendition filter
 * 
 * @author Richard Chan
 *
 *
@SlingFilter(
        label = "RenditionFilter",
        description = "TI rendition filter",
        metatype = true,
        generateComponent = true, // True if you want to leverage activate/deactivate
        generateService = true,
        order = 0, // The smaller the number, the earlier in the Filter chain (can go negative)
        scope = SlingFilterScope.REQUEST) // REQUEST, INCLUDE, FORWARD, ERROR, COMPONENT (REQUEST, INCLUDE, COMPONENT)
@Properties({
    @Property(
            name = "sling.filter.pattern",
            value = "(?i).*\\.(jpg|jpeg|png|svg):.+"
    )
})
*/
@Component(service = Filter.class, name = "tiRenditionFilter", property = {
		SLING_FILTER_SCOPE + "=" + FILTER_SCOPE_REQUEST, Constants.SERVICE_RANKING + ":Integer=0",
		SLING_FILTER_PATTERN + "=(?i).*\\.(jpg|jpeg|png|svg):.+" })
public class RenditionFilter implements Filter {
	private static final Logger log = LoggerFactory.getLogger(RenditionFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Must implement init even if empty
    }
 
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (request instanceof SlingHttpServletRequest) {
            final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;

           	Asset asset = slingRequest.getResource().adaptTo(Asset.class);
           	if (asset != null) {
           		// Find the rendition matching the selector
           		String selector = java.net.URLDecoder.decode(slingRequest.getRequestURI().replaceAll("(?i).*\\.(jpg|jpeg|png|svg):", ""),"UTF-8");

           		Rendition matchingRendition = findMatchingRendition(asset, selector);

            	if (matchingRendition != null)
            		slingRequest.getRequestDispatcher(matchingRendition.getPath()).forward(slingRequest, response);
           	}
        }
        // to proceed with the rest of the Filter chain
        chain.doFilter(request, response);
    }

    private Rendition findMatchingRendition(Asset asset, String selector) {
    	final String GT = ">";
    	final String GTE = ">=";
    	final String LT = "<";
    	final String LTE = "<=";
    	final String WIDTH_HEIGHT_DELIMITER = "(?i)x";
   		String[] selectorWidthHeight = null;

   		// Determine if dimension selector is used (otherwise name selector)
		if (selector.startsWith(GT)) {
			if (selector.startsWith(GTE)) {
				selectorWidthHeight = selector.substring(2).split(WIDTH_HEIGHT_DELIMITER);
				selector = GTE;
			}
			else {
				selectorWidthHeight = selector.substring(1).split(WIDTH_HEIGHT_DELIMITER);
				selector = GT;
			}
		}
		else if (selector.startsWith(LT)) {
			if (selector.startsWith(LTE)) {
				selectorWidthHeight = selector.substring(2).split(WIDTH_HEIGHT_DELIMITER);
				selector = LTE;
			}
			else {
				selectorWidthHeight = selector.substring(1).split(WIDTH_HEIGHT_DELIMITER);
				selector = LT;
			}
		}

		// Find matching rendition main routine
		Rendition matchingRendition = null;
    	try {
			boolean gtCond, gteCond, ltCond, lteCond;
			int renditionWidth, renditionHeight, selectorWidth, selectorHeight;
	    	int lastWidth = 0;
	    	int lastHeight = 0;
	    	BufferedImage bImg;
        	for (Rendition rendition : asset.getRenditions()) {
        		// Go through only custom renditions, skip any OOTB renditions
        		if (rendition.getName().startsWith("cq5dam"))
        			continue;

        		// Based on selector type, find rendition by either name or by dimension.
        		if (selectorWidthHeight == null) {
        			// Find rendition by name selector (exact match only)
        			if (selector.equalsIgnoreCase(rendition.getName().split("\\.")[0]))
            			return rendition;
        		}
        		else {
        			// Find rendition by dimension selector (by providing desired width and/or height)
        			bImg = ImageIO.read(rendition.getStream());
        	    	renditionWidth = bImg.getWidth();
        	    	renditionHeight = bImg.getHeight();
        			bImg.flush();

        			if (selectorWidthHeight.length == 1) {
        				// Only width selector is provided
        				selectorWidth = Integer.parseInt(selectorWidthHeight[0]);

        				if ((GT.equals(selector) && renditionWidth > selectorWidth) || (GTE.equals(selector) && renditionWidth >= selectorWidth) ) {
        					if (lastWidth == 0 || renditionWidth < lastWidth) {
        						lastWidth = renditionWidth;
        						matchingRendition = rendition;
        					}
        				}
        				else if ((LT.equals(selector) && renditionWidth < selectorWidth) || (LTE.equals(selector) && renditionWidth <= selectorWidth) ) {
        					if (lastWidth == 0 || renditionWidth > lastWidth) {
        						lastWidth = renditionWidth;
        						matchingRendition = rendition;
        					}
        				}
        			}
        			if (selectorWidthHeight.length == 2) {
        				if (selectorWidthHeight[0].isEmpty()) {
            				// Only height selector is provided
            				selectorHeight = Integer.parseInt(selectorWidthHeight[1]);

            				if ((GT.equals(selector) && renditionHeight > selectorHeight) || (GTE.equals(selector) && renditionHeight >= selectorHeight) ) {
            					if (lastHeight == 0 || renditionHeight < lastHeight) {
            						lastHeight = renditionHeight;
            						matchingRendition = rendition;
            					}
            				}
            				else if ((LT.equals(selector) && renditionHeight < selectorHeight) || (LTE.equals(selector) && renditionHeight <= selectorHeight) ) {
            					if (lastHeight == 0 || renditionHeight > lastHeight) {
            						lastHeight = renditionHeight;
            						matchingRendition = rendition;
            					}
            				}
        				}
        				else {
            				// Both width and height selectors are provided
            				selectorWidth = Integer.parseInt(selectorWidthHeight[0]);
            				selectorHeight = Integer.parseInt(selectorWidthHeight[1]);

            				gtCond = GT.equals(selector) && renditionWidth > selectorWidth && renditionHeight > selectorHeight;
            				gteCond = GTE.equals(selector) && renditionWidth >= selectorWidth && renditionHeight >= selectorHeight;
            				if (gtCond || gteCond) {
            					if (lastWidth == 0 || (renditionWidth < lastWidth && renditionHeight < lastHeight)) {
            						lastWidth = renditionWidth;
            						lastHeight = renditionHeight;
            						matchingRendition = rendition;
            					}
            				}
            				else {
                				ltCond = LT.equals(selector) && renditionWidth < selectorWidth && renditionHeight < selectorHeight;
                				lteCond = LTE.equals(selector) && renditionWidth <= selectorWidth && renditionHeight <= selectorHeight;
            					if (ltCond || lteCond) {
                					if (lastWidth == 0 || (renditionWidth > lastWidth && renditionHeight > lastHeight)) {
                						lastWidth = renditionWidth;
                						lastHeight = renditionHeight;
                						matchingRendition = rendition;
                					}
            					}
            				}
        				}
        			}
        		}
    		}
    	}
    	catch (Exception e) {
    		log.error("Error in findMatchingRendition", e);
    	}

    	return matchingRendition;
    }

    @Override
    public void destroy() {
        // Must implement destroy even if empty
    }
}