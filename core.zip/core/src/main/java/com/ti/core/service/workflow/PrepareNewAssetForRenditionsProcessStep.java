package com.ti.core.service.workflow;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.ti.core.models.assets.RenditionsMapping;
import com.ti.core.service.RenditionsMappingsConfig;
import com.ti.core.util.AssetUtils;

/**
 * 
 * PrepareNewAssetForRenditionsProcessStep
 * 
 * @author Richard Chan


		"Workflow step for preparing newly created or copied assets fo renditions: copy source file and update metadata mapping" }) })
 */
@Component(service = WorkflowProcess.class, immediate=true, property = {
		Constants.SERVICE_DESCRIPTION + "=Workflow step for preparing newly created or copied assets fo renditions: copy source file and update metadata mapping",
		Constants.SERVICE_VENDOR + "=TI",
		"process.label=TI: Prepare New Asset For Renditions " })
public class PrepareNewAssetForRenditionsProcessStep implements WorkflowProcess {
	private static final Logger log = LoggerFactory.getLogger(PrepareNewAssetForRenditionsProcessStep.class);
	
    @Reference
    RenditionsMappingsConfig mappingsService;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final WorkflowData workflowData = item.getWorkflowData();
			String payload = workflowData.getPayload().toString();

			ResourceResolver resourceResolver = session.adaptTo(ResourceResolver.class);
			if (resourceResolver == null)
				return;

			Resource resource = resourceResolver.getResource(payload);
			if (resource == null)
				return;

			ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
			if (map == null)
				return;

			final String DAM_FOLDER = "dam:folder";
			final String assetFolder = resource.getPath().replace(resource.getName(), StringUtils.EMPTY);
			String lastFolder = map.get(DAM_FOLDER, String.class);

			// Proceed with source and mapping applications only if this is a newly uploaded asset, or the asset has changed path  
			if (!StringUtils.equals(assetFolder, lastFolder)) {
				log.debug("Updating asset path.  New: {}, old: {}", resource.getPath(), lastFolder);

				map.put(DAM_FOLDER, assetFolder);
				// Remove existing mapping(s) from asset's metadata if lastPath already exists 
				if (!StringUtils.isBlank(lastFolder))
					map.remove(AssetUtils.RENDITIONS_MAPPINGS);
				resourceResolver.commit();

				// Find all renditions mapping(s) that apply for this asset's path
				List<RenditionsMapping> renditionsMappingsList = AssetUtils.getRenditionsMappingsForPath(mappingsService.getRenditionsMappings(), resource.getPath());
				for (RenditionsMapping mapping : renditionsMappingsList) {
            		log.debug("Uploaded asset {} found matching renditions mapping: {}", resource.getPath(), mapping.getString(RenditionsMapping.IMAGE_TYPE));
					
					// 1) Apply source file treatment if applicable, and 2) if source file has been applied (or already been applied), then update the asset's metadata mapping
					if (AssetUtils.applySourceToSubasset(resource.adaptTo(Asset.class), mapping, resourceResolver))
						AssetUtils.applyRenditionsMappingToAssetMetadata(AssetUtils.getModifiableMetadata(resource), mapping, resourceResolver);
				}
			}
		}
		catch (Exception e) {
			log.error("Error occurred in PrepareNewAssetForRenditionsProcessStep", e);
		}
	}
}