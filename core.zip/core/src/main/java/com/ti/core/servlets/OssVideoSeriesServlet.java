package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.SightlyWCMMode;
import com.day.cq.replication.ReplicationStatus;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.ReportingUtils;

@Component(service = Servlet.class, immediate=true, property = {
	SLING_SERVLET_PATHS + "=/bin/ti/oss/video-series", 
	SLING_SERVLET_METHODS + "=GET" })
public class OssVideoSeriesServlet extends SlingSafeMethodsServlet {
	protected static final Logger log = LoggerFactory.getLogger(OssVideoSeriesServlet.class);

	@Reference
	private transient WCMComponents wcmService;

	private transient SightlyWCMMode wcmMode;

	private transient Session session;

	private transient ResourceResolver resourceResolver;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		try {
			resourceResolver = request.getResourceResolver();
			session = resourceResolver.adaptTo(Session.class);
			wcmMode = new SightlyWCMMode(request);
			var languageQuery = request.getParameter("language");
			if (StringUtils.isBlank(languageQuery)) {
				languageQuery = "en";
			}
			final var pageLanguage = pageLanguageFromVideoSpokenLanguage(languageQuery);
			final var query = "select parent.* from [cq:Page] as parent inner join [nt:unstructured] as child on ischildnode(child,parent) where child.[cq:template] = '/conf/ti/settings/wcm/templates/video-series-page-template' and isdescendantnode(parent, '/content/texas-instruments/" + pageLanguage + "/video/series')";
			final var nodeIter = ReportingUtils.executeQuery(query, session);
			if (null == nodeIter) {
				return;
			}
			final var jsonResponse = new JSONArray();
			while (nodeIter.hasNext()) {
				final var node = nodeIter.nextNode();
				final var jsonObj = getJson(node.getPath());
				if (null != jsonObj) { 
					jsonResponse.put(jsonObj);
				}
			}
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			jsonResponse.write(response.getWriter());
		} catch (Exception ex) {
			log.error( "Exception", ex );
		}
	}

	private boolean isPublished( Resource resource ) {
		if (wcmMode.isDisabled()) {
			return true;
		}		
		final ReplicationStatus replicationStatus = resource.adaptTo(ReplicationStatus.class);
		return null != replicationStatus && replicationStatus.isActivated(); 
	}

	private JSONObject getJson( String path ) throws JSONException, RepositoryException {
		final var pageRes = resourceResolver.getResource(path);
		if (null == pageRes) {
			return null;
		}
		if (!isPublished(pageRes)) {
			return null;
		}
		final var contentRes = resourceResolver.getResource(pageRes, "jcr:content");
		if (null == contentRes) {
			return null;
		}
		final var titleRes = resourceResolver.getResource(contentRes, "videoTitleAndDescription");
		if (null == titleRes) {
			return null;
		}
		final var contentMap = contentRes.getValueMap();
		final var titleMap = titleRes.getValueMap();
		final var videoIds = getVideoIds(path);
		final var jsonObj = new JSONObject();
		jsonObj.put("url", PathBrowserHelper.addHtmlIfContentPath(resourceResolver, path));
		jsonObj.put("title", titleMap.get("title", ""));
		final var SHORT_DESCRIPTION_MAX_LENGTH = 160;
		var shortDescription = titleMap.get("description", "");
		if (shortDescription.length() > SHORT_DESCRIPTION_MAX_LENGTH ) {
			shortDescription = shortDescription.substring(0, SHORT_DESCRIPTION_MAX_LENGTH);
		}
		jsonObj.put("short_description", shortDescription);
		jsonObj.put("product_tree_id", getTagNames(contentMap.get("gpt", String[].class)));
		jsonObj.put("applications_designs_tree_id", getTagNames(contentMap.get("mse", String[].class)));
		jsonObj.put("tools_software_tree_id", getTagNames(contentMap.get("emsg", String[].class)));
		jsonObj.put("other_content_tree_id", getTagNames(contentMap.get("other", String[].class)));
		jsonObj.put("no_of_videos", videoIds.size());
		return jsonObj;
	}

	private List<String> getVideoIds( String path ) throws RepositoryException {
		final var query = "select * from [nt:unstructured] where [videoId] is not null and isdescendantnode('" + path + "')";
		final var retval = new ArrayList<String>();
		final var nodeIter = ReportingUtils.executeQuery(query, session);
		if (null == nodeIter) {
			return retval;
		}
		while (nodeIter.hasNext()) {
			final var node = nodeIter.nextNode();
			final var res = resourceResolver.getResource(node.getPath());
			if (null == res) {
				continue;
			}
			final var map = res.getValueMap();
			final var videoId = map.get("videoId", "");
			if (StringUtils.isNotEmpty(videoId)) {
				retval.add(videoId);
			}
		}
		return retval;
	}

	private String getTagNames(String[] tags) {
		if (null == tags) return "";
		final var tagNames = new ArrayList<String>();
		for (final var t : tags) {
			final var tagParts = t.split("/");
			final var tagName = tagParts[tagParts.length - 1];
			tagNames.add(tagName);
		}
		return String.join(",", tagNames);
	}

	private String pageLanguageFromVideoSpokenLanguage(String videoSpokenLanguage) {
		if ("en".equalsIgnoreCase(videoSpokenLanguage)) {
			return "en-us";
		}
		if ("zh-cn".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-cn";
		}
		if ("zh-tw".equalsIgnoreCase(videoSpokenLanguage)) {
			return "zh-tw";
		}
		if ("ja".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ja-jp";
		}
		if ("ko".equalsIgnoreCase(videoSpokenLanguage)) {
			return "ko-kr";
		}
		if ("de".equalsIgnoreCase(videoSpokenLanguage)) {
			return "de-de";
		}
		return "en-us";
	}
}
