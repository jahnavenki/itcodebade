package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import javax.jcr.Session;

public class FaqSchema extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private List<Map<String, String>> faqList = new ArrayList<>();
	
	@Override
	public void activate() throws Exception {
		try {
			String path=""; 
			Node currentNode = getResource().adaptTo(Node.class);
			NodeIterator faqIterator = null;
			if(null != currentNode && currentNode.hasNode("sectionTitles"))
			{	
				faqIterator=currentNode.getNode("sectionTitles").getNodes();
				path=currentNode.getParent().getPath();
			}
			if (faqIterator != null) {
				int count=0;
				while (faqIterator.hasNext()) {
					Node faqNode = faqIterator.nextNode();
					Map<String, String> faqMap = new HashMap<>();
					String questions = StringUtils.EMPTY;
					if (faqNode.hasProperty("sectionTitle")) {
						questions = faqNode.getProperty("sectionTitle").getString();
					}
					faqMap.put("questions", questions);
					count++;
					StringBuilder ansPath=new StringBuilder();
					ansPath.append(path);
					ansPath.append("/accordion/sectionTitlePar"+count);
					String answers = getAnswer(ansPath.toString());
					if (StringUtils.isNotEmpty(answers)) {
						faqMap.put("answers", answers);
						faqList.add(faqMap);
					}
				}
			}
		}catch (Exception ex) {
			log.error( "Exception", ex );
	}
}
	
	public List<Map<String, String>> getFaqList() {
		return faqList;
	} 

	private String getAnswer(String path) {
		ResourceResolver resourceResolver = getResourceResolver();
		Map<String, String> map = new HashMap<>();
		String answer="";
		map.put("path", path);
		map.put("type", "nt:unstructured");
		map.put("property", "textIsRich");
		map.put("property.operation", "exists");
		try{
			QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
			Session session = resourceResolver.adaptTo(Session.class);
			if(builder != null) {
				Query query = builder.createQuery(PredicateGroup.create(map), session);
				SearchResult result = query.getResult();
				for (Hit hit : result.getHits()) {
					String queryPath = hit.getPath();
					Resource resource = resourceResolver.getResource(queryPath);
					if(resource!=null){
						Node node = resource.adaptTo(Node.class);
						if(node!=null){
							answer = node.getProperty("text").getString();
						}	
					}
				}
			}
		}
		catch (Exception e) {
			log.error("Exception: ", e);
		}
		return answer;
	}

	public String  getSchema() throws JSONException {
		List<Map<String, String>> faqItems=getFaqList();
		final var faqPage = new JSONObject();
		faqPage.put("@context", "https://schema.org");
		faqPage.put("@type", "FAQPage");
		var faqSchema = new JSONArray();
		for (Map<String, String> faqItem : faqItems) {
		final var question = new JSONObject();
		question.put("@type", "Question");
		question.put("name", faqItem.get("questions"));
		final var answer = new JSONObject();
		answer.put("@type", "Answer");
		answer.put("text", faqItem.get("answers") );
		question.put("acceptedAnswer", answer);
		faqSchema.put(question);
		}

		faqPage.put("mainEntity", faqSchema);
		return faqPage.toString();
	} 
}