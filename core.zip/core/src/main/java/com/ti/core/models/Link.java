package com.ti.core.models;

public class Link {
    private String text;
    private String enText;
    private String href;
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getEnText() {
        return enText;
    }

    public void setEnText(String enText) {
        this.enText = enText;
    }
    public void setText( String text ) {
        this.text = text;
    }

    public void setHref( String href ) {
        this.href = href;
    }

    public String getText() {
        return text;
    }

    public String getHref() {
        return href;
    }
}
