package com.ti.core.util;

public class Constants {

	public static final String EN_LANG_CODE = "en";
	public static final String EN_LANG = "en-US";
	public static final String CN_LANG_CODE = "cn";
	public static final String CN_LANG = "zh-CN";
	public static final String JP_LANG_CODE = "jp";
	public static final String JP_LANG = "ja-JP";
	public static final String LANG_CODES_EN_KR_DE = "en|kr|de";
	public static final String LANG_EN_CN = "en-us|zh-cn";
	public static final String LANG_CODE_CN = "zh";
	public static final String LANG_CODES_ALL = "zh|ja|fr|de|en|it|ko|es|ru|es|vi";
	public static final String LANG_REGION_CODES_ALL = "en-us|zh-cn|ja-jp|ko-kr|de-de|ru-ru|zh-tw|es-mx";
	public static final String REGION_CODES_ALL = "us|cn|jp|kr|de|ru|tw|mx";

	private Constants() {

	}
}
