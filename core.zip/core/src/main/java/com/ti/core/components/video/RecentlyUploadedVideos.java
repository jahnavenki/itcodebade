package com.ti.core.components.video;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.ti.core.models.VideoMetadataModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.PathBrowserHelper;

public class RecentlyUploadedVideos extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(RecentlyUploadedVideos.class);
	
	private final List<VideoMetadataModel> videoMetadataList = new ArrayList<>(); 

	public List<VideoMetadataModel> getVideoMetadataList() {
		return videoMetadataList;
	}
	private ResourceResolver resourceResolver;
	
	@Override
    public void activate() {
        try {
			resourceResolver = getResourceResolver();
			String pagelanguage = "en-us";
			String videoLanguage;
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);
			if (tabsService != null) {
				pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
			}
			if (!(pagelanguage.equals("zh-cn") || pagelanguage.equals("zh-tw"))) {
				videoLanguage = pagelanguage.substring(0,pagelanguage.indexOf("-"));
			}
			else{
				videoLanguage = pagelanguage;
			}			
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
			List<Resource> recentlyUploadedVideosList = getRecentlyUploadedVideos(resourceResolver, videoLanguage, videoService.getVideoPath());
			if (recentlyUploadedVideosList.size() == 0 && videoLanguage != "en") {
				videoLanguage = "en";
				recentlyUploadedVideosList = getRecentlyUploadedVideos(resourceResolver, videoLanguage, videoService.getVideoPath());
			}
			for (Resource resource: recentlyUploadedVideosList) {
				setVideoMetadata(resource, pagelanguage,videoLanguage);
			}   
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

	private List<Resource> getRecentlyUploadedVideos(ResourceResolver resourceResolver, String videoLanguage, String videoPath) {
		List<Resource> recentlyUploadedVideosList = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
		map.put("path", videoPath);
		map.put("type", "dam:Asset");
		map.put("1_property", "jcr:content/metadata/dc:format");
		map.put("1_property.value", "video/mp4");
		map.put("2_property", "jcr:content/metadata/videoSpokenLanguage");
		map.put("2_property.value", videoLanguage);
		map.put("3_property", "jcr:content/metadata/dam:videoPage");
		map.put("3_property.value", "yes");
		map.put("p.limit", "4");
		map.put("orderby","@jcr:content/metadata/dam:published");
        map.put("orderby.sort","desc");

		QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
		Session session = resourceResolver.adaptTo(Session.class);
		if(builder != null) {
			Query query = builder.createQuery(PredicateGroup.create(map), session);
			SearchResult result = query.getResult();
			 
			Iterator<Resource> resourcesItr = result.getResources();
			while (resourcesItr.hasNext()) {
				recentlyUploadedVideosList.add(resourcesItr.next());
			}
		}
		return recentlyUploadedVideosList;
	}
	
	private void setVideoMetadata(Resource resource,String pageLanguage, String videoLanguage)
	{
		VideoMetadataModel videoMetadataObject = new VideoMetadataModel();
		final var map = AssetUtils.getMetadata(resource);
        if (null == map) return;
		String videoSpokenLanguage=map.get("videoSpokenLanguage", String.class);
		if (null == videoSpokenLanguage) return;
		if(videoSpokenLanguage.equalsIgnoreCase(videoLanguage)){
			videoMetadataObject.setVideoId(map.get("brc_id", String.class));
			videoMetadataObject.setTitle(map.get("dc:title", String.class));
			videoMetadataObject.setDuration(map.get("brc_duration", String.class));
			videoMetadataObject.setThumbnailUrl(resource.getPath() + "/jcr:content/renditions/brc_thumbnail.png");
			String videoUrl = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, "/content/texas-instruments/" + pageLanguage
				+ "/video/" + videoMetadataObject.getVideoId());
			//remove .html from url
			videoUrl = videoUrl.substring(0, videoUrl.length()-5);
			videoMetadataObject.setVideoUrl(videoUrl);
			videoMetadataList.add(videoMetadataObject);
		}
	}
			
}
