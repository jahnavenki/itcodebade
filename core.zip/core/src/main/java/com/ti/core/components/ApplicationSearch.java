package com.ti.core.components;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

public class ApplicationSearch extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	// WS requires application ID, but component does not.
	private static final int APPLICATION_ID_INDUSTRIAL = 120;

	private static class ApplicationTreeNode {
		public ApplicationTreeNode( JSONObject json ) throws JSONException {
			childId = json.getInt( "childId" );
			parentAppId = getInteger( json, "parentAppId" );
			appUrl = json.getString( "appUrl" );
			if ("null".equals( appUrl ) ) appUrl = null;
			sectionName = json.getString( "sectionName" );
		}

		private int childId;
		private Integer parentAppId;
		private String appUrl;
		private String sectionName;
		private ApplicationTreeNode parent;
		private final List<ApplicationTreeNode> children = new ArrayList<>();

		private static Integer getInteger( JSONObject json, String key ) throws JSONException {
			if( json.isNull( key ) ) return null;
			else return json.getInt( key );
		}

		public int getChildId() {
			return childId;
		}

		public Integer getParentAppId() {
			return parentAppId;
		}

		public String getAppUrl() {
			return appUrl;
		}

		public String getSectionName() {
			return sectionName;
		}

		public ApplicationTreeNode getParent() {
			return parent;
		}

		public void setParent( ApplicationTreeNode parent ) {
			this.parent = parent;
		}

		public List<ApplicationTreeNode> getChildren() {
			return children;
		}

		public boolean hasChildren() {
			return !children.isEmpty();
		}
	}

	public static class Link {
		private String text;
		private String href;

		public String getText() {
			return text;
		}

		public void setText( String text ) {
			this.text = text;
		}

		public String getHref() {
			return href;
		}

		public void setHref( String href ) {
			this.href = href;
		}
	}

	public static class Market extends Link {
		private final List<Sector> sectors = new ArrayList<>();

		public List<Sector> getSectors() {
			return sectors;
		}
	}

	public static class Sector extends Link {
		private final List<EndEquipment> endEquipment = new ArrayList<>();

		public List<EndEquipment> getEndEquipment() {
			return endEquipment;
		}
	}

	public static class EndEquipment extends Link {}

	private final List<Market> markets = new ArrayList<>();

	public List<Market> getMarkets() {
		return markets;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.adobe.cq.sightly.WCMUsePojo#activate()
	 */
	@Override
	public void activate() {
		try {
			final var wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if (null == wcmComponents) return;
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if (null == tabsService) return;
			final var language = tabsService.getPageLanguage(getCurrentPage());
			final var jsonObject = wcmComponents.getAllApplicationService(getRequest(), APPLICATION_ID_INDUSTRIAL, language);
			final var jsonAppHierarchyList = jsonObject.getJSONArray( "AppHierarchyList" );
			final var appNodeList = new ArrayList<ApplicationTreeNode>();
			final var appNodeMap = new HashMap<Integer, ApplicationTreeNode>();
			for (var i = 0; i < jsonAppHierarchyList.length(); ++i) {
				final var node = new ApplicationTreeNode( jsonAppHierarchyList.getJSONObject(i) );
				appNodeList.add( node );
				appNodeMap.put( node.getChildId(), node );
			}
			for (final var node : appNodeList) {
				var parentId = node.getParentAppId();
				var parent = appNodeMap.get( parentId );
				node.setParent( parent );
				if (null != parent) {
					parent.getChildren().add( node );
				}
			}
			for (final var node : appNodeList) {
				if (null == node.getParent()) {
					var market = new Market();
					market.setText( node.getSectionName() );
					market.setHref( node.getAppUrl() );
					for (final var sectorNode : node.getChildren()) {
						var sector = new Sector();
						sector.setText( sectorNode.getSectionName() );
						sector.setHref( sectorNode.getAppUrl() );
						for (final var endEquipmentNode : sectorNode.getChildren()) {
							if (endEquipmentNode.hasChildren()) {
								for (final var endEquipmentLeafNode : endEquipmentNode.getChildren()) {
									var endEquipment = new EndEquipment();
									endEquipment.setText( endEquipmentLeafNode.getSectionName() );
									endEquipment.setHref( endEquipmentLeafNode.getAppUrl() );	
									sector.getEndEquipment().add( endEquipment );
								}
							} else {
								var endEquipment = new EndEquipment();
								endEquipment.setText( endEquipmentNode.getSectionName() );
								endEquipment.setHref( endEquipmentNode.getAppUrl() );	
								sector.getEndEquipment().add( endEquipment );
							}
						}
						market.getSectors().add( sector );
					}
					markets.add( market );
				}
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
