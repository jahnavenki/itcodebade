package com.ti.core.service.workflow;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.service.WCMComponents;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to sync updated metadata to Brightcove.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Sync Brightcove Metadata" })
public class SyncBrightcoveMetadataProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private WCMComponents wcmService;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) throw new NullPointerException("resourceResolver");
			final var resource = resourceResolver.getResource(payload);
			if (null == resource) return;
			final var metadata = resource.getChild("jcr:content/metadata");
			if (null == metadata) return;
			final var valueMap = metadata.getValueMap();
			final var videoId = valueMap.get("brc_id", "");
			final var tagsArr = valueMap.get("brc_tags", String[].class);
			final var tags = ( null == tagsArr ) ? new ArrayList<String>() : List.of(tagsArr);
			final var jsonObj = new JSONObject();
			final var jsonTags = new JSONArray();
			for (var tag : tags) {
				jsonTags.put(tag);
			}
			jsonObj.put("tags", jsonTags);
			jsonObj.put("schedule", JSONObject.NULL);
			wcmService.updateBrightcoveVideo(videoId, jsonObj);
		} catch (Exception e) {
			log.error("Error occurred in SyncBrightcoveMetadataProcessStep", e);
		}
	}
}
