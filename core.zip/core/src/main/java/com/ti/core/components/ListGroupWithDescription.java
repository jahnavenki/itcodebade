package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.ListGroupWithDescriptionModel;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import com.ti.core.util.PathBrowserHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ListGroupwithDescription WCMUsePojo.
 */
public class ListGroupWithDescription extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    private String title;
    private static final String TITLE = "title";
    private static final String TEXT_LINKS = "textLinks";
    private static final String LINK_TITLE = "linkTitle";
    private static final String LINK_DESCRIPTION = "linkDescription";
    private static final String DESC_LINK_URL = "descLinkURL";

    public String getTextLinks() {
        return TEXT_LINKS;
    }
    public String getTitle() {
        return title;
    }
    /**
 * ListGroupWithDescriptionModel sorting based on linkTitle.
 */
    Comparator<ListGroupWithDescriptionModel> listGroupsort = new Comparator<ListGroupWithDescriptionModel>(){
    public int compare(ListGroupWithDescriptionModel listGroup1, ListGroupWithDescriptionModel listGroup12){
      return listGroup1.getLinkTitle().compareTo(listGroup12.getLinkTitle());
    }
};
    public List<ListGroupWithDescriptionModel> getListGroupWithDescriptionModel() {
        Collections.sort(listGroupWithDescriptionModel, listGroupsort);
        return listGroupWithDescriptionModel;
    }
    private final List<ListGroupWithDescriptionModel> listGroupWithDescriptionModel = new ArrayList<>();
    
    @Override
    public void activate() throws JSONException {
        try {
            this.title = getProperties().get(TITLE, String.class);
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(TEXT_LINKS)) {
                    for (Resource textlink : nodeChild.getChildren()) {
                        ListGroupWithDescriptionModel listGroupWithDescriptionModelObject = new ListGroupWithDescriptionModel();
    
                        ValueMap properties = textlink.adaptTo(ValueMap.class);
                        if (null != properties) {
                            listGroupWithDescriptionModelObject.setLinkTitle(properties.get(LINK_TITLE, String.class));
                            listGroupWithDescriptionModelObject.setLinkDescription(properties.get(LINK_DESCRIPTION, String.class));
                            listGroupWithDescriptionModelObject.setDescLinkURL(PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get(DESC_LINK_URL, String.class)));
                            listGroupWithDescriptionModel.add(listGroupWithDescriptionModelObject);
                        }
                    }
                }
            }
            
        } catch (Exception e) {
            log.error("Exception : ", e);
        }

    }
}