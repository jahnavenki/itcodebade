package com.ti.core.service.config;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * VideoConfigService for video assets in DAM.
 *
 */

@Component(service = VideoConfigService.class, immediate = true)
@Designate(ocd = VideoConfiguration.class)

public class VideoConfigService {

	/**
	 * Instance of the OSGi configuration class
	 */
	protected VideoConfiguration videoConfiguration;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String videoPath;
	private String accountId;
	private String playerId;
	private int partitionSize;
	private int partitionStartIndex;
	private String apiKey3play;

	@Activate
	public void activate(VideoConfiguration config) {
		log.debug("type of config: {}", config);
		this.videoPath = config.videoPath();
		this.accountId = config.accountId();
		this.playerId = config.playerId();
		this.partitionSize = config.partitionSize();
		this.partitionStartIndex = config.partitionStartIndex();
		this.apiKey3play = config.apiKey3play();
	}

	public String getVideoPath() {
		return videoPath;
	}

	public String getAccountId() {
		return accountId;
	}

	public String getPlayerId() {
		return playerId;
	}

	public int getPartitionSize() {
		return partitionSize;
	}

	public int getPartitionStartIndex() {
		return partitionStartIndex;
	}

	public String getApiKey3play() {
		return apiKey3play;
	}

}
