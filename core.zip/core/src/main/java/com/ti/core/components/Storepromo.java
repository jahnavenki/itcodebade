package com.ti.core.components;

import java.text.DecimalFormat;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

public class Storepromo extends WCMUsePojo {

	private String toolName;
	private String toolOPN;
	private String price;
	private String tooldisPrice;
	private String toolStoreURL;
	private String tooldis;
	private String coupon;
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String TOOL_OPN = "toolOrderableNumber";
	private static final String TOOL_DISCOUNT = "couponDis";
	private static final String COUPON_PROMO = "coupon";
	private static final String TOOL_ORDERABLE_NUMBER = "toolOrderableNumber";
	private static final String TOOL_ORDERABLE_NAME = "toolOrderableName";
	private static final String TOOL_PRICE = "price";
	private static final String STORE_URL = "https://store.ti.com/AddToCart_TI.aspx?p=";

	@Override
	public void activate() {
		String language = null;

		ValueMap properties = getProperties();
		toolOPN = properties.get(TOOL_OPN, "");
		tooldis = properties.get(TOOL_DISCOUNT, "");
		coupon = properties.get(COUPON_PROMO, "");
		log.debug("coupon check box is checked or not " + coupon);
		WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		if (wcmService == null)
			log.error("store promo: could not get wcmService");

		if (null != tabsService) {
			language = tabsService.getPageLanguage(getCurrentPage());
		}
		if (null != wcmService) {
			getToolOpnDetails(wcmService, language);
		}
		getdiscountedprice();
		generatestoreUrl();

		log.debug("opn details " + this.toolOPN + "-" + this.toolName + "-" + this.price + "-" + this.toolStoreURL);
	}

	public void generatestoreUrl() {

		this.toolStoreURL = STORE_URL + this.toolOPN;
		log.debug("store URL" + this.toolStoreURL);

	}

	public void getdiscountedprice() {
		DecimalFormat format_2Places = new DecimalFormat("#.00");
		log.debug("getdiscountedprice" + tooldis);
		double toolactualprice = Double.parseDouble(this.price);
		if (null != tooldis && !("").equals(tooldis) && StringUtils.equalsIgnoreCase(coupon, "true")) {
			double tooldisdouble = Double.parseDouble(tooldis);

			double discountedprice;

			discountedprice = toolactualprice * (tooldisdouble / 100);
			discountedprice = toolactualprice - discountedprice;
			discountedprice = Double.parseDouble(format_2Places.format(discountedprice));
			log.debug("discountedprice" + discountedprice);
			this.tooldisPrice = String.format("%.2f", discountedprice);
		} else {
			toolactualprice = Double.parseDouble(format_2Places.format(toolactualprice));
			this.tooldisPrice = String.format("%.2f", toolactualprice);
		}
		log.debug("final discountedprice " + this.tooldisPrice);
	}

	public void getToolOpnDetails(WCMComponents wcmService, String language) {

		log.debug("inside getToolOpnDetails");

		JSONObject jsonToolOPNdetails;
		log.debug("toolOPN" + toolOPN);
		String tooOPNInfo = wcmService.getToolOpnService(getRequest(), toolOPN, language);
		log.debug("tooOPNInfo response" + tooOPNInfo);

		try {

			if (StringUtils.isNotEmpty(tooOPNInfo)) {
				jsonToolOPNdetails = new JSONObject(tooOPNInfo);
				this.toolOPN = jsonToolOPNdetails.getString(TOOL_ORDERABLE_NUMBER);
				this.toolName = jsonToolOPNdetails.getString(TOOL_ORDERABLE_NAME);
				if (("null").equals(jsonToolOPNdetails.getString(TOOL_PRICE))) {
					this.price = "0";
					log.debug("price value us 0 " + this.price + "#" + jsonToolOPNdetails.getString(TOOL_PRICE));
				} else {
					this.price = jsonToolOPNdetails.getString(TOOL_PRICE);
				}
			}
		} catch (JSONException e) {
			log.error("JSONException: " + e);
		}

	}

	public String getToolName() {
		return toolName;
	}

	public String getToolOPN() {
		return toolOPN;
	}

	public String getPrice() {
		return price;
	}

	public String getTooldisPrice() {
		return tooldisPrice;
	}

	public String getToolStoreURL() {
		return toolStoreURL;
	}
}