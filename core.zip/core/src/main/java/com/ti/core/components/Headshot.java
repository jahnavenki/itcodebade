package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Headshot extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private boolean needsAuthoring;
    public boolean getNeedsAuthoring() {
        return needsAuthoring;
    }

    private String imageSrc;
    public String getImageSrc() {
        return imageSrc;
    }

    private String employeeName;
    public String getEmployeeName() {
        return employeeName;
    }

    private String employeeTitle;
    public String getEmployeeTitle() {
        return employeeTitle;
    }

    private String title;
    public String getTitle() {
        return title;
    }

    @Override
    public void activate() {
        try {
            imageSrc = getProperties().get("imageSrc", String.class);
            if (StringUtils.isEmpty(imageSrc)) {
                needsAuthoring = true;
                return;
            }
            needsAuthoring = false;
            final var resourceResolver = getResourceResolver();
            final var resource = resourceResolver.getResource(imageSrc);
            final var asset = resource.adaptTo(Asset.class);
            employeeName = asset.getMetadataValue("dam:employeeName");
            employeeTitle = asset.getMetadataValue("dam:employeeTitle");
            title = asset.getMetadataValue("dc:title");
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
}
