package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PdfIntro - WCMUsePojo for PDF Introduction component
 * A piece of PDF content with the title, overview, image of cover, link to PDF and topic list. 
 */
public class PdfIntro extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    // property from the component dialog
    private static final String LIT_NUMBER = "litNumber";
    private static final String LITERATURE_NUMBER = "literatureNumber";
    private static final String CONCISE_DESCRIPTION = "conciseDescription";
    private static final String IMAGE_PATH = "fileReference";
    
    private String litNumberFromDB;
    private String ctaUrl;
    private String docTitle;
    private String imageAltText;
  
    public String getLitNumberFromDB() {
      return litNumberFromDB;
    }
  
    public String getCtaUrl() {
      return ctaUrl;
    }
  
    public String getDocTitle() {
      return docTitle;
    }
  
    public String getImageAltText() {
      return imageAltText;
    }
  
    @Override
    public void activate() throws Exception {
        try {
            JSONObject jsonLiterature;
            String pagelanguage = "en-us";

            WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
            if (null != wcmService) {
                ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                        .getService(ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
                }

                String litNumber = getProperties().get(LIT_NUMBER, String.class);
                String litResponse = wcmService.getFeaturedliterature(litNumber, pagelanguage);  
                if (StringUtils.isNotEmpty(litResponse)) {
                    jsonLiterature = new JSONObject(litResponse);

                    this.litNumberFromDB = jsonLiterature.getString(LITERATURE_NUMBER);
                    this.docTitle = jsonLiterature.getString(CONCISE_DESCRIPTION);                
                    LanguageUtils langUtils = new LanguageUtils(getRequest());
                    // get the literature number from json response, as it is different for regions
                    this.ctaUrl = langUtils.getI18nStr("https://www.ti.com/lit/") + this.litNumberFromDB;

                    // Get title from DAM property and set as alt text for image
                    Resource resource = getResourceResolver().getResource(getProperties().get(IMAGE_PATH).toString());
                    if (resource != null) {                    
                        Asset asset = resource.adaptTo(Asset.class);
                        if (asset != null) {
                            this.imageAltText = asset.getMetadataValue("dc:title");
                        }                    
                    }
                } else {
                    log.debug("Json response is empty or null");
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
    
}
