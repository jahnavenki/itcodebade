package com.ti.core.components.models;

import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.dam.api.Asset;

@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	resourceType = FaqsPageHeading.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class FaqsPageHeading {
    protected final Logger log = LoggerFactory.getLogger(getClass());
	public static final String RESOURCE_TYPE = "ti/components/faqsPageHeading";
    private static final String IMAGE_OPTION = "imageOption";

    @SlingObject
	private ResourceResolver resourceResolver;

    @ValueMapValue(name = "fileReference")
    private String imagePath;

    @ValueMapValue
    private String featureOptions;

    private String imageAltText;

    @PostConstruct
	public void init(){
		try {
			imagePath = StringUtils.defaultString(imagePath);
			featureOptions = StringUtils.defaultString(featureOptions);
            imageAltText = StringUtils.defaultString(imageAltText);
            if(!imagePath.isEmpty() && IMAGE_OPTION.equals(featureOptions.toString())){
                setImageAltText();
            }
		} catch (Exception e) {
			log.error("Exception in FaqsPageHeading", e);
		}
	}

    public String getImageAltText() {
        return imageAltText;
    }

    private void setImageAltText() {
        // Get title from DAM property and set as alt text for image
        Resource resource = resourceResolver.getResource(imagePath);
        if (resource != null) {
            Asset asset = resource.adaptTo(Asset.class);
            if (asset != null) {
                this.imageAltText = asset.getMetadataValue("dc:title");
            }
        }
    }

}
