package com.ti.core.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.FieldOption;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;
import com.ti.core.service.TiUrlPattern;
import com.ti.core.service.TiUrlPatternConfigs;

@Component(immediate = true, service = TiUrlPatternConfigs.class)
public class TiUrlPatternConfigsImpl implements TiUrlPatternConfigs {
		
	 @Reference(
			  policy =ReferencePolicy.DYNAMIC, 
			  fieldOption = FieldOption.UPDATE,
			  cardinality =  ReferenceCardinality.MULTIPLE,
			 service = TiUrlPattern.class
			  )
	private Collection<TiUrlPattern> configs;
	

	protected synchronized void bindTiUrlPattern(final TiUrlPattern config) {
		if (configs == null) {
			configs = new ArrayList<>();
		}
		Set<TiUrlPattern> tiUrlPatternSet =new HashSet<>(configs);
		tiUrlPatternSet.add(config);
		
	}

	protected synchronized void unbindTiUrlPattern(final TiUrlPattern config) {
		Set<TiUrlPattern>  tiUrlPatternSet = new HashSet<>(configs);
		tiUrlPatternSet.remove(config);
		
	}

	public List<TiUrlPattern> getConfigs() {
		return (new ArrayList<>(configs));
	}
}
