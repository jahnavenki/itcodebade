package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PDFLandingPageMetadata extends WCMUsePojo {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PDF_INTRODUCTION = "pdfintroduction";
    private static final String DOC_TITLE = "title";
    private static final String OVERVIEW = "overview";
    private String browserTitle;
    private String metaDescription;
    private String keywords;

    public String getBrowserTitle() {
        return browserTitle;
    }

    public String getMetaDescription() {
        return metaDescription;
    }

    public String getKeywords() {
        return keywords;
    }
  
    @Override
    public void activate() throws Exception {
        final Resource pageResource = getResource();
        if (null == pageResource) {
            logger.debug("resource is null");
            return;
        }
        String overviewCopy = "";
        boolean foundPDFComponent = false;
        // get PDF Introduction component which is at the third level on the template
        // i.e. /root/responsivegrid/pdfintrolduction
        final Resource rootResource = pageResource.getChild("root"); 
        if (null == rootResource) {
            logger.debug("root is null");
            return;
        }
        for (Resource gridResource : rootResource.getChildren()) {
            for (Resource nodeChild : gridResource.getChildren()) {
                if (nodeChild != null && nodeChild.getName().toLowerCase().indexOf(PDF_INTRODUCTION) > -1) {
                    ValueMap map = nodeChild.getValueMap();
                    this.browserTitle = map.get(DOC_TITLE).toString();
                    this.keywords = this.browserTitle;
                    overviewCopy = map.get(OVERVIEW).toString();
                    if (overviewCopy.length() > 160) {
                        overviewCopy = overviewCopy.substring(0, 160) + "...";
                    }
                    this.metaDescription = overviewCopy;
                    foundPDFComponent = true;
                    break;
                }
            }
            if (foundPDFComponent) {
                break;
            }
        }
    }
}