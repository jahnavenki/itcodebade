package com.ti.core.service.impl;

import com.ti.core.service.GeneralConfig;

public class GeneralConfigImpl implements GeneralConfig {

	@Override
	public String getTIContentFragmentPath() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTIDamImagesPath() {
		// TODO Auto-generated method stub
		return null;
	}

}
