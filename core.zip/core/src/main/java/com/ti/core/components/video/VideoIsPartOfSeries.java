package com.ti.core.components.video;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.jcr.Session;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;

public class VideoIsPartOfSeries extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(VideoIsPartOfSeries.class);

    private Map<String,List<String>> topicsMap = new HashMap<>();

	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

    public Map<String, List<String>> getTopicsMap() {
        return topicsMap;
    }

    @Override
    public void activate() {
        try {
            String pageLanguage = "en-us";
            WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
            if (null != wcmService) {
                ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                    .getService(ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    pageLanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
                }
            }    
            final var resourceResolver = getResourceResolver();
            final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
            final String videoId = matcher.find() ? matcher.group(1) : null;   
            Iterator<Resource> videoSeriesPageResourceItr = getVideoSeriesPages(resourceResolver,pageLanguage);
            if(videoSeriesPageResourceItr != null) {
                while(videoSeriesPageResourceItr.hasNext())
                {
                    Resource videoSeriesPageResource = videoSeriesPageResourceItr.next();
                    Resource videoSeriesNavigation = getVideoSeriesNavigationComponent(videoSeriesPageResource);
                    if(videoSeriesNavigation != null)
                    {
                        checkVideoSeriesNavigationProperties(videoSeriesNavigation,videoId,videoSeriesPageResource);
                    }
                }
            }        
		}
        catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    private Iterator<Resource> getVideoSeriesPages(ResourceResolver resourceResolver,String pageLanguage) {
        QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
		Session session = resourceResolver.adaptTo(Session.class);
        Map<String, String> map = new HashMap<>();
        map.put("path", "/content/texas-instruments/"+pageLanguage);
        map.put("type", "cq:Page");
        map.put("property","jcr:content/cq:template");
        map.put("property.value","/conf/ti/settings/wcm/templates/video-series-page-template");
        map.put("p.limit", "-1");
        if(builder != null) {
            Query query = builder.createQuery(PredicateGroup.create(map), session);
            SearchResult result = query.getResult();
            return result.getResources();
        }
        return null;    
    }

    private Resource getVideoSeriesNavigationComponent(Resource videoSeriesPageResource) {
            Page page = videoSeriesPageResource.adaptTo(Page.class);
            if(page != null) {
                //get VideoSeriesNavigation component on page
                return page.getContentResource("videoSeriesNavigation/topics");
            }
            return null;    
    }

    private void checkVideoSeriesNavigationProperties(Resource videoSeriesNavigation,String videoId,Resource videoSeriesPageResource) {
        Iterator<Resource> videoSeriesNavigationChild = videoSeriesNavigation.listChildren();
        try {
            while (videoSeriesNavigationChild.hasNext()) {
                Resource items = videoSeriesNavigationChild.next();
                Resource videosListChild = items.getChild("videosList");
                if(videosListChild == null) {
                    return;
                }
                Iterator<Resource> videosListItr = videosListChild.listChildren();
                while (videosListItr.hasNext()) {
                    Resource videoList = videosListItr.next();
                    if(videoList.getValueMap().get("videoId").equals(videoId)) {
                        String topic = getVideoSeriesTitle(videoSeriesPageResource);
                        String pageUrl = videoSeriesNavigation.getPath().substring(0,videoSeriesNavigation.getPath().indexOf("jcr:content") -1);
                        pageUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), pageUrl);    
                        String videoCount = getVideoCount(videoSeriesNavigation);
                        List<String> topicsProperty = new ArrayList<>();
                        topicsProperty.add(pageUrl);
                        topicsProperty.add(videoCount);
                        topicsMap.put(topic,topicsProperty);
                        break;                                             
                    }
                }    
            }    
        }    
        catch (NullPointerException e) {
            log.error("Exception in reading properties of videoSeriesNavigation: ", e);
        }   
    }
    
    private String getVideoSeriesTitle(Resource videoSeriesPageResource) {
        Page page = videoSeriesPageResource.adaptTo(Page.class);
        String title = StringUtils.EMPTY;
        if(page != null) {
            //get VideoSeriesNavigation component on page
            Resource videoTitleAndDescription = page.getContentResource("videoTitleAndDescription");
            title = videoTitleAndDescription.getValueMap().get("title","");
        }
        return title;
    }

    private String getVideoCount(Resource videoSeriesNavigation) {
        int videoCount = 0;
        Iterator<Resource> videoSeriesNavigationChild = videoSeriesNavigation.listChildren();
        while (videoSeriesNavigationChild.hasNext()) {
            Resource items = videoSeriesNavigationChild.next();
            Resource videosListChild = items.getChild("videosList");
            if(videosListChild != null) {
            videoCount += IteratorUtils.size(videosListChild.listChildren());
            }
        }    
        return String.valueOf(videoCount);
    }
}