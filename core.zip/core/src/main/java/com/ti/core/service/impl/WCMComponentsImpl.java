package com.ti.core.service.impl;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.models.assets.EpodVariantMetadata;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.WCMComponentConfiguration;

import com.ti.core.util.Constants;

/**
 * Implementation of WCMComponents.
 *
 * @author Andy Doerr
 */

@Component(immediate = true, service = WCMComponents.class)
@Designate(ocd = WCMComponentConfiguration.class)
public class WCMComponentsImpl implements WCMComponents {

	private static final String UTF8 = "UTF-8";
	private static final String QUERY_STRING_SEP = "&";
	private static final String QUERY_STRING_EQUALS = "=";
	private static final String URL_QUERYSTRING_INIT = "?";
	private static final String PROXY_HOST = "webproxy.ext.ti.com";

	// These params are used in the Tools and Software Listing
	private static final String PARAM_TOOL_TYPE_ID = "tooltype";
	private static final String PARAM_DEFAULT_SORT_COLUMN = "sortColumn";
	private static final String PARAM_DEFAULT_SORT_DIRECTION = "sortType";

	private static final String GRANT_TYPE = "grant_type=";
	private static final String CLIENT_CREDENTIALS = "client_credentials";

	private static final Logger log = LoggerFactory.getLogger(WCMComponentsImpl.class);
	private static final String POST = "POST";
	private static final String ACCEPT = "Accept";
	private static final String AUTHORIZATION = "Authorization";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String CONTENT_LANGUAGE = "Content-Language";
	/** The Constant CHARSET. */
	private static final String CHARSET = "Charset";
	private static final String CONTENT_LENGTH = "Content-Length";
	private static final String ACCEPT_VALUE = "application/json";
	private static final String FORM_URL_ENCODED = "application/x-www-form-urlencoded";
	private static final String EXPIRES_IN = "expires_in";
	private static final String ACCESS_TOKEN = "access_token";
	private static final String TOKEN_TYPE = "token_type";
	private static final String GET = "GET";
	private static final int MILISECONDS = 1000;
	private static final String CHINESE_LANG_CODE = "CN";
	/** The Constant JAPANESE_LANG_CODE. */
	private static final String JAPANESE_LANG_CODE = "JP";
	private static final String ENGLISH_LANG_CODE = "EN-US";
	private static final String DASH = "-";
	private String oauthToken = null;
	private Date oauthDate = null;
	private Date percolateoauthDate = null;
	private Date brightcoveOauthDate = null;
	private Date now = null;
	private int oauthExpires;
	private static int expiryFlag = 0;
	private String tokenType = null;
	private String percolateoauthToken = null;
	private int percolateoauthExpires;
	private int brightcoveOauthExpires;
	private String brightcoveOauthToken = null;

	private static final String EXCEPTION_TEXT = ":::::Exception while calling URL::::::";
	private static final String EXCEPTION_MESSAGE = "\n:::::Exception Message ::::::";
	private static final String READ_TIMED_OUT_MESSAGE = "Read timed out";
	private static final String CONNECT_TIMED_OUT_MESSAGE = "connect timed out";
	protected WCMComponentConfiguration wcmComponentConfiguration;
	private String techDocsUrl = null;

	private String featuredLitUrl = null;

	private String emsgProductAll = null;

	private String emsgToolOpn = null;

	private String emsgApplicationAll = null;

	private String emsgApplicationList = null;
	private String siloUrl = null;
	private String percolateuserlisturl = null;

	private String productFamilyUrl = null;

	private String apphomepageurl = null;

	private String toolsSoftwareListingUrl = null;

	private String productTechDocCategoriesUrl = null;

	private String techDocCategoriesUrlSuffix = null;

	private String applicationTechDocCategoriesUrl = null;

	private String productTechDocListingUrlSuffix = null;

	private String applicationTechDocListingUrlSuffix = null;

	private String techDocListingUrlCountSuffix;

	private String techDocListingUrlSearchTermSuffix;

	private String oauthUrl = null;

	private String oauthAuthentication = null;

	private String percolateoauthUrl = null;

	private String percolateoauthAuthentication = null;

	private String defaultDocumentCategories = null;

	private String recommendedAppsUrl = null;

	private String boomiToken = null;

	private String boomiSiloFamilies = null;

	private String boomiProductFamilyAllUrl = null;

	private String boomiProductFamilyGPNsUrl = null;

	private String boomiToolTypeUrl = null;

	private String boomiToolTypeTPNsUrl = null;

	private String boomiEpodVariantUrl = null;

	private String boomiDamDeleteUrl = null;

	private String boomildapUrl = null;

	private String boomiCategoryListingUrl = null;

	private String boomiApplicationMarketUrl = null;

	private String boomiApplicationSectorUrl = null;

	private String boomiApplicationCategoryUrl = null;

	private String boomiApplicationEndEquipmentsUrl = null;

	private String productModelUrl = null;

	private String supplyFrameUrlDomain;
	private String jackDefaultTrendingDataUrl = null;

	private String emsgToolPartDetailUrl = null;

	private String homePageFeaturedProductsUrl = null;

	private String toolDetailsUrl = null;

	private String productFamilyNewProductsUrl = null;

	private String brightcoveOauthAuthentication = null;

	private String brightcoveAuthUrl = null;

	private String brightcoveVideoMetaDataUrl = null;

	private String brightcoveVideoSourceUrl = null;

	private int connectTimeOut;

	private int readTimeOut;

	private int defaultRetries;

	private long defaultWaitTime;

	@Override
	public String getFeaturedliterature(String litnum, String language) {

		String literatureInfo = null;
		try {
			generateOauthToken();

			String litUrl = this.featuredLitUrl;

			literatureInfo = getUrlConnectionData(litUrl + litnum, language, oauthToken, tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return literatureInfo;
	}

	@Override
	public String getProductFamily(String familyId, String language) {

		String familyInfo = null;
		try {
			generateOauthToken();

			String pfUrl = this.productFamilyUrl + familyId + "/all";

			familyInfo = getUrlConnectionData(pfUrl, language, oauthToken, tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return familyInfo;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ti.core.service.WCMComponents#getProductTechDocCategories(java.lang.
	 * String)
	 */
	@Override
	public String getProductTechDocCategories(String familyId, String language) {

		String techDocInfo = null;
		try {
			generateOauthToken();
			String tdcUrl = this.productTechDocCategoriesUrl + familyId + this.techDocCategoriesUrlSuffix;

			techDocInfo = getUrlConnectionData(tdcUrl, language, oauthToken, tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return techDocInfo;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ti.core.service.WCMComponents#getProductTechDocCategories(java.lang.
	 * String)
	 */
	@Override
	public String getProductTechDocCategoriesApplication(String applicationId, String language) {
		String techDocInfo = null;
		techDocInfo = getProductTechDocCategories(applicationId, language);
		return techDocInfo;
	}

	@Override
	public String getApplicationTechDocCategories(String applicationId, String language) {

		String techDocInfo = null;
		try {
			generateOauthToken();

			String tdcUrl = this.applicationTechDocCategoriesUrl + applicationId + this.techDocCategoriesUrlSuffix;
			techDocInfo = getUrlConnectionData(tdcUrl, language, oauthToken, tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return techDocInfo;
	}

	@Override
	public String getSilo(String language) {
		String siloInfo = null;
		try {
			generateOauthToken();

			siloInfo = getUrlConnectionData(this.siloUrl, language, oauthToken, tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return siloInfo;
	}

	@Override
	public String getPercolateUserlist() {
		String userlist = null;
		try {
			generatePercolateOauthToken();
			log.debug("percolate URL " + this.percolateuserlisturl);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			String tokentype = "Bearer";
			userlist = getUrlConnectionData(this.percolateuserlisturl, null, percolateoauthToken, tokentype, proxy);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return userlist;
	}

	private String getUrlConnectionData(final String urlStr, final String language, final String token,
			final String tokentype, final Proxy proxy) throws IOException {
		HttpURLConnection connection = null;
		RetryOperation retry = new RetryOperation(this.defaultRetries, this.defaultWaitTime);
		String resp = null;
		while (retry.shouldRetry()) {
			try {
				URL url = new URL(urlStr);
				if (null != proxy) {
					connection = (HttpURLConnection) url.openConnection(proxy);
				} else {
					connection = (HttpURLConnection) url.openConnection();
				}
				connection.setDoOutput(true);
				connection.setRequestMethod(GET);
				connection.setRequestProperty(ACCEPT, ACCEPT_VALUE);
				connection.setRequestProperty(AUTHORIZATION, tokentype + " " + token);
				connection.setConnectTimeout(this.connectTimeOut);
				connection.setReadTimeout(this.readTimeOut);
				if (language != null) {
					String languageCode = StringUtils.substringAfter(language, DASH);
					log.debug("language" + language + languageCode);
					log.debug("languagelist " + Constants.REGION_CODES_ALL);
					if (Constants.REGION_CODES_ALL.contains(languageCode.toLowerCase())) {
						String contentLanguage = StringUtils.substringBefore(language, DASH).concat(DASH)
								.concat(languageCode.toUpperCase());
						connection.setRequestProperty(CONTENT_LANGUAGE, contentLanguage);
						log.debug("contentLanguage and language code " + contentLanguage + "" + languageCode);

					}
				}
				resp = readStream(connection.getInputStream());
				break;

			} catch (SocketTimeoutException e) {
				log.error(EXCEPTION_TEXT + urlStr + EXCEPTION_MESSAGE, e);

				retry.errorOccured(e.getMessage());
			}
		}
		return resp;
	}

	private void generateOauthToken() {

		if (expiryFlag != 1) {
			getOauthToken();
		} else {
			this.now = new Date();
			if (oauthDate != null && now.getTime() - oauthDate.getTime() >= oauthExpires * MILISECONDS) {
				getOauthToken();
			}
		}

	}

	private void generatePercolateOauthToken() {

		if (expiryFlag != 1) {
			getPercolateOauthToken();
		} else {
			this.now = new Date();
			if (percolateoauthDate != null
					&& now.getTime() - percolateoauthDate.getTime() >= percolateoauthExpires * MILISECONDS) {
				getPercolateOauthToken();
			}
		}
	}

	@SuppressWarnings("static-access")
	private void getOauthToken() {

		try {
			String query = GRANT_TYPE + URLEncoder.encode(CLIENT_CREDENTIALS, UTF8);
			String URL = this.oauthUrl;

			log.debug("query" + query);
			URL url = new URL(URL);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();

			con.setDoOutput(true);
			con.setRequestMethod(POST);
			con.setRequestProperty(ACCEPT, ACCEPT_VALUE);

			con.setRequestProperty(AUTHORIZATION, this.oauthAuthentication);

			con.setRequestProperty(CONTENT_TYPE, FORM_URL_ENCODED);
			con.setRequestProperty(CHARSET, UTF8);
			con.setRequestProperty(CONTENT_LENGTH, String.valueOf(query.length()));
			con.setConnectTimeout(this.connectTimeOut);
			con.setReadTimeout(this.readTimeOut);

			DataOutputStream os = new DataOutputStream(con.getOutputStream());
			os.writeBytes(query);

			String authString = readStream(con.getInputStream());
			JSONObject authJson = new JSONObject(authString);
			this.oauthDate = new Date();
			this.oauthExpires = authJson.getInt(EXPIRES_IN);
			this.oauthToken = authJson.getString(ACCESS_TOKEN);
			this.tokenType = StringUtils.capitalize(authJson.getString(TOKEN_TYPE));

			os.close();

		} catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException: ", e);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException: ", e);
		} catch (IOException e) {
			log.error("IOException: ", e);
		} catch (JSONException e) {
			log.error("JSONException: ", e);
		}

	}

	private void getPercolateOauthToken() {

		try {
			String query = "{\"grant_type\": \"client_credentials\"}";
			String URL = this.percolateoauthUrl;
			URL url = new URL(URL);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection con = (HttpURLConnection) url.openConnection(proxy);

			con.setDoOutput(true);
			con.setRequestMethod(POST);
			con.setRequestProperty(AUTHORIZATION, this.percolateoauthAuthentication);
			con.setRequestProperty(CONTENT_TYPE, ACCEPT_VALUE);

			DataOutputStream os = new DataOutputStream(con.getOutputStream());
			os.writeBytes(query);

			String authString = readStream(con.getInputStream());
			JSONObject authJson = new JSONObject(authString);

			this.percolateoauthDate = new Date();
			this.percolateoauthExpires = authJson.getInt(EXPIRES_IN);
			this.percolateoauthToken = authJson.getString(ACCESS_TOKEN);
			os.close();

		} catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException: ", e);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException: ", e);
		} catch (IOException e) {
			log.error("IOException: ", e);
		} catch (JSONException e) {
			log.error("JSONException: ", e);
		}

	}

	public String doGetAllDocCategories() {
		String retval = null;
		try {
			log.debug("all doGetAllDocCategories URL " + this.techDocsUrl);
			retval = getUrlConnectionData(this.techDocsUrl, null, oauthToken, tokenType, null);
			log.debug("doc categories" + retval);
		} catch (Exception e) {
			log.error("IO Exception: ", e);
		}

		return retval;
	}

	@Override
	public JSONArray getBoomiSiloFamilies() {
		JSONArray jsonBoomiSiloFamilies = null;
		String boomiSiloFamiliesLocal = null;
		try {
			boomiSiloFamiliesLocal = getUrlConnectionData(this.boomiSiloFamilies + this.boomiToken, null, null, null,
					null);
			log.debug("silo " + boomiSiloFamiliesLocal);
			jsonBoomiSiloFamilies = new JSONArray(boomiSiloFamiliesLocal);
		} catch (MalformedURLException e) {
			log.error("Malformed URL Exception: ", e);
		} catch (IOException e) {
			log.error("IO Exception: ", e);
		} catch (JSONException e) {
			log.error("JSON Exception: ", e);
		}
		return jsonBoomiSiloFamilies;
	}

	@Override
	public JSONArray getBoomiProductFamilyAll(String familyId) {
		JSONArray jsonBoomiProductFamily = null;
		String boomiProductFamily = null;

		String boomiUrl = StringUtils.replace(this.boomiProductFamilyAllUrl, "{familyId}", familyId);
		try {
			boomiProductFamily = getUrlConnectionData(boomiUrl + this.boomiToken, null, null, null, null);
			jsonBoomiProductFamily = new JSONArray(boomiProductFamily);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiProductFamilyAll: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiProductFamilyAll:", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiProductFamilyAll: ", e);
		}

		return jsonBoomiProductFamily;
	}

	@Override
	public JSONArray getBoomiProductFamilyGPNs(String familyId) {
		JSONArray jsonBoomiProductFamilyGPNs = null;
		String boomiProductFamilyGPNsResponse = null;

		try {
			boomiProductFamilyGPNsResponse = getUrlConnectionData(this.boomiProductFamilyGPNsUrl.replace("{familyId}", familyId) + this.boomiToken, null, null, null,
					null);
			jsonBoomiProductFamilyGPNs = new JSONArray(boomiProductFamilyGPNsResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiProductFamilyGPNs: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiProductFamilyGPNs: ", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiProductFamilyGPNs: : ", e);
		}

		return jsonBoomiProductFamilyGPNs;
	}

	@Override
	public EpodVariantMetadata getBoomiEpodVariantMetadata(String variant) {
		try {
			final var boomiUrl = StringUtils.replace(this.boomiEpodVariantUrl, "{variant}", variant);
			final var str = getUrlConnectionData(boomiUrl + this.boomiToken, null, null, null, null);
			final var jsonObject = new JSONObject( str ).getJSONObject( "data" );
			final var retval = new EpodVariantMetadata();
			retval.setStatus( jsonObject.getBoolean( "status" ) );
			if( retval.getStatus() ) { // if status is false, no variant metadata exists
				retval.setPinCount( jsonObject.getInt( "pinCount" ) );
				retval.setPackageGroup( jsonObject.getString( "packageGroup" ) );
				retval.setPackageDesignator( jsonObject.getString( "packageDesignator" ) );
				retval.setVariant( jsonObject.getString( "variant" ) );
				retval.setVariation( jsonObject.getString( "variation" ) );
			}
			return retval;
		} catch(JSONException|IOException e) {
			log.error("Exception in getBoomiEpodVariant: ", e);
			return null;
		}
	}

	private void jsonPutNull(JSONObject json, String key, String value) throws JSONException {
		if(null == value) {
			json.put(key, JSONObject.NULL);
		} else {
			json.put(key, value);
		}
	}


	@Override public void boomiDamDelete(String actionType, String username, String market, String orderablePartNumber, String genericPartNumber, String packageVariant, Date deletedTimestamp, String publishUrl, String assetType) {
		try {
			final var dateFormat = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH );
			dateFormat.setTimeZone(TimeZone.getTimeZone( "UTC" ));
			final var boomiUrl = this.boomiDamDeleteUrl + this.boomiToken;
			var jsonObj = new JSONObject();
			jsonPutNull( jsonObj, "Market", market );
			jsonPutNull( jsonObj, "OrderablePartNumber", orderablePartNumber );
			jsonPutNull( jsonObj, "GenericPartNumber", genericPartNumber );
			jsonPutNull( jsonObj, "PackageVariant", packageVariant );
			jsonObj.put( "DeletedTimestamp", dateFormat.format(deletedTimestamp) );
			jsonObj.put( "PublishUrl", publishUrl );
			jsonPutNull( jsonObj, "AssetType", assetType );
			final var jsonArray = new JSONArray();
			jsonArray.put(jsonObj);
			jsonObj = new JSONObject();
			jsonObj.put("Image", jsonArray);
			jsonPutNull( jsonObj, "ActionType", actionType);
			jsonPutNull( jsonObj, "Username", username);
			final var json = jsonObj.toString();
			final var bytes = json.getBytes(StandardCharsets.UTF_8);
			final var retry = new RetryOperation(this.defaultRetries, this.defaultWaitTime);
			while (retry.shouldRetry()) {
				try {
					final var url = new URL(boomiUrl);
					final var connection = (HttpURLConnection) url.openConnection();
					connection.setDoOutput(true);
					connection.setRequestMethod(POST);
					connection.setRequestProperty(CONTENT_TYPE, ACCEPT_VALUE);
					connection.setRequestProperty(CONTENT_LENGTH, Integer.toString(bytes.length));
					connection.setRequestProperty(ACCEPT, ACCEPT_VALUE);
					connection.setConnectTimeout(this.connectTimeOut);
					connection.setReadTimeout(this.readTimeOut);
					try(final var os = connection.getOutputStream()) {
						os.write(bytes, 0, bytes.length);
						os.flush();
					}
					readStream(connection.getInputStream());
					break;
				} catch (SocketTimeoutException e) {
					log.error(EXCEPTION_TEXT + boomiUrl + EXCEPTION_MESSAGE, e);
					retry.errorOccured(e.getMessage());
				}
			}
		} catch(JSONException|IOException e) {
			log.error("Exception in boomiDamDelete: ", e);
		}
	}

	@Override
	public JSONObject getBoomildap(String userid) {
		JSONObject jsonBoomildap = null;
		String boomiUrl = null;
		String boomildapresponse = null;
		try {

			boomiUrl = StringUtils.replace(this.boomildapUrl, "{userid}", userid);
			boomildapresponse = getUrlConnectionData(boomiUrl + this.boomiToken, null, null, null, null);
			log.debug("ldap response " + boomildapresponse);
			if (StringUtils.isNotBlank(boomildapresponse)) {
				jsonBoomildap = new JSONObject(boomildapresponse);
			}
		} catch (MalformedURLException e) {
			log.error("Malformed URL Exception: ", e);
		} catch (IOException e) {
			log.error("IO Exception: ", e);
		} catch (JSONException e) {
			log.error("JSON Exception: ", e);
		}
		return jsonBoomildap;
	}

	@Override
	public JSONArray getBoomiToolType() {
		JSONArray jsonBoomiToolType = null;
		String boomiToolTypeResponse = null;

		try {
			boomiToolTypeResponse = getUrlConnectionData(this.boomiToolTypeUrl + this.boomiToken, null, null, null,
					null);
			jsonBoomiToolType = new JSONArray(boomiToolTypeResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiToolType: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiToolType: ", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiToolType: : ", e);
		}

		return jsonBoomiToolType;
	}

	@Override
	public JSONArray getBoomiToolTypeTPNs(String toolTypeId) {
		JSONArray jsonBoomiToolTypeTPNs = null;
		String boomiToolTypeTPNsResponse = null;

		try {
			boomiToolTypeTPNsResponse = getUrlConnectionData(this.boomiToolTypeTPNsUrl.replace("{toolTypeId}", toolTypeId) + this.boomiToken, null, null, null,
					null);
			jsonBoomiToolTypeTPNs = new JSONArray(boomiToolTypeTPNsResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiToolTypeTPNs: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiToolTypeTPNs: ", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiToolTypeTPNs: : ", e);
		}

		return jsonBoomiToolTypeTPNs;
	}

	@Override
	public JSONArray getBoomiLiteratureCategoryListing() {
		JSONArray jsonBoomiLiteratureCategory = null;
		String boomiLiteratureCategoryResponse = null;

		try {
			boomiLiteratureCategoryResponse = getUrlConnectionData(this.boomiCategoryListingUrl + this.boomiToken, null,
					null, null, null);
			jsonBoomiLiteratureCategory = new JSONArray(boomiLiteratureCategoryResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiLiteratureCategoryListing: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiLiteratureCategoryListing:", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiLiteratureCategoryListing: ", e);
		}

		return jsonBoomiLiteratureCategory;
	}

	@Override
	public JSONArray getBoomiApplicationMarket() {
		JSONArray jsonBoomiApplicationMarket = null;
		String boomiApplicationMarketResponse = null;

		try {
			boomiApplicationMarketResponse = getUrlConnectionData(this.boomiApplicationMarketUrl + this.boomiToken,
					null, null, null, null);
			jsonBoomiApplicationMarket = new JSONArray(boomiApplicationMarketResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiApplicationMarket: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiApplicationMarket", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiApplicationMarket: ", e);
		}

		return jsonBoomiApplicationMarket;
	}

	@Override
	public JSONArray getBoomiApplicationSector(String marketid) {
		JSONArray jsonBoomiApplicationSector = null;
		String boomiApplicationSectorResponse = null;

		try {
			String sectorUrl = StringUtils.replace(this.boomiApplicationSectorUrl, "{marketId}", marketid);
			boomiApplicationSectorResponse = getUrlConnectionData(sectorUrl + this.boomiToken, null, null, null, null);
			jsonBoomiApplicationSector = new JSONArray(boomiApplicationSectorResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiApplicationSector: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiApplicationSector", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiApplicationSector: ", e);
		}

		return jsonBoomiApplicationSector;
	}

	@Override
	public JSONArray getBoomiApplicationCategory(String sectorId) {
		JSONArray jsonBoomiApplicationCategory = null;
		String boomiApplicationCategoryResponse = null;

		try {
			String categoryUrl = StringUtils.replace(this.boomiApplicationCategoryUrl, "{sectorId}", sectorId);
			boomiApplicationCategoryResponse = getUrlConnectionData(categoryUrl + this.boomiToken, null, null, null,
					null);
			jsonBoomiApplicationCategory = new JSONArray(boomiApplicationCategoryResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiApplicationCategory: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiApplicationCategory", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiApplicationCategory: ", e);
		}

		return jsonBoomiApplicationCategory;
	}

	@Override
	public JSONArray getBoomiApplicationEndEquipments(String sectorId, String webcategoriesId) {
		JSONArray jsonBoomiApplicationEndEquipments = null;
		String boomiApplicationEndEqupmentsResponse = null;

		try {
			String endEquipmentUrl = StringUtils.replace(this.boomiApplicationEndEquipmentsUrl, "{sectorId}", sectorId);
			if (StringUtils.isNotBlank(webcategoriesId)) {
				endEquipmentUrl = StringUtils.replace(endEquipmentUrl, "{webcategory}", webcategoriesId);
			} else {
				endEquipmentUrl = StringUtils.replace(endEquipmentUrl, "{webcategory}", "null");
			}
			boomiApplicationEndEqupmentsResponse = getUrlConnectionData(endEquipmentUrl + this.boomiToken, null, null,
					null, null);
			jsonBoomiApplicationEndEquipments = new JSONArray(boomiApplicationEndEqupmentsResponse);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException in getBoomiApplicationEndEquipments: ", e);
		} catch (IOException e) {
			log.error("IOException in getBoomiApplicationEndEquipments", e);
		} catch (JSONException e) {
			log.error("JSONException in getBoomiApplicationEndEquipments: ", e);
		}

		return jsonBoomiApplicationEndEquipments;
	}

	@Override
	public JSONObject getFeaturedProduct(String gpn, String language) {
                JSONObject retVal = null;
                JSONArray dataArray = null;
		try {
			String url = productModelUrl.replace("{gpn}", gpn).replace("{language}", language);
			retVal = new JSONObject(getUrlConnectionData(url, null, oauthToken, tokenType, null));
                        dataArray = retVal.getJSONObject("featuredProductInfo").getJSONArray("partNumberInformation");
                        if(dataArray.length() > 0) {
                            retVal = dataArray.getJSONObject(0);
                            return retVal;
                        }
		} catch (Exception ex) {
			log.error("getFeaturedProduct", ex);
		}
		return null;
	}

	@Override
	public JSONObject getHomePageFeaturedProducts(String language) {
		JSONObject retval = null;
		try {
			String url = homePageFeaturedProductsUrl.replace("{language}", URLEncoder.encode(language, UTF8));
			retval = new JSONObject(getUrlConnectionData(url, null, oauthToken, tokenType, null));
		} catch (Exception ex) {
			log.error("getHomePageFeaturedProducts", ex);
		}
		return retval;
	}

	@Override
	public JSONObject getProductFamilyNewProducts(String familyId, String language) {
		JSONObject retval = null;
		try {
			String url = productFamilyNewProductsUrl.replace("{familyId}", URLEncoder.encode(familyId, UTF8));
			url = url.replace("{language}", URLEncoder.encode(language, UTF8));
			retval = new JSONObject(getUrlConnectionData(url, null, oauthToken, tokenType, null));
		} catch (Exception ex) {
			log.error("getProductFamilyNewProducts", ex);
		}
		return retval;
	}

	private String readStream(InputStream inputStream) {
		StringBuilder sb = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, UTF8));
			String nextLine = "";
			while ((nextLine = reader.readLine()) != null) {
				sb.append(nextLine);
			}
		} catch (IOException e) {
			log.error("IO Exception: ", e);
		}
		return sb.toString();
	}

	/* OSGI Service Methods */

	@Activate
	@Modified
	protected void activate(WCMComponentConfiguration config) {

		setUrls(config);
	}

	private void setUrls(WCMComponentConfiguration config) {

		this.emsgProductAll = config.emsgProductAllUrl();
		this.emsgToolOpn = config.emsgToolOpnUrl();
		this.emsgApplicationAll = config.emsgApplicationAllUrl();
		this.emsgApplicationList = config.emsgApplicationListUrl();
		this.techDocsUrl = config.tiTechDocsUrl();
		this.oauthUrl = config.oauthUrl();
		this.oauthAuthentication = config.oauthAuthentication();
		this.percolateoauthUrl = config.percolateoauthUrl();
		this.percolateoauthAuthentication = config.percolateoauthAuthentication();
		this.featuredLitUrl = config.featuredLitUrl();
		this.siloUrl = config.siloUrl();
		this.productFamilyUrl = config.productFamilyUrl();
		this.percolateuserlisturl = config.percolateuserlistUrl();

		this.productTechDocCategoriesUrl = config.productTechDocCategoriesUrl();
		this.applicationTechDocCategoriesUrl = config.applicationTechDocCategoriesUrl();
		this.techDocCategoriesUrlSuffix = config.productTechDocCategoriesUrlSuffix();
		this.productTechDocListingUrlSuffix = config.productTechDocListingUrl();
		this.techDocListingUrlCountSuffix = config.productTechDocListingCountUrlSuffix();
		this.techDocListingUrlSearchTermSuffix = config.productTechDocListingSearchTermUrlSuffix();
		this.defaultDocumentCategories = config.defaultDocumentCategories();
		this.apphomepageurl = config.apphomepageUrl();
		this.applicationTechDocListingUrlSuffix = config.applicationTechDocListingUrl();
		this.recommendedAppsUrl = config.recommendedAppsUrl();
		this.boomiToken = config.boomiToken();
		this.boomiSiloFamilies = config.boomiSiloFamilies();
		this.boomiProductFamilyAllUrl = config.boomiProductFamilyAllUrl();
		this.boomiProductFamilyGPNsUrl = config.boomiProductFamilyGPNsUrl();
		this.boomiEpodVariantUrl = config.boomiEpodVariantUrl();
		this.boomiDamDeleteUrl = config.boomiDamDeleteUrl();
		this.boomildapUrl = config.boomildapUrl();
		this.boomiToolTypeUrl = config.boomiToolTypeUrl();
		this.boomiToolTypeTPNsUrl = config.boomiToolTypeTPNsUrl();
		this.boomiCategoryListingUrl = config.boomiCategoryListingUrl();
		this.boomiApplicationMarketUrl = config.boomiApplicationMarketUrl();
		this.boomiApplicationSectorUrl = config.boomiApplicationSectorUrl();
		this.boomiApplicationCategoryUrl = config.boomiApplicationCategoryUrl();
		this.emsgToolPartDetailUrl = config.emsgToolPartDetailUrl();
		this.homePageFeaturedProductsUrl = config.homePageFeaturedProductsUrl();
		this.productFamilyNewProductsUrl = config.productFamilyNewProductsUrl();
		this.boomiApplicationEndEquipmentsUrl = config.boomiApplicationEndEquipmentsUrl();
		this.productModelUrl = config.productModelUrl();
		this.supplyFrameUrlDomain = config.supplyFrameUrlDomain();
		this.jackDefaultTrendingDataUrl = config.jackDefaultTrendingDataUrl();
		this.connectTimeOut = config.connectTimeOutValue();
		this.readTimeOut = config.readTimeOutValue();
		this.defaultRetries = config.defaultRetries();
		this.defaultWaitTime = config.defaultWaitTime();
		this.toolDetailsUrl = config.toolDetailsUrl();
		this.brightcoveAuthUrl = config.brightcoveOauthUrl();
		this.brightcoveOauthAuthentication = config.brightcoveOauthAuthentication();
		this.brightcoveVideoMetaDataUrl = config.brightcoveVideoMetaDataUrl();
		this.brightcoveVideoSourceUrl = config.brightcoveVideoSourceUrl();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ti.core.service.WCMComponents#getAllDocCategories()
	 */
	@Override
	public String getAllDocCategories() {
		return doGetAllDocCategories();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ti.core.service.WCMComponents#getAllProductService(org.apache.sling.
	 * api.SlingHttpServletRequest, int)
	 */
	@Override
	public JSONObject getAllProductService(SlingHttpServletRequest request, int familyId, String language) {

		JSONObject retval = null;

		String attribKey = "EMSG_PRODUCT_DATA_ALL_" + familyId + "_" + language;

		try {

			Object oJSON = request.getAttribute(attribKey);

			if (oJSON != null && oJSON instanceof JSONObject)
				retval = (JSONObject) oJSON;
			else {

				generateOauthToken();
				String url;
				if (familyId == 0) {
					url = StringUtils.replace(this.emsgProductAll, "/{familyId}/", "/");
				} else {
					url = StringUtils.replace(this.emsgProductAll, "{familyId}", Integer.toString(familyId));
				}
				String resp = getUrlConnectionData(url, language, oauthToken, tokenType, null);
				retval = new JSONObject(resp);

				request.setAttribute(attribKey, retval);

			}

		} catch (IOException e) {
			log.error("IOException: ", e);
		} catch (JSONException e) {
			log.error("Could not create JSONObject from service response: ", e);
		}

		return retval;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ti.core.service.WCMComponents#getToolOpnService(org.apache.sling.api.
	 * SlingHttpServletRequest, int, String)
	 */
	@Override
	public String getToolOpnService(SlingHttpServletRequest request, String opn, String language) {

		String toolOPNInfo = null, resp = null;

		String attribKey = "EMSG_TOOL_OPN_DATA_ALL_" + opn + "_" + language;
		try {
			toolOPNInfo = (String) request.getAttribute(attribKey);

			if (toolOPNInfo != null)
				resp = toolOPNInfo;
			else {

				generateOauthToken();

				String url = StringUtils.replace(this.emsgToolOpn, "{opn}", opn);
				resp = getUrlConnectionData(url, language, oauthToken, tokenType, null);
				log.debug("response for tool details " + resp);
				request.setAttribute(attribKey, resp);

			}
		} catch (IOException e) {
			log.error("IOException: ", e);
		}

		return resp;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ti.core.service.WCMComponents#getAllProductService(org.apache.sling.
	 * api.SlingHttpServletRequest, int)
	 */
	@Override
	public JSONObject getAllApplicationService(SlingHttpServletRequest request, int applicationId, String language) {

		JSONObject retval = null;

		String attribKey = "EMSG_APPLICATION_DATA_ALL_" + applicationId + "_" + language;

		Object oJSON = request.getAttribute(attribKey);

		if (oJSON != null && oJSON instanceof JSONObject)
			retval = (JSONObject) oJSON;
		else {

			retval = getAllApplicationService(applicationId, language);

			request.setAttribute(attribKey, retval);

		}

		return retval;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.ti.core.service.WCMComponents#getListProductService(org.apache.sling.
	 * api.SlingHttpServletRequest, int)
	 */
	@Override
	public JSONObject getApplicationListService(SlingHttpServletRequest request, String language) {

		JSONObject retval = null;

		String attribKey = "EMSG_APPLICATION_DATA_LIST";

		try {

			Object oJSON = request.getAttribute(attribKey);
			if (oJSON != null && oJSON instanceof JSONObject)
				retval = (JSONObject) oJSON;
			else {
				generateOauthToken();
				String resp = getUrlConnectionData(this.emsgApplicationList, language, oauthToken, tokenType, null);
				retval = new JSONObject(resp);
				request.setAttribute(attribKey, retval);
			}

		} catch (IOException e) {
			log.error("IOException: ", e);
		} catch (JSONException e) {
			log.error("Could not create JSONObject from service response: ", e);
		}
		return retval;
	}

	@Override
	public String getLiteraturesByDocumentType(String documentTypes, String id, String language, boolean isFamily) {
		String literaturesByDocumentType = null;
		String getLiteraturesByDocumentTypeUrl = null;
		String lang = language;
		try {
			generateOauthToken();
			if (isFamily) {
				getLiteraturesByDocumentTypeUrl = this.productTechDocCategoriesUrl + id
						+ this.productTechDocListingUrlSuffix + documentTypes;
			} else {
				getLiteraturesByDocumentTypeUrl = this.applicationTechDocCategoriesUrl + id
						+ this.applicationTechDocListingUrlSuffix + documentTypes;
			}
			if (!(language.toUpperCase().contains(CHINESE_LANG_CODE)
					|| language.toUpperCase().contains(JAPANESE_LANG_CODE))) {
				lang = ENGLISH_LANG_CODE.toLowerCase();
			}
			literaturesByDocumentType = getUrlConnectionData(getLiteraturesByDocumentTypeUrl, lang, oauthToken,
					tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return literaturesByDocumentType;
	}

	@Override
	public String getLiteraturesByCount(String count, String id, String documentType, String language,
			boolean isFamily) {
		String literaturesByCount = null;
		String getLiteraturesByCountUrl = null;
		try {
			generateOauthToken();
			if (isFamily) {
				getLiteraturesByCountUrl = this.productTechDocCategoriesUrl + id + this.productTechDocListingUrlSuffix
						+ documentType + this.techDocListingUrlCountSuffix + count;
			} else {
				getLiteraturesByCountUrl = this.applicationTechDocCategoriesUrl + id
						+ this.applicationTechDocListingUrlSuffix + documentType + this.techDocListingUrlCountSuffix
						+ count;
			}
			log.debug("literature URL " + getLiteraturesByCountUrl);

			literaturesByCount = getUrlConnectionData(getLiteraturesByCountUrl, language, oauthToken, tokenType, null);

			log.debug("response" + literaturesByCount);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return literaturesByCount;
	}

	@Override
	public String getLiteraturesBySearchTerm(String searchTerm, String id, String documentType, String count,
			String language, boolean isFamily) {
		String literaturesBySearchTerm = null;
		String getLiteraturesBySearchTermUrl = null;
		try {
			generateOauthToken();

			if (isFamily) {
				getLiteraturesBySearchTermUrl = this.productTechDocCategoriesUrl + id
						+ this.productTechDocListingUrlSuffix + documentType + this.techDocListingUrlSearchTermSuffix
						+ searchTerm + ",count=" + count;
			} else {
				getLiteraturesBySearchTermUrl = this.applicationTechDocCategoriesUrl + id
						+ this.applicationTechDocListingUrlSuffix + documentType
						+ this.techDocListingUrlSearchTermSuffix + searchTerm + ",count=" + count;
			}
			literaturesBySearchTerm = getUrlConnectionData(getLiteraturesBySearchTermUrl, language, oauthToken,
					tokenType, null);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return literaturesBySearchTerm;
	}

	@Override
	public String getToolsAndSoftwareListings(String familyId, String toolTypeId, String sortColumn, String sortType,
			String language) {
		String toolsAndSoftwareListingResponse = null;
		String lang = language;
		try {

			generateOauthToken();
			String getToolsListing = this.toolsSoftwareListingUrl + familyId + "/" + PARAM_TOOL_TYPE_ID + "/"
					+ toolTypeId + URL_QUERYSTRING_INIT + "filter" + QUERY_STRING_EQUALS + PARAM_DEFAULT_SORT_COLUMN
					+ QUERY_STRING_EQUALS + sortColumn + QUERY_STRING_SEP + PARAM_DEFAULT_SORT_DIRECTION
					+ QUERY_STRING_EQUALS + sortType;
			log.debug("tools and s/w url" + getToolsListing);
			if (!(language.contains(CHINESE_LANG_CODE) || language.contains(JAPANESE_LANG_CODE))) {
				lang = ENGLISH_LANG_CODE.toLowerCase();
			}
			toolsAndSoftwareListingResponse = getUrlConnectionData(getToolsListing, lang, oauthToken, tokenType, null);
		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return toolsAndSoftwareListingResponse;
	}

	@Override
	public String getDefaultDocumentCategories() {
		return defaultDocumentCategories;
	}

	@Override
	public String getApphomepageurl() {
		return apphomepageurl;
	}

	@Override
	public JSONObject getAllApplicationService(int applicationId, String language) {

		JSONObject retval = null;
		try {
			generateOauthToken();
			String url = StringUtils.replace(this.emsgApplicationAll, "{applicationId}",
					Integer.toString(applicationId));
			String resp = getUrlConnectionData(url, language, oauthToken, tokenType, null);
			if (!StringUtils.isEmpty(resp)) {
				retval = new JSONObject(resp);
			}
		} catch (IOException e) {
			log.error("IOException: getAllApplicationService ", e);
		} catch (JSONException e) {
			log.error("Could not create JSONObject from service response: getAllApplicationService", e);
		}
		return retval;
	}

	@Override
	public String getRecommendedAppsForProductFamily(String familyId, String language) {
		String jsonResponse = null;
		try {
			generateOauthToken();
			String recommendedApplicationUrl = StringUtils.replace(this.recommendedAppsUrl, "{familyId}", familyId);
			log.debug("getRecommendedAppsForProductFamily URL: ", recommendedApplicationUrl);
			jsonResponse = getUrlConnectionData(recommendedApplicationUrl, language, oauthToken, tokenType, null);
		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return jsonResponse;
	}

	@Override
	public String getSupplyFrameUrlDomain() {
		return supplyFrameUrlDomain;
	}

	public void setSupplyFrameUrlDomain(String supplyFrameUrlDomain) {
		this.supplyFrameUrlDomain = supplyFrameUrlDomain;
	}

	public String getToolDetailService(SlingHttpServletRequest request, String toolPartNumber, String language) {

		String toolDetailInfo = null;
		String toolResponse = null;

		String attribKey = "EMSG_TOOL_DATA_ALL_" + toolPartNumber + "_" + language;
		try {
			toolDetailInfo = (String) request.getAttribute(attribKey);

			if (null != toolDetailInfo)
				toolResponse = toolDetailInfo;
			else {

				generateOauthToken();

				String url = StringUtils.replace(this.emsgToolPartDetailUrl, "{toolPartNumber}", toolPartNumber);
				toolResponse = getUrlConnectionData(url, language, oauthToken, tokenType, null);
				log.debug("response for tool details " + toolResponse);
				request.setAttribute(attribKey, toolResponse);

			}
		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return toolResponse;
	}

	@Override
	public JSONObject getToolDetails(String toolPartNumber, String language) {
		JSONObject retval = null;
		try {
			String url = this.toolDetailsUrl.replace("{toolPartNumber}", toolPartNumber)
							.replace("{locale}", language);
			retval = new JSONObject(getUrlConnectionData(url, null, oauthToken, tokenType, null));
		} catch (Exception ex) {
			log.error("getToolDetails", ex);
		}
		return retval;
	}


	@Override
	public String getJackDefaultTrendingData(String language) {

		String jackDefaultTrendingData = null;
		try {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			String Url = this.jackDefaultTrendingDataUrl + language;
			jackDefaultTrendingData = getUrlConnectionData(Url, null, null, null, proxy);

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		return jackDefaultTrendingData;
	}

	@Override
	public JSONObject getBrightcoveVideoMetaData(String videoId) {
		JSONObject jsonBrightcoveRespObject = null;
		try {
			generateBrightcoveOauthToken();
			String url = StringUtils.replace(this.brightcoveVideoMetaDataUrl, "{videoId}", videoId);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			String tokentype = "Bearer";
			jsonBrightcoveRespObject = new JSONObject(getUrlConnectionData(url, null, brightcoveOauthToken, tokentype, proxy));

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		catch (JSONException e) {
			log.error("JSONException: ", e);
		}
		return jsonBrightcoveRespObject;

	}

	@Override
	public JSONObject getBrightcoveVideoSourceUrl(String videoId) {
		JSONObject jsonBrightcoveRespObject = null;
		JSONArray jsonBrightcoveRespArray = null;
		try {
			generateBrightcoveOauthToken();
			String url = StringUtils.replace(this.brightcoveVideoSourceUrl, "{videoId}", videoId);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			String tokentype = "Bearer";
			jsonBrightcoveRespArray = new JSONArray(getUrlConnectionData(url, null, brightcoveOauthToken, tokentype, proxy));
			if(jsonBrightcoveRespArray.length() > 0) {
				jsonBrightcoveRespObject = jsonBrightcoveRespArray.getJSONObject(2);
		   }

		} catch (IOException e) {
			log.error("IOException: ", e);
		}
		catch (JSONException e) {
			log.error("JSONException: ", e);
		}
		return jsonBrightcoveRespObject;
	}

	@Override
	public void updateBrightcoveVideo(String videoId, JSONObject json) {
		try {
			generateBrightcoveOauthToken();
			final var url = StringUtils.replace(this.brightcoveVideoMetaDataUrl, "{videoId}", videoId);
			try(var httpClient =
				HttpClients.custom()
				.setProxy(new HttpHost(PROXY_HOST, 80))
				.build()
			) {
				var httpPatch = new HttpPatch(url);
				httpPatch.setHeader(AUTHORIZATION, "Bearer " + brightcoveOauthToken);
				httpPatch.setHeader(CONTENT_TYPE, ACCEPT_VALUE);
				httpPatch.setHeader(ACCEPT, ACCEPT_VALUE);
				httpPatch.setEntity(new StringEntity(json.toString(), StandardCharsets.UTF_8));
				try(var httpResponse = httpClient.execute(httpPatch)) {
					EntityUtils.consume(httpResponse.getEntity());
				}
			}
		} catch (IOException e) {
			log.error("IOException: ", e);
		}
	}

	private void generateBrightcoveOauthToken() {

		if (expiryFlag != 1) {
			getBrightcoveOauthToken();
		} else {
			this.now = new Date();
			if (brightcoveOauthDate != null
					&& now.getTime() - brightcoveOauthDate.getTime() >= brightcoveOauthExpires * MILISECONDS) {
				getBrightcoveOauthToken();
			}
		}
	}

	private void getBrightcoveOauthToken() {
		try {
			String query = "{\"grant_type\": \"client_credentials\"}";
			String URL = this.brightcoveAuthUrl;
			URL = URL + "?" + "grant_type=client_credentials";
			URL url = new URL(URL);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection con = (HttpURLConnection) url.openConnection(proxy);

			con.setDoOutput(true);
			con.setRequestMethod(POST);
			con.setRequestProperty(AUTHORIZATION, this.brightcoveOauthAuthentication);
			con.setRequestProperty(CONTENT_TYPE, ACCEPT_VALUE);

			DataOutputStream os = new DataOutputStream(con.getOutputStream());
			os.writeBytes(query);

			String authString = readStream(con.getInputStream());
			JSONObject authJson = new JSONObject(authString);

			this.brightcoveOauthDate = new Date();
			this.brightcoveOauthExpires = authJson.getInt(EXPIRES_IN);
			this.brightcoveOauthToken = authJson.getString(ACCESS_TOKEN);
			os.close();

		} catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException: ", e);
		} catch (MalformedURLException e) {
			log.error("MalformedURLException: ", e);
		} catch (IOException e) {
			log.error("IOException: ", e);
		} catch (JSONException e) {
			log.error("JSONException: ", e);
		}
	}
	static class RetryOperation {

		private int numberOfRetries;
		private int numberOfTriesLeft;
		private long timeToWait;

		public RetryOperation(int numberOfRetries, long timeToWait) {
			this.numberOfRetries = numberOfRetries;
			numberOfTriesLeft = numberOfRetries;
			this.timeToWait = timeToWait;
		}

		/**
		 * @return true if there are tries left
		 */
		public boolean shouldRetry() {
			return numberOfTriesLeft > 0;
		}

		public void errorOccured(String responseMessage) {
			numberOfTriesLeft--;
			if (responseMessage.equalsIgnoreCase(READ_TIMED_OUT_MESSAGE)
					|| responseMessage.equalsIgnoreCase(CONNECT_TIMED_OUT_MESSAGE)) {
				log.debug("\n\n numberOfTriesLeft **" + numberOfTriesLeft);
				if (!shouldRetry()) {
					log.error(">>>>>>>Retry Failed:::::: Total " + numberOfRetries + " attempts made at interval "
							+ getTimeToWait() + "ms");
				}
				waitUntilNextTry();
			} else {
				numberOfTriesLeft = 0;
			}
		}

		public long getTimeToWait() {
			return timeToWait;
		}

		private void waitUntilNextTry() {
			try {
				Thread.sleep(getTimeToWait());
			} catch (InterruptedException e) {
				log.error("Interrupted!", e);
				Thread.currentThread().interrupt();
			}
		}
	}
}
