package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.LinkListModel;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/**
 * LinkList WCMUsePojo.
 */
public class LinkList extends WCMUsePojo {

    private String headline;
    private String description;

    private boolean listExist;
    private static final String PARAM_HEADLINE = "headline";
    private static final String PARAM_DESCRIPTION = "description";
    private static final String PARAM_URLLIST = "urlList";
    
    private final List<LinkListModel> listLinkListModel = new ArrayList<>();

    @Override
    public void activate() throws JSONException {
        this.headline = getProperties().get(PARAM_HEADLINE, String.class);
        this.description = getProperties().get(PARAM_DESCRIPTION, String.class);

        for (Resource nodeChild : getResource().getChildren()) {
            if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(PARAM_URLLIST)) {
                for (Resource ctaLink : nodeChild.getChildren()) {
                    LinkListModel linkListModelObject = new LinkListModel();

                    ValueMap properties = ctaLink.adaptTo(ValueMap.class);
                    if (null != properties) {
                        linkListModelObject.setResolver(getResourceResolver());
                        linkListModelObject.setCtaText(properties.get("ctaText", String.class));
                        linkListModelObject.setCtaUrl(properties.get("ctaUrl", String.class));
                        listLinkListModel.add(linkListModelObject);

                    }
                }
            }
        }
    }

    public String getUrlList() {
        return PARAM_URLLIST;
    }

    public String getHeadline() {
        return headline;
    }

    public String getDescription() {
        return description;
    }

    public List<LinkListModel> getListLinkListModel() {
        return listLinkListModel;
    }

    public boolean isListExist() {
        if(!listLinkListModel.isEmpty())
        {
            listExist = true;
        }
        return listExist;
    }

}
