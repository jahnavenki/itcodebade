package com.ti.core.service.workflow;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set values for YouTube description and Short description metadata.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: YouTube Description Metadata" })
public class YouTubeDescriptionMetadataProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private WCMComponents wcmService;

	private String getYouTubeDescription(ValueMap map) {
		var details = map.get("dam:details", "");
		final var cta1 = map.get("dam:cta1", "");
		final var url1 = map.get("dam:url1", "");
		final var cta2 = map.get("dam:cta2", "");
		final var url2 = map.get("dam:url2", "");
		final var cta3 = map.get("dam:cta3", "");
		final var url3 = map.get("dam:url3", "");
		final var cta4 = map.get("dam:cta4", "");
		final var url4 = map.get("dam:url4", "");
		final var sb = new StringBuilder();
		final var _D = "</div>";
		final var BR = "<br>";
		final var _P = "</p>";
		final var _LI = "</li>";
		final var CRLF = "\r\n";

		if (StringUtils.isNotEmpty(details)) {
			details = details
				.replace(BR, CRLF)
				.replace(_P, CRLF)
				.replace(_D, CRLF)
				.replace(_LI, CRLF)
				.replace("\u2122", "&trade;")
				.replace("\u00a9", "&copy;")
				.replace("\u00ae", "&reg;")
				.replaceAll("<!--.*?-->", "")
				.replaceAll("<[^>]+>", "")
				.trim();
			details = StringEscapeUtils.unescapeHtml(details);
			sb.append(details);
			sb.append(CRLF);
		}
		if (StringUtils.isNotEmpty(cta1) || StringUtils.isNotEmpty(url1)) {
			sb.append(cta1);
			sb.append(CRLF);
			sb.append(url1);
			sb.append(CRLF);
		}
		if (StringUtils.isNotEmpty(cta2) || StringUtils.isNotEmpty(url2)) {
			sb.append(cta2);
			sb.append(CRLF);
			sb.append(url2);
			sb.append(CRLF);
		}
		if (StringUtils.isNotEmpty(cta3) || StringUtils.isNotEmpty(url3)) {
			sb.append(cta3);
			sb.append(CRLF);
			sb.append(url3);
			sb.append(CRLF);
		}
		if (StringUtils.isNotEmpty(cta4) || StringUtils.isNotEmpty(url4)) {
			sb.append(cta4);
			sb.append(CRLF);
			sb.append(url4);
			sb.append(CRLF);
		}
		String sbString = sb.toString()
			.replace("<","")
			.replace(">","")
			.replaceAll("&lt;([^.]*?)&gt;", "$1");
		return sbString.substring(0,Math.min(5000, sbString.length()));
	}

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final WorkflowData workflowData = item.getWorkflowData();
			final String payload = workflowData.getPayload().toString();
			final ResourceResolver resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) throw new NullPointerException("resourceResolver");
			final Resource resource = resourceResolver.getResource(payload);
			if (null == resource) return;
			final ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
			if (null == map) return;
			final String youTube = map.get("dam:youtube", "no");
			String youTubeDescription = "";
			if ("yes".equals(youTube)) {
				youTubeDescription = getYouTubeDescription(map);
			}
			// Set the value for 'YouTube description' field in Brightcove tab
			map.put("dam:youtube_description", youTubeDescription);

			// Set the value for 'Short description' field in Brightcove tab
			final String desc = map.get("shortDescription", "");
			map.put("brc_description", desc);
		} catch (Exception e) {
			log.error("Error occurred in YouTubeDescriptionMetadataProcessStep", e);
		}
	}
}
