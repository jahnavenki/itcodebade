package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.ti.core.service.ApiPortalService;

@Model(
	adaptables = { SlingHttpServletRequest.class, Resource.class },
	resourceType = SubsiteHeader.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class SubsiteHeader {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/subsiteHeader";

	@ScriptVariable
	private Page currentPage;

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ApiPortalService apiPortalService;

	@ChildResource(name = "level1Links")
	private Collection<SubsiteHeaderLevel1> links;

	@PostConstruct
	public void init() {
		try {
			links = CollectionUtils.emptyIfNull(links);
			if (null != currentPage) {
				final var currentUrl = apiPortalService.getUrl(currentPage.getPath());
				for (final var level1Link : links) {
					if (currentUrl.equals(level1Link.getUrl())) level1Link.setSelected(true);
					for (final var level2Link : level1Link.getChildren()) {
						if (currentUrl.equals(level2Link.getUrl())) {
							level1Link.setSelected(true);
							level2Link.setSelected(true);
						}
					}
				}
			}
		} catch(Exception ex) {
			log.error( "Exception in SubsiteHeader", ex );
		}
	}

	public Collection<SubsiteHeaderLevel1> getLinks() {
		return links;
	}

	public Boolean isNeedsAuthoring() {
		return links.isEmpty();
	}
}
