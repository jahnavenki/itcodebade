package com.ti.core.service.workflow;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.regex.Pattern;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.util.AssetUtils;
import com.ti.core.service.WCMComponents;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step for fetching ePOD variant metadata.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Fetch ePOD Variant Metadata" })
public class FetchEpodVariantMetadataProcessStep implements WorkflowProcess {
	private static final Logger log = LoggerFactory.getLogger(FetchEpodVariantMetadataProcessStep.class);

	@Reference
	private WCMComponents wcmService;

	private static class FilenameData {
		public FilenameData(String variantName, String perspective) {
			this.variantName = variantName;
			this.perspective = perspective;
		}

		private String variantName;
		public String getVariantName() { return variantName; }

		private String perspective;
		public String getPerspective() { return perspective; }
	}

	private static Pattern filenamePattern = Pattern.compile("^(.*?)(?:[-_ ](2[-_ ]point|3d|angled|bottom|isometric|single[-_ ]point|straight|top|what[-_ ]is[-_ ]included))?$", Pattern.CASE_INSENSITIVE);
	private static Pattern separatorPattern = Pattern.compile("[-_ ]");
	private FilenameData getFilenameData(String path) {
		final var basename = FilenameUtils.getBaseName(path);
		final var matcher = filenamePattern.matcher(basename);
		if(!matcher.matches()) throw new IllegalArgumentException("path");
		final var matchResult = matcher.toMatchResult();
		final var variantName = matchResult.group(1).toUpperCase(Locale.ENGLISH);
		var perspective = matchResult.group(2);
		if (null != perspective) {
			perspective = "ticom:image/perspective/" + separatorPattern.matcher(perspective).replaceAll("-").toLowerCase(Locale.ENGLISH);
		}
		return new FilenameData(variantName, perspective);
	}

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();

			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (resourceResolver == null) return;

			final var resource = resourceResolver.getResource(payload);
			if (resource == null) return;

			final var map = AssetUtils.getModifiableMetadata(resource);
			if (map == null) return;

			final var filenameData = getFilenameData(payload);

			var changes = false;

			final var perspective = filenameData.getPerspective();
			if (StringUtils.isNotEmpty(perspective)) {
				map.put("dam:perspective", new String[] { perspective } );
				changes = true;
			}

			final var result = wcmService.getBoomiEpodVariantMetadata(filenameData.getVariantName());
			if (null != result && result.getStatus()) {
				map.put("dam:pinCount", result.getPinCount());
				map.put("dam:packageGroup", result.getPackageGroup());
				map.put("dam:packageDesignator", result.getPackageDesignator());
				map.put("dam:epodOrPackageVariant", result.getVariant());
				changes = true;
			}

			if (changes) {
				resourceResolver.commit();
			}
		} catch (Exception e) {
			log.error("Error occurred in FetchEpodMetadataProcessStep", e);
		}
	}
}
