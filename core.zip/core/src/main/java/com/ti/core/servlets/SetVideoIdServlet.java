package com.ti.core.servlets;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.LanguageUtils;

@Component(service = { Servlet.class }, property = { "sling.servlet.methods=get",
"sling.servlet.paths=/bin/ti/setVideoId" })
public class SetVideoIdServlet extends SlingAllMethodsServlet {
	protected static final transient Logger log = LoggerFactory.getLogger(SetVideoIdServlet.class);

	private static final String PRESENTATION_QUIZ = "presentation-quiz";
	private static final String PRESENTATION_TEXT = "Presentation";
	private static final String PRESENTATION_QUIZ_TEXT = "Presentation & quiz";
	private static final String PDF = ".pdf";
	private static final String METADATA = "/jcr:content/metadata";
	private static final String DD_MMM_YYYY = "dd MMM YYYY";
	private static final String EN_US = "en-us";
	private static final String ZH_CN = "zh-cn";
	private static final String JA_JP = "ja-jp";
	private static final String DE_DE = "de-de";
	private static final String KO_KR = "ko-kr";
	private static final String ZH_TW = "zh-tw";
	private static final String LIT = "/lit/";
	private static final String DOWNLOAD = "download";
	private static final String EXTERNAL = "external";
	private static final String URL = "url";
	private static final String TEXT = "text";
	private static final String ICON = "icon";
	private static final String PUBLICATION_DATE = "dam:published";

	@Reference
	private transient ProductNavigationTabsOrdering tabsService;
	@Reference
	private transient WCMComponents wcmService;
	@Reference
	private transient VideoConfigService videoService;

	private static final String PROXY_HOST = "webproxy.ext.ti.com";

	private transient LanguageUtils langUtils;
	private transient SlingHttpServletRequest servletRequest;
	private transient ResourceResolver resourceResolver;
	private transient Page page;

	private String formattedDate;
	private String lang;
	String localeString = "";
	String pagelanguage = EN_US;

	private static final String DIV_TI_IMAGE = "<div class='u-flex-item mod-item-grow u-margin-right-8' style='max-width: 174px; width: 174px;'>";
	private static final String TI_IMAGE = "<ti-image class='u-pull-left u-margin-bottom-4' src='";
	private static final String TI_IMAGE_END = "'></ti-image>";
	private static final String DIV_HTML = "<div>";
	private static final String DIV_HTML_END = "</div>";
	private static final String DIV_EMPLOYEE = "<div class='u-font-size-2 u-font-weight-heavy u-margin-bottom-2'>";

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
		throws ServletException, IOException {
		try {
			servletRequest = request;
			resourceResolver = request.getResourceResolver();
			langUtils = new LanguageUtils(servletRequest);
			String path = request.getParameter("path");
			String videoId = request.getParameter("videoId");
			Resource pageRes = resourceResolver.getResource(path);
			if(pageRes == null)
				return;
			page = pageRes.adaptTo(Page.class);

			if (null != tabsService) {
                lang = tabsService.getPageLanguage(page);
            }

			String videoPath = videoService.getVideoPath();
			if (videoPath == null || videoPath.length() <= 0) {
				log.debug("Video path not found in the config");
				return;
			}

			Resource damRes = AssetUtils.getDamResource(resourceResolver, videoPath ,videoId);
			if(damRes != null) {
				Resource damMetaDataRes = resourceResolver.getResource(damRes.getPath() + METADATA);
				if (damMetaDataRes != null) {
					ValueMap metaDataProps = damMetaDataRes.getValueMap();
					JSONObject videoJsonObj = new JSONObject();
					setTitleAndDescriptionAsJson(metaDataProps,videoJsonObj);
					setDateAndDurationAsJson(metaDataProps,videoJsonObj);
					setPresenterAsJson(metaDataProps,videoJsonObj);
					setResourcesAsJson(damRes,videoJsonObj);
					setTranscriptAsJson(metaDataProps,videoJsonObj, videoId);
					response.setCharacterEncoding("UTF-8");
					response.getWriter().write(videoJsonObj.toString());
				}

			}
		} catch (JSONException e) {
			log.error("JSONException ", e);
		} catch (ParseException e) {
			log.error("ParseException ", e);
		}
	}

	private void setTitleAndDescriptionAsJson(ValueMap metaData, JSONObject videoJsonObj) throws JSONException {
		videoJsonObj.put("title", metaData.get("dc:title",""));
		String description = metaData.get("dam:details","");
		String descriptionHtml = "<ti-view-more ><div>"+description+"</div></ti-view-more>";
		videoJsonObj.put("description", descriptionHtml);
	}

	private void setDateAndDurationAsJson(ValueMap metaData, JSONObject videoJsonObj) throws JSONException, ParseException {
		videoJsonObj.put("duration", metaData.get("brc_duration",""));
		if (metaData.containsKey(PUBLICATION_DATE)) {
			Date pubDate = metaData.get(PUBLICATION_DATE, Date.class);
			if (pubDate != null) {
				setDateFormattedValue(pubDate,servletRequest);
				videoJsonObj.put("date",formattedDate);
			}
		}
	}

	private void setDateFormattedValue(Date theDate,SlingHttpServletRequest request) {
        String dateFormat = langUtils.getI18nStr(DD_MMM_YYYY, page,request);
        if (StringUtils.isNotEmpty(dateFormat)) {
            SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
            formattedDate = formatter.format(theDate.getTime());

            // Formatting for German
            if (lang.equals(DE_DE)) {
                formattedDate = updateDEMonth(formattedDate);
            }
			formattedDate = formattedDate.toUpperCase();
        }
    }

	private void setPresenterAsJson(ValueMap metaData, JSONObject videoJsonObj) throws JSONException {
		String firstPresenterImgSrc = metaData.get("dam:presenter1", "");
		String secondPresenterImgSrc = metaData.get("dam:presenter2", "");
		String presenter;
		switch(lang) {
			case ZH_CN:presenter = "讲解人"; break;
			case JA_JP: presenter = "講演者"; break;
			case DE_DE: presenter = "Referent(en)"; break;
			case KO_KR: presenter = "발표자"; break;
			case ZH_TW: presenter = "簡報者"; break;
			default: presenter = "Presenter(s)";
		}
		if (StringUtils.isEmpty(firstPresenterImgSrc) && StringUtils.isEmpty(secondPresenterImgSrc)) {
			return;
		}
		StringBuilder firstPresenterHtml = new StringBuilder();
		StringBuilder secondPresenterHtml = new StringBuilder();
		if (!StringUtils.isEmpty(firstPresenterImgSrc)) {
			firstPresenterHtml = buildPresenterHTML(firstPresenterImgSrc);
		}
		if (!StringUtils.isEmpty(secondPresenterImgSrc)) {
        	secondPresenterHtml = buildPresenterHTML(secondPresenterImgSrc);
		}

		StringBuilder presenterHtml = new StringBuilder();
		if (firstPresenterHtml.length() > 0 || secondPresenterHtml.length() > 0) {
			presenterHtml.append("<div class='ti_aem-video-Presenter'><h4 class='u-margin-bottom-6 u-margin-right-6'>" + presenter + "</h4>");
			presenterHtml.append("<div class='u-flex mod-wrap'>");
			presenterHtml.append(firstPresenterHtml);
			presenterHtml.append(secondPresenterHtml);
			presenterHtml.append(DIV_HTML_END);
			presenterHtml.append(DIV_HTML_END);
		}
		videoJsonObj.put("presenterObj", presenterHtml);
	}

	private StringBuilder buildPresenterHTML(String imgSrc) {
		StringBuilder presenterHtml = new StringBuilder();
		Resource imgResource = resourceResolver.getResource(imgSrc);
		if (imgResource != null) {
			Asset asset = imgResource.adaptTo(Asset.class);
			if (asset != null) {
				String name = StringUtils.defaultString(asset.getMetadataValue("dam:employeeName"));
				String title = StringUtils.defaultString(asset.getMetadataValue("dam:employeeTitle"));
				presenterHtml.append(DIV_TI_IMAGE); //1
				presenterHtml.append(TI_IMAGE);
				presenterHtml.append(imgSrc);
				presenterHtml.append(TI_IMAGE_END);
				presenterHtml.append(DIV_HTML); //2
				presenterHtml.append(DIV_EMPLOYEE); //3
				presenterHtml.append(name);
				presenterHtml.append(DIV_HTML_END); //2
				presenterHtml.append(DIV_HTML); //3
				presenterHtml.append(title);
				presenterHtml.append(DIV_HTML_END);
				presenterHtml.append(DIV_HTML_END);
				presenterHtml.append(DIV_HTML_END);
			}
		}
		return presenterHtml;

	}

	private void setResourcesAsJson(Resource damRes ,JSONObject videoJsonObj) throws JSONException {
		Resource damMetaDataRes = resourceResolver.getResource(damRes.getPath() + METADATA);
		List<Map<String, String>> ctaLinkList = new ArrayList<>();
		if (damMetaDataRes != null) {
			ctaLinkList = getCTAList(damMetaDataRes);
		}
		String subAssetText = null;
		String subAssetLink = null;
		Resource subAssetsRes = damRes.getChild("subassets");
		if (subAssetsRes != null) {
			Iterator<Resource> subAssetsItr = subAssetsRes.listChildren();
			while (subAssetsItr.hasNext()) {
				Resource resource = subAssetsItr.next();
				String name = resource.getName();
				if (name.contains(PDF)) {
					if (name.contains(PRESENTATION_QUIZ)) {
						subAssetText = langUtils.getI18nStr(PRESENTATION_QUIZ_TEXT, page, servletRequest);
					} else {
						subAssetText = langUtils.getI18nStr(PRESENTATION_TEXT, page, servletRequest);
					}
					subAssetLink = resource.getPath();
					break;
				}
			}
		}
		JSONObject resourcesObj = new JSONObject();
		resourcesObj.put("subAssetText",subAssetText);
		resourcesObj.put("subAssetLink",subAssetLink);
		resourcesObj.put("ctaLinkList",ctaLinkList);
		videoJsonObj.put("resourcesObj",resourcesObj);
	}

	private void setTranscriptAsJson(ValueMap metaData, JSONObject videoJsonObj, String videoId) throws JSONException {
		final String transcript = metaData.get("transcript","");
		if (!"yes".equals(transcript)) return;

		final var apiKey = videoService.getApiKey3play();
		if (apiKey == null || apiKey.length() <= 0) {
			log.debug("3Play API key not found in the config");
			return;
		}

		final var accountId = videoService.getAccountId();
		if (accountId == null || accountId.length() <= 0) {
			log.debug("3Play account ID not found in the config");
			return;
		}

		final var url = "https://api.3playmedia.com/v3/files/?reference_id=" + videoId + "&api_key=" + apiKey;
		final var res = makeRequest(url);
		final var fileObj = new JSONObject(res);
		final var tpmFiles = fileObj.getJSONArray("data");

		if (tpmFiles.length() == 0) {
			log.error("3Play API to get 3Play ID didn't return data");
			return;
		}

		final var tpmFile = tpmFiles.getJSONObject(0);

		final var languageMap = new HashMap<Integer, Language>();
		languageMap.put(1, new Language(1, EN_US, "English"));
		languageMap.put(7, new Language(7, DE_DE, "German"));
		languageMap.put(17, new Language(17, ZH_CN, "Chinese (Simplified)"));
		languageMap.put(23, new Language(23, JA_JP, "Japanese"));
		languageMap.put(31, new Language(31, KO_KR, "Korean"));

		final var threePlayId = String.valueOf(tpmFile.getInt("id"));
		final var threePlayLanguages = tpmFile.getJSONArray("language_ids");
		final var languagesArr = new JSONArray();
		for (var i = 0; i < languagesArr.length(); ++i) {
			final var threePlayLanguage = threePlayLanguages.getInt(i);
			final var language = languageMap.getOrDefault(threePlayLanguage, null);
			if (null != language) {
				final var jsonLanguage = new JSONObject();
				jsonLanguage.put("id", language.id);
				jsonLanguage.put("code", language.code);
				jsonLanguage.put("label", language.label);
				languagesArr.put(jsonLanguage);
			}
		}
		final var transcriptObj = new JSONObject();
		final var src = "//plugin.3playmedia.com/ajax.js?data_account_number=" + accountId + "&embed=ajax&itx_multi_text_track=1&itx_collapsible=0&itx_downloadable=1&itx_keywords=0&mf=" + threePlayId + "&p3sdk_version=1.10.7&p=16931&pt=891&seo_format=inline&target=3p-plugin-target&vembed=0&video_id=" + videoId + "&video_target=videoPlayerId";
		transcriptObj.put("src", src);
		transcriptObj.put("languages", languagesArr);
		videoJsonObj.put("transcript",transcriptObj);
	}



	/**
		*
		* @param date
		*
		* 	The Method will take date and return month name in DE
		* @return
	*/
	private String updateDEMonth(String date) {
	    date = date.replace("May.", "MAI");
	    date = date.replace("Oct.", "OKT.");
	    date = date.replace("Dec.", "DEZ.");
		date = date.replace("Mar.", "MÄR.");
	    return date;
	}

	public List<Map<String,String>> getCTAList(Resource metaDataRes) {
		ValueMap metaDataProps = metaDataRes.getValueMap();
		List<Map<String,String>> ctaList = new ArrayList<>();
		String cta1Url = metaDataProps.get("dam:url1","");
		if(StringUtils.isNotBlank(cta1Url)) {
			String cta1Text = metaDataProps.get("dam:cta1","");
			String icon = EXTERNAL;
			Map<String,String> cta1Map = new HashMap<>();
			if(cta1Url.contains(LIT)) {
				icon = DOWNLOAD;
			}
			cta1Map.put(URL, cta1Url);
			cta1Map.put(TEXT, cta1Text);
			cta1Map.put(ICON, icon);
			ctaList.add(cta1Map);
		}

		String cta2Url = metaDataProps.get("dam:url2","");
		if(StringUtils.isNotBlank(cta2Url)) {
			String cta2Text = metaDataProps.get("dam:cta2","");
			String icon = EXTERNAL;
			Map<String,String> cta2Map = new HashMap<>();
			if(cta2Url.contains(LIT)) {
				icon = DOWNLOAD;
			}
			cta2Map.put(URL, cta2Url);
			cta2Map.put(TEXT, cta2Text);
			cta2Map.put(ICON, icon);
			ctaList.add(cta2Map);
		}

		String cta3Url = metaDataProps.get("dam:url3","");
		if(StringUtils.isNotBlank(cta3Url)) {
			String cta3Text = metaDataProps.get("dam:cta3","");
			String icon = EXTERNAL;
			Map<String,String> cta3Map = new HashMap<>();
			if(cta3Url.contains(LIT)) {
				icon = DOWNLOAD;
			}
			cta3Map.put(URL, cta3Url);
			cta3Map.put(TEXT, cta3Text);
			cta3Map.put(ICON, icon);
			ctaList.add(cta3Map);
		}

		String cta4Url = metaDataProps.get("dam:url4","");
		if(StringUtils.isNotBlank(cta4Url)) {
			String cta4Text = metaDataProps.get("dam:cta4","");
			String icon = EXTERNAL;
			Map<String,String> cta4Map = new HashMap<>();
			if(cta4Url.contains(LIT)) {
				icon = DOWNLOAD;
			}
			cta4Map.put(URL, cta4Url);
			cta4Map.put(TEXT, cta4Text);
			cta4Map.put(ICON, icon);
			ctaList.add(cta4Map);
		}

		return ctaList;
	}

	private String makeRequest(String apiUrl) {
		String result = "";

		try {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection connection;
			URL url = new URL(apiUrl);
			connection = (HttpURLConnection) url.openConnection(proxy);
			connection.setRequestMethod("GET");
			connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			connection.setRequestProperty("Content-length", "0");
			connection.setUseCaches(false);
			connection.setAllowUserInteraction(false);

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
			String line;
			StringBuilder res = new StringBuilder();

			while ((line=in.readLine()) != null) {
				res.append(line + '\n');
			}
			in.close();
			result = res.toString();
		} catch (MalformedURLException e){
			log.error("3play bad url : ", e);
		} catch (IOException e){
			log.error("3play Read Error : ", e);
		}
		return result;
	}

	private static class Language {
		private int id;
		private String code;
		private String label;

		public Language(int id, String code, String label) {
			this.id = id;
			this.code = code;
			this.label = label;
		}
	}
}
