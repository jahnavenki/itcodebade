package com.ti.core.listeners;

import java.util.HashMap;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
	immediate = true,
	service = EventListener.class
)
public class ResourceMovedListener implements EventListener {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private ResourceResolverFactory resolverFactory;
	@Reference
	private SlingRepository repository;
	@Reference
	private WorkflowService workflowService;

	private Session session;

	@Activate
	protected void activate(ComponentContext componentContext) {
		try {
			session = repository.loginService( "writeService", null );
			if (null == session) return;
			final var workspace = session.getWorkspace();
			if (null == workspace) return;
			final var observationManager = workspace.getObservationManager();
			if (null == observationManager) return;
			observationManager.addEventListener(this, Event.NODE_MOVED, "/content/dam/ticom", true, null, null, false);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	@Deactivate
	protected void deactivate() throws RepositoryException {
		if (null != session) {
			final var workspace = session.getWorkspace();
			if (null != workspace) {
				final var observationManager = workspace.getObservationManager();
				if (null != observationManager) {
					observationManager.removeEventListener(this);
				}
			}
			session.logout();
			session = null;
		}
	}
	
	@Override
	public void onEvent(final EventIterator events) {
		while (events.hasNext()) {
			var event = events.nextEvent();
			try {
				final var username = event.getUserID();
				final var path = event.getPath();
				final var infoMap = event.getInfo();
				final var srcAbsPath = (String)infoMap.get("srcAbsPath");
				final var destAbsPath = (String)infoMap.get("destAbsPath");
				final var workflowSession = workflowService.getWorkflowSession(session);
				final var workflowModel = workflowSession.getModel("/var/workflow/models/ti-resource-moved");
				final var metadata = new HashMap<String, Object>();
				metadata.put("username", username);
				metadata.put("srcAbsPath", srcAbsPath);
				metadata.put("destAbsPath", destAbsPath);
				final var workflowData = workflowSession.newWorkflowData("JCR_PATH", path);
				workflowSession.startWorkflow(workflowModel, workflowData, metadata);
			} catch (RepositoryException|WorkflowException e){
				log.error(e.getMessage(), e);
			}
		}
	}
}
