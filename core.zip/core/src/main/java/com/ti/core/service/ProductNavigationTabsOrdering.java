package com.ti.core.service;

import com.day.cq.wcm.api.Page;

public interface ProductNavigationTabsOrdering {
  String getStandardTabsOrdering();
  String getAnalyticsPagename();
  String getApplicationStandardTabsOrdering();

  /**
   * Get this pages standard tab location is. returns -1 if not a standard tab
   * 
   * @param page
   *          page to check for standard tab order
   * @return This returns -1 if page nav title is not found in standard tab ordering list. Otherwise
   *         this returns the zero based index of where the tab is found.
   */
  int getTabOrderIndexForPage(Page page);
  
  
  String getLanguageCodeForPage(Page page);
  String getPageLanguage(Page languagePageObject);
  String getDomainFromLanguageCode(String languageCode);
  
  /**
   * Gets the adobe help link.
   *
   * @return the adobe help link
   */
  String getCustomAdobeHelpLink();
}
