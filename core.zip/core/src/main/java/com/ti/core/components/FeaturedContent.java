package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.util.PathBrowserHelper;

import org.apache.sling.api.resource.ValueMap;

/**
 * Featured Content WCMUsePojo.
 */
public class FeaturedContent extends WCMUsePojo {

  private String image;

  private String layout;

  private String expandedCta2Url;

  private String expandedCta1Url;

  private String expandedImage;

  private String expandedHeadline;

  private String expandedDescription;

  private String expandedCta1Title;

  private String expandedCta2Title;

  private String condensedCta2Url;

  private String condensedCta1Url;

  private String condensedImage;

  private String condensedHeadline;

  private String condensedDescription;

  private String condensedCta1Title;

  private String condensedCta2Title;

  @Override
  public void activate() {

    ValueMap properties = getProperties();
    image = properties.get("image", "");
    layout = properties.get("layout", "");
    expandedCta2Url = properties.get("expanded_cta2_url", "");
    expandedCta2Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),expandedCta2Url);
    expandedCta1Url = properties.get("expanded_cta1_url", "");
    expandedCta1Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),expandedCta1Url);
    expandedImage = properties.get("expanded_image", "");
    expandedHeadline = properties.get("expanded_headline", "");
    expandedDescription = properties.get("expanded_description", "");
    expandedCta1Title = properties.get("expanded_cta1_title", "");
    expandedCta2Title = properties.get("expanded_cta2_title", "");
    condensedCta2Url = properties.get("condensed_cta2_url", "");
    condensedCta2Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),condensedCta2Url);
    condensedCta1Url = properties.get("condensed_cta1_url", "");
    condensedCta1Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),condensedCta1Url);
    condensedImage = properties.get("condensed_image", "");
    condensedHeadline = properties.get("condensed_headline", "");
    condensedDescription = properties.get("condensed_description", "");
    condensedCta1Title = properties.get("condensed_cta1_title", "");
    condensedCta2Title = properties.get("condensed_cta2_title", "");
  }

  public String getImage() {
    return image;
  }

  public String getLayout() {
    return layout;
  }

  public String getExpandedCta2Url() {
    return expandedCta2Url;
  }

  public String getExpandedCta1Url() {
    return expandedCta1Url;
  }

  public String getExpandedImage() {
    return expandedImage;
  }

  public String getExpandedHeadline() {
    return expandedHeadline;
  }

  public String getExpandedDescription() {
    return expandedDescription;
  }

  public String getExpandedCta1Title() {
    return expandedCta1Title;
  }

  public String getExpandedCta2Title() {
    return expandedCta2Title;
  }

  public String getCondensedCta2Url() {
    return condensedCta2Url;
  }

  public String getCondensedCta1Url() {
    return condensedCta1Url;
  }

  public String getCondensedImage() {
    return condensedImage;
  }

  public String getCondensedHeadline() {
    return condensedHeadline;
  }

  public String getCondensedDescription() {
    return condensedDescription;
  }

  public String getCondensedCta1Title() {
    return condensedCta1Title;
  }

  public String getCondensedCta2Title() {
    return condensedCta2Title;
  }

}
