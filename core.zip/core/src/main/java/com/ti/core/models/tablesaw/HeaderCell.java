/**
 *
 */
package com.ti.core.models.tablesaw;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * @author Andy
 *
 */
@Model(adaptables = Resource.class)
public class HeaderCell {

    @ValueMapValue
    @Optional
    @Default(values = StringUtils.EMPTY)
    private String title;

    @ValueMapValue
    @Optional
    @Default(longValues = 1)
    private long colspan;

    @Self
    private Resource resource;

    private String name;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getColspan() {
        return colspan;
    }

    public void setColspan(long colspan) {
        this.colspan = colspan;
    }

    public String getName() {
        if (resource != null) {
            return resource.getName();
        } else {
            return this.name;
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }
}
