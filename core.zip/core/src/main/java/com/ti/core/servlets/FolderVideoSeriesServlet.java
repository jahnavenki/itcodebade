package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.SightlyWCMMode;
import com.day.cq.replication.ReplicationStatus;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.ReportingUtils;

@Component(service = Servlet.class, immediate=true, property = {
	SLING_SERVLET_PATHS + "=/bin/ti/folder/video-series",
	SLING_SERVLET_METHODS + "=GET" })
public class FolderVideoSeriesServlet extends SlingSafeMethodsServlet {
	protected static final Logger log = LoggerFactory.getLogger(FolderVideoSeriesServlet.class);

	@Reference
	private transient WCMComponents wcmService;

	private transient SightlyWCMMode wcmMode;

	private transient ResourceResolver resourceResolver;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		try {
			resourceResolver = request.getResourceResolver();
			final var session = resourceResolver.adaptTo(Session.class);
			wcmMode = new SightlyWCMMode(request);
			final var resultQuery = request.getParameter("result");
			var limit = Integer.MAX_VALUE;
			if (StringUtils.isNotEmpty(resultQuery)) {
				limit = Integer.parseInt(resultQuery);
			}
			var languageQuery = request.getParameter("language");
			if (StringUtils.isEmpty(languageQuery)) {
				languageQuery = "en,cn,jp";
			}
			final var fmQuery = request.getParameter("fm");
			final var foldertypeQuery = request.getParameter("foldertype");
			final var locales =
				Stream.of(languageQuery.split(","))
				.map(String::trim)
				.map(this::localeFromLanguage)
				.filter(StringUtils::isNotEmpty)
				.distinct()
				.collect(Collectors.toList());
			final var jsonCourses = new JSONArray();
			var i = 0;
			for( final var locale : locales ) {
				final var query = "select parent.* from [cq:Page] as parent inner join [nt:unstructured] as child on ischildnode(child,parent) where child.[cq:template] = '/conf/ti/settings/wcm/templates/video-series-page-template' and isdescendantnode(parent, '/content/texas-instruments/" + locale + "/video/series')";
				final var nodeIter = ReportingUtils.executeQuery(query, session);
				while (null != nodeIter && nodeIter.hasNext()) {
					if (i >= limit) {
						break;
					}
					final var node = nodeIter.nextNode();
					final var jsonObj = getJson(node.getPath(), fmQuery, foldertypeQuery);
					if (null != jsonObj) {
						jsonCourses.put(jsonObj);
						++i;
					}
				}
			}
			final var jsonResponse = new JSONObject();
			jsonResponse.put("courses", jsonCourses);
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			jsonResponse.write(response.getWriter());
		} catch (Exception ex) {
			log.error( "Exception", ex );
		}
	}

	private boolean isPublished( Resource resource ) {
		if (wcmMode.isDisabled()) {
			return true;
		}
		final ReplicationStatus replicationStatus = resource.adaptTo(ReplicationStatus.class);
		return null != replicationStatus && replicationStatus.isActivated();
	}

	private JSONObject getJson( String path, String fmQuery, String foldertypeQuery ) throws JSONException, RepositoryException {
		final var pageRes = resourceResolver.getResource(path);
		if (null == pageRes) {
			return null;
		}
		if (!isPublished(pageRes)) {
			return null;
		}
		final var contentRes = resourceResolver.getResource(pageRes, "jcr:content");
		if (null == contentRes) {
			return null;
		}
		final var titleRes = resourceResolver.getResource(contentRes, "videoTitleAndDescription");
		if (null == titleRes) {
			return null;
		}
		final var language = videoSpokenLanguageFromPath(path);
		final var contentMap = contentRes.getValueMap();
		final var titleMap = titleRes.getValueMap();
		var tagField = "";
		if ("product_tree".equalsIgnoreCase(foldertypeQuery)) {
			tagField = "gpt";
		} else if ("applications_designs_tree".equalsIgnoreCase(foldertypeQuery)) {
			tagField = "mse";
		} else if ("tools_software_tree".equalsIgnoreCase(foldertypeQuery)) {
			tagField = "emsg";
		} else if ("other_content_tree".equalsIgnoreCase(foldertypeQuery)) {
			tagField = "other";
		}
		if (StringUtils.isNotEmpty(tagField) && StringUtils.isNotEmpty(fmQuery)) {
			final var tagNames = getTagNames(contentMap.get(tagField, String[].class));
			if (tagNames.stream().noneMatch(t -> t.equalsIgnoreCase(fmQuery))) {
				return null;
			}
		}
		final var tagNamesGpt = getTagNames(contentMap.get("gpt", String[].class));
		final var tagNamesMse = getTagNames(contentMap.get("mse", String[].class));
		final var tagNamesEmsg = getTagNames(contentMap.get("emsg", String[].class));
		final var tagNamesOther = getTagNames(contentMap.get("other", String[].class));
		final var foldertype = new ArrayList<String>();
		final var allTagNames = new ArrayList<String>();
		if (!tagNamesGpt.isEmpty()) {
			foldertype.add("product_tree");
			allTagNames.addAll(tagNamesGpt);
		}
		if (!tagNamesMse.isEmpty()) {
			foldertype.add("applications_designs_tree");
			allTagNames.addAll(tagNamesMse);
		}
		if (!tagNamesEmsg.isEmpty()) {
			foldertype.add("tools_software_tree");
			allTagNames.addAll(tagNamesEmsg);
		}
		if (!tagNamesOther.isEmpty()) {
			foldertype.add("other_content_tree");
			allTagNames.addAll(tagNamesOther);
		}
		final var jsonObj = new JSONObject();
		jsonObj.put("title", titleMap.get("title", ""));
		jsonObj.put("created", contentMap.get("jcr:created", ""));
		jsonObj.put("url", PathBrowserHelper.addHtmlIfContentPath(resourceResolver, path));
		jsonObj.put("short_description", titleMap.get("description", ""));
		jsonObj.put("foldertype", String.join(",", foldertype));
		jsonObj.put("foldervalue", String.join(",", allTagNames));
		jsonObj.put("product_tree_id", tagNamesGpt);
		jsonObj.put("applications_designs_tree_id", tagNamesMse);
		jsonObj.put("tools_software_tree_id", tagNamesEmsg);
		jsonObj.put("other_content_tree_id", tagNamesOther);
		jsonObj.put("language", language);
		return jsonObj;
	}

	private List<String> getTagNames(String[] tags) {
		final var tagNames = new ArrayList<String>();
		if (null == tags) return tagNames;
		for (final var t : tags) {
			final var tagParts = t.split("/");
			final var tagName = tagParts[tagParts.length - 1];
			tagNames.add(tagName);
		}
		return tagNames;
	}

	private static final Pattern patternLocale = Pattern.compile( "^[a-z]{2}-[a-z]{2}$", Pattern.CASE_INSENSITIVE );
	private String localeFromLanguage(String language) {
		if (patternLocale.matcher(language).find()) {
			return language.toLowerCase();
		}
		if ("en".equalsIgnoreCase(language)) {
			return "en-us";
		}
		if ("ja".equalsIgnoreCase(language)) {
			return "ja-jp";
		}
		if ("ko".equalsIgnoreCase(language)) {
			return "ko-kr";
		}
		if ("de".equalsIgnoreCase(language)) {
			return "de-de";
		}
		return "";
	}

	private String videoSpokenLanguageFromLocale(String locale) {
		if ("en-us".equalsIgnoreCase(locale)) {
			return "en";
		}
		if ("zh-cn".equalsIgnoreCase(locale)) {
			return "zh-cn";
		}
		if ("zh-tw".equalsIgnoreCase(locale)) {
			return "zh-tw";
		}
		if ("ja-jp".equalsIgnoreCase(locale)) {
			return "ja";
		}
		if ("ko-kr".equalsIgnoreCase(locale)) {
			return "ko";
		}
		if ("de-de".equalsIgnoreCase(locale)) {
			return "de";
		}
		if ("es-mx".equalsIgnoreCase(locale)) {
			return "es-mx";
		}
		return "en";
	}

	private static final Pattern PATH_LOCALE = Pattern.compile("^/content/texas-instruments/([^/]+)/", Pattern.CASE_INSENSITIVE);
	private String videoSpokenLanguageFromPath(String path) {
		final var matcher = PATH_LOCALE.matcher(path);
		String locale;
		if (matcher.find()) {
			locale = matcher.group(1);
		} else {
			locale = "en-us";
		}
		return videoSpokenLanguageFromLocale(locale);
	}
}
