package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.util.PathBrowserHelper;

import org.apache.sling.api.resource.ValueMap;

/**
 * Featured Product WCMUsePojo.
 */
public class FeaturedProduct extends WCMUsePojo {

	private String partUrl;

	private String productGPNName;

	private String description;

	private String onlinedatasheet;

	private String downloaddatasheet;

	private String evaluationmodule;

	private String toolssoftware;

	private String referencedesigns;

	private String cta1title;

	private String cta1Url;

	private String cta2title;

	private String cta2Url;

	private String cta3title;

	private String cta3Url;

	private String ordernowUrl;

	private String textLinkCTA;

	private String textLinkCTAURL;

	@Override
	public void activate() {

		ValueMap properties = getProperties();

		partUrl = properties.get("partURL", "");
		partUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),partUrl);

		productGPNName = properties.get("productGPNName", "");

		description = properties.get("description", "");

		onlinedatasheet = properties.get("onlinedatasheet", "");
		onlinedatasheet = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),onlinedatasheet);

		downloaddatasheet = properties.get("downloaddatasheet", "");
		downloaddatasheet = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),downloaddatasheet);

		evaluationmodule = properties.get("evaluationmodule", "");
		evaluationmodule = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),evaluationmodule);

		toolssoftware = properties.get("toolssoftware", "");
		toolssoftware = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),toolssoftware);

		referencedesigns = properties.get("referencedesigns", "");
		referencedesigns = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),referencedesigns);

		cta1title = properties.get("cta1title", "");

		cta1Url = properties.get("cta1URL", "");
		cta1Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),cta1Url);

		cta2title = properties.get("cta2title", "");

		cta2Url = properties.get("cta2URL", "");
		cta2Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),cta2Url);

		cta3title = properties.get("cta3title", "");

		cta3Url = properties.get("cta3URL", "");
		cta3Url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),cta3Url);

		ordernowUrl = properties.get("ordernowURL", "");
		ordernowUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),ordernowUrl);
		
		textLinkCTA = properties.get("textLinkCTA", "");
		
		textLinkCTAURL = properties.get("textLinkCTAURL", "");
		textLinkCTAURL = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),textLinkCTAURL);
	}

	public String getPartUrl() {
		return partUrl;
	}

	public String getProductGPNName() {
		return productGPNName;
	}

	public String getDescription() {
		return description;
	}

	public String getOnlinedatasheet() {
		return onlinedatasheet;
	}

	public String getDownloaddatasheet() {
		return downloaddatasheet;
	}

	public String getEvaluationmodule() {
		return evaluationmodule;
	}

	public String getToolssoftware() {
		return toolssoftware;
	}

	public String getReferencedesigns() {
		return referencedesigns;
	}

	public String getCta1title() {
		return cta1title;
	}

	public String getCta1Url() {
		return cta1Url;
	}

	public String getCta2title() {
		return cta2title;
	}

	public String getCta2Url() {
		return cta2Url;
	}

	public String getCta3title() {
		return cta3title;
	}

	public String getCta3Url() {
		return cta3Url;
	}

	public String getOrdernowUrl() {
		return ordernowUrl;
	}

	public String getTextLinkCTA() {
		return textLinkCTA;
	}

	public String getTextLinkCTAURL() {
		return textLinkCTAURL;
	}

}
