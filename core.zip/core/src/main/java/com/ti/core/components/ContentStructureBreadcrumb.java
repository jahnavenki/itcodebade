package com.ti.core.components;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.models.BreadcrumbLink;
import com.ti.core.service.BreadcrumbConfigService;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.util.PathBrowserHelper;

/**
 * The Class ContentStructureBreadcrumb.
 */
public class ContentStructureBreadcrumb extends WCMUsePojo {
	private static final String LINK = "link";
	private static final String LABEL = "label";

	private static final String AUTHORED_LIST = "authoredList";
	private static final String USE_AUTHORED_VALUE = "useAuthoredValue";
	private static final String HIDE_IN_NAV = "hideInNav";
	private static final String CQ_TEMPLATE = "cq:template";
	private String webSite = null;
	private String componentName;
	private static final String TEMPLATE_HOME_PAGE = "/apps/ti/templates/homePage";
	private static final String ROOT_PATH = "/";
	private static final Set<String> languagelist = new HashSet<>(Arrays.asList("JP", "KR", "DE", "RU", "MX", "TW"));
	private static final String EXCEPTION_MESSAGE = "Exception: ";
	/**
	 * The log.
	 */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String DASH = "-";
	private static final String HTTPS = "https://";
	private transient ResourceResolver resourceResolver;
	private boolean breadcrumballlevel = false;
	private static final String TI_STORE = "ordering-resources";
	private static final String DESIGN_RESOURCES = "/design-resources";
	private static final String TECH = "/technologies";
	/**
	 * The bread crumb links.
	 */
	List<BreadcrumbLink> breadCrumbLinks = new ArrayList<>();

	/*
	 * (non-Javadoc)
	 *
	 * @see com.adobe.cq.sightly.WCMUsePojo#activate()
	 */
	@Override
	public void activate() {
		try {

			log.debug(" Inside activate ");
			Resource resource = this.getResource();
			String componentPath = resource.getPath();
			resourceResolver = this.getRequest().getResourceResolver();
			log.debug("componentPath {} " ,componentPath);
			setComponentName(componentPath.substring(componentPath.lastIndexOf("/") + 1, componentPath.length()));

			Boolean isAuthorList = getProperties().get(USE_AUTHORED_VALUE, Boolean.class);
			BreadcrumbConfigService breadcrumbService = getSlingScriptHelper()
					.getService(BreadcrumbConfigService.class);
			if (breadcrumbService == null)
				log.debug("Breadcrumb: could not get breadcrumbService");
			if (isAuthorList != null && isAuthorList.booleanValue()) {
				for (Resource nodeChild : getResource().getChildren()) {
					if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(AUTHORED_LIST)) {
						for (Resource breadcrumbRes : nodeChild.getChildren()) {
							ValueMap properties = breadcrumbRes.adaptTo(ValueMap.class);
							if (null != properties) {
								BreadcrumbLink breadcrumb = new BreadcrumbLink();
								String link = getLinkWithExtension(properties.get(LINK, String.class));
								breadcrumb.setLink(link);
								breadcrumb.setTitle(properties.get(LABEL, String.class));
								breadCrumbLinks.add(breadcrumb);
							}
						}
					}
				}
				log.debug("authored breadcrumb");
				buildWebSite(true, breadCrumbLinks, breadcrumbService);
			} else {
				log.debug("generated breadcrumb");

				Page page = this.getCurrentPage();
				if (page != null && StringUtils.contains(page.getPath(), TECH)) {
					breadcrumballlevel = true;
				}

				if (breadcrumballlevel) {
					buildbreadcrumbforalllevels(false, breadCrumbLinks, breadcrumbService);
				} else {

					buildWebSite(false, breadCrumbLinks, breadcrumbService);
				}
				Collections.reverse(breadCrumbLinks);
			}

		} catch (Exception e) {
			log.error("Could not create breadcrumb: ", e);
		}
	}

	/**
	 * Method to get the breadcrumb links.
	 *
	 * @return List of links
	 */
	public List<BreadcrumbLink> getBreadcrumbLinks() {

		return breadCrumbLinks;
	}

	/**
	 * Method to adapt a page into a BreadcrumbLink object.
	 *
	 * @param page Actual Page
	 * @return BreadcrumbLink object
	 */
	private BreadcrumbLink getBreadcrumbLinkFromPage(BreadcrumbConfigService breadcrumbService, Page page,
			String language) {

		log.debug("getBreadcrumbLinkFromPage: {}", page.getPath());
		BreadcrumbLink breadcrumb = new BreadcrumbLink();
		String link = null;
		Boolean hideInNav = null;
		isbreadcrumballlevel(breadcrumbService);
		log.debug("isbreadcrumballlevel {} ", breadcrumballlevel);
		if (breadcrumballlevel) {
			hideInNav = page.getProperties().get(HIDE_IN_NAV, Boolean.class);
			log.debug("hideInNav {} ", hideInNav);
			if (hideInNav != null && hideInNav.booleanValue()) {
				// do nothing
			} else {
				link = getLinkWithExtension(page.getPath());
			}
		} else {
			if (page.getPath().contains(DESIGN_RESOURCES)) {
				link = buildbreadcrumbfordesignResources(breadcrumbService, language, page);
			} else {
				link = buildbreadcrumb(breadcrumbService, language);
			}
		}
		if (null != link) {
			breadcrumb.setLink(link);
			log.debug(" Link: {} ", breadcrumb.getLink());
		}
		if (null != page.getNavigationTitle()) {
			breadcrumb.setTitle(page.getNavigationTitle());
		} else {
			breadcrumb.setTitle(page.getTitle()); // nav title is empty for few
			// tools and s/w
		}
		log.debug(" title: {}", breadcrumb.getTitle());

		return breadcrumb;
	}

	private String getLinkWithExtension(String link) {
		return PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), link);
	}

	private void buildWebSite(boolean useAuthoredValue, List<BreadcrumbLink> bcLinks,
			BreadcrumbConfigService breadcrumbService) {
		Page currentPage = this.getCurrentPage();
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);

		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String template = "";
		Boolean hideInNav;

		String language = null, languageCode = null;
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);

		if (breadcrumbService == null)
			log.error("Breadcrumb: could not get breadcrumbService");

		if (null != tabsService) {
			language = tabsService.getPageLanguage(getCurrentPage());
			languageCode = StringUtils.substringAfter(language, DASH);
		}

		do {

			if (currentPage != null) {
				log.debug("curren page is not null: {}  ", currentPage.getPath());
				hideInNav = currentPage.getProperties().get(HIDE_IN_NAV, Boolean.class);
				log.debug("hideInNav: {}", hideInNav);
				if (hideInNav != null && hideInNav.booleanValue()) {
					currentPage = currentPage.getParent();
					log.debug("Setting current page to parent in hideinNav");
					continue;
				}
			}
			if (currentPage == null) {
				this.webSite = ROOT_PATH;
				log.error("Current page is null cannot continue ");
				break;

			} else if (currentPage.getParent() != null) {
				if (!useAuthoredValue && !(TEMPLATE_HOME_PAGE.equals(currentPage.getProperties().get(CQ_TEMPLATE, ""))))
					bcLinks.add(getBreadcrumbLinkFromPage(breadcrumbService, currentPage, language));
				currentPage = currentPage.getParent();
			} else {
				break; // Use current page if no parent
			}

			template = currentPage.getProperties().get(CQ_TEMPLATE, "");
			 // if no template exit, set root, and report error
			if (StringUtils.isBlank(template)) {
				// unexpected
				this.webSite = ROOT_PATH;
				log.error("template for {} came up null, stopped walking up tree and set website root",
						currentPage.getPath());
				break;
			}

		} while (!TEMPLATE_HOME_PAGE.equals(template));

		try {
			if (null != languageCode && languagelist.contains(languageCode.toUpperCase())
					&& null != breadcrumbService) {
				buildtihome(breadcrumbService, language);
			} else {
				URI requestUrl = new URI(this.getRequest().getRequestURL().toString());
				URI targetUrl = new URI(requestUrl.getScheme(), domain, null, null);
				this.webSite = targetUrl.toString();
			}
			log.debug("website: {}", this.webSite);
		} catch (URISyntaxException ex) {
			log.error("Could not read uri from page request {}", this.getRequest().getRequestURI(), ex);
			this.webSite = ROOT_PATH;
		}

	}

	private void buildbreadcrumbforalllevels(boolean useAuthoredValue, List<BreadcrumbLink> bcLinks,
			BreadcrumbConfigService breadcrumbService) {
		Page currentPage = this.getCurrentPage();
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);

		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String template = "";
		String language = null, languageCode = null;
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);

		if (breadcrumbService == null)
			log.error("Breadcrumb: could not get breadcrumbService");

		if (null != tabsService) {
			language = tabsService.getPageLanguage(getCurrentPage());
			languageCode = StringUtils.substringAfter(language, DASH);
		}

		do {
			if (currentPage == null) {
				this.webSite = ROOT_PATH;
				log.error("Current page is null cannot continue ");
				break;
			} else if (currentPage.getParent() != null) {
				if (!useAuthoredValue && !(TEMPLATE_HOME_PAGE.equals(currentPage.getProperties().get(CQ_TEMPLATE, ""))))
					bcLinks.add(getBreadcrumbLinkFromPage(breadcrumbService, currentPage, language));
				currentPage = currentPage.getParent();
			} else {
				break; // Use current page if no parent
			}
			template = currentPage.getProperties().get(CQ_TEMPLATE, "");
			// if no template exit, set root, and report error
			if (StringUtils.isBlank(template)) {
				// unexpected
				this.webSite = ROOT_PATH;
				log.error("template for {} came up null, stopped walking up tree and set website root",
						currentPage.getPath());
				break;
			}

		} while (!TEMPLATE_HOME_PAGE.equals(template));

		try {
			if (null != languageCode && languagelist.contains(languageCode.toUpperCase())
					&& null != breadcrumbService) {
				buildtihome(breadcrumbService, language);
			} else {
				URI requestUrl = new URI(this.getRequest().getRequestURL().toString());
				URI targetUrl = new URI(requestUrl.getScheme(), domain, null, null);
				this.webSite = targetUrl.toString();
			}
			log.debug("website: {}", this.webSite);
		} catch (URISyntaxException ex) {
			log.error("Could not read uri from page request {}", this.getRequest().getRequestURI(), ex);
			this.webSite = ROOT_PATH;
		}

	}

	private void buildtihome(BreadcrumbConfigService breadcrumbService, String languageCode) {
		Page currentPage = this.getCurrentPage();

		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);

		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String homepageconfig = breadcrumbService.gethomepageurl();
		log.debug("homepageconfig: {}", homepageconfig);
		String[] homepageArray = StringUtils.split(homepageconfig, ",");
		String homepageURL = null;
		for (int i = 0; i < homepageArray.length; i++) {
			if (StringUtils.equalsIgnoreCase(languageCode,
					StringUtils.substringBefore(StringUtils.trim(homepageArray[i]), "|"))) {
				homepageURL = HTTPS.concat(domain)
						.concat(StringUtils.substringAfter(StringUtils.trim(homepageArray[i]), "|"));

				log.debug("home page url: {} ", homepageURL);
			}

		}

		this.webSite = homepageURL;

	}

	private String buildbreadcrumb(BreadcrumbConfigService breadcrumbService, String languageCode) {
		Page currentPage = this.getCurrentPage();
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String breadcrumburlconfig = breadcrumbService.getBreadcrumburl();
		log.debug("breadcrumburlconfig: {}", breadcrumburlconfig);
		String[] breadcrumburlArray = StringUtils.split(breadcrumburlconfig, ",");
		String breadcrumburl = null;
		String folder = StringUtils.substringAfter(currentPage.getPath(), languageCode);
		String[] rootFamily = folder.split("/");
		String aemFolder = rootFamily[1].trim();

		for (int i = 0; i < breadcrumburlArray.length; i++) {
			if (StringUtils.equalsIgnoreCase(aemFolder, "store")) {
				aemFolder = TI_STORE;
			}
			if (breadcrumburlArray[i].contains(aemFolder)) {
				if ("en-us".equals(languageCode)) {
					breadcrumburl = HTTPS.concat(domain).concat(breadcrumburlArray[i]);
				} else {
					breadcrumburl = HTTPS.concat(domain) + "/" + languageCode + breadcrumburlArray[i];
				}

				log.debug("Breadcrumb url: {}", breadcrumburl);
			}

		}
		return breadcrumburl;

	}

	private String buildbreadcrumbfordesignResources(BreadcrumbConfigService breadcrumbService, String languageCode,
			Page currentPage) {

		log.debug("page name {} ", currentPage.getName());
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String breadcrumburlconfig = breadcrumbService.getDesignbreadcrumburl();
		log.debug("breadcrumburlconfig: {}", breadcrumburlconfig);
		String[] breadcrumburlArray = StringUtils.split(breadcrumburlconfig, ",");
		String breadcrumburl = null;
		Resource pageResource = resourceResolver.getResource(currentPage.getPath());
		Node pageNode = null;
		String pageNodeName = null;
		if (null != pageResource) {
			pageNode = pageResource.adaptTo(Node.class);
			if (null != pageNode) {
				try {
					pageNodeName = pageNode.getName();
				} catch (RepositoryException e) {
					log.error(EXCEPTION_MESSAGE, e);
				}
			}

		}

		for (int i = 0; i < breadcrumburlArray.length; i++) {
			String[] breadcrumburlArr = StringUtils.split(breadcrumburlArray[i], "|");
			if (null != breadcrumburlArr) {
				log.debug("breadcrumb array values and pageNode Name {} --- {} ", breadcrumburlArr[0], pageNodeName);
				if (breadcrumburlArr[0].contains(pageNodeName)) {

					if ("en-us".equals(languageCode)) {
						breadcrumburl = HTTPS.concat(domain).concat(breadcrumburlArr[1]);
					} else {
						breadcrumburl = HTTPS.concat(domain) + "/" + languageCode + breadcrumburlArr[1];
					}

					log.debug("Breadcrumb url for designresources: {}", breadcrumburl);
					return breadcrumburl;
				}

			}
		}

		return breadcrumburl;

	}

	private void isbreadcrumballlevel(BreadcrumbConfigService breadcrumbService) {
		Page currentPage = this.getCurrentPage();
		String breadcrumbtype = breadcrumbService.getBreadcrumbtype();
		String[] breadcrumbtypeArray = StringUtils.split(breadcrumbtype, ",");

		for (int i = 0; i < breadcrumbtypeArray.length; i++) {
			if (currentPage.getPath().contains(breadcrumbtypeArray[i])) {
				breadcrumballlevel = true;
			}

		}
	}

	public String getWebSite() {
		return this.webSite;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

}