package com.ti.core.service;

/**
 * Service Interface to interact with WCM Components service.
 * 
 * @author Andy Doerr
 */
public interface GeneralConfig {

	/**
	 * Returns the configured path to content fragments
	 * @return
	 */
	public String getTIContentFragmentPath();
	
	/**
	 * Returns the configured path to images.
	 * @return
	 */
	public String getTIDamImagesPath();

}