package com.ti.core.service.workflow;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.tagging.Tag;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
    Constants.SERVICE_DESCRIPTION + "=Workflow step to import associations.",
    Constants.SERVICE_VENDOR + "=TI",
    "process.label=TI: Import Associations Tags" })
public class ImportAssociationsTagsProcessStep implements WorkflowProcess {
    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference
    private WCMComponents wcmService;
    @Reference
	private VideoConfigService videoService;

    private String videoPath;

    private ResourceResolver resourceResolver;

    private final Map<String, Tag> productMap = new HashMap<>();
    private final Map<String, Tag> marketMap = new HashMap<>();
    private final Map<String, Tag> toolMap = new HashMap<>();
    private final DataFormatter dataFormatter = new DataFormatter();

    @Override
    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
        try {
            videoPath = videoService.getVideoPath();
            if (videoPath == null || videoPath.length() <= 0) {
                log.error("Error occurred in ImportAssociationsTagsProcessStep - Video path not found in the config");
                return;
            }
            final var workflowData = item.getWorkflowData();
            final var payload = workflowData.getPayload().toString();
            resourceResolver = session.adaptTo(ResourceResolver.class);
            if (null == resourceResolver) throw new NullPointerException("resourceResolver");
            // payload should be spreadsheet
            Resource resource = resourceResolver.getResource(payload);
            // if resource is null end it
            if (null == resource) return;
            // convert spreadsheet to input stream
            InputStream stream = resourceToInputStream(resource);
            // iterate through data and import 
            processData(stream);
            // need this to save all changes
            resourceResolver.commit();
        } catch (Exception e) {
            log.error("Error occurred in ImportAssociationsTagsProcessStep", e);
        }
    }

    // gets resource and converts to input stream
    private InputStream resourceToInputStream(Resource resource) {
        try {
            Asset asset = resource.adaptTo(Asset.class);
            InputStream stream = null;
            if(asset != null) {
                Rendition original = asset.getOriginal();
                if(original !=null) {
                    stream = original.getStream();
                }
            }
            return stream;
        } catch (Exception e) {
            log.error("Error occurred in ImportAssociationsTagsProcessStep resourceToInputStream", e);
        }
        return null;
    }

    private void loadMap(Resource res, Map<String, Tag> map) {
        final var tag = res.adaptTo(Tag.class);
        if (null != tag) {
            final var name = res.getName();
            if (map.containsKey(name)) {
                log.warn("Duplicate key: {} at {}", name, res.getPath());
            }
            map.put(name, tag);
        }
        for (final var child : res.getChildren()) {
            loadMap(child, map);
        }
    }

    // iterates through data
    // calls function to construct string with full tree path
    // sets values to video metadata
    private void processData(InputStream stream) {
        loadMap(resourceResolver.resolve("/content/cq:tags/imported/products"), productMap);
        log.debug("productMap loaded {} entries", productMap.size());
        loadMap(resourceResolver.resolve("/content/cq:tags/imported/markets"), marketMap);
        log.debug("marketMap loaded {} entries", marketMap.size());
        loadMap(resourceResolver.resolve("/content/cq:tags/imported/tools"), toolMap);
        log.debug("toolMap loaded {} entries", toolMap.size());
        try (XSSFWorkbook workbook = new XSSFWorkbook(stream)) {
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                processRow(row);
            } // end while
        } catch (Exception e) {
            log.error("Error occurred in ImportAssociationsTagsProcessStep processData", e);
        }
    }

    private String getCellValue(Row row, int cellNum) {
        final var cell = row.getCell(cellNum);
        if (null == cell) return "";
        var cellValue = dataFormatter.formatCellValue(cell);
        if (StringUtils.isBlank(cellValue)) return "";
        return cellValue;
    }
    
    private void processRow(Row row) {
        String videoId = StringUtils.EMPTY;
        if (row.getCell(0) != null) {
            videoId  = dataFormatter.formatCellValue(row.getCell(0));
        }
        Resource videoResource =  AssetUtils.getDamResource(resourceResolver, videoPath, videoId);
        // check we have the video resource
        if (videoResource == null) {
            log.debug("Video {} not found",videoId);
            return;
        }
        // if resource not null, get association tab values
        log.debug("processing videoid: {}",videoId);
        //
        // cell 7 - Product Tree
        // cell 9 - Applications & Designs Tree
        // cell 11 - Tools & Software Tree   
        // cell 13 - dc:title
        int colProd = 6;
        int colApp = 8;
        int colTool = 10;
        int colTitle = 12;
        if (StringUtils.isBlank(getCellValue(row, colTitle))) {
            return;
        }

        final var prods = getCellValue(row, colProd).split("\\|");
        final var apps = getCellValue(row, colApp).split("\\|");
        final var tools = getCellValue(row, colTool).split("\\|");
        
        List<String> prodList =
            Stream.of(prods)
            .filter(StringUtils::isNotBlank)
            .map(p -> productMap.getOrDefault(p, null))
            .filter(Objects::nonNull)
            .map(Tag::getTagID)
            .collect(Collectors.toList());
        List<String> appsList =
            Stream.of(apps)
            .filter(StringUtils::isNotBlank)
            .map(p -> marketMap.getOrDefault(p, null))
            .filter(Objects::nonNull)
            .map(Tag::getTagID)
            .collect(Collectors.toList());
        List<String> toolsList =
            Stream.of(tools)
            .filter(StringUtils::isNotBlank)
            .map(p -> toolMap.getOrDefault(p, null))
            .filter(Objects::nonNull)
            .map(Tag::getTagID)
            .collect(Collectors.toList());

        setAssociationTags(videoResource, prodList.toArray(new String[0]), appsList.toArray(new String[0]), toolsList.toArray(new String[0]));
    }

    private void setAssociationTags(Resource  videoResource, String[] prods, String[] apps,  String[] tools) {
        ModifiableValueMap metaDataMap = AssetUtils.getModifiableMetadata(videoResource);
        // set values (these values are the text coming from cells, we still need to get ids)
        if (!ArrayUtils.isEmpty(prods)) {
            metaDataMap.put("dam:tagsProducts", prods);
        }    
        if (!ArrayUtils.isEmpty(apps)) {
            metaDataMap.put("dam:tagsApplications", apps);
        }    
        if (!ArrayUtils.isEmpty(tools)) {
            metaDataMap.put("dam:tagsTools", tools);
        }    
    }
}
