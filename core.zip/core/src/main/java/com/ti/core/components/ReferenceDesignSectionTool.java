package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * ReferenceDesignSectionTool
 *
 */
public class ReferenceDesignSectionTool extends WCMUsePojo {

	private String applId;

	public String getApplId() {
		return applId;
	}

	public void setApplId(String applId) {
		this.applId = applId;
	}

	@Override
	public void activate() throws Exception {
		String marketId = getCurrentPage().getProperties().get("marketId", String.class);
		String sectorId = getCurrentPage().getProperties().get("sectorId", String.class);
		String categoryId = getCurrentPage().getProperties().get("categoryId", String.class);
		StringBuilder applicationId = new StringBuilder();

		if (null != marketId) {
			applicationId.append(marketId);
			if (null != sectorId) {
				applicationId.append("," + sectorId);
				if (null != categoryId) {
					applicationId.append("," + categoryId);
				}
			}
			this.applId = applicationId.toString();
		}
	}
}
