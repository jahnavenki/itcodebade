package com.ti.core.components.models;

import com.day.cq.wcm.api.Page;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.ti.core.service.ProductNavigationTabsOrdering;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class EventFilter {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@SlingObject
	private Resource currentResource;

	@ScriptVariable
	private Page currentPage;

    @OSGiService
	ProductNavigationTabsOrdering productNavigationTabsOrdering;

    private String lang;

    @ValueMapValue
	private List<String> xpPaths;

    private List<String> eventType = new ArrayList<>();

    private List<String> location = new ArrayList<>();

    private List<String> language = new ArrayList<>();

    @SlingObject
    private ResourceResolver resourceResolver;

    public List<String> getEventType() {
        return eventType;
    }

    public List<String> getLocation() {
        return location;
    }

    public List<String> getLanguage() {
        return language;
    }
	

	@PostConstruct
	public void init() {
		try {
            // Gets page's language
            if(null == currentPage){
				lang = "en-us";
			}
			else{
				lang = productNavigationTabsOrdering.getPageLanguage(currentPage);
                if(lang == null){
				    lang = "en-us";
			    }
			}

            // Gets paths of events from EventListing component
            final var eventListingResource = findResourceByType(currentPage.getContentResource(), "ti/components/eventListing");
			xpPaths = findXpPaths(eventListingResource.getChild("eventListingLinks"));

            // Gets tags from event components
            for(String i : xpPaths){
                
                final var event = Event.findResource(resourceResolver.getResource(i + "/jcr:content"));
                
                eventType.add(getTagTitle(event.getValueMap().get("eventType", String.class)));
                location.add(getTagTitle(event.getValueMap().get("region", String.class)));
                language.add(getTagTitle(event.getValueMap().get("language", String.class)));
            }

            eventType = formatTags(eventType);
            location = formatTags(location);
            language = formatTags(language);
		} catch(Exception ex) {
			log.error("Exception in EventFilter", ex);
		}
	}

    private static List<String> formatTags(List<String> tags){
        tags = tags.stream().distinct().collect(Collectors.toList());
        Collections.sort(tags);

        return tags;
    }

    private static Resource findResourceByType(Resource resource, String resourceType) {
		final var valueMap = resource.getValueMap();
		final var type = valueMap.get("sling:resourceType");
		if (resourceType.equals(type)) return resource;
		for (final var child : resource.getChildren()) {
			final var descendant = findResourceByType(child, resourceType);
			if (null != descendant) return descendant;
		}
		return null;
	}

    private static List<String> findXpPaths(Resource resource){
        final List<String> paths = new ArrayList<String>();

        for (final var child : resource.getChildren()){
            paths.add(child.getValueMap().get("link").toString());
        }
        return paths;
    }

    private String getTagTitle(String tagId) {
        TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
        Tag tag = tagManager.resolve(tagId);

        if (tag != null) {
            Locale locale = java.util.Locale.forLanguageTag(lang); 
            if (!"en-us".equals(lang)) {
                String localizedTitle = tag.getLocalizedTitle(locale);
                if (StringUtils.isNotBlank(localizedTitle)) {
                    return localizedTitle;
                }
            }else{
                return tag.getTitle();
            }
        }

        return null;
    }
}
