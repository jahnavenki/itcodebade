package com.ti.core.service.workflow;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import javax.jcr.Node;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.tagging.TagManager;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set metadata fields in Brightcove tab.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Brightcove metadata fields" })
public class PopulateBrightcoveMetadataProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	private TagManager tagManager;
	private boolean is3playProcessed = false;

    private static final String BRC_CUSTOM_FIELDS = "brc_custom_fields";
    private static final String ERROR_MESSAGE = "Error occurred in PopulateBrightcoveMetadataProcessStep";
    private static final String ENGLISH_STRING = "en";
    private static final String CHINESE_STRING = "zh-cn";
    private static final String JAPANESE_STRING = "ja";

	@Reference
	private WCMComponents wcmService;

	private String tagProductToTicomid(String tagProduct) {
		var tag = tagManager.resolve(tagProduct);
		var subtags = tag.listAllSubTags();
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return ( subtags.hasNext() ? "fm_" : "gp_" ) + lastPart;
	}

	private String tagApplicationToTicomid(String tagApplication) {
		var tag = tagManager.resolve(tagApplication);
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return "eq_" + lastPart;
	}

	private String tagToolToTicomid(String tagTool) {
		var tag = tagManager.resolve(tagTool);
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return "tl_" + lastPart;
	}

	private String getTicomids(ValueMap map) {
		if (null == tagManager) throw new NullPointerException("tagManager");
		var tagsProducts = map.get("dam:tagsProducts", String[].class);
		if(null == tagsProducts) tagsProducts = new String[0];
		var tagsApplications = map.get("dam:tagsApplications", String[].class);
		if(null == tagsApplications) tagsApplications = new String[0];
		var tagsTools = map.get("dam:tagsTools", String[].class);
		if(null == tagsTools) tagsTools = new String[0];
		final var ticomids = new ArrayList<String>(tagsProducts.length + tagsApplications.length + tagsTools.length);
		for(final var tagProduct : tagsProducts) {
			ticomids.add(tagProductToTicomid(tagProduct));
		}
		for(final var tagApplication : tagsApplications) {
			ticomids.add(tagApplicationToTicomid(tagApplication));
		}
		for(final var tagTool : tagsTools) {
			ticomids.add(tagToolToTicomid(tagTool));
		}
		return String.join(",", ticomids);
	}

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final WorkflowData workflowData = item.getWorkflowData();
			final String payload = workflowData.getPayload().toString();
			if(!payload.endsWith(".mp4")) {
				session.terminateWorkflow(item.getWorkflow());
				return;
			}
			final ResourceResolver resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
				throw new NullPointerException("Resource Resolver");
			}
			final Resource resource = resourceResolver.getResource(payload);
			if (null == resource)
			{
				throw new NullPointerException("Resource " + payload);
			}
			final ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
			if (null == map) {
				throw new NullPointerException("Metadata map");
			}
			final ModifiableValueMap jcrMap = getModifiableData(resource);
			if (null == jcrMap) {
				throw new NullPointerException("Metadata jcrMap");
			}
			String videoStatus = map.get("dam:status","");
			if (videoStatus.equalsIgnoreCase("unpublished")) {
				session.terminateWorkflow(item.getWorkflow());
				return;
			}
			tagManager = resourceResolver.adaptTo(TagManager.class);

			// Set fields - "Text for related item" and "Link for related item"
            var ctaText = map.get("dam:cta1", "");
            map.put("brc_link_text", ctaText); // "Text for related item"
            var ctaUrl = map.get("dam:url1", "");
            map.put("brc_link_url", ctaUrl); // "Link for related item"
			var lastUpdatedDate=map.get("jcr:lastModified", "");
			map.put("brc_updated_at", lastUpdatedDate); // Last updated date
			var dateAcquired=map.get("jcr:created", "");
			map.put("brc_created_at", dateAcquired); // Created date
			Node brcCustomFieldsNode = getBrcCustomFieldsNode(resource);
			if (brcCustomFieldsNode == null) {
				return;
			}
			setBrightcoveCustomFields(brcCustomFieldsNode, map, resource);

			// Set duration - call to Brightcove API
			// Set this field last, so Brightcove has time to process video and give duration back
			int duration = 0;
			JSONObject jsonBrightCoveRespObject = null;
			String videoId = map.get("brc_id", String.class);
			if (StringUtils.isNotEmpty(videoId)) {
				// Make a call to Brightcove API to get duration
				jsonBrightCoveRespObject = wcmService.getBrightcoveVideoMetaData(videoId);
				if (jsonBrightCoveRespObject != null) {
					duration = jsonBrightCoveRespObject.getInt("duration");
				}
			}
			if (duration > 0) {
				String durationInHhMmSs = DurationFormatUtils.formatDuration(duration,"HH:mm:ss");
				map.put("brc_duration", durationInHhMmSs);
			}

			if (jsonBrightCoveRespObject != null) {
				JSONArray tagsFromBrightcove = jsonBrightCoveRespObject.getJSONArray("tags");
				is3playProcessed = check3playProcessed(tagsFromBrightcove);
			}

			if(is3playProcessed) {
				map.put("transcript", "yes");
			}

			final var tagValue = getTagValue(map);
			map.put("brc_tags", tagValue);

			final var tagsProducts = map.get("dam:tagsProducts", String[].class);
			final var tagsApplications = map.get("dam:tagsApplications", String[].class);
			final var tagsTools = map.get("dam:tagsTools", String[].class);

			map.put("dam:tagsProductsName", getTagPathNames(tagsProducts));
			map.put("dam:tagsApplicationsName", getTagPathNames(tagsApplications));
			map.put("dam:tagsToolsName", getTagPathNames(tagsTools));

			var tagsProductsPrimary = "";
			if (tagsProducts != null && tagsProducts.length > 0) {
				tagsProductsPrimary = tagsProducts[ 0 ];
			}
			map.put("dam:tagsProductsPrimary", tagsProductsPrimary);
			map.put("dam:tagsProductsPrimaryName", getTagPathName(tagsProductsPrimary));

			var tagsApplicationsPrimary = "";
			if (tagsApplications != null && tagsApplications.length > 0) {
				tagsApplicationsPrimary = tagsApplications[ 0 ];
			}
			map.put("dam:tagsApplicationsPrimary", tagsApplicationsPrimary);
			map.put("dam:tagsApplicationsPrimaryName", getTagPathName(tagsApplicationsPrimary));

			resourceResolver.commit();
		} catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
	}
	public static ModifiableValueMap getModifiableData(Resource res) {
    	if (res != null) {
    		Resource metadataNode = res.getChild("jcr:content");

    		if (metadataNode != null) {
    			return metadataNode.adaptTo(ModifiableValueMap.class);
			}
    	}
    	return (ModifiableValueMap) ValueMap.EMPTY;
	}
	private Node getBrcCustomFieldsNode(Resource resource) {
		Node brcCustomFieldsNode = null;
		try {
			Resource metadataRes = resource.getChild("jcr:content/metadata");
			if (metadataRes == null) {
				throw new NullPointerException("metadataNode is null");
			}
			Node metadataNode = metadataRes.adaptTo(Node.class);
			if (metadataNode == null) {
				throw new NullPointerException("metadataNode is null");
			}

			// Can't use metadata map here for fields under the folder 'brc_custom_fields'
			// because AEM doesn't create brc_custom_fields folder automatically
			// So create a folder 'brc_custom_fields' under metadata
			if (metadataNode.hasNode(BRC_CUSTOM_FIELDS)) {
				brcCustomFieldsNode = metadataNode.getNode(BRC_CUSTOM_FIELDS);
			} else {
				brcCustomFieldsNode = metadataNode.addNode(BRC_CUSTOM_FIELDS);
			}
		} catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
		return brcCustomFieldsNode;
	}

	private void setBrightcoveCustomFields(Node brcCustomFieldsNode, ModifiableValueMap map, Resource resource) {
		try {
			// set language
			final String language = map.get("videoSpokenLanguage", ENGLISH_STRING);
			brcCustomFieldsNode.setProperty("language", language.toUpperCase());

			// Set SiteCode
			var sitecode = "";
			if (ENGLISH_STRING.equals(language)) {
				sitecode = "EN, CN, JP";
			} else if (JAPANESE_STRING.equals(language)) {
				sitecode = "JP";
			} else if (CHINESE_STRING.equals(language)) {
				sitecode = "CN";
			}
			brcCustomFieldsNode.setProperty("sitecode", sitecode);

			// Set TICOMIDs
			final var languages = Set.of(ENGLISH_STRING, JAPANESE_STRING, CHINESE_STRING);
			var ticomids = "";
			if (languages.contains(language)) {
				ticomids = getTicomids(map);
			}
			brcCustomFieldsNode.setProperty("ticomids", ticomids);

			// Set uploader
			final var createdBy = resource.getValueMap().get("jcr:createdBy", "");
			brcCustomFieldsNode.setProperty("uploader", createdBy);

			// Set taxonomy
			final String taxonomy = map.get("taxonomyField", "");
			brcCustomFieldsNode.setProperty("taxonomy", taxonomy);
		} catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
	}

	private String[] getTagValue(ModifiableValueMap map) {
		final var tagValue = new HashSet<String>();

		// Transcript
		final var transcript = map.get("transcript", "requested");
		if (is3playProcessed) {
			tagValue.add("3play_processed");
		} else if ("yes".equalsIgnoreCase(transcript) || "requested".equalsIgnoreCase(transcript)) {
			tagValue.add("3play");
		}

		// YouTube
		final String publishToYoutube = map.get("dam:youtube", "no");
		if (StringUtils.isNotEmpty(publishToYoutube) && "yes".equals(publishToYoutube)) {
			tagValue.add("youtube");
		}

		// Language
		final var videoSpokenLanguage = map.get("videoSpokenLanguage", ENGLISH_STRING);
		if (StringUtils.isNotEmpty(videoSpokenLanguage)) {
			tagValue.add(getLanguageTag(videoSpokenLanguage));
		}

		// Associations tab
		final var associationTagsField = new String[] {"dam:tagsProducts", "dam:tagsApplications", "dam:tagsTools", "additionalTags"};
		for(final var associationTag: associationTagsField) {
			setAssociationTags(associationTag, map, tagValue);
		}

        return tagValue.toArray(new String[0]);
	}

	private String getLanguageTag(String langCode) {
		String langTag = "english";
		if(ENGLISH_STRING.equals(langCode)){
			langTag = "english";
		}
		else if(CHINESE_STRING.equals(langCode)){
			langTag = "chinese (simplified)";
		}
		else if("zh-tw".equals(langCode)){
			langTag = "chinese (traditional)";
		}
		else if(JAPANESE_STRING.equals(langCode)){
			langTag = "japanese";
		}
		else if("de".equals(langCode)){
			langTag = "german";
		}
		else if("ko".equals(langCode)){
			langTag = "korean";
		}
		return langTag;
	}

	private void setAssociationTags(String associationTag, ValueMap map, Set<String> tagValues) {
		final var tagsAssociation = map.get(associationTag, String[].class);
        if (null != tagsAssociation) {
			for (final var tagId : tagsAssociation) {
				final var tag = tagManager.resolve(tagId);
				if (null != tag) {
					final var tagTitle = tag.getTitle();
					final var tagValue =
						( StringUtils.isBlank(tagTitle)
							? tag.getName()
							: tagTitle
						).toLowerCase();
					tagValues.add(tagValue.replaceAll(",",""));
				}
			}
		}
	}

	private boolean check3playProcessed(JSONArray tagsFromBrightcove) {
		if (tagsFromBrightcove == null || tagsFromBrightcove.length() == 0) {
			return false;
		}
		try {
			for (int i = 0; i < tagsFromBrightcove.length(); i++) {
				if (tagsFromBrightcove.getString(i).equalsIgnoreCase("3play_processed")) {
					return true;
				}
			}
		} catch (JSONException e) {
			log.error(ERROR_MESSAGE,e);
		}
		return false;
	}

	private String getTagPathName(String tagId) {
		if (StringUtils.isEmpty(tagId)) return "";
		final var tag = tagManager.resolve(tagId);
		if (null == tag) return "";
		final var names = new ArrayList<String>();
		for(var t = tag; ( null != t ) && StringUtils.isNumeric(t.getName()); t = t.getParent()) {
			names.add(0, t.getTitle());
		}
		return "/" + String.join("/", names) + "/";
	}

	private String[] getTagPathNames(String[] tagIds) {
		if (null == tagIds || tagIds.length < 1) return new String[] {};
		return Stream.of(tagIds)
			.map(this::getTagPathName)
			.filter(StringUtils::isNotEmpty)
			.toArray(String[]::new);
	}
}
