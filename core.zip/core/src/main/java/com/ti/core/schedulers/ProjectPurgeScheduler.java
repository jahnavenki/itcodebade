package com.ti.core.schedulers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.caconfig.annotation.Property;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Purging the old translation project based on a scheduled basis
 * 
 */
@Designate(ocd= ProjectPurgeScheduler.Config.class)
@Component(service = Runnable.class)

public class ProjectPurgeScheduler implements Runnable {
	@ObjectClassDefinition(name = "Translation Projects Purge", description = "Translation Projects Purge")
	public @interface Config {
		 @AttributeDefinition( name = "schedulerExpression", description = "example 0 0 12 1/1 * ? * for 12 PM everyday",type = AttributeType.STRING )
			String scheduler_expression() default "0 0 20 ? * FRI *";

		@AttributeDefinition(name = "ProjectsAge", description = "ProjectsAge in days", type = AttributeType.INTEGER )
		int projectsAge() default 90;
	}

	private int numOfDays;
	private static final String EXCEPTION_MESSAGE = "Exception: ";
	private static final String EXCLUDE_PROJECT = "hpaem-master-projects";
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private ResourceResolverFactory resolverFactory;

	private ResourceResolver resourceResolver;

	private int schedulerID;

	@Reference
	protected Scheduler scheduler;

	@Activate
	public void activate(Config config) {
		this.numOfDays = config.projectsAge();
		schedulerID = this.getClass().getName().hashCode(); // update schedulerID
		addScheduler(config);
		log.debug("no of days {}", this.numOfDays);
	}
	@Modified
	protected void modified(ProjectPurgeScheduler.Config config) {
		schedulerID = this.getClass().getName().hashCode(); // update schedulerID
		removeScheduler();
		addScheduler(config);
	}

	@Deactivate
	protected void deactivate(ProjectPurgeScheduler.Config config) {
		removeScheduler();
	}

	/**
	 * Remove a scheduler based on the scheduler ID
	 */
	private void removeScheduler() {
		log.debug("Removing Scheduler Job '{}'", schedulerID);
		scheduler.unschedule(String.valueOf(schedulerID));
	}

	/**
	 * Add a scheduler based on the scheduler ID
	 */
	private void addScheduler(ProjectPurgeScheduler.Config config) {
		ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
		sopts.name(String.valueOf(schedulerID));
		sopts.canRunConcurrently(false);
		scheduler.schedule(this, sopts);
		log.debug("Scheduler added succesfully");
	}

	@Override
	public void run() {
		try {

			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			this.resourceResolver = this.resolverFactory.getServiceResourceResolver(param);
			deleteoldprojects();
		} catch (Exception e) {
			log.error("Error in execute.", e);
		} finally {
			if (null != this.resourceResolver) {
				this.resourceResolver.close();
			}
		}
	}

	private void deleteoldprojects() {

		String queryString = "SELECT * FROM [sling:OrderedFolder] AS s WHERE ISDESCENDANTNODE([/content/projects/]) and [jcr:primaryType]='sling:OrderedFolder'";
		NodeIterator nodeResult = null;

		Session session = resourceResolver.adaptTo(Session.class);
		try {
			QueryManager queryManager = session.getWorkspace().getQueryManager();

			Query query = queryManager.createQuery(queryString, "JCR-SQL2");
			// Execute the query and get the results ...
			QueryResult result = query.execute();
			nodeResult = result.getNodes();
			while (nodeResult != null && nodeResult.hasNext()) {
				Node payloadNode = nodeResult.nextNode();
				Resource resource1 = resourceResolver.getResource(payloadNode.getPath());
				ValueMap payloadpro = null != resource1 ? resource1.getValueMap() : null;
				if (null != payloadpro) {
					String projcreationDate = payloadpro.get("jcr:created", String.class);
					DateFormat jcrFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
					DateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
					projcreationDate = jcrFormat.format(simpleFormat.parse(projcreationDate));
					Date today;
					log.debug("No of days {}", this.numOfDays);
					today = DateUtils.addDays(new Date(), -this.numOfDays);

					log.debug("start date {}", today);
					String deletestartdate = jcrFormat.format(today);
					log.debug("Node path" + payloadNode.getPath());
					if ((jcrFormat.parse(deletestartdate).after(jcrFormat.parse(projcreationDate)))
							&& !payloadNode.getPath().contains(EXCLUDE_PROJECT)) {
						log.debug("projcreationDate {}", projcreationDate);
						payloadNode.remove();
						session.save();
					}
				}
			}
		} catch (RepositoryException | ParseException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}

}
