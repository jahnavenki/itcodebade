package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.FeaturedToolModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.Constants;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PortfolioFeaturedTool extends WCMUsePojo {

	private static Logger log = LoggerFactory.getLogger(PortfolioFeaturedTool.class);
    private static final String TOOLS_LIST = "tools";
	private static final String TOOL_TITLE = "title";
    private static final String EN_TOOL_TITLE = "enTitle";
	private static final String TOOL_DESCRIPTION = "description";
	private static final String TOOL_CATEGORY = "category";
	private static final String IMAGE_URL = "imageUrl";
	private static final String COMPANY_NAME = "companyName";
	private static final String COMPANY_URL = "companyUrl";
	private static final String COMPANY_IS_3P = "3p";
	private static final String TOOL_PATH = "/tool/";
	private static final String URL_DELIMITER = "/";
	private static final String SLASH = "//";
    private static final String OPTICAL_MODULE = "opticalmodule";
    private static final String NO_IMAGE_ICON = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/miscellaneous/no-image-available-icon.png";
    private static final String OPTICAL_IMAGE_ICON = "/content/dam/ticom/images/icons/illustrative-icons/products/optical-module-icon.png";
    private static final String EXCEPTION = "Exception: ";
    private List<FeaturedToolModel> featuredToolList = new ArrayList<>();

    public List<FeaturedToolModel> getFeaturedToolList() {
        return featuredToolList;
    }

	@Override
	public void activate() {
        try {
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(TOOLS_LIST)) {
                    for (Resource resourceChild : nodeChild.getChildren()) {
                        ValueMap properties = resourceChild.adaptTo(ValueMap.class);
                        if (null != properties) {
                            addToolToList(properties);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(EXCEPTION, e);
        }
	}

    private void addToolToList(ValueMap properties) {
        try {
            FeaturedToolModel toolModel = new FeaturedToolModel();
            boolean isStandardTool = properties.get("toolOptions").toString().equals("standardTool");
            if (isStandardTool) {
                String toolPartNumber = properties.get("toolPartNumber").toString();
                WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
                final var langUtils = new LanguageUtils(getRequest());
		        final var language = langUtils.getPageLanguageForProductFolder();

                if (StringUtils.isNotEmpty(toolPartNumber) && wcmService != null) {
                    JSONObject jsonToolDetails = wcmService.getToolDetails(toolPartNumber, language);
                    if (jsonToolDetails != null) {
                        toolModel.setToolTitle(jsonToolDetails.getString(TOOL_TITLE));
                        toolModel.setEnToolTitle(jsonToolDetails.getString(EN_TOOL_TITLE));
                        toolModel.setToolDescription(jsonToolDetails.getString(TOOL_DESCRIPTION));
                        toolModel.setToolCategory(jsonToolDetails.getString(TOOL_CATEGORY));
                        toolModel.setToolURL(getToolURL(toolPartNumber));
                        // If the image does not exist, default to the no image icon
                        // /content/dam/ticom/images/icons/illustrative-icons/miscellaneous/no-image-available-icon.png
                        String image =  StringUtils.isNotEmpty(jsonToolDetails.getString(IMAGE_URL)) ?
                                    jsonToolDetails.getString(IMAGE_URL) : NO_IMAGE_ICON;
                        if(jsonToolDetails.getString(TOOL_CATEGORY).replace(" ", "").equalsIgnoreCase(OPTICAL_MODULE)){
                            image= OPTICAL_IMAGE_ICON;
                        }
                        toolModel.setToolImage(image);
                        set3PProperties(jsonToolDetails, toolModel);
                    }
                }
            } else {
                setCustomToolProperties(toolModel, properties);
            }
            featuredToolList.add(toolModel);
        } catch (Exception e) {
            log.error(EXCEPTION, e);
        }
    }

    private String getToolURL(String toolPartNumber) {
        String toolURL = "";
        String languageCode = null;
        ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
        if (tabsService != null) {
            languageCode = tabsService.getLanguageCodeForPage(getCurrentPage()).toLowerCase();
        }
        String url = "";
		if (null != languageCode && !(Constants.LANG_CODES_EN_KR_DE.contains(languageCode))) {
			url = generateDomain() + TOOL_PATH + languageCode + URL_DELIMITER + toolPartNumber;
		} else {
			url = generateDomain() + TOOL_PATH + toolPartNumber;
		}
        toolURL = URLHelper.toScheme(url, URLHelper.getScheme(getRequest()));
        return toolURL;
    }

	private String generateDomain() {
		String domain = "";
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		if (null != factoryConfigs) {
			List<SeoUrlTagging> listConfig = factoryConfigs.getConfigs();
			for (SeoUrlTagging seoUrlTagging : listConfig) {
				if (StringUtils.containsIgnoreCase(getCurrentPage().getPath(), seoUrlTagging.getContentPath())) {
					domain = seoUrlTagging.getDomainName();
					domain = SLASH.concat(domain);
					break;
				}
			}
		}
		return domain;
	}

    private void set3PProperties(JSONObject jsonToolDetails, FeaturedToolModel toolModel) {
        try {
            if (jsonToolDetails.has(COMPANY_IS_3P) && !jsonToolDetails.isNull(COMPANY_IS_3P)) {
                toolModel.setThirdParty(jsonToolDetails.getBoolean(COMPANY_IS_3P));
                if (jsonToolDetails.has(COMPANY_NAME) && !jsonToolDetails.isNull(COMPANY_NAME)) {
                    toolModel.setThirdPartyCompany(jsonToolDetails.getString(COMPANY_NAME));
                    if (jsonToolDetails.has(COMPANY_URL) && !jsonToolDetails.isNull(COMPANY_URL)) {
                        toolModel.setThirdPartyCompanyURL(jsonToolDetails.getString(COMPANY_URL));
                    }
                }
            }
        } catch (Exception e) {
            log.error(EXCEPTION, e);
        }
    }

    private void setCustomToolProperties(FeaturedToolModel toolModel, ValueMap properties) {
        toolModel.setToolPartNumber("custom");
        toolModel.setToolTitle(properties.get("toolCustomTitle").toString());
        toolModel.setToolDescription(properties.get("toolCustomDescription").toString());
        toolModel.setToolCategory(properties.get("toolCustomCategory").toString());
        String url = properties.get("toolCustomURL").toString();
        url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), url);
        toolModel.setToolURL(url);
        if (properties.containsKey("fileReference")) {
            toolModel.setToolImage(properties.get("fileReference").toString());
        }
        if (properties.get("toolCustom3PCompany") != null && properties.get("toolCustom3PCompany").toString().length() > 0) {
            toolModel.setThirdParty(true);
            toolModel.setThirdPartyCompany(properties.get("toolCustom3PCompany").toString());
            toolModel.setThirdPartyCompanyURL(properties.get("toolCustom3PURL").toString());
        }
    }
}
