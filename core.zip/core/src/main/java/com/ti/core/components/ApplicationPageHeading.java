package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.AssetUtils;

import org.apache.sling.api.resource.Resource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationPageHeading extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private static final String APPLICATION_ID = "applicationId";
	private static final String JSON_KEY_APP_AREA_NAME = "appAreaName";
	
	private boolean isVideo;
	private String ctaUrl;
	
	public boolean getIsVideo() {
		return isVideo;
	}

	private String headline;
	public String getHeadline() {
		return headline;
	}

	private String imageAltText;
	public String getImageAltText() {
		return imageAltText;
	}

	private String videoTitle;
	public String getVideoTitle() {
		return videoTitle;
	}
	public String getCtaUrl() {
		return ctaUrl;
	}

	@Override
	public void activate() {
		try {
			final var pageProperties = getPageProperties();
			final var properties = getProperties();
			final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if(null == wcmService) return;
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if(null == tabsService) return;
			final var language = tabsService.getPageLanguage(getCurrentPage());
			final var langUtils = new LanguageUtils(getRequest());
			final var appId = (String) pageProperties.get(APPLICATION_ID);
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
			if(StringUtils.isEmpty(appId)) {
				headline = langUtils.getI18nStr("Applications");
			} else {
				final var jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(appId), language);
				if(null != jsonObject) {
					headline = jsonObject.get(JSON_KEY_APP_AREA_NAME).toString();
				}
			}
			final var imageSrc = properties.get("imageSrc", "");
			final var secondaryCtaVideoId = properties.get("secondaryCtaVideoId", "");
			getDamResources(imageSrc,secondaryCtaVideoId,videoService.getVideoPath());
			ctaUrl = "products.html";
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
	private void getDamResources(String imageSrc,String secondaryCtaVideoId, String videoFolderPath) {
        try {    
			if (StringUtils.isNotEmpty(imageSrc)) {
				final var resource = getResourceResolver().getResource(imageSrc);
				if (null != resource) {
					final var asset = resource.adaptTo(Asset.class);
					if (null != asset) {
						isVideo = asset.getMimeType().startsWith("video/");
						imageAltText = asset.getMetadataValue("dc:title");
					}
				}
			}
			if (StringUtils.isNotEmpty(secondaryCtaVideoId)) {
				Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoFolderPath, secondaryCtaVideoId);
				if (null != damRes) {
					final var map = AssetUtils.getMetadata(damRes);
					if (null != map) {
						videoTitle = map.get("dc:title",String.class);
					}
				}
			}
		} catch (Exception e) {
		log.error("Exception:", e);
		}
	}
}
