package com.ti.core.schedulers;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Binary;
import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;



@Component(immediate = true,service = Job.class)
@Designate(ocd = DeleteMp4Scheduler.Config.class)
public class DeleteMp4Scheduler implements Job {

    private static final Logger log = LoggerFactory.getLogger(DeleteMp4Scheduler.class);
    
    
    @Reference
    private Scheduler scheduler;

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    private VideoConfigService videoConfigService;

    @ObjectClassDefinition(name = "TI DAM Delete Mp4 Scheduler", description = "TI DAM Delete Mp4 Scheduler")
    public @interface Config {
        @AttributeDefinition
        (type = AttributeType.STRING,
         name = "cronExpression",
        description = "Regular expression for time based Scheduler. Eg: '0 0 0 * * ?'. The example expression triggers the Job @ 00 hrs.")
        String cronExpression() default "0 0 12 ? * MON *"; 

        @AttributeDefinition
        (type = AttributeType.STRING,
         name = "days",
        description = "Mention the no of  days for which the mp4 needs to be deleted. ex: For last week : 7")
        String days() default "7"; 
    
        @AttributeDefinition
        (type = AttributeType.BOOLEAN,
         name = "runNow",
        description = "Run Now")
        boolean runNow() default false;

        @AttributeDefinition(
            name = "Enabled",
            description = "Check the box to enable the scheduler",
            type = AttributeType.BOOLEAN)
            boolean enabled() default false;
        
        }
    private String schedulerName;
    private ResourceResolver resourceResolver;

    public void execute(final JobContext context) {
        try {
            String days= context.getConfiguration().get("days").toString();
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            resourceResolver = resolverFactory.getServiceResourceResolver(param);
            List<Resource> recentlyCreatedVideosList = getRecentlyCreatedVideos(resourceResolver,days );
            for (Resource resource: recentlyCreatedVideosList) {
                Resource fileResource = resourceResolver.getResource(resource.getPath()+ "/jcr:content/renditions/original/jcr:content");
                if (null != fileResource) {
                    Node fileNode = fileResource.adaptTo(Node.class);
                    Session session = resourceResolver.adaptTo(Session.class);
                    if (null != session && null != fileNode && fileNode.hasProperty(JcrConstants.JCR_DATA)) { // Fetching XML from jcr:data property
                        String updatedXml = "";
                        InputStream targetStream = new ByteArrayInputStream(updatedXml.getBytes());
                        Binary contentValue = session.getValueFactory().createBinary(targetStream);
                        fileNode.setProperty(JcrConstants.JCR_DATA, contentValue);
                        ModifiableValueMap metadata = AssetUtils.getModifiableMetadata(resource);
					    metadata.put("dam:size","");
                        session.save();
                        contentValue.dispose();
                        
                    }   
                }
            }
        }catch (Exception e) {
            log.error("Error in execute.", (Throwable) e);
        } finally {
            if (null != this.resourceResolver) {
                this.resourceResolver.close();
            }
        }
    }

    private List<Resource> getRecentlyCreatedVideos(ResourceResolver resourceResolver, String days) {

        
		List<Resource> recentlyCreatedVideosList = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
        map.put("path", videoConfigService.getVideoPath());
		map.put("type", "dam:Asset");
		map.put("property", "jcr:content/metadata/dc:format");
		map.put("property.value", "video/mp4");
		map.put("relativedaterange.property", "jcr:created");
		map.put("relativedaterange.lowerBound", "-"+days+"d");
        map.put("1_property", "jcr:content/metadata/brc_id");
		map.put("1_property.operation", "exists");
        map.put("2_property", "jcr:content/dam:assetState");
		map.put("2_property.value", "processed");
        map.put("p.limit", "-1");
		
		QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
		Session session = resourceResolver.adaptTo(Session.class);
		if(builder != null) {
			Query query = builder.createQuery(PredicateGroup.create(map), session);
			SearchResult result = query.getResult();
	
			Iterator<Resource> resourcesItr = result.getResources();
			while (resourcesItr.hasNext()) {
				recentlyCreatedVideosList.add(resourcesItr.next());
			}
		}
		return recentlyCreatedVideosList;
	}

    @Activate
    protected void activate(Config config) {
        this.schedulerName = this.getClass().getSimpleName(); // update schedulerID
        addScheduler(config);
    }

    @Modified
    protected void modified(Config config) {
        this.schedulerName = this.getClass().getSimpleName();
        removeScheduler();
        addScheduler(config);
    }

    @Deactivate
    protected void deactivate(Config config) {
        removeScheduler();
    }

    /**
     * Remove a scheduler based on the scheduler ID
     */
    private void removeScheduler() {
        log.debug("Removing Scheduler Job '{}'", schedulerName);
        scheduler.unschedule(String.valueOf(schedulerName));
    }


    private void addScheduler(Config configuration) {
        // Check if the scheduler has enable flag set to true
        ScheduleOptions scheduleOptions;
        if(configuration.enabled()){
            if(configuration.runNow()){
                final long delay = 30*1000;
                final Date fireDate = new Date();
                fireDate.setTime(System.currentTimeMillis() + delay);
                scheduleOptions = scheduler.AT(fireDate);
            }
            else{
                scheduleOptions = scheduler.EXPR(configuration.cronExpression());
            }
            scheduleOptions.name(schedulerName);
            scheduleOptions.canRunConcurrently(false);
            Map<String,Serializable> configMap = new HashMap<>();
            configMap.put("days", configuration.days());
            scheduleOptions.config(configMap);
            scheduler.schedule(this, scheduleOptions);
            log.debug("Scheduler added succesfully");
        }
        else{
            removeScheduler();
        }
        
    }
}