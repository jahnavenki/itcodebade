package com.ti.core.schedulers;

import com.day.cq.dam.api.Asset;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.ti.core.models.assets.RenditionsMapping;
import com.ti.core.service.RenditionsMappingsConfig;
import com.ti.core.util.AssetUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.util.*;

/**
 * Use this scheduler to apply Renditions Mappings updates to applicable paths
 * in the DAM. 1. Update the Renditions Mappings 2. Choose which mapping(s) to
 * apply or delete 3. Update any other flags as needed 4. Change the Next run
 * time to be a time of your choosing (Note: for Next run time, always enter a
 * specific time, do not enter a recurring time)
 *
 * @author Richard Chan
 */
/*
 *
 */

@Designate(ocd = RenditionsMappingsScheduler.Config.class)
@Component(service = {Runnable.class, RenditionsMappingsConfig.class }, immediate=true)

public class RenditionsMappingsScheduler implements RenditionsMappingsConfig, Runnable {
	private static final Logger log = LoggerFactory.getLogger(RenditionsMappingsScheduler.class);

	private static final String AUTHOR = "author";

	@Reference
	private ResourceResolverFactory rrFactory;
	@Reference
	private SlingSettingsService slingSettings;
	@Reference
	Replicator replicator;

	private int schedulerID;

	@Reference
	protected Scheduler scheduler;

	@ObjectClassDefinition(name = "TI DAM Renditions Mappings Scheduler configuration", description = "TI DAM Renditions Mappings Scheduler ")
	public @interface Config {

		@AttributeDefinition(name = "schedulerExpression", description = "Scheduler will apply the current renditions mappings for Next run time (in cron expression)")
		String scheduler_expression() default " ";

		@AttributeDefinition(name = "Path to process", description = "Specify the path (and its subpaths) where images will be tested against the renditions mappings' paths.  (The actual updates still depend on whether the image applies to any one of the renditions mappings' paths)")
		String pathToProcess() default "/content/dam/ticom/images/";

		@AttributeDefinition(type = AttributeType.STRING, name = "Mapping(s) to apply", description = "Enter the mapping name(s) (specified by imageType, separated by semi-colons) that will apply on the next run.  If blank, no mappings will apply. Enter '*' to re-apply all mappings.  Default: blank")
		String mappingsToApply();


		@AttributeDefinition(type = AttributeType.STRING, name = "Mapping(s) to delete", description = "Before deleting a mapping permanently, be sure to enter its name here and run it on the next run.  Then, you can delete the mapping.  Default: blank")
		String mappingsToDelete();

		@AttributeDefinition(type = AttributeType.BOOLEAN, name = "Force regenerate renditions", description = "If checked, rendition files would be regenerated for each image, even if there are no changes to the underlying renditions mapping rules")
		boolean forceRegenerate() default false;

		@AttributeDefinition(type = AttributeType.BOOLEAN, name = "Publish renditions", description = "If checked, images that have their renditions (re)generated will also be published")
		boolean publishRenditions() default true;

		@AttributeDefinition(type = AttributeType.STRING, name = "Renditions Mappings", description = "Each item represents one renditions mapping, all items represent the entire global Renditions Mappings")
		String[] renditionsMappings();
	}

	// @Property(label = "Path to process", description = "Specify the path (and its
	// subpaths) where images will be tested against the renditions mappings' paths.
	// (The actual updates still depend on whether the image applies to any one of
	// the renditions mappings' paths)", value = "/content/dam/ticom/images/")

	private String pathToProcess;

	//@Property(label = "Mapping(s) to apply", description = "Enter the mapping name(s) (specified by imageType, separated by semi-colons) that will apply on the next run.  If blank, no mappings will apply. Enter '*' to re-apply all mappings.  Default: blank", value = "")

	private String mappingsToApply;


	private String mappingsToDelete;


	private boolean forceRegenerate;


	private boolean publishRenditions;


	private String[] renditionsMappings;

	@Activate
	public void activate(Config config) {
		pathToProcess = config.pathToProcess();
		forceRegenerate = config.forceRegenerate();
		publishRenditions = config.publishRenditions();
		renditionsMappings = config.renditionsMappings();
		mappingsToApply = config.mappingsToApply() + ";";
		mappingsToDelete = config.mappingsToDelete() + ";";
		schedulerID = this.getClass().getName().hashCode(); // update schedulerID
		addScheduler(config);		
	}

	
	@Modified
	protected void modified(RenditionsMappingsScheduler.Config config) {

		schedulerID = this.getClass().getName().hashCode(); // update schedulerID
		removeScheduler();

		// If scheduler has no expression, then run it immediately
		if (config.scheduler_expression().isEmpty())
			run();
	}

	@Deactivate
	protected void deactivate(RenditionsMappingsScheduler.Config config) {
		removeScheduler();
	}

	/**
	 * Remove a scheduler based on the scheduler ID
	 */
	private void removeScheduler() {
		log.debug("Removing Scheduler Job '{}'", schedulerID);
		scheduler.unschedule(String.valueOf(schedulerID));
	}

	/**
	 * Add a scheduler based on the scheduler ID
	 */
	private void addScheduler(RenditionsMappingsScheduler.Config config) {
		if (!config.scheduler_expression().isEmpty()) {
			ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
			sopts.name(String.valueOf(schedulerID));
			sopts.canRunConcurrently(false);
			scheduler.schedule(this, sopts);
			log.debug("Scheduler added succesfully");
		}
	}

	@Override
	public void run() {
		try {						
			if (slingSettings == null || rrFactory == null || replicator == null)
				return;

			// Scheduler should only run in author instance
			Set<String> runModes = slingSettings.getRunModes();
			if (null == runModes || !runModes.contains(AUTHOR))
				return;

			List<RenditionsMapping> renditionsMappingsList = AssetUtils
					.getRenditionsMappingsFromProperty(renditionsMappings);
			log.debug("Path to process: {}, Number of mappings: {}", pathToProcess, renditionsMappingsList.size());
			log.debug("Mappings to apply: {}, Mappings to delete: {}", mappingsToApply, mappingsToDelete);
			log.debug("Force regenerate: {}, Publish renditions: {}", forceRegenerate, publishRenditions);

			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			ResourceResolver resourceResolver = rrFactory.getServiceResourceResolver(param);

			for (RenditionsMapping mapping : renditionsMappingsList) {
				String imageType = mapping.getString(RenditionsMapping.IMAGE_TYPE);
				String path = mapping.getString(RenditionsMapping.IMAGE_PATH);

				if (!StringUtils.isEmpty(imageType) && mappingsToApply.contains(imageType + ';')) {
					log.debug("Applying mapping: {}", imageType);

					// Find all assets (source file or not) that are either in the mapping's path,
					// or the asset already contains a mapping with the same Image Type
					String queryString = "SELECT * FROM [dam:Asset] WHERE ISDESCENDANTNODE('" + pathToProcess
							+ "') AND [jcr:path] NOT LIKE '%/subassets/%' AND ([jcr:path] LIKE '%" + path
							+ "%' OR [jcr:content/metadata/dam:renditionsMappings] LIKE '%\"imageType\":\"" + imageType
							+ "\"%')";

					Iterator<Resource> iter = resourceResolver.findResources(queryString,
							javax.jcr.query.Query.JCR_SQL2);
					while (iter.hasNext())
						updateAsset(iter.next(), mapping, resourceResolver);
				}
			}
		} catch (Exception e) {
			log.error("Exception in RenditionsScheduler during run()", e);
		} finally {
			log.debug("RenditionsMappingsScheduler run ended");
		}
	}

	/**
	 * Apply the following updates to the asset: 1. Apply source file to image as a
	 * subasset, if applicable 2. If image has a source file matching the mapping's
	 * source format, update image's mapping 3. If image's mapping has been updated,
	 * or scheduler runs with Force Regenerate flag, (re)generate the image's
	 * renditions based on its mapping 4. If scheduler has Publish Image flag,
	 * publish the image if any renditions are (re)generated
	 *
	 * @param res              the image as a Resource
	 * @param mapping          is the global mapping provided
	 * @param resourceResolver a ResourceResolver
	 */
	private void updateAsset(Resource res, RenditionsMapping mapping, ResourceResolver resourceResolver) {
		try {
			Asset asset = res.adaptTo(Asset.class);
			ModifiableValueMap metadata = AssetUtils.getModifiableMetadata(res);

			// Step 1: apply source file to the image as a subasset, if applicable
			if (metadata != null && asset != null
					&& AssetUtils.applySourceToSubasset(asset, mapping, resourceResolver)) {
				// Step 2: Update asset's metadata from global mapping, if asset matches
				// mapping's matching criteria or asset already has a mapping with the same
				// image type (this can be simplified as simply having the 'renditionsMappings'
				// metadata field)
				boolean isMappingUpdated = AssetUtils.applyRenditionsMappingToAssetMetadata(metadata, mapping,
						resourceResolver);

				// Step 3: Generate renditions from asset's metadata mapping(s) if 1) in Step 2
				// the mapping got added/updated AND the publish image flag is true, or 2)
				// scheduler's Force Regenerate flag is true
				if (forceRegenerate || (isMappingUpdated && publishRenditions)) {
					AssetUtils.generateRenditions(asset, resourceResolver, forceRegenerate);
					if (publishRenditions)
						replicator.replicate(resourceResolver.adaptTo(Session.class), ReplicationActionType.ACTIVATE,
								asset.getPath());
				}
			}
		} catch (Exception e) {
			log.error("Exception in updateAsset", e);
		}
	}

	public String[] getRenditionsMappings() {
		return renditionsMappings;
	}

}