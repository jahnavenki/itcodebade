/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ti.core.components.video;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author x1055799
 */
public class TopLevelVideoSeriesPageMetaData extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(TopLevelVideoSeriesPageMetaData.class);
	
	private String browserTitle;
    private String metaDescription;
    private String keywords;

	public String getBrowserTitle() {
		return browserTitle;
	}

	public String getMetaDescription() {
		return metaDescription;
	}

	public String getKeywords() {
		return keywords;
	}
	
	@Override
    public void activate() throws Exception {
		try {  
            String language = "en-us";
            final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                language = tabsService.getPageLanguage(getCurrentPage());
            }
			String pageTitle = getCurrentPage().getTitle();
			
            setMetadata(pageTitle, language);
      
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }
    }

    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = <Page Title> + “|” + “TI.com”
			   For CN, it should be <Page Title> + “|” + “TI.com.cn”
            2. Meta description = <Page Title> + "." + "Find demos, on-demand tutorials and technical how-to videos."
            3. Keywords: <Page Title> +"," + "video series"

    */

    private void setMetadata(String pageTitle, String language) {  
        if("zh-cn".equals(language)) {
            browserTitle = pageTitle + " | TI.com.cn";
        } else {
            browserTitle = pageTitle + " | TI.com";
        }
		metaDescription = pageTitle + ". Find demos, on-demand tutorials and technical how-to videos.";
        keywords = pageTitle + ", video series";
        
    }		
}