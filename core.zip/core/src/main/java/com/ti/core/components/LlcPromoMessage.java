package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LlcPromoMessage extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private String imageSrc;
	private String imageAlt;

	public String getImageSrc() {
		return imageSrc;
	}

	public String getImageAlt() {
		return imageAlt;
	}

	private String getImageAltText( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		final var asset = resource.adaptTo(Asset.class);
		if(null == asset) return "";
		return asset.getMetadataValue("dc:title");
	}

	@Override
	public void activate() {
		try {
			final var properties = getProperties();
			imageSrc = properties.get("imageSrc", "");
			imageAlt = getImageAltText(imageSrc);
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
