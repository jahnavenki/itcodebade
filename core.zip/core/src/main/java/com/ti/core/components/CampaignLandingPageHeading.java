package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.util.PathBrowserHelper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;

public class CampaignLandingPageHeading extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(CampaignLandingPageHeading.class);
    private String ctaUrl;
    private boolean isVideo;
    private String imageAltText;
    private String bcVideoId;
    private String secondaryctaUrl;

    public String getCtaUrl() {
        return ctaUrl;
    }
	public boolean getIsVideo() {
		return isVideo;
	}
    public String getImageAltText() {
        return imageAltText;
    }
    public String getBcVideoId() {
      return bcVideoId;
    }
    public String getSecondaryctaUrl() {
		return secondaryctaUrl;
	}

    @Override
    public void activate() throws Exception {
        try {
            final Page currentPage = getCurrentPage();
            final String pagePath = currentPage.getPath();
            final boolean isTechnology = pagePath.contains("/technologies/");
            final Resource resource = getResource();
            if (null == resource) {
                log.debug("Resource is null");
                return;
            }
            // Get title from DAM property and set as alt text for image
            setAltTextForImage();

            // If CTA is video and video is DAM asset, get video id from DAM property
            // If CTA is link, get URL for the link
            final String ctaOption = getProperties().get("ctaOptions", String.class);
            if ("linkOption".equals(ctaOption)) {
                setCTA();
            } else if ("videoOption".equals(ctaOption) && null == getProperties().get("videoid")) {
                setVideoId();
            }
            // set secondary CTA URL
            secondaryctaUrl = "products.html";
            if (isTechnology) {
                secondaryctaUrl = "functional-safety/" + secondaryctaUrl;
            }
        } catch (Exception e) {
            log.error("Exception:", e);
        }
    }
    /**
     * Get title from DAM property and set as alt text for image
     */
    private void setAltTextForImage() {
        String imageSrc = getProperties().get("fileReference", String.class);
        if (StringUtils.isEmpty(imageSrc)) {
            log.debug("Image not authored");
            return;
        }
        Resource resource = getResourceResolver().getResource(imageSrc);
        if (resource != null) {
            Asset asset = resource.adaptTo(Asset.class);
            if (asset != null) {
                isVideo = asset.getMimeType().startsWith("video/");
                imageAltText = asset.getMetadataValue("dc:title");
            }
        }
    }

    private void setCTA() {
        ctaUrl = getProperties().get("ctaUrl", "");
        ctaUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), ctaUrl);
    }

    /**
     * If CTA is video and video is DAM asset, get video id from DAM property
     */
    private void setVideoId() {
        Resource resource = getResourceResolver().getResource(getProperties().get("mediaFileReference").toString());
        if (resource != null) {
            Resource metadataResource = resource.getChild("jcr:content/metadata");
            ValueMap properties = ResourceUtil.getValueMap(metadataResource);
            this.bcVideoId = properties.get("brc_id").toString();
        }
    }

}
