package com.ti.core.service.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

import com.ti.core.service.TiUrlPattern;
import com.ti.core.service.config.TiUrlPatternConfiguration;



@Component(immediate = true, 
service = TiUrlPattern.class)
@Designate(ocd = TiUrlPatternConfiguration.class, factory=true)

public class TiUrlPatternImpl implements TiUrlPattern {
	protected TiUrlPatternConfiguration tiUrlPatternConfiguration;
	
	private String urlPattern = null;

		private String[] replacementPatterns;

		private String keys = null;

		private int groupNumber = 0;

	@Override
	public String getUrlPattern() {
		return urlPattern;
	}

	@Override
	public String[] getReplacementPatterns() {
		return replacementPatterns;
	}

	@Override
	public String getKey() {
		return keys;
	}

	@Override
	public int getGroupNumber() {
		return groupNumber;
	}

	@Activate
	@Modified
	public void activate(TiUrlPatternConfiguration config) {
		this.urlPattern = config.urlPattern();
		this.replacementPatterns = config.replacementPatterns();
		this.keys = config.key();
		this.groupNumber = config.groupNumber();
	}

	public void setUrlPattern(String urlPattern) {
		this.urlPattern = urlPattern;
	}

	public void setReplacementPatterns(String[] replacementPatterns) {
		this.replacementPatterns = replacementPatterns;
	}

	public void setKey(String key) {
		this.keys = key;
	}

	public void setGroupNumber(int groupNumber) {
		this.groupNumber = groupNumber;
	}

}
