package com.ti.core.schedulers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.jcr.Session;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;


/**
 * Publishing pages via Scheduler
 */
@Designate(ocd = PagePublishScheduler.Config.class)
@Component(service = Runnable.class)

public class PagePublishScheduler implements Runnable {
    @ObjectClassDefinition(name = "Publish Page Scheduler", description = "Publish Page Scheduler")
    public @interface Config {
        @AttributeDefinition(name = "schedulerExpression", description = "example 0 0 12 1/1 * ? * for 12 PM everyday")
        String scheduler_expression();

        @AttributeDefinition(type = AttributeType.STRING, name = "Page Paths", description = "Select page path e.g. /content/texas-instruments/en-us/page")
        String[] pagePaths();
    }

    private String[] pagePaths;
    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private Replicator replicator;

    private int schedulerID;

    @Reference
    protected Scheduler scheduler;

    @Activate
    protected void activate(Config config) {
        this.pagePaths = config.pagePaths();
        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        addScheduler(config);
    }

    @Modified
    protected void modified(PagePublishScheduler.Config config) {

        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        removeScheduler();
        addScheduler(config);
    }

    @Deactivate
    protected void deactivate(PagePublishScheduler.Config config) {
        removeScheduler();
    }

    /**
     * Remove a scheduler based on the scheduler ID
     */
    private void removeScheduler() {
        log.debug("Removing Scheduler Job '{}'", schedulerID);
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    /**
     * Add a scheduler based on the scheduler ID
     */
    private void addScheduler(PagePublishScheduler.Config config) {
        ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
        sopts.name(String.valueOf(schedulerID));
        sopts.canRunConcurrently(false);
        scheduler.schedule(this, sopts);
        log.debug("Scheduler added succesfully");
    }

    @Override
    public void run() {
        Map<String, Object> param = new HashMap<>();
        param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
        try {
            ResourceResolver resourceResolver = this.resolverFactory.getServiceResourceResolver(param);
            publishPages(resourceResolver);
        } catch (LoginException e) {
            log.error("LoginException", e);
        }

    }

    private void publishPages(ResourceResolver resolver) {
        Session session = Objects.nonNull(resolver) ? resolver.adaptTo(Session.class) : null;
        if (Objects.nonNull(this.pagePaths) && Objects.nonNull(replicator) && Objects.nonNull(session)) {
            Arrays.asList(this.pagePaths).stream().forEach(path ->
            {
                try {
                    replicator.replicate(session, ReplicationActionType.ACTIVATE, path);
                } catch (ReplicationException e) {
                    log.error("ReplicationException", e);
                }
            });
        }
    }
}