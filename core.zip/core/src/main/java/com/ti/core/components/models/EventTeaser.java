package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = {Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class EventTeaser { 	

	protected static final Logger log = LoggerFactory.getLogger(EventTeaser.class);

	@ScriptVariable
	private ResourceResolver resolver;

	@ValueMapValue
	private String attendanceType;

	@ValueMapValue
	private String eventTitle;
	
	@ValueMapValue
	private String eventDescription;

	@ValueMapValue
	private String eventType;

	@ValueMapValue
	private String eventImgReference;

	@ValueMapValue
	private String ctaTitle;

	@ValueMapValue
	private String ctaUrl;
	
	private String altText;

	public String getEventTitle() {
		return eventTitle;
	}
	
	public String getEventDescription() {
		return eventDescription;
	}

	public String getEventType() {
		return eventType;
	}
	
	public String getAttendanceType() {
		return attendanceType;
	}

	public String getAltText() {
		return altText;
	}

	public String getEventImgReference() {
		return eventImgReference;
	}

	public String getCtaTitle() {
		return ctaTitle;
	}

	public String getCtaUrl() {
		return ctaUrl;
	}
		
	@PostConstruct
	protected void init() {		
		if(StringUtils.isNotBlank(eventImgReference) && resolver != null 
			&& resolver.getResource(eventImgReference + "/jcr:content/metadata") != null) {
			Resource metadataRes = resolver.getResource(eventImgReference + "/jcr:content/metadata");
			if (metadataRes != null) {
				altText = metadataRes.getValueMap().get("jcr:title","");
			}
		}
		
	}

}