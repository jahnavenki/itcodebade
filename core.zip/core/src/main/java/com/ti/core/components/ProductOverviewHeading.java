package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductOverviewHeading extends WCMUsePojo {

    private static final String FEATURE_OPTIONS = "featureOptions";
    private static final String IMAGE_PATH = "fileReference";
    private static final String VIDEO_ID = "videoid";
    private static final String VIDEO_PATH = "mediaFileReference";
	protected static final Logger log = LoggerFactory.getLogger(ProductOverviewHeading.class);

    private String imageAltText;
    private String bcVideoId;

    @Override
    public void activate() throws Exception {       
        try {              
            if (getProperties().get(FEATURE_OPTIONS).toString().equals("imageOption")) {
                setImageAltText();
            } else if (getProperties().get(FEATURE_OPTIONS).toString().equals("videoOption")
                && getProperties().get(VIDEO_ID) == null) {
                setVideoId();
            }
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }    
    }

    private void setImageAltText() {       
        // Get title from DAM property and set as alt text for image
        Resource resource = getResourceResolver().getResource(getProperties().get(IMAGE_PATH).toString());
        if (resource != null) {                    
            Asset asset = resource.adaptTo(Asset.class);
            if (asset != null) {
                this.imageAltText = asset.getMetadataValue("dc:title");
            }                    
        }
    }

    private void setVideoId() {       
        // Get title from DAM property and set as alt text for image
        Resource resource = getResourceResolver().getResource(getProperties().get(VIDEO_PATH).toString());
        if (resource != null) {   
            Resource metadataResource = resource.getChild("jcr:content/metadata");
            ValueMap properties = ResourceUtil.getValueMap(metadataResource);
            this.bcVideoId = properties.get("brc_id").toString();               
        }
    }
  
    public String getImageAltText() {
      return imageAltText;
    }   
  
    public String getBcVideoId() {
      return bcVideoId;
    }
}
