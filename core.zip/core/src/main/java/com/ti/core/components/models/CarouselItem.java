package com.ti.core.components.models;

public class CarouselItem {

	private String title;
	private String headline;
	private String image;
	private String applicationstoryPath;
	private String featuredResourcesPath;

	public CarouselItem(String title, String headline, String image, String applicationstoryPath, String featuredResourcesPath) {
		this.title = title;
		this.headline = headline;
		this.image = image;
		this.applicationstoryPath = applicationstoryPath;
		this.featuredResourcesPath = featuredResourcesPath;
	}

	public String getFeaturedResourcesPath() {
		return featuredResourcesPath;
	}

	public String getTitle() {
		return title;
	}

	public String getHeadline() {
		return headline;
	}

	public String getImage() {
		return image;
	}

	public String getApplicationstoryPath() {
		return applicationstoryPath;
	}

}
