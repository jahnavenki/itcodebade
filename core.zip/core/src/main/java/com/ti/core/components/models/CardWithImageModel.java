package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.LoggerFactory;


import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class, Resource.class},
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class CardWithImageModel {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	@ValueMapValue
	private String altText;

	@ValueMapValue
	private String description;

	@ValueMapValue(name = "fileReference")
	private String image;

	@ValueMapValue
	private String url;

	@ValueMapValue
	private String ctaLabel;

    private String ctaIcon;

	@PostConstruct
	public void init(){
		try {
			altText = StringUtils.defaultString(altText);
			description = StringUtils.defaultString(description);
			image = StringUtils.defaultString(image);
			ctaLabel = StringUtils.defaultString(ctaLabel);
            ctaIcon= StringUtils.defaultString(ctaIcon);
		} catch (Exception e) {
			log.error("Exception in CardWithImage", e);
		}
	}

	public String getCtaLabel() {
		return ctaLabel;
	}

	public String getAltText() {
		return altText;
	}

	public String getDescription() {
		return description;
	}

	public String getImage() {
		return image;
	}

	public String getUrl() {
		return url;
	}

    public String getCtaIcon(){
        return ctaIcon;
    }

    public void setCtaIcon( String ctaIcon ) {
        this.ctaIcon = ctaIcon;
    }

    public void setUrl( String url ) {
        this.url = url;
    }

}