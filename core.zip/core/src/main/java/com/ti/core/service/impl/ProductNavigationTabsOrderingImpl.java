package com.ti.core.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.config.ProductsNavigationTabsOrderingConfiguration;

/**
 * ProductNavigationTabsOrderingImpl service.
 */

@Component(immediate = true, service = ProductNavigationTabsOrdering.class)
@Designate(ocd = ProductsNavigationTabsOrderingConfiguration.class)
public class ProductNavigationTabsOrderingImpl implements ProductNavigationTabsOrdering {

	@Reference
	SeoUrlFactoryConfigs factoryConfigs;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

		private String standardTabsOrdering;

	private String applicationStandardTabsOrdering;
	private String analyticsPagename;

		private String adobeHelpLink;
	protected ProductsNavigationTabsOrderingConfiguration productsNavigationTagsOrderingConfiguration;

	@Override
	public int getTabOrderIndexForPage(Page page) {
		if (page == null) {
			throw new NullPointerException("page may not be null");
		}
		String navTitle = page.getNavigationTitle();

		if (navTitle == null) {
			return StringUtils.INDEX_NOT_FOUND;
		}
		navTitle = StringUtils.strip(navTitle).toLowerCase();

		List<String> tabs = Arrays.asList(
				StringUtils.stripAll(StringUtils.split(StringUtils.lowerCase(this.getStandardTabsOrdering()), ',')));

		return tabs.indexOf(navTitle);
	}

	@Override
	public String getLanguageCodeForPage(Page page) {
		String result = "";
		if (page == null) {
			throw new NullPointerException("page cannot be null");
		}
		try {
			Node node = page.adaptTo(Node.class);
			List<String> languageWithCountryCodeList = Arrays
					.asList(StringUtils.stripAll(StringUtils.split(this.getAnalyticsPagename(), ',')));
			List<String> languageAndCountryCodeList = new ArrayList<>();
			for (String temp : languageWithCountryCodeList) {
				languageAndCountryCodeList.add(StringUtils.substringBefore(temp, "/"));
				languageAndCountryCodeList.add(StringUtils.substringAfter(temp, "/"));
			}
			if (node != null) {
				result = extractMatchingLanguageCode(node, languageAndCountryCodeList);
			}
		} catch (RepositoryException e) {
			log.error("RepositoryException while getting language code from OSGi: ", e);
		}
		return result;
	}

	private String extractMatchingLanguageCode(Node node, List<String> languageAndCountryCodeList)
			throws RepositoryException {
		String langCode = "";
		Node parentNode = node;
		while (langCode.isEmpty() || langCode.equalsIgnoreCase(null)) {
			for (int i = 1; i < languageAndCountryCodeList.size(); i = i + 2) {
				if (parentNode.getName().equals(languageAndCountryCodeList.get(i - 1))) {
					langCode = languageAndCountryCodeList.get(i);
					break;
				}
			}
			parentNode = parentNode.getParent();
			if (("content").equals(parentNode.getName())) {
				break;
			}

		}
		return langCode;
	}

	@Override
	public String getPageLanguage(Page page) {
		String result = "";
		if (page == null) {
			throw new NullPointerException("page cannot be null");
		}
		try {
			Node node = page.adaptTo(Node.class);
			List<String> languageWithCountryCodeList = Arrays
					.asList(StringUtils.stripAll(StringUtils.split(this.getAnalyticsPagename(), ',')));
			List<String> languageAndCountryCodeList = new ArrayList<>();
			for (String temp : languageWithCountryCodeList) {
				languageAndCountryCodeList.add(StringUtils.substringBefore(temp, "/"));
				languageAndCountryCodeList.add(StringUtils.substringAfter(temp, "/"));
			}
			if (node != null) {
				result = extractMatchingLanguage(node, languageAndCountryCodeList);
			}
		} catch (RepositoryException e) {
			log.error("RepositoryException while getting language code from OSGi: ", e);
		}
		return result;
	}

	private String extractMatchingLanguage(Node node, List<String> languageAndCountryCodeList)
			throws RepositoryException {
		String result = "";
		Node parentNode = node;
		while (result.isEmpty() || result.equalsIgnoreCase(null)) {
			for (int i = 1; i < languageAndCountryCodeList.size(); i = i + 2) {
				if (parentNode.getName().equals(languageAndCountryCodeList.get(i - 1))) {
					return parentNode.getName();
				}
			}
			parentNode = parentNode.getParent();
			if (("content").equals(parentNode.getName())) {
				break;
			}
		}
		return result;
	}

	/**
	 * This method accepts the language code as a parameter and returns the domain
	 * from osgi configurations.
	 * 
	 * @param languageCode
	 * @return Domain name associated for the given language code
	 */
	@Override
	public String getDomainFromLanguageCode(String languageCode) {
		String domainName = null;
		try {
			if (!StringUtils.isEmpty(languageCode)) {
				List<SeoUrlTagging> domainConfig;
				if (null != factoryConfigs) {
					domainConfig = factoryConfigs.getConfigs();
					for (SeoUrlTagging seoUrlTagging : domainConfig) {
						if (!StringUtils.isEmpty(seoUrlTagging.getContentPath())
								&& !StringUtils.isEmpty(seoUrlTagging.getDomainName())
								&& seoUrlTagging.getContentPath().contains(languageCode)) {
							domainName = seoUrlTagging.getDomainName();
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Error getting domain name from language code due to " , e);
		}

		return domainName;
	}

	@Override
	public String getStandardTabsOrdering() {
		return standardTabsOrdering;
	}

	@Activate
	@Modified
	protected void activate(ProductsNavigationTabsOrderingConfiguration config

			) {
		this.productsNavigationTagsOrderingConfiguration = config; 
		
		readProperties(config);
	}
	
	
	private void readProperties(ProductsNavigationTabsOrderingConfiguration properties) {
		this.applicationStandardTabsOrdering = properties.applicationStandardTabsOrdering();
		this.standardTabsOrdering = properties.standardTabsOrdering();
		this.analyticsPagename = properties.analyticsPagename();
		this.adobeHelpLink = properties.adobeHelpLink();
	}

	@Override
	public String getAnalyticsPagename() {
		return analyticsPagename;
	}

	public void setAnalyticsPagename(String analyticsPagename) {
		this.analyticsPagename = analyticsPagename;
	}

	public void setStandardTabsOrdering(String standardTabsOrdering) {
		this.standardTabsOrdering = standardTabsOrdering;
	}

	@Override
	public String getApplicationStandardTabsOrdering() {
		return applicationStandardTabsOrdering;
	}

	public void setApplicationStandardTabsOrdering(String applicationStandardTabsOrdering) {
		this.applicationStandardTabsOrdering = applicationStandardTabsOrdering;
	}

	@Override
	public String getCustomAdobeHelpLink() {
		return adobeHelpLink;
	}

	public void setAdobeHelpLink(String adobeHelpLink) {
		this.adobeHelpLink = adobeHelpLink;
	}

}