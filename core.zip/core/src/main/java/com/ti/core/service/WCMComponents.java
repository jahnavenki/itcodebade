package com.ti.core.service;

import java.util.Date;

import com.ti.core.models.assets.EpodVariantMetadata;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;

/**
 * Service Interface to interact with WCM Components service.
 *
 * @author Andy Doerr
 */
public interface WCMComponents {

	/**
	 * Get featured literature.
	 *
	 * @param litnum
	 *            Literature Number
	 * @return String
	 */
	String getFeaturedliterature(String litnum, String language);

	/**
	 * Get featured literature.
	 *
	 * @param familyId
	 *            Family ID
	 * @param language
	 *            Language Code
	 *
	 * @return String
	 */
	String getProductFamily(String familyId, String language);

	/**
	 * Get Silo Family.
	 *
	 * @param language
	 *            Language Code
	 * @return String
	 */
	String getSilo(String language);

	/**
	 * Get featured literature.
	 *
	 * @param familyId
	 *            Family Id
	 * @param language
	 *            Language Code
	 * @return String
	 */
	String getProductTechDocCategories(String familyId, String language);

	/**
	 * Gets the all doc categories.
	 *
	 * @return the all doc categories
	 */
	String getAllDocCategories();

	/**
	 * Get all product service data in one request. Will store data on current
	 * request to make sure request is only made once.
	 *
	 * @param request
	 *            request object to save response data on
	 * @param familyId
	 *            the family id to pull data for
	 * @param language
	 *            Language Code
	 * @return returns a json object
	 */
	JSONObject getAllProductService(SlingHttpServletRequest request, int familyId, String language);

	/**
	 * This method will fetch all the literatures by Document Types selected.
	 * Only 3 per document type
	 *
	 * @param documentTypes
	 * @param familyId
	 * @param language
	 *            Language Code
	 * @param isFamily
	 * @return
	 */
	String getLiteraturesByDocumentType(String documentTypes, String familyId, String language, boolean isFamily);

	/**
	 * This method will fetch all the literatures by count
	 *
	 * @param count
	 * @param familyId
	 * @param documentType
	 * @param language
	 *            Language Code
	 * @param isFamily
	 * @return
	 */
	String getLiteraturesByCount(String count, String familyId, String documentType, String language, boolean isFamily);

	/**
	 * This method will fetch all the literatures by search term
	 *
	 * @param searchTerm
	 * @param familyId
	 * @param documentType
	 * @param count
	 * @param language
	 * @param isFamily
	 * @return
	 */
	String getLiteraturesBySearchTerm(String searchTerm, String familyId, String documentType, String count,
			String language, boolean isFamily);

	/**
	 * This method will fetch all the tools and software listings based on tool
	 * type selected
	 *
	 * @param compVariationId
	 * @param familyId
	 * @param toolTypeId
	 * @param sortColumn
	 * @param sortType
	 * @return
	 */
	String getToolsAndSoftwareListings(String familyId, String toolTypeId, String sortColumn, String sortType,
			String language);

	/**
	 * This will return the default document categories that are configured
	 *
	 * @return String
	 */
	String getDefaultDocumentCategories();

	/**
	 * This will return the application home page url that are configured
	 *
	 * @return String
	 */
	String getApphomepageurl();

	/**
	 * @param applicationId
	 * @param language
	 *            Language Code
	 * @return
	 */
	String getProductTechDocCategoriesApplication(String applicationId, String language);

	/**
	 * @param request
	 * @param applicationId
	 * @param language
	 *            Language Code
	 * @return
	 */
	JSONObject getAllApplicationService(SlingHttpServletRequest request, int applicationId, String language);

	/**
	 *
	 * @param applicationId
	 * @param language
	 * @return
	 */
	JSONObject getAllApplicationService(int applicationId, String language);

	/**
	 * @param request
	 * @param language
	 * @return
	 */
	JSONObject getApplicationListService(SlingHttpServletRequest request, String language);

	/**
	 * @param applicationId
	 * @param language
	 * @return
	 */
	String getApplicationTechDocCategories(String applicationId, String language);

	/**
	 * Returns the recommended apps for the family id
	 *
	 * @param familyId
	 * @param language
	 * @return
	 */
	String getRecommendedAppsForProductFamily(String familyId, String language);

	/**
	 * Gets the boomi silo families.
	 *
	 * @return the boomi silo families
	 */
	JSONArray getBoomiSiloFamilies();

	/**
	 * Gets the boomi product family all.
	 *
	 * @param familyId
	 *            the family id
	 * @return the boomi product family all
	 */
	JSONArray getBoomiProductFamilyAll(String familyId);

	/**
	 * Gets the boomi product family GPNs.
	 *
	 * @param familyId
	 *            the family id
	 * @return the boomi product family GPNs
	 */
	JSONArray getBoomiProductFamilyGPNs(String familyId);

	/**
	 * Gets the boomi tool type.
	 *
	 * @return the boomi tool type
	 */
	JSONArray getBoomiToolType();

	/**
	 * Gets the boomi tool type TPNs.
	 *
	 * @param toolTypeId
	 *            the tool type id
	 * @return the boomi tool type TPNs
	 */
	JSONArray getBoomiToolTypeTPNs(String toolTypeId);

	/**
	 * Gets the boomi literature category listing.
	 *
	 * @return the boomi literature category listing
	 */
	JSONArray getBoomiLiteratureCategoryListing();

	/**
	 * Gets the boomi application market.
	 *
	 * @return the boomi application market
	 */
	JSONArray getBoomiApplicationMarket();

	/**
	 * Gets the boomi application sector.
	 *
	 * @param marketid
	 *
	 * @return the boomi application sector
	 */
	JSONArray getBoomiApplicationSector(String marketid);

	/**
	 * Gets the boomi application category.
	 *
	 * @param sectorId
	 *
	 * @return the boomi application category
	 */
	JSONArray getBoomiApplicationCategory(String sectorId);

	/**
	 * Gets the boomi application end equipments
	 *
	 * @param sectorId
	 *
	 * @param webcategoriesId
	 *
	 * @return the boomi application end equipments
	 */
	JSONArray getBoomiApplicationEndEquipments(String sectorId, String webcategoriesId);

	/**
	 * Get Tool OPN Details.
	 *
	 * @param opn
	 *            Orderable Part Number
	 * @param language
	 *            Language Code
	 *
	 * @return jsonObject
	 */
	String getToolOpnService(SlingHttpServletRequest request, String opn, String language);

	/**
	 * Get Supply Frame URL.
	 *
	 * @return String
	 */
	String getSupplyFrameUrlDomain();

	/**
	 * Get Tool Part Details.
	 *
	 * @param toolPartNumber
	 *            Tool Part Number
	 * @param language
	 *            Language Code
	 *
	 * @return jsonObject
	 */
	String getToolDetailService(SlingHttpServletRequest request, String toolPartNumber, String language);

	/**
	 * Get default trending table data from JACK.
	 *
	 * @param language
	 *            Language Code
	 *
	 * @return JSONArray
	 */
	String getJackDefaultTrendingData(String language);

	String getPercolateUserlist();

	JSONObject getBoomildap(String userid);

	/**
	 * Get Featured Product Details
	 *
	 * @param gpn
	 *            Product Generic Part Number
	 * @param language
	 *            Locale / Language Code (en-US, zh-CN, ja-JP, de-DE, etc)
	 *
	 * @return JSONObject
	 */
	JSONObject getFeaturedProduct(String gpn, String language);

	JSONObject getHomePageFeaturedProducts(String language);

	JSONObject getProductFamilyNewProducts(String familyId, String language);

	EpodVariantMetadata getBoomiEpodVariantMetadata(String variant);

	void boomiDamDelete(String actionType, String username, String market, String orderablePartNumber, String genericPartNumber, String packageVariant, Date deletedTimestamp, String publishUrl, String assetType);

	/**
	 * Get emsg tool details. Calls the same web service as tool folders
	 * @param toolPartNumber
	 * @param language
	 * @return
	 */
	JSONObject getToolDetails(String toolPartNumber, String language);

	JSONObject getBrightcoveVideoMetaData(String videoId);

	JSONObject getBrightcoveVideoSourceUrl(String videoId);

	void updateBrightcoveVideo(String videoId, JSONObject json);
}
