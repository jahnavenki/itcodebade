package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.ValueMap;
import com.ti.core.util.LanguageUtils;

public class ProductTeaser extends WCMUsePojo {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private String imgAlt;
	private String lid;
	private String nav;
	private String designDevTitle;
	private String genericTitle;

	public String getImgAlt() {
		return imgAlt;
	}
	public String getLid() {
		return lid;
	}

	public String getNav() {
		return nav;
	}
	public String getDesignDevTitle() {
		return designDevTitle;
	}
	public String getGenericTitle() {
		return genericTitle;
	}


	@Override
	public void activate() {
		try {
			String imgSrc = "/content/dam/ticom/images/icons/illustrative-icons/products/processor-chip-icon.png";
			final ResourceResolver resourceResolver = getResourceResolver();
			final Resource img = resourceResolver.resolve(imgSrc);
			final Asset asset = img.adaptTo(Asset.class);
			LanguageUtils langUtils = new LanguageUtils(getRequest());
			if(null != asset) {
				imgAlt = asset.getMetadataValue("dc:title");
			}
			ValueMap properties = getProperties();
			String chooseVariation=properties.get("chooseVariation", "");
			if(chooseVariation.equals("designAndDevProductsTeaser")){
				String title=properties.get("title", "");
				if(null!=title && title.equals("designDevTools")){
					lid="design & development tools";
				}
				else if(null!=title && title.equals("softwareDevTools")){
					lid="software development tools";
				}
				else if(null!=title && title.equals("hardwareDevTools")){
					lid="hardware development tools";
				}
				String ctaLabel=properties.get("buttonCtaLabel", "");
				if(null!=ctaLabel && ctaLabel.equals("findYourProduct")){
					nav="Find your product";
				}
				else if(null!=ctaLabel && ctaLabel.equals("viewAllProducts")){
					nav="View all products";
				}
				String authoredTitle=langUtils.getI18nStr(title);
				designDevTitle = langUtils.getI18nStr("Find product-specific {}", authoredTitle);
			}else{
				String titleVar2=properties.get("titleVar", "");
				genericTitle = langUtils.getI18nStr("View all {}", titleVar2);
			}
		} catch (Exception e) {
			log.error("Error setting metadata: ", e);
		}
	}
}
