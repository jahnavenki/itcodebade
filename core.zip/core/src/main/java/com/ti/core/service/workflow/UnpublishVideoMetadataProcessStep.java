package com.ti.core.service.workflow;

import java.util.Calendar;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.tagging.TagManager;
import com.ti.core.util.AssetUtils;


@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set video metadata on unpublish.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Unpublish Video Metadata" })
public class UnpublishVideoMetadataProcessStep implements WorkflowProcess {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Override
    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
        try {
            log.debug("Starting Unpublish Workflow");
            final var workflowData = item.getWorkflowData();
            final var payload = workflowData.getPayload().toString();
            if(!payload.endsWith(".mp4")) {
				session.terminateWorkflow(item.getWorkflow());
				return;
			}
            final var resourceResolver = session.adaptTo(ResourceResolver.class);
            if (null == resourceResolver) throw new NullPointerException("resourceResolver");
            final var resource = resourceResolver.getResource(payload);
            if (null == resource) return;

            Resource jcrFieldNode = resource.getChild("jcr:content");
            ModifiableValueMap jcrFieldMap = null;
            if(jcrFieldNode != null) {
                jcrFieldMap = jcrFieldNode.adaptTo(ModifiableValueMap.class);
            }
            if(jcrFieldMap != null) {
                jcrFieldMap.put("dam:unpublished", Calendar.getInstance());
            }

            Resource brcCustomFieldNode = resource.getChild("jcr:content/metadata/brc_custom_fields");
            ModifiableValueMap brcFieldMap = null;
            if (brcCustomFieldNode != null) {
                brcFieldMap = brcCustomFieldNode.adaptTo(ModifiableValueMap.class);
            }
            if (brcFieldMap != null) {
                brcFieldMap.put("sitecode", "");
                brcFieldMap.put("taxonomy", "");
                brcFieldMap.put("ticomids", "");
            }
            
            final var metadata = AssetUtils.getModifiableMetadata(resource);
            metadata.put("dam:status", "unpublished");

            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            if (null == tagManager) {
                throw new NullPointerException("tagManager");
            }
            String[] tags = metadata.get("brc_tags", String[].class);
            if (null != tags && tags.length > 0) {
                String youtubeArchive = tagManager.resolve("youtube_archive").getTitle();
                String youtube = "youtube";
                for (int i = 0; i < tags.length; i++) {
                    if (youtube.equals(tags[i])) {
                        tags[i] = youtubeArchive;
                    }
                }    
                metadata.put("brc_tags",tags);        
            } 
            resourceResolver. commit();
        } catch (Exception e) {
            log.error("Error occurred in UnpublishedVideoMetadataProcessStep", e);
        }
    }
}