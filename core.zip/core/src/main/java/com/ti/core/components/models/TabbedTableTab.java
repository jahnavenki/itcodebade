package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = { SlingHttpServletRequest.class, Resource.class },
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class TabbedTableTab {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	@ValueMapValue
	private String title;

	@PostConstruct
	public void init(){
		try {
			title = StringUtils.defaultString(title);
		} catch (Exception e) {
			log.error("Exception in TabbedTableTab", e);
		}
	}

	public String getTitle() {
		return title;
	}
}
