package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DrChapterNavigation extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(getClass());
	private String pageTitle;

	public String getPageTitle() {
		return pageTitle;
	}

	private Resource findResource(Resource root, String resourceType) {
		if (root.isResourceType(resourceType)) return root;
		if (root.hasChildren()) {
			for (final var child : root.getChildren()) {
				final var res = findResource(child, resourceType);
				if (null != res) return res;
			}
		}
		return null;
	}

	@Override
	public void activate() {
		try {
			final var resource = getResourcePage().adaptTo(Resource.class);
			final var child = findResource(resource, "ti/components/designDevelopmentPageHeading");
			if (null != child) {
				final var valueMap = child.adaptTo(ValueMap.class);
				pageTitle = valueMap.get("headline", String.class);
			}
		} catch (Exception e) {
			log.error("Exception:", e);
		}
	}
}
