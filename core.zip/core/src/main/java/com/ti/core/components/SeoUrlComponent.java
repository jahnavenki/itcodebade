package com.ti.core.components;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ApiPortalService;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.util.Constants;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;

/**
 * Class SeoUrlComponent WCMUsePojo.
 *
 */
public class SeoUrlComponent extends WCMUsePojo {

    private static final String REGEX_PATH_ROOT = "(^/content/texas-instruments/[^/]*)";
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    private List<SeoUrlTagging> listConfig;
    private String canonicalUrl;
    private static final String ENGLISH_CODE = "en-us";
    private static final String DEFAULT_ALTERNATE_URL_CODE = "en";
    private static final String ZH_CN_LANG_CODE = "zh-cn";
    private static final String ZH_CN_LANG_CODE_EXPECTED = "zh-Hans";
    private static final String ZH_TW_LANG_CODE = "zh-tw";
    private static final String ZH_TW_LANG_CODE_EXPECTED = "zh-Hant";
    private static final String DEFAULT_LANG_CODE = "x-default";
    private static final String HTTP = "http://";
    private static final String HTTPS = "https://";
    private static final String HOMEPAGE_PATH = "/homepage";

    Map<String, String> urlMap = new HashMap<>();

    public Map<String, String> getUrlMap() {
        return urlMap;
    }

    public void setUrlMap(Map<String, String> urlMap) {
        this.urlMap = urlMap;
    }

    @Override
    public void activate() {
        ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                .getService(ProductNavigationTabsOrdering.class);
        ApiPortalService apiPortalService = getSlingScriptHelper().getService(ApiPortalService.class);
        SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
        String pagePath = getCurrentPage().getPath();
        String commonPagePath = pagePath.replaceFirst(REGEX_PATH_ROOT, StringUtils.EMPTY);

        if (null != factoryConfigs) {
            listConfig = factoryConfigs.getConfigs();

            /**
             * Construct Canonical Url
             */
            try {
                /**
                 * Adding HTTPS to the domain fetched from OSGI config.
                 */
                canonicalUrl = PathBrowserHelper.addHtmlIfContentPath(this.getResourceResolver(), pagePath);

                // Return url with https.
                canonicalUrl = getHttpsUrl(canonicalUrl);

                /**
                 * Construct Alternate Urls.
                 */
                ResourceResolver resolver = getRequest().getResourceResolver();
                for (SeoUrlTagging seoUrlTagging : listConfig) {
                    if (!StringUtils.isEmpty(seoUrlTagging.getContentPath())
                            && !StringUtils.isEmpty(seoUrlTagging.getDomainName())) {

                        String targetPath = seoUrlTagging.getContentPath() + commonPagePath;
                        boolean isResourceExist = checkIsResourceExist(targetPath, resolver);
                        if (isResourceExist && tabsService != null) {
                            Page languagePageObject = getSpecificPage(resolver, targetPath);
                            String languageCode = tabsService.getPageLanguage(languagePageObject);

                            if (pagePath.contains(languageCode) && Constants.LANG_EN_CN.contains(languageCode)) {
                                if (commonPagePath.equalsIgnoreCase(HOMEPAGE_PATH)) {
                                    canonicalUrl = seoUrlTagging.getDomainName();
                                    canonicalUrl = getHttpsUrl(canonicalUrl);
                                }
                            }

                            /**
                             * Adding HTTPS to the domain fetched from OSGI
                             * config.
                             */
                            String alternateUrl;
                            if (null != apiPortalService && apiPortalService.isSecureUrl(targetPath)) {
                                alternateUrl = apiPortalService.getUrl(targetPath);
                            } else {
                                alternateUrl = PathBrowserHelper.addHtmlIfContentPath(resolver, targetPath);
                            }
                            alternateUrl = getHttpsUrl(alternateUrl);
                            addAlternateUrlToMap(languageCode, alternateUrl, seoUrlTagging.getDomainName(),
                                    commonPagePath);
                            /**
                             * Return url with https.
                             */

                        }
                    }
                }
                addDefaultUrlToMap();

            } catch (Exception e) {
                log.error("Error generating SEO Urls due to ", e);
            }
        }
    }

    /**
     * Add alternate urls to Map to be used on html for iteration.
     *
     * @param languageCode valid language code
     * @param alternateUrl alternate url containing host and content path
     */
    private void addAlternateUrlToMap(String languageCode, String alternateUrl, String domain, String commonPagePath) {
        String mapLang;
        mapLang = languageCode;
        String altUrl = null;
        if (ENGLISH_CODE.equals(languageCode)) {
            mapLang = DEFAULT_ALTERNATE_URL_CODE;
        } else if (ZH_CN_LANG_CODE.equals(languageCode)) {
            mapLang = ZH_CN_LANG_CODE_EXPECTED;
        } else if (ZH_TW_LANG_CODE.equals(languageCode)) {
            mapLang = ZH_TW_LANG_CODE_EXPECTED;
        } else {
            mapLang = StringUtils.substringBefore(mapLang, "-");
        }

        if (commonPagePath.equalsIgnoreCase(HOMEPAGE_PATH) && Constants.LANG_EN_CN.contains(languageCode)) {
            altUrl = getHttpsUrl(domain);
        } else {
            altUrl = alternateUrl;
        }
        urlMap.put(mapLang, altUrl);

    }

    /**
     * Add default alternate url to Map to be used on html for iteration.
     *
     */
    private void addDefaultUrlToMap() {
        String mapLang;
        mapLang = DEFAULT_LANG_CODE;
        String altUrl = null;
        altUrl = urlMap.get(DEFAULT_ALTERNATE_URL_CODE);
        if (altUrl != null) {
            urlMap.put(mapLang, altUrl);
        }
    }

    /**
     * This method accepts the url as a parameter, adds https irrespective it
     * has https or not.
     *
     * @param url url containing host and content path
     * @return url with https
     */
    private String getHttpsUrl(String url) {
        if (!url.contains(HTTP) && !url.contains(HTTPS)) {
            return HTTPS + url;
        } else {
            return URLHelper.toHttps(url);
        }
    }

    /**
     * Return Page Object by PageURI.
     *
     * @param resourceResolver ResourceResolver
     * @param pageUri page URI
     * @return Page Object
     */
    public Page getSpecificPage(ResourceResolver resourceResolver, String pageUri) {
        Resource resource = resourceResolver.resolve(pageUri);
        return resource.adaptTo(Page.class);

    }

    /**
     * Method is used to check if resource exist for the given path.
     *
     * @param resourcePath Page Path for a language specified in osgi
     * configuration
     * @param resolver Resource Resolver Object
     * @return boolean value
     */
    private boolean checkIsResourceExist(String resourcePath, ResourceResolver resolver) {
        try {
            Resource resource = resolver.getResource(resourcePath);
            if (resource != null) {
                return true;
            }
        } catch (Exception e) {
            log.error("Error while testing if resource exist due to ", e);
        }
        return false;
    }

    /**
     * Return the configuration list.
     *
     * @return list of SeoUrlTagging containing configurations of domain name
     * and content path.
     */
    public List<SeoUrlTagging> getListConfig() {
        return listConfig;
    }

    /**
     * Returns the configuration url.
     *
     * @return configUrl
     */
    public String getCanonicalUrl() {
        return canonicalUrl;
    }

    /**
     * Setting the Canonical Url.
     *
     * @param canonicalUrl current url.
     */
    public void setCanonicalUrl(String canonicalUrl) {
        this.canonicalUrl = canonicalUrl;
    }

}
