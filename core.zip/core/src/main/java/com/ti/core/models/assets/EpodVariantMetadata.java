package com.ti.core.models.assets;

public class EpodVariantMetadata {
	public EpodVariantMetadata() {}

	public EpodVariantMetadata(boolean status, Integer pinCount, String packageGroup, String packageDesignator, String variant, String variation) {
		this.status = status;
		this.pinCount = pinCount;
		this.packageGroup = packageGroup;
		this.packageDesignator = packageDesignator;
		this.variant = variant;
		this.variation = variation;
	}

	private boolean status;
	private Integer pinCount;
	private String packageGroup;
	private String packageDesignator;
	private String variant;
	private String variation;

	public boolean getStatus() {
		return this.status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getPackageGroup() {
		return this.packageGroup;
	}

	public void setPackageGroup(String packageGroup) {
		this.packageGroup = packageGroup;
	}

	public Integer getPinCount() {
		return this.pinCount;
	}

	public void setPinCount(Integer pinCount) {
		this.pinCount = pinCount;
	}

	public String getPackageDesignator() {
		return this.packageDesignator;
	}

	public void setPackageDesignator(String packageDesignator) {
		this.packageDesignator = packageDesignator;
	}

	public String getVariant() {
		return this.variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public String getVariation() {
		return this.variation;
	}

	public void setVariation(String variation) {
		this.variation = variation;
	}
}
