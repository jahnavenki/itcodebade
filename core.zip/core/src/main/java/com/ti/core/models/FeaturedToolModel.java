package com.ti.core.models;

public class FeaturedToolModel {
    private String toolPartNumber;
    private String toolTitle;
    private String enToolTitle;
    private String toolImage;
    private String toolDescription;
    private String toolCategory;
    private String toolURL;
    private boolean thirdParty;
    private String thirdPartyCompany;
    private String thirdPartyCompanyURL;

    public String getToolPartNumber() {
        return toolPartNumber;
    }
    public void setToolPartNumber(String toolPartNumber) {
        this.toolPartNumber = toolPartNumber;
    }
    public String getToolTitle() {
        return toolTitle;
    }
    public void setToolTitle(String toolTitle) {
        this.toolTitle = toolTitle;
    }
    public String getEnToolTitle() {
        return enToolTitle;
    }
    public void setEnToolTitle(String enToolTitle) {
        this.enToolTitle = enToolTitle;
    }
    public String getToolImage() {
        return toolImage;
    }
    public void setToolImage(String toolImage) {
        this.toolImage = toolImage;
    }
    public String getToolDescription() {
        return toolDescription;
    }
    public void setToolDescription(String toolDescription) {
        this.toolDescription = toolDescription;
    }
    public String getToolCategory() {
        return toolCategory;
    }
    public void setToolCategory(String toolCategory) {
        this.toolCategory = toolCategory;
    }
    public String getToolURL() {
        return toolURL;
    }
    public void setToolURL(String toolURL) {
        this.toolURL = toolURL;
    }
    public boolean isThirdParty() {
        return thirdParty;
    }
    public void setThirdParty(boolean thirdParty) {
        this.thirdParty = thirdParty;
    }
    public String getThirdPartyCompany() {
        return thirdPartyCompany;
    }
    public void setThirdPartyCompany(String thirdPartyCompany) {
        this.thirdPartyCompany = thirdPartyCompany;
    }
    public String getThirdPartyCompanyURL() {
        return thirdPartyCompanyURL;
    }
    public void setThirdPartyCompanyURL(String thirdPartyCompanyURL) {
        this.thirdPartyCompanyURL = thirdPartyCompanyURL;
    }
    
}
