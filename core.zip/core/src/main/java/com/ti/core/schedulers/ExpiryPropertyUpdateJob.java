package com.ti.core.schedulers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.ti.core.util.WorkflowUtils;

@Component(immediate = true, service = Job.class)
@Designate(ocd = ExpiryPropertyUpdateJob.Config.class)
public class ExpiryPropertyUpdateJob implements Job {
    private static final Logger log = LoggerFactory.getLogger(ExpiryPropertyUpdateJob.class);

    @Reference
    private Scheduler scheduler;

    @Reference
    private ResourceResolverFactory resolverFactory;

    @ObjectClassDefinition(name = "TI DAM Expired Asset Update", description = "TI DAM Expired Asset Update")
    public @interface Config {
        @AttributeDefinition(type = AttributeType.STRING, name = "cqDamExpiryNotificationSchedulerTimebasedRule", description = "Regular expression for time based Scheduler. Eg: '0 0 0 * * ?'. The example expression triggers the Job @ 00 hrs. This expression get picked if Time Based Scheduler is true (cqDamExpiryNotificationSchedulerTimebasedRule)")
        String cqDamExpiryNotificationSchedulerTimebasedRule() default "0 0 0 * * ?"; // cqDamExpiryNotificationSchedulerTimebasedRule
    }

    private ResourceResolver resourceResolver;

    public void execute(final JobContext arg0) {
        try {
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            this.resourceResolver = this.resolverFactory.getServiceResourceResolver(param);
            updateExpiredAssets();
        } catch (Exception e) {
            log.error("Error in execute.", (Throwable) e);
        } finally {
            if (null != this.resourceResolver) {
                this.resourceResolver.close();
            }
        }
    }

    private void updateExpiredAssets() {
        String queryString = "SELECT p.* FROM [dam:Asset] AS p WHERE ISDESCENDANTNODE(p, '/content/dam/ticom')";
        Iterator<Resource> iterator = this.resourceResolver.findResources(queryString, javax.jcr.query.Query.JCR_SQL2);
        while (iterator.hasNext()) {
            Resource assetJcrRes = iterator.next().getChild(JcrConstants.JCR_CONTENT);
            WorkflowUtils.updateExpiredAssetProperty(assetJcrRes, this.resourceResolver);
        }
    }

	@SuppressWarnings("deprecation")
	protected void activate(Config config) throws Exception {
		try {
			final String expression = config.cqDamExpiryNotificationSchedulerTimebasedRule();
			this.scheduler.addJob(ExpiryPropertyUpdateJob.class.getName(), this, null, expression, false);
		} catch (Exception e) {
			log.error("Error in activate.", e);
		}
	}

	@SuppressWarnings("deprecation")
	protected void deactivate(final ComponentContext componentContext) {
		log.debug("Deactivating the expiry notification scheduler");
		this.scheduler.removeJob(ExpiryPropertyUpdateJob.class.getName());
	}
}