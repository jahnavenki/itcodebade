package com.ti.core.service;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.PropertyType;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFactory;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;

/**
 * The Class UrlUpdateRulesProcessStep. This class will update the regional URL
 * mapping by taking URL pattern from TI URL Pattern configuration and replace
 * it with replacement pattern.
 * <p>
 * Also, this will publish the translated pages if manual publish flag is not
 * set.
 * 
 * @author p.palandurkar
 */


@Component(service = WorkflowProcess.class,immediate=true, property = {
"service.description=TI Translation Process step for URL updates rules.",
"chooser.label=TI Translation URL updates rules"})
public class UrlUpdateRulesProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private ResourceResolverFactory resourceFactory;
	private ResourceResolver resourceResolver;
	@Reference
	private TiUrlPatternConfigs config;
	@Reference
	ProductNavigationTabsOrdering tabsService;
	@Reference
	Replicator replicator;
	@Reference
	WCMComponents wcmComponents;

	private static final String JCR_CONTENT = "/jcr:content";
	private static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	private static final String REPOSITORY_EXCEPTION = "RepositoryException: {} ";
	private static final String MANUAL_PUBLISH = "manualPublish";
	private static final String SOURCE_PATH = "sourcePath";
	private static final String RESOURCE_TYPE = "cq:PageContent";
	private static final String PATH = "path";
	private static final String TYPE = "type";
	private static final String PROPERTY = "property";
	private static final String PROPERTY_OPERATION = "property.operation";
	private static final String PROPERTY_VALUE = "property.value";
	private static final String P_LIMIT = "p.limit";
	private static final String NT_UNSTRUCTURED = "nt:unstructured";
	private static final String EXISTS = "exists";
	private static final String TRANSLATED = "translated";
	public static final String DATA = "data";
	public static final String LIT_NUMBER = "literatureNumber";
	public static final String URL_PATTERN_KEY_LIT = "lit";
	public static final String ALPHA_REGEX_PATTERN = "^[a-zA-Z]*$";

	private List<String> sourcePathList = new ArrayList<>();

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap metadata) {
		try {
			setResolver();

			WorkflowData workflowData = item.getWorkflowData();
			String payload = workflowData.getPayload().toString();
			log.debug(">>>>>>>>>>>>> payload {}", payload);

			Session jcrSession = resourceResolver.adaptTo(Session.class);
			if (jcrSession != null) {
				SearchResult results = getResults(payload, jcrSession, SOURCE_PATH);

				setSourcePath(results);
				log.debug("setting tranlated property");
				for (String sourcePath : sourcePathList) {
					log.debug("sourcePath {}" ,  sourcePath);
					String sourcePathJcrContent = sourcePath.concat(JCR_CONTENT);
					setTranslatedProperty(sourcePathJcrContent);
					setAuthoredtiPageName(sourcePathJcrContent);
					log.debug("setTranslatedProperty done");
					SearchResult components = getResults(sourcePathJcrContent, jcrSession, RESOURCE_TYPE);
					updateUrl(sourcePath, components);
				}
				log.debug("Search Results  {}" , results );
				log.debug("sourcePathList {}" , sourcePathList );
				jcrSession.save();
			}
		} catch (Exception e) {
			log.error("Exception: {}", e);
		}
	}

	private void publishPages(String payload, Session jcrSession, String sourcePath) {
		String payloadJcrContentPath = payload.substring(0, payload.indexOf(JCR_CONTENT) + JCR_CONTENT.length());
		Resource pageResource = resourceResolver.getResource(payloadJcrContentPath);
		log.debug("payloadJcrContentPath >>>>>>>>>>>>>>>>>> {}", payloadJcrContentPath);
		try {
			if (pageResource != null) {
				Node node = pageResource.adaptTo(Node.class);
				if (node != null && !node.hasProperty(MANUAL_PUBLISH)) {
					log.debug("node has no manual prop >>>>>>>>>>>>>>>>>> {}", node.hasProperty(MANUAL_PUBLISH));
					replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE, sourcePath);
				}
			}
		} catch (ReplicationException e) {
			log.error("ReplicationException: {} ", e);
		} catch (RepositoryException e) {
			log.error(REPOSITORY_EXCEPTION  , e);
		}
	}

	private void updateUrl(String sourcePath, SearchResult components) {
		try {
			for (Hit hit : components.getHits()) {
				String path = hit.getPath();
				log.debug("path >>>>>>>>>>>>>>>>>> {}", path);

				Node node = hit.getResource().adaptTo(Node.class);
				if (node != null) {
					PropertyIterator properties = node.getProperties();
					iterateProperties(sourcePath, node, properties);
				}
			}
		} catch (RepositoryException e) {
			log.error(REPOSITORY_EXCEPTION, e);
		}
	}

	private void iterateProperties(String sourcePath, Node node, PropertyIterator properties) {
		try {
			while (properties.hasNext()) {
				Property property = properties.nextProperty();
				if (property.getType() == PropertyType.STRING) {
					checkAndReplaceUrl(sourcePath, node, property);
				}
			}
		} catch (RepositoryException e) {
			log.error(REPOSITORY_EXCEPTION , e);
		}
	}

	private void checkAndReplaceUrl(String sourcePath, Node node, Property property) {
		try {
			String propertyValue = null;
			String propertyValueUpdated = null;
			Session session = resourceResolver.adaptTo(Session.class);
			if (session != null) {
				if (property.isMultiple()) {
					Value vs[] = new Value[0];
					List<Value> multivalueList = new ArrayList<>();
					boolean multivaluechanged = false;
					for (Value propValue : property.getValues()) {
						if (propValue != null) {
							propertyValue = propValue.toString();
							propertyValueUpdated = updateProperty(sourcePath, propertyValue);
							if (StringUtils.isNotEmpty(propertyValueUpdated)) {
								ValueFactory valueFactory = session.getValueFactory();
								Value newValue = valueFactory.createValue(propertyValueUpdated);
								multivalueList.add(newValue);
								multivaluechanged = true;
							} else {
								multivalueList.add(propValue);
							}
						}
					}

					if (multivaluechanged) {
						Value[] finalValues = (Value[]) multivalueList.toArray(vs);
						node.setProperty(property.getName(), finalValues);
						node.getSession().refresh(true);
						node.getSession().save();
					}

				} else {
					propertyValue = property.getValue().getString();
					propertyValueUpdated = updateProperty(sourcePath, propertyValue);
					if (StringUtils.isNotEmpty(propertyValueUpdated)) {
						log.debug("Source path {} Node path {}" , sourcePath,node.getPath() );
						log.debug("Updating property {} with value {}" , property.getName(),propertyValueUpdated );
						node.setProperty(property.getName(), propertyValueUpdated);
						node.getSession().refresh(true);
						node.getSession().save();
					}
				}
			}
			log.debug("property Value >>>>>>>>>>>> {}", propertyValueUpdated);
		} catch (RepositoryException e) {
			log.error(REPOSITORY_EXCEPTION, e);
		}
	}

	private String updateProperty(String sourcePath, String propertyValue) {
		List<TiUrlPattern> configs = config.getConfigs();
		String propertyValueAssigned = propertyValue;
		String propertyValueUpdated = "";
		boolean valuechanged = false;
		String pageLanguageCode = "";
		log.debug("sourcePath >>>>>> {}", sourcePath);
		Resource pageResource = resourceResolver.getResource(sourcePath);
		if (pageResource != null && tabsService != null) {
			Page page = pageResource.adaptTo(Page.class);
			log.debug("tabsService.getPageLanguage(page) >>>>>>>>>> {}", tabsService.getPageLanguage(page));
			pageLanguageCode = tabsService.getPageLanguage(page);
		}
		for (TiUrlPattern cnfg : configs) {
			log.debug("Property Value >>>>>>>>>>>> {}", propertyValue);
			String urlPattern = cnfg.getUrlPattern();
			log.debug("url Pattern >>>>>>>>>> {}", urlPattern);
			// Special case for literature URL patterns: need to look up
			// regional Literature URL pattern from API instead of search and
			// replace uriPatterns.
			if ((URL_PATTERN_KEY_LIT).equals(cnfg.getKey())) {
				log.debug("key >>>>>>>>>> {}", cnfg.getKey());

				propertyValueUpdated = getRegionalProperty(pageLanguageCode, propertyValueAssigned, cnfg, sourcePath);
				log.debug(
						"Updated Property Value with Regional literature code from replace url with pattern >>>>>>>> {} ",
						propertyValueUpdated);
			} else {

				propertyValueUpdated = replaceUrlWithPattern(sourcePath, cnfg, propertyValueAssigned);
				log.debug("Updated Property Value with old literature code from replace url with pattern >>>>>>>> {} ",
						propertyValueUpdated);
			}
			if (StringUtils.isNotEmpty(propertyValueUpdated)) {
				propertyValueAssigned = propertyValueUpdated;
				log.debug("Updated Property Value with not empty check >>>>> {} ", propertyValueAssigned);
				valuechanged = true;
			}
		}
		if (valuechanged) {
			propertyValueUpdated = propertyValueAssigned;
			log.debug("Updated Property Value with Value changed >>>>> {} ", propertyValueUpdated);
		}

		log.debug("final updated value >>>>>>>>>>>> {}", propertyValueUpdated);
		return propertyValueUpdated;
	}

	private String replaceUrlWithPattern(String sourcePath, TiUrlPattern cnfg, String propertyValue) {
		String propertyValueUpdated = "";
		String pageLanguageCode = "";
		log.debug("sourcePath >>>>>> {}", sourcePath);
		Resource pageResource = resourceResolver.getResource(sourcePath);
		if (pageResource != null && tabsService != null) {
			Page page = pageResource.adaptTo(Page.class);
			log.debug("tabsService.getPageLanguage(page) >>>>>>>>>> {}", tabsService.getPageLanguage(page));
			pageLanguageCode = tabsService.getPageLanguage(page);
		}
		String urlPattern = cnfg.getUrlPattern();
		log.debug("url Pattern >>>>>>>>>> {}", urlPattern);
		String[] replacementPatterns = cnfg.getReplacementPatterns();
		if (StringUtils.isNotBlank(propertyValue)) {
			Pattern pattern = Pattern.compile(urlPattern);
			Matcher matcher = pattern.matcher(propertyValue);
			if (matcher.find()) {
				for (String replacementPattern : replacementPatterns) {
					log.debug("replacement pattern >>>>>>>>>> {}", replacementPattern);
					if (StringUtils.equalsIgnoreCase(pageLanguageCode,
							StringUtils.substringBefore(replacementPattern, "|"))) {
						propertyValueUpdated = propertyValue.replaceAll(urlPattern,
								StringUtils.substringAfter(replacementPattern, "|"));
						log.debug("propertyValueUpdated >>>>>>>>>> {}", propertyValueUpdated);
						return propertyValueUpdated;
					}
				}
			}
		}
		return propertyValueUpdated;
	}

	/**
	 * 
	 * This method does the following - 1. Initially matches all the substrings
	 * with the defined pattern 2. Get the replacement featured literature code
	 * from the existing literature number captured from the matcher group by
	 * calling the SOA service 3. Replace the regional literature number to the
	 * existing property value for all the matched substrings and perform URL
	 * stand and return that regional property value.
	 * 
	 * @param propertyValue
	 * @param pageLanguageCode
	 * @param cnfg
	 * @param sourcePath
	 * @param groupNumber
	 * @return
	 * 
	 * @author x0277261
	 */
	private String getRegionalPropertyValueWithUpdatedLiteratureCode(String propertyValue, String pageLanguageCode,
			TiUrlPattern cnfg, String sourcePath, int groupNumber) {
		String regionalPropertyValue = propertyValue;
		if (StringUtils.isNotBlank(regionalPropertyValue)) {
			log.debug("Old property Value - {}", regionalPropertyValue);
			Pattern pattern = Pattern.compile(cnfg.getUrlPattern());
			Matcher matcher = pattern.matcher(regionalPropertyValue);
			StringBuffer sb = new StringBuffer();
			while (matcher.find()) {
				String replacement = "";
				log.debug("groupNumber >>>>>>>>>> {}", cnfg.getGroupNumber());
				String litNum = matcher.group(groupNumber);
				// Special Case for URL Pattern6 to check if output string litno
				// contains atleast one numeric value
				if (StringUtils.isAlphanumeric(litNum) && !litNum.matches(ALPHA_REGEX_PATTERN)) {
					String regionalLitNum = litNum;
					String featuredLiterature = wcmComponents.getFeaturedliterature(regionalLitNum, pageLanguageCode);
					log.debug("Featured Literature - {}", featuredLiterature);
					JSONObject jsonLiterature;
					if (StringUtils.isNotBlank(featuredLiterature)) {
						try {
							jsonLiterature = new JSONObject(featuredLiterature);
							regionalLitNum = jsonLiterature.getString(LIT_NUMBER);
							log.debug("Regional Literature Number - {}", regionalLitNum);
						} catch (JSONException e1) {
							log.error("Exception occured in Json : {}", e1);
						}
					}

					// Fetch the First Seven characters from regional
					// lit number to exclude the revision details if regional
					// literature number length is greater than 7

					if (regionalLitNum.length() > 7) {
						regionalLitNum = regionalLitNum.substring(0, 7);
					}
					log.debug("Base Literature Number for Regional Literatures - {}", regionalLitNum);

						replacement = matcher.group(0).replaceAll(litNum, regionalLitNum.toLowerCase());
						log.debug("Replaced Property Value - {}", replacement);
						regionalPropertyValue = replaceUrlWithPattern(sourcePath, cnfg, replacement);
						matcher.appendReplacement(sb, regionalPropertyValue);
					
				}
			}
			matcher.appendTail(sb);
			if (StringUtils.isNotBlank(sb.toString())) {
				regionalPropertyValue = sb.toString();
			}
			log.debug("Updated Regional Property value - {}", regionalPropertyValue);

		}

		return regionalPropertyValue;
	}

	/**
	 * This method does the following - If PageLanguageCode is chinese/japanese
	 * it will call method getRegionalPropertyValueWithUpdatedLiteratureCode and
	 * fetches the regional property value. Else it will fetch
	 * propertyValueAssigned.
	 * 
	 * @param pageLanguageCode
	 * @param propertyValueAssigned
	 * @param cnfg
	 * @param sourcePath
	 * @return
	 * 
	 * @author x0277261
	 */
	private String getRegionalProperty(String pageLanguageCode, String propertyValueAssigned, TiUrlPattern cnfg,
			String sourcePath) {
		String propertyValueUpdated = "";
		String chineseLocale = Locale.CHINA.toString().toLowerCase().replace("_", "-");
		String japaneseLocale = Locale.JAPAN.toString().toLowerCase().replace("_", "-");

		if (chineseLocale.equalsIgnoreCase(pageLanguageCode) || japaneseLocale.equalsIgnoreCase(pageLanguageCode)) {
			String regionalPropertyValue = getRegionalPropertyValueWithUpdatedLiteratureCode(propertyValueAssigned,
					pageLanguageCode, cnfg, sourcePath, cnfg.getGroupNumber());

			if (StringUtils.isNotEmpty(regionalPropertyValue)) {
				propertyValueUpdated = regionalPropertyValue;
			}

		} else {
			propertyValueUpdated = propertyValueAssigned;
		}

		return propertyValueUpdated;
	}

	private void setTranslatedProperty(String sourcePath) {
		log.debug("inside sourcePath" + sourcePath);
		Resource pageResource = resourceResolver.getResource(sourcePath);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
		String timestamp = ZonedDateTime.now().format(formatter);

		try {
			if (pageResource != null) {
				Node node = pageResource.adaptTo(Node.class);
				if (node != null) {
					node.setProperty(TRANSLATED, timestamp);
					log.debug("translated property is set" + timestamp);
				}
			}
		} catch (Exception e) {
			log.error("Exception: {}", e);
		}

	}

	private void setAuthoredtiPageName(String sourcePath) {

		Resource pageResource = resourceResolver.getResource(sourcePath);
		String pageLanguageCode = "";
		String pageLanguage = "";

		try {
			if (pageResource != null) {
				Page page = pageResource.adaptTo(Page.class);
				if (tabsService != null) {
					pageLanguage = tabsService.getPageLanguage(page);
					if (pageLanguage != null) {
						pageLanguageCode = StringUtils.substringAfter(pageLanguage, "-").toLowerCase();
					}
				}
				Node node = pageResource.adaptTo(Node.class);
				if (node != null) {
					Property property = node.getProperty("tiPageName");
					String tiPageNamevalue = property.getValue().toString();
					if (tiPageNamevalue.toUpperCase().contains("-EN") && pageLanguageCode != null) {
						tiPageNamevalue = StringUtils.replace(tiPageNamevalue, "-en", "-" + pageLanguageCode)
								.replace("-EN", "-" + pageLanguageCode.toUpperCase());
					}
					if (tiPageNamevalue != null) {
						node.setProperty("tiPageName", tiPageNamevalue);
						log.debug("tipagename property is set" + tiPageNamevalue);
					}
				}
			}

		} catch (Exception e) {
			log.error("Exception: {}", e);
		}

	}

	private void setSourcePath(SearchResult results) {
		for (Hit hit : results.getHits()) {
			try {
				Node node = hit.getResource().adaptTo(Node.class);
				if (node != null) {
					Property property = node.getProperty(SOURCE_PATH);
					String sourcePath = property.getValue().toString();
					log.debug("sourcePath >>>>>>>>>> {}", sourcePath);
					sourcePathList.add(sourcePath);
				}
			} catch (RepositoryException e) {
				log.error(REPOSITORY_EXCEPTION, e);
			}
		}
	}

	private SearchResult getResults(String path, Session jcrsession, String property) {
		SearchResult result = null;
		Map<String, String> map = new HashMap<>();

		map.put(PATH, path);
		map.put(TYPE, NT_UNSTRUCTURED);
		map.put(PROPERTY, property);
		map.put(PROPERTY_OPERATION, EXISTS);
		if (!StringUtils.equals(SOURCE_PATH, property))
			map.put(PROPERTY_VALUE, "false");
		map.put(P_LIMIT, "-1");
		QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
		if (builder != null) {
			Query createQuery = builder.createQuery(PredicateGroup.create(map), jcrsession);
			result = createQuery.getResult();
		}
		return result;
	}

	private void setResolver() {
		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = resourceFactory.getServiceResourceResolver(param);
		} catch (LoginException e) {
			log.error("LoginException: {}", e);
		}
	}

}
