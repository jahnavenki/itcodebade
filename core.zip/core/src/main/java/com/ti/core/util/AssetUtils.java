package com.ti.core.util;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.models.assets.RenditionsMapping;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.asset.api.AssetManager;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;

/**
 *
 * The purpose of this utility class is to provide functions and operations related to assets/images/renditions
 *
 * @author Richard Chan
 */
public class AssetUtils extends WCMUsePojo {
	private static final Logger log = LoggerFactory.getLogger(AssetUtils.class);

	public static final String METADATA_NODE = "jcr:content/metadata";
	public static final String RENDITIONS_MAPPINGS = "dam:renditionsMappings";
	public static final int KB_TO_BYTE = 1000;

    @Override
    public void activate() throws Exception {
    	// To be implemented
    }

    /**
     * Converts a Resource class object to Asset class object.  Return null if either the resource object is null, or the conversion fails
     * @param resource the Resource class object to convert
     * @return an Asset class object converted from a Resource class object if successful.  Return null otherwise.
     */
    public static Asset resourceToAsset(Resource resource) {
        if (resource != null)
            return resource.adaptTo(Asset.class);

        return null;
    }

    /**
     * Returns an ArrayList of RenditionsMappings from a given property (such as OSGi config property).  The property is assumed to be of type String[].
     * @param property is assumed to be String[] containing an array of string, each string is a string representation of a RenditionsMapping
     * @return Assuming no errors in the input, an ArrayList of RenditionsMappings.  If input contains invalid string[] format, return empty list.
     */
    public static List<RenditionsMapping> getRenditionsMappingsFromProperty(String[] property) {
    	try {
        	List<RenditionsMapping> renditionsMappingsList = new ArrayList<>();
        	for (String strMapping : property)
        		renditionsMappingsList.add(new RenditionsMapping(strMapping));

        	return renditionsMappingsList;
    	}
    	catch (Exception e) {
    		log.error("JSONException while processing {}", property, e);
    		return new ArrayList<>();
    	}
    }

    /**
     * Returns a list of all renditions mappings where the provided path resides within the mapping's path or any path below it
     * @param property is assumed to be String[] an array of string, each string is a Json object representing a RenditionsMapping
     * @param path is the asset's path that must satisfy the renditions mapping's path, residing directly in it or any paths below it
     * @return all RenditionsMappings where the provided path reside in their paths or their subpaths.  Return an empty list if there is no renditions mapping with a match.
     */
    public static List<RenditionsMapping> getRenditionsMappingsForPath(String[] property, String path) {
    	try {
        	List<RenditionsMapping> renditionsMappingsList = new ArrayList<>();

    		if (property != null && property.length > 0) {
        		JSONObject jsonObj;
            	for (String strMapping : property) {
            		jsonObj = new JSONObject(strMapping);
            		String pathRegex = jsonObj.optString("path").replace("%", ".*");   // special note: convert mapping's path SQL2 % wildcard operator with regex .* equivalent
            		if (!pathRegex.isEmpty() && path.matches(pathRegex + ".*"))
            			renditionsMappingsList.add(new RenditionsMapping(strMapping));
            	}
    		}

        	return renditionsMappingsList;
    	}
    	catch (Exception e) {
    		log.error("JSONException while processing {}", property, e);
    		return new ArrayList<>();
    	}
    }

    /**
     * Returns the ValueMap which is the metadata of the asset.
     * @param res is Resource representing the DAM asset (in Resource class format)
     * @return the asset's metadata node as a ValueMap class.  Returns null if metadata node does not exist or otherwise any problems.
     */
    public static ValueMap getMetadata(Resource res) {
    	if (null == res) return null;
		Resource metadataNode = res.getChild(METADATA_NODE);
		if (null == metadataNode) return null;
		return metadataNode.getValueMap();
    }

	/**
     * Returns the ModifiableValueMap which is the metadata of the asset (although parameter uses Resource - use adaptTo to change class).  Modifiable allows the metadata to be modified in the future (instead of read-only).
     * @param res is Resource representing the DAM asset (in Resource class format)
     * @return the asset's metadata node as a ModifiableValueMap class.  Returns null if metadata node does not exist or otherwise any problems.
     */
    public static ModifiableValueMap getModifiableMetadata(Resource res) {
    	if (null == res) return null;
		Resource metadataNode = res.getChild(METADATA_NODE);
		if (null == metadataNode) return null;
		return metadataNode.adaptTo(ModifiableValueMap.class);
    }

    /**
     * Add or update a RenditionsMapping to the metadata supplied.  Multiple renditions mappings (each identified by their imageType) can be applied to the same metadata.  Metadata that already has the same mapping will be updated if the mapping is changed.
     * @param metadata to be applied with the renditions mapping
     * @param newMapping to be applied to the asset
     * @param resourceResolver a resource resolver
     * @return true if asset's rendition mapping is modified as a result, false if asset's metadata is not modified
     */
    public static boolean applyRenditionsMappingToAssetMetadata(ModifiableValueMap metadata, RenditionsMapping newMapping, ResourceResolver resourceResolver) {
    	try {
        	Boolean bUpdateMetadata = true;

    		String[] metadataMappings = metadata.get(RENDITIONS_MAPPINGS, new String[0]);

    		if (metadataMappings.length > 0) {
    			// Run through all the existing mappings in the metadata one-by-one and check against newMapping
	    		for (int i = 0; i < metadataMappings.length; i++) {
	    			RenditionsMapping mapping = new RenditionsMapping(metadataMappings[i]);

	    			if (newMapping.getString(RenditionsMapping.IMAGE_TYPE).equals(mapping.getString(RenditionsMapping.IMAGE_TYPE))) {
	    				// This mapping already exists in the metadata, update mapping from source if necessary (returns true if mapping is changed)
	    				mapping.copyFrom(newMapping);
	    				if (!mapping.isModified())
	    					bUpdateMetadata = false;
	    				else
	    					metadataMappings[i] = mapping.toString();
	    				break;
	    			}
	    			// Missing else case here
	    		}
	    		metadata.remove(RENDITIONS_MAPPINGS);	// this extra remove() is not redundant.  It is needed to resolve String vs String[] type inconsistency in the JCR node
	    		metadata.put(RENDITIONS_MAPPINGS, metadataMappings);
    		}
    		else {
    			// This asset's metadata didn't have any pre-existing mapping, so add this as the new one
         		metadata.put(RENDITIONS_MAPPINGS, new String[] { newMapping.toString() });
         		log.debug("New renditions mapping added: {}", newMapping);
    		}

    		if (bUpdateMetadata)
    			resourceResolver.commit();

    		log.debug("Metadata updated? {} ", bUpdateMetadata);

        	return bUpdateMetadata;
    	}
    	catch (Exception e) {
    		log.error("Error in applyRenditionsMappingToAssetMetadata", e);
    		return false;
    	}
    }



    /**
     * This function attempts to update the asset to include the source file into its Subassets section.  Either by copying a valid file from the 'Master File Location', or if the asset itself is a source file, copy itself as its own Subasset.  In both ways, the source file must match the format specified by sourceFormat.
     * @param asset to be used
     * @param mapping the RenditionsMapping object containing source file requirements such as sourceFormat, sourceMinSize, sourceAR, etc
     * @param resourceResolver a resource resolver
     * @return true if asset has been applied or already has, a source file under Subassets.  False if fails to apply or asset does not have an eligible source file to be applied.
     */
    public static boolean applySourceToSubasset(Asset asset, RenditionsMapping mapping, ResourceResolver resourceResolver) {
    	try {
    		if (asset.isSubAsset()) {
    			log.debug("applySourceToSubasset: no action due to asset itself is a subasset - {}", asset.getPath());
    			return false;
    		}

			Asset subasset = asset.getSubAssets().stream().findFirst().orElse(null);
			if (subasset != null) {
				log.debug("applySourceToSubasset: no action due to the asset already has a subasset - {}", subasset.getPath());
				return sourceFileQualifies(subasset, mapping);
			}

    		String masterFileLocation = asset.getMetadataValue("dam:masterFileLocation");
    		if (StringUtils.isEmpty(masterFileLocation)) {
    			// If no Master File Location is referenced, then check if this file itself is supposed to be the source file.  If so, add itself as a source as its subasset
    			log.debug("applySourceToSubasset: checking source file {}", asset.getPath());
    			if (sourceFileQualifies(asset, mapping) && moveResourceAsSubasset(asset, asset, resourceResolver))
    				return true;
    		}
    		else {
    			// If there is a valid source file referenced in the dam:masterFileLocation field, copy the file as its subasset
    			log.debug("applySourceToSubasset: checking Master File Location {}", masterFileLocation);

				// URL decode the string, and strip out redundant portion &_charset_=utf8
				masterFileLocation = URLDecoder.decode(masterFileLocation, "UTF-8").replace("&_charset_=utf8", StringUtils.EMPTY);
				// Only the portion 'content/' is needed to locate the file
				masterFileLocation = masterFileLocation.substring(masterFileLocation.lastIndexOf("/content/"));

				Asset masterFile = resourceToAsset(resourceResolver.getResource(masterFileLocation));
				if (masterFile != null && sourceFileQualifies(masterFile, mapping) && moveResourceAsSubasset(masterFile, asset, resourceResolver))
					return true;
    		}

    		log.debug("applySourceAsSubasset: no source file applied for this asset: {}", asset.getPath());
			return false;
    	}
    	catch (Exception e) {
    		log.error("Error in applySourceAsSubasset", e);
    		return false;
    	}
    }

    /**
     * Private helper to determine if the source file meets all the qualifications.  Return true if qualifies, false otherwise.
     * @param sourceFile the Asset object to be tested
     * @param mapping the Renditions Mapping object containing the source file matching criteria, such as sourceMinSize, sourceFormats, sourceAR, etc
     * @return true if all criteria passes and meets qualification.  False otherwise.
     */
    private static boolean sourceFileQualifies(Asset sourceFile, RenditionsMapping mapping) {
    	try {
            if (!sourceFileQualifiesFormatHelper(sourceFile, mapping.getSourceFormats()))
            	return false;

            final int INCHES_TO_PIXELS = 72;
            long imageWidth = NumberUtils.isNumber(sourceFile.getMetadataValue("tiff:ImageWidth")) ? NumberUtils.toLong(sourceFile.getMetadataValue("tiff:ImageWidth")) : Math.round(NumberUtils.toDouble(sourceFile.getMetadataValue("dam:Physicalwidthininches")) * INCHES_TO_PIXELS);
            long imageHeight = NumberUtils.isNumber(sourceFile.getMetadataValue("tiff:ImageLength")) ? NumberUtils.toLong(sourceFile.getMetadataValue("tiff:ImageLength")) : Math.round(NumberUtils.toDouble(sourceFile.getMetadataValue("dam:Physicalheightininches")) * INCHES_TO_PIXELS);

            String sourceAR = mapping.getSourceAR();
            boolean correctAR = true;
            if (!sourceAR.isEmpty())
            	correctAR = sourceFileQualifiesDoubleHelper((double) imageWidth / imageHeight, Double.parseDouble(sourceAR), mapping.getSourceAROperator());
            if (!correctAR)
            	return false;

            String sourceWidth = mapping.getSourceWidth();
            boolean correctWidth = true;
            if (!sourceWidth.isEmpty())
            	correctWidth = sourceFileQualifiesLongHelper(imageWidth, Long.parseLong(sourceWidth), mapping.getSourceWidthOperator());
            if (!correctWidth)
            	return false;

            String sourceHeight = mapping.getSourceHeight();
            boolean correctHeight = true;
            if (!sourceHeight.isEmpty())
            	correctHeight = sourceFileQualifiesLongHelper(imageHeight, Long.parseLong(sourceHeight), mapping.getSourceHeightOperator());
            if (!correctHeight)
            	return false;

            return sourceFile.getOriginal().getSize() >= (mapping.getSourceMinSize() * KB_TO_BYTE);
    	}
    	catch (Exception e) {
    		log.error("Error in sourceFileQualifies", e);
    	}
    	return false;
    }
    private static boolean sourceFileQualifiesFormatHelper(Asset sourceFile, String mappingSourceFormats) {
		String[] sourceFormats = mappingSourceFormats.split(",");
		for (String sourceFormat : sourceFormats) {
			if (StringUtils.endsWithIgnoreCase(sourceFile.getName(), sourceFormat))
				return true;
		}

		return false;
    }
    private static boolean sourceFileQualifiesLongHelper(long leftOperand, long rightOperand, String operator) {
    	boolean result = false;

    	switch (operator) {
    	case ">" :
    		result = leftOperand > rightOperand;
    		break;
    	case ">=" :
    		result = leftOperand >= rightOperand;
    		break;
    	case "<" :
    		result = leftOperand < rightOperand;
    		break;
    	case "<=" :
    		result = leftOperand <= rightOperand;
    		break;
    	default :
    		result = leftOperand == rightOperand;
    	}

    	return result;
    }
    private static boolean sourceFileQualifiesDoubleHelper(double leftOperand, double rightOperand, String operator) {
    	boolean result = false;
    	final double EPSILON = 0.001;

    	switch (operator) {
    	case ">" :
    		result = leftOperand > rightOperand;
    		break;
    	case ">=" :
    		result = leftOperand >= rightOperand;
    		break;
    	case "<" :
    		result = leftOperand < rightOperand;
    		break;
    	case "<=" :
    		result = leftOperand <= rightOperand;
    		break;
    	default :
    		result = Math.abs(leftOperand - rightOperand) < EPSILON;
    	}

    	return result;
    }

    /**
     * This function moves the Asset at src into the Subassets section of the target asset.
     * In addition, make a copy of the source to the \content\dam\master-files-archive location (on the equivalent path as the asset's path under \content\dam\ticom\images)
     * @param src is the source Asset to be moved
     * @param asset is the target Asset where src will move into it as a subasset
     * @param resourceResolver a resource resolver
     * @return true only if src is successfully moved into asset's Subassets section.  False otherwise.
     */
    public static boolean moveResourceAsSubasset(Asset src, Asset asset, ResourceResolver resourceResolver) {
    	try {
        	if (src == null || asset == null || resourceResolver == null)
        		return false;

        	// Create an empty subasset file matching the target's filename, and then get its path
        	String subAssetPath = asset.addSubAsset(src.getName(), src.getMimeType(), null).getPath();

			AssetManager am = resourceResolver.adaptTo(com.adobe.granite.asset.api.AssetManager.class);
			com.day.cq.dam.api.AssetManager cqAm = resourceResolver.adaptTo(com.day.cq.dam.api.AssetManager.class);
			if (am != null && cqAm != null) {
				// Before moving the source, make a copy of it to /content/dam/master-files-archive.  Source file can be located in a ticom web folder, or in the master-files location.
				String masterFileArchiveLocation = "/content/dam/master-files-archive" + src.getPath().replace("/content/dam/ticom/images/", "/").replace("/content/dam/tinews/images/", "/tinews/").replace("/content/dam/master-files/", "/");
				cqAm.createAsset(masterFileArchiveLocation, null, src.getMimeType(), true);
				am.copyAsset(src.getPath(), masterFileArchiveLocation);

				if (src == asset) {
					// Special case: moving itself into its own subassets section.  This requires moving the asset's original rendition into its subasset's original rendition
    				log.debug("Adding itself as its own subasset: {}", asset.getPath());

	    			Session session = resourceResolver.adaptTo(Session.class);
	    			if (session == null)
	    				return false;

	    			session.move(asset.getOriginal().getPath(), subAssetPath + "/jcr:content/renditions/original");
	    			session.save();
				}
				else {
					// Normal case: moving another asset into the target asset's subasset
					log.debug("Moving the file at {} as subasset of: {}", src.getPath(), asset.getPath());

					am.removeAsset(subAssetPath);
					am.moveAsset(src.getPath(), subAssetPath);
					resourceResolver.commit();
				}

				return true;
			}
    	}
    	catch (Exception e) {
    		log.error("Error in moveResourceAsSubasset", e);
    	}

		return false;
    }

    /**
     * This function generate renditions for the given asset, by going through all the renditions settings stored in the asset's metadata, and (re)generate renditions that have the 'regenerate' flag set to true
     * @param asset to generate renditions
     * @param resourceResolver a resource resolver
     * @param forceRegenerate tells the asset to regenerate all renditions, regardless if a rendition's 'regenerate' flag may be false
     * @return true if any renditions are being generated for the asset, false if no renditions are generated
     */
    public static boolean generateRenditions(Asset asset, ResourceResolver resourceResolver, boolean forceRegenerate) {
    	try {
    		Resource resource = asset.adaptTo(Resource.class);

    		if (resource != null && resourceResolver != null) {
        		Resource jcrContent = resourceResolver.getResource(resource.getPath() + "/" + JcrConstants.JCR_CONTENT);
        		if (jcrContent == null)
        			return false;

        		ModifiableValueMap jcrContentMap = jcrContent.adaptTo(ModifiableValueMap.class);
        		ModifiableValueMap metadata = getModifiableMetadata(resource);
        		if (jcrContentMap != null && metadata != null) {
            		String lastModifiedBy = jcrContentMap.get(JcrConstants.JCR_LAST_MODIFIED_BY, resource.getValueMap().get(JcrConstants.JCR_CREATED_BY, StringUtils.EMPTY));
            		String[] metadataMappings = metadata.get(RENDITIONS_MAPPINGS, new String[0]);

        			// Run through all the existing mappings in the metadata one-by-one and check against newMapping
            		for (int i = 0; i < metadataMappings.length; i++)
            			generateRenditionsOuterLoopHelper(asset, metadata, metadataMappings, i, resourceResolver, forceRegenerate);

            		// Any changes made that have not been committed up to this point, will be committed
            		if (resourceResolver.hasChanges()) {
        				// Need to explicitly set the lastModifiedBy back to the user who triggered it, otherwise, it will be set to 'serviceuser' (which is technically correct, but incorrect from user's perspective)
            			jcrContentMap.put(JcrConstants.JCR_LAST_MODIFIED_BY, lastModifiedBy);

            			resourceResolver.commit();
            			return true;
            		}
        		}
    		}
    	}
    	catch (Exception e) {
    		log.error("Error in generateRenditions", e);
    	}

    	return false;
    }


    /**
     * This private helper function created in order to bypass Sonar cyclomatic complexity...  these are the actions that would have taken place inside the outer loop (to loop through the mappings).  This function would have been inline code for generateRenditions.
     * @param asset to generate renditions
     * @param metadata is the ModifiableValueMap adaptation of the asset's metadata node
     * @param i the current for loop index of the outer loop...
     * @param resourceResolver a resource resolver
     * @param forceRegenerate tells the asset to regenerate all renditions, regardless if a rendition's 'regenerate' flag may be false
     */
    private static void generateRenditionsOuterLoopHelper(Asset asset, ModifiableValueMap metadata, String[] metadataMappings, int i, ResourceResolver resourceResolver, boolean forceRegenerate) {
    	try {
			RenditionsMapping mapping = new RenditionsMapping(metadataMappings[i]);

			// Ensure that the source file must exist prior to generating rendition
			String[] sourceFormats = mapping.optString(RenditionsMapping.IMAGE_SOURCE_FORMATS,"format").split(",");
			Asset sourceFile = null;
			for (String sourceFormat : sourceFormats)
				  sourceFile = asset.getSubAssets().stream().filter(x -> StringUtils.endsWithIgnoreCase(x.getName(), sourceFormat)).findFirst().orElse(sourceFile);
			if (sourceFile == null) {
				log.debug("generateRenditions: cannot find source file with given format(s): {}", sourceFormats);
				return;
			}

			File tmpDir = null;
			JSONArray arr = mapping.getJSONArray(RenditionsMapping.RENDITIONS);
			boolean mappingChanged = false;
			String defaultRenditionFormat = StringUtils.EMPTY;

			// Go through each rendition settings inside the mapping
			for (int j = 0; j < arr.length(); j++) {
				JSONObject settings = arr.getJSONObject(j);
				boolean isDefaultRendition = settings.optBoolean(RenditionsMapping.RENDITION_DEFAULTRENDITION);

				if (generateRenditionCondition(isDefaultRendition, metadata.get("dam:masterFileLocation", StringUtils.EMPTY), settings.optBoolean(RenditionsMapping.RENDITION_REGENERATE), forceRegenerate)) {
					// Only the first rendition that needs to regenerate will create the temporary directory and put the source file in there (need to avoid using If-statements here due to Sonar cyclomatic complexity, so moved to private helper...)
					tmpDir = generateRenditionsNewFileHelper(tmpDir, sourceFile);

					if (generateRenditionFromSettings(asset, settings, sourceFile, tmpDir)) {
						mappingChanged = true;

						if (isDefaultRendition) {
							defaultRenditionFormat = settings.optString(RenditionsMapping.RENDITION_FORMAT);
							log.debug("Default rendition generated for {}", asset.getPath());

							// Hacky operation (to be improved): if the asset's original rendition is changed, then also update the asset's dam:size property
							metadata.put(DamConstants.DAM_SIZE, asset.getOriginal().getSize());
						}

						// Update the rendition setting's 'regenerate' flag back to false (due to metadata schema convention, false is actually an empty string)
						settings.put(RenditionsMapping.RENDITION_REGENERATE, StringUtils.EMPTY);
					}
				}
			}

			// Remove the temporary directory, if it exists
			deleteTempDirectory(tmpDir);

			// If any rendition was generated, then its 'regenerate' flag would need to be updated
			if (mappingChanged) {
				metadataMappings[i] = mapping.toString();
	    		metadata.remove(RENDITIONS_MAPPINGS);	// this extra remove() is not redundant.  It is needed to resolve String vs String[] type inconsistency in the JCR node
	    		metadata.put(RENDITIONS_MAPPINGS, metadataMappings);
			}

			// If the default rendition is regenerated but has a different file extension than the current image, change the image's file extension
			changeAssetFileExtension(asset, defaultRenditionFormat, resourceResolver);
    	}
    	catch (Exception e) {
    		log.error("Error occurred during generateRenditionsOuterLoopHelper", e);
    	}
    }

    /**
     * Another private helper to bypass Sonar Cyclomatic Complexity issue... this is the condition for testing whether the rendition should be generated, based on four factors
     * @param isDefaultRendition if rendition to be generated is also a default rendition
     * @param masterFileLocation if the original image has the Master File Location (i.e. prior to migration)
     * @param regenerateRendition if the rendition's settings specify this rendition to be regenerated
     * @param forceRegenerate external flag (such as from scheduler) to make the rendition to be generated and overwrite the existing file if available
     * @return true or false whether the rendition should be (re)generated
     */
    private static boolean generateRenditionCondition(boolean isDefaultRendition, String masterFileLocation, boolean regenerateRendition, boolean forceRegenerate) {
    	return forceRegenerate || (regenerateRendition && (!isDefaultRendition || masterFileLocation.isEmpty()));
    }

    /**
     * Private helper function for generateRenditions, created in order to resolve Sonar... would have made this section inline otherwise.
     *   This function will only execute if there is currently no temporary directory already created (i.e. tmpDir needs to be null to proceed)
     *    Once proceed, this function will 1. Create a temporary directory, 2. Put the source file in it, 3. Return a handle of the temporary directory
     * @param tmpDir handle to the temporary directory to be created.  If tmpDir is null, a new temporary directory will be created.  If tmpDir already exists, then exit routine.
     * @param sourceFile the Asset representing the source file
     * @return File handle to the temporary directory, if it was created successfully.  Skip the entire routine if tmpFile was already created earlier.
     */
    private static File generateRenditionsNewFileHelper(File tmpDir, Asset sourceFile) throws IOException {
    	if (tmpDir == null) {
    		tmpDir = Files.createTempDirectory("cqdam").toFile();
            log.debug("Temporary directory created at:{}", tmpDir);

            File file = new File(tmpDir, sourceFile.getName());
            try (OutputStream fos = new FileOutputStream(file)) {
                IOUtils.copy(sourceFile.getOriginal().getStream(), fos);
                IOUtils.closeQuietly(fos);
            }
            catch (Exception e) {
            	log.error("Error while creating a new file for {}", sourceFile.getName(), e);
            }
    	}

    	return tmpDir;
    }

    /**
     * Private helper function used by generateRenditions() to generate one rendition based on the rendition specifications.
     * @param asset to generate renditions
     * @param settings is the specification for one rendition
     * @param sourceFile is the source used to generate this rendition
     * @param tmpDir File handle to the temporary directory created
     * @return true if the rendition is generated successfully, false otherwise.
     */
    private static boolean generateRenditionFromSettings(Asset asset, JSONObject settings, Asset sourceFile, File tmpDir) {

    	try {
    		String renditionName = settings.optString("name");
    		String renditionFormat = settings.optString("format");
    		String renditionQuality = settings.optString("quality");
    		final long renditionFileSizeLimit = settings.optLong("maxFileSize", 10000);		// If maxFileSize not specified, default is 10MB max

    		if (sourceFile != null && !renditionName.isEmpty() && !renditionFormat.isEmpty()) {
    			String renditionFilename = renditionName  + "." + renditionFormat;

                // Execute ImageMagick command in one of two ways: 1) directly via supplied cmd, or 2) command constructed from parameters
                String cmd = settings.optString("cmd");
                if (cmd.isEmpty()) {
                	cmd = String.format("convert \"%s\"  -resize 48x48 %s", sourceFile.getName(), renditionFilename);
                }
                else
                	cmd = generateRenditionFromSettingsCmdHelper(cmd, sourceFile.getName(), renditionFilename, settings.optString(RenditionsMapping.RENDITION_RESIZE_TO), settings.optString(RenditionsMapping.RENDITION_CANVAS_SIZE), renditionQuality, Long.toString(renditionFileSizeLimit));

                execCmd(cmd, tmpDir);

                String mimeType = "image/jpeg";		// (To be expanded later): assume default rendition mimetype is JPEG

                // If mimetype is PNG
                if ("PNG".equalsIgnoreCase(renditionFormat)) {
                	mimeType = "image/png";

                    // PNG compression
                	generateRenditionFromSettingsPngHelper(renditionFilename, renditionQuality, renditionFileSizeLimit, tmpDir);
                }

                // Add rendition to asset.  If rendition is the default rendition, make it the asset's original rendition
                asset.addRendition(settings.optBoolean("default") ? "original" : renditionFilename, new FileInputStream(FileUtils.getFile(tmpDir, renditionFilename)), mimeType);

                log.debug("Generated rendition {} for asset: {}", renditionFilename, asset.getPath());

                return true;
    		}
    	}
    	catch (Exception e) {
    		log.error("Error in generateRenditionFromSettings", e);
    	}

		return false;
    }

    /**
     * Helper function used by generateRenditionFromSettings() to fill in the final command string with rendition parameters.
     * @param cmd command to be parameterized
     * @param inputFilename
     * @param outputFilename
     * @return the final command string to call, fully parameterized
     */
    private static String generateRenditionFromSettingsCmdHelper(String cmd, String inputFilename, String outputFilename, String resizeTo, String canvasSize, String quality, String maxFileSize) {
    	if (!resizeTo.isEmpty())
    		resizeTo = " -thumbnail " + resizeTo;
    	if (!canvasSize.isEmpty())
    		canvasSize = " -extent " + canvasSize;
    	if (!quality.isEmpty())
    		quality = " -quality " + quality;
    	String jpgMaxFileSize = " -define jpeg:extent=" + maxFileSize + "KB ";

    	return cmd.replace("{filename}", inputFilename).replace("{outfile}", outputFilename)
    			.replace("{resizeTo}", resizeTo).replace("{canvasSize}", canvasSize)
    			.replace("{quality}", quality).replace("{JPGMaxFileSize}", jpgMaxFileSize);
    }

    /**
     * Helper function to be used only by generateRenditionFromSettings() to deeply compress PNG files
     * @param filename name of the source file (assumed to be PNG)
     * @param quality either an integer, or a lower to upper range in the form of [minQuality]-[maxQuality]
     * @param tmpDir is a File handle to the temporary directory created
     */
    private static void generateRenditionFromSettingsPngHelper(String filename, String quality, long fileSizeLimit, File tmpDir) {
    	try {
    		// pngquant: Run through multiple passes in decreasing quality until the file size drops to acceptable size, OR, the min quality has been reached (in that case, don't go any lower)
    		final int MAX_QUALITY = 100;	// if not provided, default max quality is 100
    		final int MIN_QUALITY = 60;		// if not provided, default min quality is 60
    		final int QUALITY_STEP = 10;	// if not provided, default quality decreases by 10 each iteration

    		// Quality can either be a single integer number (in which case it signifies the LOWER quality limit), or a range with two integers in the form of [MIN_QUALITY-MAX_QUALITY]
    		int maxQuality = MAX_QUALITY;
    		int minQuality = MIN_QUALITY;
    		if (!StringUtils.isEmpty(quality)) {
    			String[] qualityRange = quality.split("-");

    			if (StringUtils.isNumeric(qualityRange[0]))
    				minQuality = Integer.parseInt(qualityRange[0]);

    			if (qualityRange.length == 2 && StringUtils.isNumeric(qualityRange[1]))
    				maxQuality = Integer.parseInt(qualityRange[1]);
    		}

    		String quantName = "p_" + filename;
    		File quantFile = null;
    		for (int q = maxQuality; q >= minQuality; q -= QUALITY_STEP) {
    			execCmd(String.format("pngquant --quality %d --speed 1 --force --output %s -- %s", q, quantName, filename), tmpDir);
                quantFile = new File(tmpDir, quantName);
        		log.debug("pngquant quality: {}, filesize: {}", q, quantFile.length());

        		if (quantFile.length() <= fileSizeLimit * KB_TO_BYTE)
        			break;
    		}
    		if (quantFile != null) {
    			File tmpFile = new File(tmpDir, filename);
    			FileUtils.forceDelete(tmpFile);
    			if (!quantFile.renameTo(tmpFile))
    				return;
    		}

    		// OptiPNG
            execCmd(String.format("optipng -keep -o7 %s", filename), tmpDir);
    	}
    	catch (Exception e) {
    		log.error("Error in generateRenditionFromSettings", e);
    	}
    }

    /**
     * Delete the temporary directory and any files created within it (e.g. created during generateRenditionsNewFileHelper()), if it exists
     * @param tmpDir is the File handle which should be the temporary directory created earlier.  Null if the temp directory was not created earlier.
     */
    private static void deleteTempDirectory(File tmpDir) {
    	try {
    		if (tmpDir != null) {
    			// Delete temporary directory
                FileUtils.deleteDirectory(tmpDir);
    		}
    	}
    	catch (Exception e) {
    		log.error("deleteTempDirectory: attempt to delete temporary directory failed", e);
    	}
    }

    /**
     * Change the asset's file extension.
     * @param asset to update
     * @param ext the file extension to change to
     * @param resourceResolver a resource resolver
     */
    private static void changeAssetFileExtension(Asset asset, String ext, ResourceResolver resourceResolver) {
    	try {
        	if (!ext.isEmpty()) {
        		String assetPath = asset.getPath();
        		if (!StringUtils.endsWithIgnoreCase(assetPath, ext)) {
        			AssetManager am = resourceResolver.adaptTo(com.adobe.granite.asset.api.AssetManager.class);
        			if (am != null) {
        				String newAssetPath = assetPath.substring(0, assetPath.lastIndexOf('.') + 1).concat(ext);
        				am.moveAsset(assetPath, newAssetPath);
        				resourceResolver.commit();
        				log.debug("Changing asset's format to match the default rendition: {} -> .{}", assetPath, newAssetPath);
        			}
        		}
        	}
    	}
    	catch (Exception e) {
    		log.error("changeAssetFileExtension: error while committing", e);
    	}
    }

    /**
     * Private helper function for generateRenditionFromSettings to invoke command line at the given directory
     * @param cmd the command-line to execute
     * @param dir a File object should be set to the directory where the command will be executed
     */
    private static void execCmd(String cmd, File dir) throws IOException {
        // The old method: Runtime.getRuntime().exec(cmd, null, tmpDir).waitFor(MAX_WAIT_TIME, TimeUnit.SECONDS)

        CommandLine commandLine = CommandLine.parse(cmd);
        DefaultExecutor exec = new DefaultExecutor();
        exec.setWorkingDirectory(dir);
        log.debug("execute: executing command line [{}] for asset [{}].", cmd, dir.getPath());
        exec.execute(commandLine);
    }

	private static HashMap<String, String> videoIdCache = new HashMap<>();
    public static Resource getDamResource(ResourceResolver resourceResolver, String videoPath, String videoId) {
		if (StringUtils.isEmpty(videoId)) {
			return null;
		}
		var cachePath = videoIdCache.getOrDefault(videoId, "");
		if (StringUtils.isNotEmpty(cachePath)) {
			final var fullPath = videoPath + cachePath;
			final var resource = resourceResolver.getResource(fullPath);
			if (null != resource) {
				return resource;
			}
		}
		final var builder = resourceResolver.adaptTo(QueryBuilder.class);
		final var session = resourceResolver.adaptTo(Session.class);
		if (builder == null || session == null) return null;
		final var map = new HashMap<String, String>();
		map.put("path", videoPath);
		map.put("type", "dam:Asset");
		map.put("property", "jcr:content/metadata/brc_id");
		map.put("property.value", videoId);
		map.put("p.limit", "1");
		final var query = builder.createQuery(PredicateGroup.create(map), session);
		final var result = query.getResult();
		final var resourcesItr = result.getResources();
		if (resourcesItr.hasNext()) {
			var resource = resourcesItr.next();
			cachePath = resource.getPath().substring(videoPath.length());
			videoIdCache.put(videoId, cachePath);
			return resource;
		} else {
			return null;
		}
	}

    /**
     * Helper function for getting dam resource based on property
     */
    public static Resource getDamResourceFromProperty(ResourceResolver resolver,  String assetPath,  String property, String value) {
		if (!StringUtils.isEmpty(value)) {
			Map<String, String> map = new HashMap<>();
			map.put("path", assetPath);
			map.put("type", "dam:Asset");
			map.put("property", property);
			map.put("property.value", value);
			map.put("p.limit", "1");

			QueryBuilder builder = resolver.adaptTo(QueryBuilder.class);
			Session session = resolver.adaptTo(Session.class);
			if (builder != null) {
				Query query = builder.createQuery(PredicateGroup.create(map), session);
				SearchResult result = query.getResult();

				Iterator<Resource> resourcesItr = result.getResources();
				while (resourcesItr.hasNext()) {
					return resourcesItr.next();
				}
			}
		}
		return null;
	}
}
