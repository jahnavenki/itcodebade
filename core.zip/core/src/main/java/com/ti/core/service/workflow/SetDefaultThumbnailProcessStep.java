package com.ti.core.service.workflow;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.Iterator;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set default thumbnail.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Set default thumbnail" })
public class SetDefaultThumbnailProcessStep implements WorkflowProcess {

    private final Logger log = LoggerFactory.getLogger(getClass());
    private static final String PROXY_HOST = "webproxy.ext.ti.com";
    private static final String BRC_THUMBNAIL = "brc_thumbnail.png";
    private static final String BRC_POSTER = "brc_poster.png";

    @Reference
	private WCMComponents wcmService;
    @Reference
	private VideoConfigService videoService;

    private ResourceResolver resourceResolver;

    @Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
                throw new NullPointerException("resourceResolver");
            }
			Resource resource = resourceResolver.getResource(payload);
			if (null == resource) {
                return;
            }
            String videoPath = videoService.getVideoPath();
            if (videoPath == null || videoPath.length() <= 0) {
                log.debug("Video path not found in the config");
                return;
            }            
            InputStream stream = createInputStreamFromResource(resource);
            readExcelAndAddFiles(stream,videoPath); 
		} catch (Exception e) {
			log.error("Error occurred in BrightcoveVideoMigrationProcessStep", e);
		  }
    }    
    private InputStream createInputStreamFromResource(Resource resource) {
        try {
            Asset asset = resource.adaptTo(Asset.class);
            InputStream stream = null;
            if(asset != null) {
                Rendition original = asset.getOriginal();
                if(original !=null) {
                    stream = original.getStream();
                }
            }
            return stream;
        } catch (Exception e) {
			log.error("Error occurred in CreateThumbnailAssociatedFilesProcessStep createInputStreamFromResource", e);
		  } 
        return null;   
    }
    private void readExcelAndAddFiles(InputStream stream,String videoPath) {
        try (XSSFWorkbook workbook = new XSSFWorkbook(stream)) {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
            HttpURLConnection connection = null;
            URL url = new URL("https://www-sat.itg.ti.com/content/dam/ticom/images/training/video-playlist-thumbnail.jpg");
            connection = (HttpURLConnection) url.openConnection(proxy);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(10000);
            byte[] byteArray;
            try (InputStream inputStream = connection.getInputStream()) {
                try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                    inputStream.transferTo(outputStream);
                    outputStream.flush();
                    byteArray = outputStream.toByteArray();
                }
            }
    
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            DataFormatter dataFormatter = new DataFormatter();
			// First row is header, so import data from second row onwards
            rowIterator.next();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                String videoId = StringUtils.EMPTY;
                if (row.getCell(0) != null) {
                    videoId  = dataFormatter.formatCellValue(row.getCell(0));
                }
                Resource videoResource =  AssetUtils.getDamResource(resourceResolver, videoPath, videoId);
                if (videoResource != null) {
                    createThumbnail(videoResource, byteArray);
                }
            } 
        } catch (Exception e) {
            log.error("Error occurred in CreateThumbnailAssociatedFilesProcessStep readExcelAndAddFiles", e);
        }
    }

    public void createThumbnail(Resource videoResource, byte[] inputBytes) {
		try {
            Asset videoAsset = videoResource.adaptTo(Asset.class);
            if(videoAsset != null) {
                try (final var inputStream = new ByteArrayInputStream(inputBytes)) {
                    videoAsset.addRendition(BRC_THUMBNAIL, inputStream, "image/png");
                }
                try (final var inputStream = new ByteArrayInputStream(inputBytes)) {
                    videoAsset.addRendition(BRC_POSTER, inputStream, "image/png");
                }
            }
		} catch (MalformedURLException e) {
			log.error("MalformedURLException: ", e);
		} catch (IOException e) {
			log.error("IOException: ", e);
		}catch (Exception e) {
			log.error("Exception: ", e);
		}
    }
}
