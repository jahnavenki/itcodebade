package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PageTitleProductsApplications extends WCMUsePojo {

	private static final String FAMILY_ID = "familyId";
	private static final String APPLICATION_ID = "applicationId";
	private static final String PAGE_TITLE = "pageTitlePA";
	private static final String JSON_KEY_FAMILY_NAME = "familyName";
	private static final String JSON_KEY_APPLICATION_NAME = "appAreaName";
	private static final String SEPARATOR = " &ndash; ";

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String pageTitle;

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	@Override
	public void activate() {

		try {
			ValueMap properties;

			properties = getProperties();
			setPageTitle(properties.get(PAGE_TITLE, String.class));

			if (pageTitle == null || pageTitle.isEmpty()) {

				String name = getFamilyOrApplicationName();

				if (StringUtils.isNotEmpty(name)) {
					pageTitle = name + SEPARATOR + getCurrentPage().getNavigationTitle();
				} else {
					setPageTitle(null);
				}

			}
		} catch (Exception e) {
			setPageTitle(null);
			log.error("Exception: " + e);
		}

	}

	/**
	 * This method checks if current page has family or application configured
	 * and returns the configured name for it or otherwise returns null.
	 * 
	 * @return String containing family or application name or null otherwise.
	 */
	private String getFamilyOrApplicationName() {
		String name = null;
		try {
			String familyId, applicationId;
			if (null != getCurrentPage().getNavigationTitle()) {

				if (null != getPageProperties().get(FAMILY_ID)) {
					familyId = (String) getPageProperties().get(FAMILY_ID);
					if (!StringUtils.isEmpty(familyId)) {
						name = getFamilyName(familyId);
					}
				} else if (null != getPageProperties().get(APPLICATION_ID)) {
					applicationId = (String) getPageProperties().get(APPLICATION_ID);

					if (!StringUtils.isEmpty(applicationId)) {
						name = getApplicationName(applicationId);
					}
				}
			}

		} catch (Exception e) {
			log.error("Error getting family or application name due to " + e);
		}

		return name;
	}

	/**
	 * This method call the service for Family and returns the associated family
	 * name for provided family id.
	 * 
	 * @param familyId
	 *            family id set from page properties.
	 * @return family name.
	 */
	public String getFamilyName(String familyId) {
		String familyName = null;
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		try {
			WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if (wcmComponents != null && tabsService != null) {
				JSONObject prodData = wcmComponents.getAllProductService(this.getRequest(), Integer.parseInt(familyId),
						tabsService.getPageLanguage(getCurrentPage()));
				if (prodData != null) {
					familyName = prodData.getString(JSON_KEY_FAMILY_NAME);
				}
			}
		} catch (JSONException e) {
			log.error("Could not get family name from json", e);
		}

		return familyName;
	}

	/**
	 * This method call the service for Application and returns the associated
	 * application nam for provided application id.
	 * 
	 * @param applicationId
	 *            application id set from page properties.
	 * @return application name.
	 */
	public String getApplicationName(String applicationId) {
		String applicationName = null;
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		try {
			WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if (wcmComponents != null && tabsService != null) {
				JSONObject prodData = wcmComponents.getAllApplicationService(this.getRequest(),
						Integer.parseInt(applicationId), tabsService.getPageLanguage(getCurrentPage()));
				if (prodData != null) {
					applicationName = prodData.getString(JSON_KEY_APPLICATION_NAME);
				}
			}
		} catch (JSONException e) {
			log.error("Could not get application area name from json", e);
		}

		return applicationName;
	}

}