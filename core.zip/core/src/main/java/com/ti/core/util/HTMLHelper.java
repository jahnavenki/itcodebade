package com.ti.core.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * LanguageUtils WCMUsePojo.
 *
 */
public class HTMLHelper extends WCMUsePojo {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private String html;
	
	@Override
	public void activate() {
		try {
	        html = get("html", String.class);
	        if (html == null)
	        	html = StringUtils.EMPTY;
		}
		catch (Exception e) {
			html = StringUtils.EMPTY;
			log.error("Error in HTMLHelper.activate()", e);
		}
	}
	
  /**
   * Strips out HTML tags and return pure text (will remove line breaks if done in HTML tags)
   * 
   * @return text devoid of HTML tags
   */
	public String getText() {
		return html.replaceAll("<(?:[^>=]|='[^']*'|=\"[^\"]*\"|=[^'\"][^\\s>]*)*>", StringUtils.EMPTY).trim();
	}
	
  /**
   * Strips out only <br> and <p> tags
   * 
   * @return removing <br> and <p>, preserving other HTML tags
   */
	public String noP() {		
		return html.replaceAll("<(p|/p|br)\\s*>", StringUtils.EMPTY).trim();
	}

  /**
   * Replace <p> paragraphs to line breaks <br> instead, and strip out any empty paragraphs and duplicate line breaks.
   * 
   * @return HTML that has <p> paragraphs removed and replaced with line breaks, preserving other HTML tags
   */
	public String pToBr() {
		return html.replaceAll("<(p|/p)[^>]*>", "\r\n").trim().replaceAll("\r\n", "<br>").replaceAll("(<br>)+", "<br>");
	}
}