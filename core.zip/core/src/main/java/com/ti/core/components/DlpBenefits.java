package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.util.PathBrowserHelper;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DlpBenefits extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private final List<SectionViewModel> sections = new ArrayList<>();

	public List<SectionViewModel> getSections() {
		return sections;
	}

	public static class SectionViewModel {
		private String title;
		private String imageOrVideo;
		private String imageSrc;
		private String imageAlt;
		private String videoId;
		private String description;
		private final List<CtaViewModel> ctas = new ArrayList<>();

		public String getTitle() {
			return title;
		}

		public String getImageOrVideo() {
			return imageOrVideo;
		}

		public String getImageSrc() {
			return imageSrc;
		}

		public String getImageAlt() {
			return imageAlt;
		}

		public String getVideoId() {
			return videoId;
		}

		public String getDescription() {
			return description;
		}

		public List<CtaViewModel> getCtas() {
			return ctas;
		}

		public void setTitle( String title ) {
			this.title = title;
		}

		public void setImageOrVideo( String imageOrVideo ) {
			this.imageOrVideo = imageOrVideo;
		}

		public void setImageSrc( String imageSrc ) {
			this.imageSrc = imageSrc;
		}

		public void setImageAlt( String imageAlt ) {
			this.imageAlt = imageAlt;
		}

		public void setVideoId( String videoId ) {
			this.videoId = videoId;
		}

		public void setDescription( String description ) {
			this.description = description;
		}
	}

	public static class CtaViewModel {
		private String ctaLabel;
		private String ctaUrl;
		private String ctaIcon;

		public String getCtaLabel() {
			return ctaLabel;
		}

		public String getCtaUrl() {
			return ctaUrl;
		}

		public String getCtaIcon() {
			return ctaIcon;
		}

		public void setCtaLabel( String ctaLabel ) {
			this.ctaLabel = ctaLabel;
		}

		public void setCtaUrl( String ctaUrl ) {
			this.ctaUrl = ctaUrl;
		}

		public void setCtaIcon( String ctaIcon ) {
			this.ctaIcon = ctaIcon;
		}
	}

	private String getImageAltText( String path ) {
		final var resource = getResourceResolver().getResource(path);
		if(null == resource) return "";
		final var asset = resource.adaptTo(Asset.class);
		if(null == asset) return "";
		return asset.getMetadataValue("dc:title");
	}

	private SectionViewModel buildSectionViewModel( Resource sectionResource ) throws JSONException {
		final var valueMap = sectionResource.getValueMap();
		final var section = new SectionViewModel();
		section.setTitle( valueMap.get("title", "") );
		final String imageOrVideo = valueMap.get("imageOrVideo", "");
		section.setImageOrVideo( imageOrVideo );
		if("image".equals(imageOrVideo)) {
			final var imageSrc = valueMap.get("imageSrc", "");
			section.setImageSrc( imageSrc );
			section.setImageAlt( getImageAltText(imageSrc) );
		} else if("video".equals(imageOrVideo)) {
			section.setVideoId( valueMap.get("videoId", "") );
		}
		section.setDescription( valueMap.get("description", "") );
		final var ctasResource = getResourceResolver().getResource(sectionResource, "ctas");
		if( null != ctasResource ) {
			for( var ctaResource : ctasResource.getChildren() ) {
				section.getCtas().add( buildCtaViewModel( ctaResource ) );
			}
		}
		return section;
	}

	private CtaViewModel buildCtaViewModel( Resource ctaResource ) {
		final var valueMap = ctaResource.getValueMap();
		final var cta = new CtaViewModel();
		cta.setCtaLabel( valueMap.get( "ctaLabel", "" ) );
		var ctaUrl = valueMap.get( "ctaUrl", "" );
		cta.setCtaUrl( PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), ctaUrl) );
		cta.setCtaIcon( ctaUrl.endsWith( "/products" ) ? "parametric-filter" : "arrow-right" );
		return cta;
	}

	@Override
	public void activate() {
		try {
			final var sectionsResource = getResourceResolver().getResource(getResource(), "sections");
			if( null != sectionsResource ) {
				for( var sectionResource : sectionsResource.getChildren() ) {
					sections.add( buildSectionViewModel( sectionResource ) );
				}
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
