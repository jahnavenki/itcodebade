package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.commons.jcr.JcrUtil;
import com.ti.core.models.TechnicalDocumentsDataModel;
import com.ti.core.models.TechnicalDocumentsLiteratureModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.URLHelper;

/**
 * Enhanced Technical Document Listing Class
 *
 * @author saryu.sukumar
 *
 */
public class EnhancedTechnicalDocumentListing extends WCMUsePojo {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	private static final String FAMILY_ID = "familyId";
	private static final String APPLICATION_ID = "applicationId";
	private static final String DOCUMENT_TYPES = "listingDocumentTypes";
	private static final String CONTENT = "content";
	private static final String LITERATURE_ID = "literatureId";
	private static final String LITERATURE_NUMBER = "literatureNumber";
	private static final String LIT_DESCRIPTION = "litDescription";
	private static final String DOWNLOAD_LINK = "downloadLink";
	private static final String DOWNLOAD_FILE_EXTENSION = "downloadFileExtension";
	private static final String SIZE_IN_KB = "sizeInKB";
	private static final String DATE = "date";
	private static final String SORT_ORDER = "sortOrder";
	private static final String DOC_CATEGORY_NAME = "docCategoryName";
	private static final String LIT_CATEGORY_COUNT = "litCategoryCount";
	private static final String DOC_CATEGORY_ID = "docCategoryId";
	private static final String COMMA = ",";
	private static final String MARKET_ID = "marketId";
	private static final String INDUSTRIAL_MARKET_ID = "120";

	private String listingDocumentTypes;
	private List<TechnicalDocumentsLiteratureModel> literatureValuesList = null;

	private List<TechnicalDocumentsDataModel> technicalDocumentDataModelList = new ArrayList<>();

	private int docSize = 0;
	private String pagelanguage;

	private String template;
	private String familyId;
	private String applicationId;
	private String marketId;
	private String newAppId;

	/**
	 * The language of this page
	 *
	 * @return i.e. en-us
	 */
	public String getPagelanguage() {
		return pagelanguage;
	}

	/**
	 * Activate method.
	 */
	@Override
	public void activate() throws Exception {
		template = getCurrentPage().getProperties().get("cq:template", String.class);
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		if (tabsService != null) {
			pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
		}
		Resource currentResource = getResource();
		String resourceType = "ti/components/technicalDocumentListing";
		String resourcePath = currentResource.getPath();
		if (null != currentResource) {
			Node currentNode = currentResource.adaptTo(Node.class);
			if (null == currentNode) {
				currentNode = createNode(resourcePath);
				if (null != currentNode) {
					currentNode.setProperty(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, resourceType);
					currentNode.getSession().refresh(true);
					currentNode.getSession().save();
				}
			}
		}

		// Read the familyId from the page properties
		familyId = (String) getPageProperties().get(FAMILY_ID);
		applicationId = (String) getPageProperties().get(APPLICATION_ID);
		marketId = (String) getPageProperties().get(MARKET_ID);
		StringBuilder documentType = readDocumentTypes();

		if (null != marketId && !marketId.equalsIgnoreCase(INDUSTRIAL_MARKET_ID)) {
			this.newAppId = marketId;
		} else {
			this.newAppId = applicationId;
		}

		getDocumentsListingForDocumentTypes(documentType, pagelanguage);

	}

	public String getNewAppId() {
		return newAppId;
	}

	/**
	 * Service call to get all the Literatures based on the Document Types
	 * selected the author
	 *
	 * @param documentType
	 *            - parameter
	 * @param familyId
	 *            - parameter
	 * @param language
	 *            - parameter
	 */
	public void getDocumentsListingForDocumentTypes(StringBuilder documentType, String language) {
		String technicalDocumentsListingResponse = null;
		WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		try {
			if (wcmService == null) {
				log.error("EnhancedTechnicalDocumentListing: could not get wcmService");
			}
			if (null != wcmService && StringUtils.isNotEmpty(documentType.toString())) {
				// Setting the selected listing document types from the Listing
				// Component dialog by author.
				listingDocumentTypes = documentType.toString();

				if (StringUtils.isNotEmpty(familyId)) {
					technicalDocumentsListingResponse = wcmService.getLiteraturesByDocumentType(documentType.toString(),
							familyId, language, true);
				} else if (StringUtils.isNotEmpty(newAppId)) {
					technicalDocumentsListingResponse = wcmService.getLiteraturesByDocumentType(documentType.toString(),
							newAppId, language, false);
				}
				formDataModel(technicalDocumentsListingResponse);
			}
		} catch (Exception e) {
			log.error("Exception: ", e);
		}

	}

	/**
	 * This method segregates all the first level of document category details
	 * from the JSON and stores in POJO
	 *
	 * @param technicalDocumentsListingResponse
	 * @return
	 * @throws JSONException
	 */
	public List<TechnicalDocumentsDataModel> formDataModel(String technicalDocumentsListingResponse)
			throws JSONException {
		if (StringUtils.isNotEmpty(technicalDocumentsListingResponse)) {
			JSONObject technicalDocumentsListingJsonObject = new JSONObject(technicalDocumentsListingResponse);

			JSONArray data = (JSONArray) technicalDocumentsListingJsonObject.get(CONTENT);
			for (int i = 0; i < data.length(); i++) {
				JSONObject docCategory = data.getJSONObject(i);
				TechnicalDocumentsDataModel technicalDocumentsDataModel = new TechnicalDocumentsDataModel();
				technicalDocumentsDataModel.setDocCategoryName(docCategory.getString(DOC_CATEGORY_NAME));
				technicalDocumentsDataModel.setLitCategoryCount(docCategory.getInt(LIT_CATEGORY_COUNT));
				technicalDocumentsDataModel.setDocCategoryId(docCategory.getString(DOC_CATEGORY_ID));

				literatureValuesList = new ArrayList<>();
				JSONArray literatureValues = docCategory.getJSONArray("LiteratureValues");
				technicalDocumentsDataModel.setTotalCount(literatureValues.length());

				literatureValuesList = getLiteratureValuesJSON(literatureValues);

				technicalDocumentsDataModel.setLiteratureValuesList(literatureValuesList);
				technicalDocumentDataModelList.add(technicalDocumentsDataModel);
			}
		}
		this.docSize = technicalDocumentDataModelList.size();
		return technicalDocumentDataModelList;
	}

	/**
	 * This method reads all the Literature values in each document category and
	 * stores in Lists
	 *
	 * @param literatureValues
	 * @return
	 */
	private List<TechnicalDocumentsLiteratureModel> getLiteratureValuesJSON(JSONArray literatureValues) {
		for (int j = 0; j < literatureValues.length(); j++) {
			JSONObject literatureObject;
			try {
				literatureObject = literatureValues.getJSONObject(j);
				TechnicalDocumentsLiteratureModel technicalDocumentsLiteratureModel = new TechnicalDocumentsLiteratureModel();

				technicalDocumentsLiteratureModel.setLiteratureId(literatureObject.getString(LITERATURE_ID));
				technicalDocumentsLiteratureModel.setLiteratreNumber(literatureObject.getString(LITERATURE_NUMBER));
				technicalDocumentsLiteratureModel.setLitDescription(literatureObject.getString(LIT_DESCRIPTION));
				technicalDocumentsLiteratureModel
						.setDownloadFileExtension(literatureObject.getString(DOWNLOAD_FILE_EXTENSION));
				technicalDocumentsLiteratureModel.setSizeInKB(literatureObject.getString(SIZE_IN_KB));
				technicalDocumentsLiteratureModel.setSortOrder(literatureObject.getString(SORT_ORDER));
				technicalDocumentsLiteratureModel.setDate(literatureObject.getString(DATE));

				// Encode all ampersand and question marks in URL to avoid
				// invalid url issue
				String downloadLink = URLHelper.toScheme(literatureObject.getString(DOWNLOAD_LINK),
						URLHelper.getScheme(getRequest()));
				technicalDocumentsLiteratureModel.setDownloadLink(downloadLink);

				literatureValuesList.add(technicalDocumentsLiteratureModel);
			} catch (JSONException e) {
				log.error("JSON Exception: ", e);
			}
		}
		return literatureValuesList;
	}

	public List<TechnicalDocumentsDataModel> getTechnicalDocumentDataModelList() {
		return technicalDocumentDataModelList;
	}

	public String getListingDocumentTypes() {
		return listingDocumentTypes;
	}

	public int getDocSize() {
		return docSize;
	}

	/**
	 * This method will create a new node in JCR
	 *
	 * @param nodePath
	 * @return
	 */
	private Node createNode(String nodePath) {
		Node node = null;
		ResourceResolver resourceResolver;
		Session session;
		try {
			resourceResolver = getRequest().getResourceResolver();
			session = resourceResolver.adaptTo(Session.class);
			if (null != session) {
				node = createNode(nodePath, session);
			}
		} catch (Exception re) {
			log.error("Error creating node:", re);
		}
		return node;
	}

	private Node createNode(String nodePath, Session session) {
		Node node = null;
		Node existingNode = null;
		try {
			existingNode = session.getNode(nodePath);
		} catch (Exception e) {
			log.error("Exception:", e);
		}
		if (null == existingNode) {
			try {
				node = JcrUtil.createPath(nodePath, JcrConstants.NT_UNSTRUCTURED, session);
				node.getSession().refresh(true);
				node.getSession().save();
			} catch (Exception e) {
				log.error("Exception: ", e);
			}

		} else {
			node = existingNode;
		}
		return node;
	}

	/**
	 * This method will read the document types from the dialog properties. When
	 * component is not authored, it reads the default document categories from
	 * the Configurations
	 *
	 * @param documentType
	 * @return
	 */
	private StringBuilder readDocumentTypes() {
		StringBuilder documentType = new StringBuilder();
		WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		String[] documentTypesArray = getProperties().get(DOCUMENT_TYPES, String[].class);
		if (null != documentTypesArray) {
			for (String docType : documentTypesArray) {
				documentType.append(docType);
				documentType.append(COMMA);
			}
		} else {
			if (null != wcmService) {
				documentType.append(wcmService.getDefaultDocumentCategories());
				if (StringUtils.isNotEmpty(familyId)) {
					documentType.append(",13");
				}
			}
		}
		return documentType;
	}

	/**
	 * @return the template
	 */
	public String getTemplate() {
		String type;
		if (template.contains("product") || StringUtils.isNumeric(familyId))
			type = "product";
		else if (template.contains("application") || StringUtils.isNumeric(applicationId))
			type = "application";
		else
			type = "";
		return type;
	}
}