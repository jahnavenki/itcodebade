package com.ti.core.service.workflow;

import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step for tag automation.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Tag Automation" })
public class TagAutomationProcessStep implements WorkflowProcess {
	private static final Logger log = LoggerFactory.getLogger(TagAutomationProcessStep.class);

	private static final String FIELD_ASSET_TYPE = "dam:assetType";
	private static final String FIELD_RIGHTS = "dam:rights";
	private static final String FIELD_PERSPECTIVE = "dam:perspective";
	private static final String FIELD_CONTENT_DESIGNER = "dam:creator";
	private static final String FIELD_KEYWORDS = "dc:description";

	private static final String RIGHTS_TI_PRODUCED = "ticom:image/rights/ti-produced";
	private static final String RIGHTS_MANAGED = "ticom:image/rights/rights-managed";
	private static final String ANGLED_TI_PERSPECTIVE = "ticom:image/perspective/angled";
	private static final String TOP_TI_PERSPECTIVE = "ticom:image/perspective/top";

	private static final String ASSET_TYPE_PACKAGE = "ticom:image/asset-type/package-image";
	private static final String ASSET_DESIGN_IMAGE = "ticom:image/asset-type/design-image";
	private static final String ASSET_BOARD_IMAGE = "ticom:image/asset-type/board-image";
	private static final String ASSET_TYPE_SCREENSHOT = "ticom:image/asset-type/screenshot";
	private static final String ASSET_THIRD_PARTY = "ticom:image/asset-type/third-party";

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();

			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (resourceResolver == null) return;

			final var resource = resourceResolver.getResource(payload);
			if (resource == null) return;

			final var map = AssetUtils.getModifiableMetadata(resource);
			if (map == null) return;
			final var path = resource.getPath();
			var changes = false;

			if (path.startsWith("/content/dam/ticom/images/products/package")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_TYPE_PACKAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_PERSPECTIVE, new String[] { ANGLED_TI_PERSPECTIVE });
				map.put(FIELD_CONTENT_DESIGNER, "Kurt Sincerbox");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/design-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_DESIGN_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/design-schematics")) {
				map.put(FIELD_PERSPECTIVE, new String[] { TOP_TI_PERSPECTIVE });
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_DESIGN_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/software")) {
				map.put(FIELD_PERSPECTIVE, new String[] { TOP_TI_PERSPECTIVE });
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_TYPE_SCREENSHOT });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/third-party/products")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_THIRD_PARTY });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_MANAGED });
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/third-party/diagrams")) {
				map.put(FIELD_PERSPECTIVE, new String[] { TOP_TI_PERSPECTIVE });
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_THIRD_PARTY });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_MANAGED });
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/dataconverters/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "data converters");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/radar/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "radar");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/hival/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "hival");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/dlp-products/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "dlp products");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/wireless-connectivity/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "wireless connectivity");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/amplifiers/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "amplifiers");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/space-high-reliability/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "space high reliability");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/logic/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "logic");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/sensing-products/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "sensing");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/motor-drivers/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "motor drivers");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/clock-timing/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "clock timing");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/microcontrollers/hercules/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "microcontroller mature hercules");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/microcontrollers/tm4c/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "microcontroller mature tm4c");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/microcontrollers/performance/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "microcontroller performance c2000");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/microcontrollers/simplelink/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "microcontroller simplelink");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/microcontrollers/msp/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "microcontroller msp");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/high-voltage/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "high voltage");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/oring-and-smart-diodes/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "oring smart diodes");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/non-isolated-dc-dc-switching-regulator/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "non-isolated dc/dc switching regulator");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/digital-power-control-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "digital power control solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/sequencer/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "sequencer");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/power-management-multi-channel-ic-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "multi-channel ic solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/usb-power-charging-port-controllers/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "usb power charging port controllers");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/battery-management/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "battery management");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/lcd-oled-display-bias-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "lcd oled display bias solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/offline-isolated-dc-dc-controllers-converters/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "offline isolated dc/dc controllers converters");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/ddr-memory-power-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "ddr memory power solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/gallium-nitride-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "gallium nitride solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/power-modules/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "power modules");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/linear-regulator/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "linear regulator");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/mosfet-and-igbt-gate-drivers/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "mosfet igbt gate drivers");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/voltage-reference/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "voltage reference");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/power-over-ethernet-lan-solutions/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "power over ethernet lan solutions");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/power-management/power-mosfet/boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "power mosfet");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/switches-multiplexers/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "switches multiplexers");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/isolation/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "isolation");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/interface/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "interface");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/processors/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "processors");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/rf-microwave/evm-board")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "rf microwave");
				changes = true;
			}
			if (path.startsWith("/content/dam/ticom/images/products/ic/audio/evm-boards")) {
				map.put(FIELD_ASSET_TYPE, new String[] { ASSET_BOARD_IMAGE });
				map.put(FIELD_RIGHTS, new String[] { RIGHTS_TI_PRODUCED });
				map.put(FIELD_KEYWORDS, "audio");
				changes = true;
			}
			if (changes) {
				resourceResolver.commit();
			}
		} catch (Exception e) {
			log.error("Error occurred in TagAutomationProcessStep", e);
		}
	}
}
