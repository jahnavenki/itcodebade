package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.Constants;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this class is used in cross reference compoenent.
 */

public class CrossReference extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private String crossReferenceDomain;

	public String getCrossReferenceDomain() {
		return crossReferenceDomain;
	}

	public void setCrossReferenceDomain(String crossReferenceDomain) {
		this.crossReferenceDomain = crossReferenceDomain;
	}

	@Override
	public void activate() {
		try {

			Page currentPage = getCurrentPage();
			String lang = "en-us";
			String SEARCH_TEXT = "search?";
			StringBuilder domainSB = new StringBuilder();
			String SLASH = "/";
			String supplyFrameUrlDomain = null;

			if (currentPage != null) {
				ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
						.getService(ProductNavigationTabsOrdering.class);
				WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
				if (tabsService != null) {
					lang = tabsService.getPageLanguage(getCurrentPage());
					if (!Constants.CN_LANG.toLowerCase().contains(lang)) {
						lang = "";
					} else {
						lang = lang + SLASH;
					}
				}
				if (null != wcmComponents) {
					supplyFrameUrlDomain = wcmComponents.getSupplyFrameUrlDomain();
				}
				if (null != supplyFrameUrlDomain) {
					domainSB.append(supplyFrameUrlDomain).append(lang).append(SEARCH_TEXT);
					this.crossReferenceDomain = domainSB.toString();
				}

			}
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}
}
