package com.ti.core.components.video;

import java.util.regex.Pattern;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.xfa.ut.StringUtils;
import com.ti.core.util.AssetUtils;
import com.ti.core.service.config.VideoConfigService;

public class VideoThumbnails extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(VideoThumbnails.class);

    private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);
    private String singleVideoThumbnailUrl;
    private String videoSeriesThumbnailUrl;

    public String getVideoSeriesThumbnailUrl() {
        return videoSeriesThumbnailUrl;
    }

    public String getSingleVideoThumbnailUrl() {
        return singleVideoThumbnailUrl;
    }
	
    @Override
    public void activate() {
        try {

            videoSeriesThumbnailUrl = getVideoSeriesThumbnail(getResource());
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
            final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
            final String videoId = matcher.find() ? matcher.group(1) : null;
            if (StringUtils.isEmpty(videoId)) {
                log.debug("Video ID not found in the request path.");
                return;
            }
            Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
            if (damRes == null) {
                log.error("Resource not found for video id: {}", videoId);
                return;
            }
            Resource thumbnailResource = damRes.getChild("jcr:content/renditions/brc_thumbnail.png");
            if (thumbnailResource == null) {
                log.error("Thumbnail resource not found for video id: {}", videoId);
                return;
            }
    
            // Set the thumbnail URL as a Sightly variable
            singleVideoThumbnailUrl = thumbnailResource.getPath();
        
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
    private String getVideoSeriesThumbnail(Resource currentResource) {
        final var videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            log.debug("Video config null or Path not found");
            return "";
        }
        final var topicsList = currentResource.getChild("videoSeriesNavigation/topics");
        if (null == topicsList) return "";
        final var topic = getFirstChild(topicsList);
        if (null == topic) return "";
        final var videosList = topic.getChild("videosList");
        if (null == videosList) return "";
        final var video = getFirstChild(videosList);
        if (null == video) return "";
        final var map = video.adaptTo(ValueMap.class);
        if (null == map) return "";
        final var videoId = map.get("videoId", String.class);
        final var damRes =  AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
        if (null == damRes) return"";
        // Get the thumbnail rendition URL directly
        final var thumbnailResource = damRes.getChild("jcr:content/renditions/brc_thumbnail.png");
        final var videoMap = AssetUtils.getMetadata(damRes);
        String videoStatus = videoMap.get("dam:status", String.class);
        if ("unpublished".equalsIgnoreCase(videoStatus) || null == videoMap || null == thumbnailResource ) {
          log.error("Metadata not found for video id: {} ", videoId);
          return null;
        } 
          return thumbnailResource.getPath();    
    }
    private Resource getFirstChild(Resource res) {
        if (null == res) return null;
        final var iter = res.getChildren().iterator();
        if (!iter.hasNext()) return null;
        return iter.next();
    }

}
