/**
 * 
 */
package com.ti.core.models.tablesaw;

import java.util.ArrayList;
import java.util.List;

import com.ti.core.components.TableSawUse;

/**
 * @author Andy
 * 
 * Model for sightly to use to display headers in tables
 *
 */
public class HeaderRow {
	
	private List<HeaderCell> headerNames = new ArrayList<>();

	public List<HeaderCell> getHeaders() {
		return headerNames;
	}
	
	public int getHeaderRowNumber() {
		if (!this.headerNames.isEmpty())
			return TableSawUse.getRowNumberFromName(this.headerNames.get(0).getName());
		else
			return 0;
	}

}
