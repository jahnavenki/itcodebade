package com.ti.core.service.config;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "TI Service Configuration",
description = "Configuration for ordering of product family standard tabs.")
public @interface ProductsNavigationTabsOrderingConfiguration {
	
	   @AttributeDefinition(name = "standardTabsOrdering", description = "Standard tabs ordering (Should be comma separated values)",type = AttributeType.STRING )
	   String standardTabsOrdering();
		
	   @AttributeDefinition(name = "applicationStandardTabsOrdering", description = "Application Standard tabs ordering (Should be comma separated values)",type = AttributeType.STRING )
	   String applicationStandardTabsOrdering();
		
	   @AttributeDefinition(name = "analyticsPagename", description = "Language codes (Should be comma separated values)", type = AttributeType.STRING )
	   String analyticsPagename() default "en-us/EN,zh-cn/CN,zh-tw/TW,en-in/IN,it-it/IT,ja-jp/JP,fr-fr/FR,de-de/DE,ko-kr/KR,es-mx/MX,ru-ru/RU,vi-vn/VI,id-id/ID";
	   
		

	   @AttributeDefinition(name = "adobeHelpLink", description = "URL for Adobe Help Icon", type = AttributeType.STRING )
		String adobeHelpLink()  default "https://confluence.itg.ti.com/display/DIGIMART/CMS+-+AEM+training";
	   
	  
}
