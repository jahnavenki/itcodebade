
package com.ti.core.components;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.TextLayoutLinks;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.URLHelper;

/**
 * Featured Literature WCMUsePojo.
 */
public class FeaturedLiterature extends WCMUsePojo {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private String literatureNumber;
    private String literatureName;
    private String documentType;
    private int documentSize;
    private String ctaUrl;
    private String downloadUrl;
    private boolean itemExists;

    private String featuredLiteratureResponse = "";

    private List<TextLayoutLinks> listTextLinks = new ArrayList<>();
    private DecimalFormat sizeFormat = new DecimalFormat("#.##");
    private Boolean textVariationValidity = false;
    private List<SeoUrlTagging> listConfig;

    private String featuredLiteratureMulti = "";
    private float documentSizeMulti;
    private String documentTypeMulti;
    private String literatureNameMulti;
    private String url = null;
    private String customCtaUrl = null;

    private static final String FILE_AVAILABILITY = "litWebFileAvailability";
    private static final String CONCISE_DESCRIPTION = "conciseDescription";
    private static final String FILE_EXTENSION = "fileExtension";
    private static final String BYTE_SIZE = "byteSize";
    private static final String LINKS_ITEMS = "linksItems";
    private static final String LITERATURE_NUMBER = "litNumber";
    private static final String LITERATURE_NUMBER_TEXT = "litNumberText";
    private static final String CTA_URL = "ctaUrl";
    private static final String SLASH = "://";
    private static final String HTTP = "http";
    private static final String HTTPS = "https";
    private static final String PDF = "pdf";
    private static final String ZIP = "zip";
    private static final String LIT_NUMBER = "literatureNumber";

    private String litNumber = null;
    private String pagelanguage;

    @Override
    public void activate() throws RepositoryException {
        try {
            JSONObject jsonLiterature;
            WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
            ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                    .getService(ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
            }

            this.ctaUrl = getProperties().get(CTA_URL, String.class);

            if (ctaUrl != null && !ctaUrl.startsWith(HTTP) && !ctaUrl.startsWith(HTTPS)) {
                customCtaUrl = URLHelper.toScheme(generateDomain(), URLHelper.getScheme(getRequest()));
            }

            this.literatureNumber = getProperties().get(LITERATURE_NUMBER, String.class);

            if (null != wcmService) {

                this.featuredLiteratureResponse = wcmService.getFeaturedliterature(literatureNumber, pagelanguage);
            }

            if (StringUtils.isNotEmpty(featuredLiteratureResponse)) {
                this.url = generateDomain();
                jsonLiterature = new JSONObject(featuredLiteratureResponse);

                this.literatureName = jsonLiterature.getString(CONCISE_DESCRIPTION);

                JSONArray jsonLitAvailability = jsonLiterature.getJSONArray(FILE_AVAILABILITY);
                litNumber = jsonLiterature.getString(LIT_NUMBER);

                // The order of priority is PDF > ZIP > Any other file type

                JSONObject node = getNodeForFileExtension(jsonLitAvailability);
                if (node != null) {
                    this.documentType = node.getString(FILE_EXTENSION);
                    this.documentSize = node.getInt(BYTE_SIZE);
                    this.downloadUrl = URLHelper.toScheme(
                            getLiteratureUrl(litNumber),
                            URLHelper.getScheme(getRequest()));
                } else {
                    log.error("Json Literature availability is empty or null");
                }

            } else {
                this.literatureName = null;
            }
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(LINKS_ITEMS)) {
                    itemExists=true;
                    for (Resource number : nodeChild.getChildren()) {
                        ValueMap properties = number.adaptTo(ValueMap.class);
                        if (null != properties) {
                            this.featuredLiteratureMulti = wcmService
                                    .getFeaturedliterature(properties.get(LITERATURE_NUMBER_TEXT, String.class), pagelanguage);
                            readFeaturedLiteratureResponse(properties);
                        }

                    }

                }
            }
        } catch (JSONException e) {
            log.error("JSONException: " + e);
        }
    }

    private String generateDomain() {
        String domain = "";
        SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
        if (null != factoryConfigs) {
            listConfig = factoryConfigs.getConfigs();
            for (SeoUrlTagging seoUrlTagging : listConfig) {
                if (StringUtils.containsIgnoreCase(getCurrentPage().getPath(), seoUrlTagging.getContentPath())) {
                    domain = seoUrlTagging.getDomainName();
                    domain = HTTP.concat(SLASH).concat(domain);
                    break;
                }
            }
        }
        return domain;
    }

    private String getLiteratureUrl(String literatureNum) {
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        return langUtils.getI18nStr("https://www.ti.com/lit/") + literatureNum;
    }

    /**
     * Read the Featured Literature service response and return textLinks.
     *
     * @param properties - parameter
     */
    public void readFeaturedLiteratureResponse(ValueMap properties) {
        JSONObject jsonLiteratureMulti;
        TextLayoutLinks textLinks = new TextLayoutLinks();
        if (StringUtils.isNotEmpty(featuredLiteratureMulti)) {
            this.textVariationValidity = true;
            try {
                textLinks.setLiteratureNumber(properties.get(LITERATURE_NUMBER_TEXT, String.class));
                jsonLiteratureMulti = new JSONObject(featuredLiteratureMulti);

                this.literatureNameMulti = jsonLiteratureMulti.getString(CONCISE_DESCRIPTION);
                litNumber = jsonLiteratureMulti.getString(LIT_NUMBER);

                JSONArray jsonLitAvailability = jsonLiteratureMulti.getJSONArray(FILE_AVAILABILITY);

                JSONObject node = getNodeForFileExtension(jsonLitAvailability);
                if (node != null) {
                    this.documentTypeMulti = node.getString(FILE_EXTENSION);
                    this.documentSizeMulti = node.getInt(BYTE_SIZE);
                    this.downloadUrl = URLHelper.toScheme(
                            getLiteratureUrl(litNumber),
                            URLHelper.getScheme(getRequest()));
                } else {
                    log.error("Json Literature availability is empty or null");
                }
                textLinks.setByteSize(sizeFormat.format(documentSizeMulti));
                textLinks.setConciseDescription(literatureNameMulti);
                textLinks.setFileExtension(documentTypeMulti);
                textLinks.setValid(true);
                textLinks.setDownloadUrl(downloadUrl);

            } catch (JSONException e) {
                log.error("JSON Exception:" + e);
            }
        } else {
            textLinks.setValid(false);
        }
        listTextLinks.add(textLinks);
    }

    public String getLiteratureName() {
        return literatureName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public int getDocumentSize() {
        return documentSize;
    }

    public String getUrl() {
        return url;
    }

    public List<TextLayoutLinks> getListTextLinks() {
        return listTextLinks;
    }

    public Boolean getTextVariationValidity() {
        return textVariationValidity;
    }

    public String getCustomCtaUrl() {
        return customCtaUrl;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public boolean isItemExists() {
        return itemExists;
    }

    public void setItemExists(boolean itemExists) {
        this.itemExists = itemExists;
    }

    /**
     * Iterate through the collection - 1. If we find node with PDF extension,
     * return it. 2. If we don't find PDF, find the first node that has ZIP
     * extension and return it 3. If not, return other file type extension.
     *
     * @param jsonLitAvailability
     * @throws JSONException
     */
    private JSONObject getNodeForFileExtension(JSONArray jsonLitAvailability) throws JSONException {

        JSONObject primaryNode = null;
        if (jsonLitAvailability != null) {

            if (jsonLitAvailability.length() == 1) {
                return jsonLitAvailability.getJSONObject(0);
            }

            String currentFileExtension = null;
            String previousFileExtension = null;

            for (int i = 0; i < jsonLitAvailability.length(); i++) {
                JSONObject node = jsonLitAvailability.getJSONObject(i);
                currentFileExtension = node.getString(FILE_EXTENSION);
                if (null != currentFileExtension && !currentFileExtension.equals(previousFileExtension)) {
                    if (currentFileExtension.equalsIgnoreCase(PDF)) {
                        primaryNode = node;
                        break;
                    } else if (null == previousFileExtension || !previousFileExtension.equalsIgnoreCase(ZIP)) {
                        primaryNode = node;
                    }
                }
                previousFileExtension = currentFileExtension;
            }
        }
        return primaryNode;
    }
}
