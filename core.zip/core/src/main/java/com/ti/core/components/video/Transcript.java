package com.ti.core.components.video;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

public class Transcript extends WCMUsePojo {
    
    protected final Logger log = LoggerFactory.getLogger(Transcript.class);

    @OSGiService
    private VideoConfigService videoService;

	private static final String PROXY_HOST = "webproxy.ext.ti.com";
	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

	private String apiGet3pId = "https://api.3playmedia.com/v3/files/?reference_id={id}&api_key={key}";
	private String apiGet3pTranscriptList = "https://api.3playmedia.com/v3/transcripts/?media_file_id={id}&api_key={key}";
	private String apiGet3pTranscriptText = "https://api.3playmedia.com/v3/transcripts/{id}/text/?output_format_id=16&api_key={key}";
    
	private String accountId;
	private String title;
    private String desc;
    private String threePlayId;
	private String transcriptText;
	private int totalTranscripts;
	private List<String> transcriptList = new ArrayList<>();

    public String getAccountId() {
        return accountId;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getThreePlayId() {
		return threePlayId;
    }

    public String getTranscriptText() {
		return transcriptText;
	}
	
	public int getTotalTranscripts() {
		return totalTranscripts;
	}

	public List<String> getTranscriptList() {
		return transcriptList;
	}

    @Override
    public void activate() {      
		try {
            String pageLanguage = "en-us";
            WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
            if (null != wcmService) {
                ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                    .getService(ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    pageLanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
                }
            }    
			videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null ) {
				log.debug("Video service not found");
				return;
			}
			String videoPath = videoService.getVideoPath();
			if (videoPath == null || videoPath.length() <= 0) {
				log.debug("Video path not found in the config");
				return;
			}
			String apiKey = videoService.getApiKey3play();
			if (apiKey == null || apiKey.length() <= 0) {
				log.debug("3Play API key not found in the config");
				return;
			}

			accountId = videoService.getAccountId();
			if (accountId == null || accountId.length() <= 0) {
				log.debug("3Play account ID not found in the config");
				return;
			}

			final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
			final String videoId = matcher.find() ? matcher.group(1) : null;
			if (null == videoId) return;
			Resource resource = AssetUtils.getDamResource(getResourceResolver(), videoPath, videoId);
			if (resource == null) {
				log.error("Resource not found for video id: {} ", videoId);
				return;
			}
			// get metadata and assign to fields
			final var map = AssetUtils.getMetadata(resource);
			if (null == map)  {
				log.error("Metadata not found for video id: {} ", videoId);
				return;
			}

			title = map.get("dc:title", "");
			desc = map.get("brc_description", "");
			// if description is empty, 3 play uses title
			if (desc.isEmpty()) {
				desc = title;
			}
			String brcId = map.get("brc_id", "");
			getTranscriptFrom3P(pageLanguage, apiKey, brcId);
		}
		catch (Exception e) {
			log.error("Exception in Transcript component: ", e);
		}
    }

	private void getTranscriptFrom3P(String pageLanguage, String apiKey, String brcId) { 
		totalTranscripts = 0;
		HashMap<String, String> langs = new HashMap<>();
		langs.put("1", "en-us");
		langs.put("7", "de-de");
		langs.put("17", "zh-cn");
		langs.put("23", "ja-jp");
		langs.put("31", "ko-kr");

		HashMap<String, String> langLabels = new HashMap<>();
		langs.put("1", "English");
		langs.put("7", "German");
		langs.put("17", "Chinese (Simplified)");
		langs.put("23", "Japanese");
		langs.put("31", "Korean");

		try {
			// API call to get 3play id
			String url = apiGet3pId.replace("{id}", brcId).replace("{key}", apiKey);
			String res = makeRequest(url);
			JSONObject fileObj = new JSONObject(res);
			// get file in response, it should be just one
			JSONArray tpmFiles = fileObj.getJSONArray("data");
			if (tpmFiles.length() == 0) {
				log.error("3Play API to get 3Play ID didn't return data");
				return;
			}
			// get 3play id
			threePlayId = String.valueOf(tpmFiles.getJSONObject(0).getInt("id"));

			// next API call to get transcript list
			url = apiGet3pTranscriptList.replace("{id}", threePlayId).replace("{key}", apiKey);
			res = makeRequest(url);
			JSONObject transcriptsObj = new JSONObject(res);
			// get list of available transcripts
			JSONArray transcripts = transcriptsObj.getJSONArray("data");
			if (transcripts.length() == 0) {
				log.error("3Play API to get transcript list didn't return data");
				return;
			}

			for (int i = 0; i < transcripts.length(); i++) {
				String transcriptId = String.valueOf(transcripts.getJSONObject(i).getInt("id"));
				String transcriptLang = String.valueOf(transcripts.getJSONObject(i).getInt("language_id"));
				String transcriptStatus = transcripts.getJSONObject(i).getString("status");
				// check that status is complete and transcript is in langs we use  
				if ("complete".equals(transcriptStatus)  && langs.containsKey(transcriptLang) && langs.get(transcriptLang).equalsIgnoreCase(pageLanguage)) {				
					// get full text for seo
					url = apiGet3pTranscriptText.replace("{id}", transcriptId).replace("{key}", apiKey);
					res = makeRequest(url);
					JSONObject textObj = new JSONObject(res);
					transcriptText = textObj.getString("data");
				}
				if ("complete".equals(transcriptStatus)  && langs.containsKey(transcriptLang)) {
					totalTranscripts++;
					transcriptList.add(langLabels.get(transcriptLang));
				}
			}
      	} catch (Exception e) {
			log.error(e.getMessage(), e);
    	}
	}

	private String makeRequest(String apiUrl) {
		String result = "";
		
		try {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection connection;
			URL url = new URL(apiUrl);
			connection = (HttpURLConnection) url.openConnection(proxy);
			connection.setRequestMethod("GET");
			connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			connection.setRequestProperty("Content-length", "0");
			connection.setUseCaches(false);
			connection.setAllowUserInteraction(false);

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
			String line;
			StringBuilder res = new StringBuilder();
			
			while ((line=in.readLine()) != null) {       
				res.append(line + '\n');
			}
			in.close();
			result = res.toString();
		} catch (MalformedURLException e){
			log.error("3play bad url : ", e);
		} catch (IOException e){
			log.error("3play Read Error : ", e);
		}
		return result;
	}
}
