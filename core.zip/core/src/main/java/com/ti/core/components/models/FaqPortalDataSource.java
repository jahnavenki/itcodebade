package com.ti.core.components.models;

import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import javax.annotation.PostConstruct;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = {SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FaqPortalDataSource {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ProductNavigationTabsOrdering productNavigationTabsOrdering;

	@ScriptVariable
	private Page currentPage;

	private String faqPortalSideNavigationDataSource;
	private String faqPortalMiniTeaserDataSource;

	public String getFaqPortalSideNavigationDataSource() {
		return faqPortalSideNavigationDataSource;
	}

	public String getFaqPortalMiniTeaserDataSource() {
		return faqPortalMiniTeaserDataSource;
	}

    private static final String ROOT_PAGE_NAME = "ordering-resources";

	private Page componentDataSourcePage(Page page) {
		if (ROOT_PAGE_NAME.equalsIgnoreCase(page.getName())) {
			return page;
		}
		final var parentPage = page.getParent();
		if (null == parentPage) {
			log.error("Did not find root page");
			return null;
		}
		if (ROOT_PAGE_NAME.equalsIgnoreCase(parentPage.getName())) {
			return page;
		}
		return componentDataSourcePage(parentPage);
	}

	@PostConstruct
	public void init() {
		try {
			final var componentDataSourcePage = componentDataSourcePage(currentPage);
			if (null != componentDataSourcePage) {
				faqPortalSideNavigationDataSource = componentDataSourcePage.getPath() + "/jcr:content/apiportalsidenavigat";
                faqPortalMiniTeaserDataSource= componentDataSourcePage.getPath() + "/jcr:content/miniteaser";
			}
		} catch(Exception ex) {
			log.error("Exception in FaqPortalDataSource", ex);
		}
	}
}
