package com.ti.core.service.impl;

import java.util.Map;
import java.util.regex.Matcher;

import org.apache.sling.api.resource.LoginException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.ApiPortalService;
import com.ti.core.util.PathBrowserHelper;

@Component(immediate = true, service = ApiPortalService.class)
public class ApiPortalServiceImpl implements ApiPortalService {
	private final Logger log = LoggerFactory.getLogger(getClass());
	private static final String SECURE_APP = "/swc/";

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	public Boolean isSecureUrl(String url) {
		if (StringUtils.isEmpty(url)) return false;
		if (url.contains("/developer-apis/")) return true;
		return false;
	}

	public String getUrl(String url) {
		if (StringUtils.isEmpty(url)) return "";
		ResourceResolver resourceResolver;
		try {
			resourceResolver = resourceResolverFactory.getResourceResolver(Map.of());
		} catch(LoginException ex) {
			log.error("LoginException", ex);
			return null;
		}
		try(resourceResolver) {
			url = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, url);
			if (isSecureUrl(url)) {
				if (!url.contains(SECURE_APP)) {
					url = url.replaceAll("^((https?:)?//[^/]+)?/", "$1" + Matcher.quoteReplacement(SECURE_APP));
				}
			} else {
				url = url.replace(SECURE_APP, "/");
			}
			return url;
		}
	}
}
