package com.ti.core.schedulers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.email.EmailService;
import com.day.cq.commons.Externalizer;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.ti.core.util.PathBrowserHelper;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;

@Component(immediate = true, service = Job.class)
@Designate(ocd = VideoExpiryNotificationSchedulerJob.Config.class)
public class VideoExpiryNotificationSchedulerJob implements Job {

    private static final Logger log = LoggerFactory.getLogger(VideoExpiryNotificationSchedulerJob.class);
    private static final String PROFILE = "/profile";
    private static final String DAM_POWER_USERS_TEMPLATE = "/conf/global/settings/workflow/notification/email/ti/dam-video-email-notification-power-users.html";
    
    @Reference
    private EmailService emailService;

    @Reference
    private Scheduler scheduler;

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private QueryBuilder queryBuilder;

    @ObjectClassDefinition(name = "TI DAM Video Expiry Notification", description = "TI DAM Video Expiry Notification")
    public @interface Config {
        @AttributeDefinition(type = AttributeType.STRING, name = "cqDamVideoExpiryNotificationSchedulerTimebasedRule",
                description = "Regular expression for time based Scheduler. Eg: '0 0 0 * * ?'. The example expression triggers the Job @ 00 hrs. This expression get picked if Time Based Scheduler is true (cqDamVideoExpiryNotificationSchedulerTimebasedRule)")
        String cqDamVideoExpiryNotificationSchedulerTimebasedRule() default "0 20 15 * * ?"; //cqDamVideoExpiryNotificationSchedulerTimebasedRule
    }

    public static final String SCHEDULER_PERIOD = "cqDamVideoExpiryNotificationSchedulerTimebasedRule";

    private Calendar lastRun;
    private Calendar thisRun;

    private ResourceResolver resourceResolver;

    public void execute(final JobContext arg0) {
        this.thisRun = Calendar.getInstance();
        try {
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            this.resourceResolver = this.resolverFactory.getServiceResourceResolver(param);
            final Collection<Hit> expiredAssets = this.getExpiredAssetHits();
            final Collection<Asset> expiredSinceLastRun = this.getExpiredAssets(expiredAssets);
            for (Asset asset : expiredSinceLastRun) {
                Resource res=resourceResolver.getResource(asset.getPath());
                ValueMap properties=ResourceUtil.getValueMap(res);
                String videoId=properties.get("./jcr:content/metadata/brc_id",String.class); 
                setEmailParameters(asset,videoId);
            }
        } catch (Exception e) {
            log.error("Error in execute.", (Throwable) e);
        } finally {
            if (null != this.resourceResolver) {
                this.resourceResolver.close();
            }
        }
        this.lastRun = this.thisRun;
    }

    private void setEmailParameters(Asset asset, String videoId) {
        Externalizer externalizer = this.resourceResolver.adaptTo(Externalizer.class); // allows creation of absolute URLs.
        if (externalizer == null) {
            return;
        }
        Map<String, String> emailParams = new HashMap<>();
        emailParams.put("assetPath", asset.getPath());
        List<String> members = getEmailRecipentsFromGroup("ti-dam-power-user");
        Map<String, String> transformedPaths = new HashMap<>();
        Collection<Hit> list =getAssetReferencePath(videoId);
        String singlePath ="/content/texas-instruments/en-us/video/"+videoId;
        String pagePath="";
        for (Hit hit : list) {
            try {
                pagePath = hit.getPath();
                
                } 
            catch (RepositoryException e) {
                    log.error("RepositoryException {}", e);
                }
            transformedPaths.put(pagePath, getTransformedPath(pagePath));
            
        }
        String singlePathTransformedPath=getTransformedPath(singlePath);
        int singlePathWithoutHTMl=singlePathTransformedPath.length()-5;
        transformedPaths.put(singlePath, singlePathTransformedPath.substring(0,singlePathWithoutHTMl));
        emailParams.put("paths", String.join("\n", transformedPaths.values()));
        sendTemplatedEmail(DAM_POWER_USERS_TEMPLATE, emailParams, members);
            
        
    }

    
    private String getTransformedPath(String path) {
        String mappedPath = PathBrowserHelper.addHtmlIfContentPath(this.resourceResolver, path);
        mappedPath = mappedPath.replace("/content/texas-instruments/en-us", "");
        mappedPath = mappedPath.replace("/content/texas-instruments", "");
        return mappedPath;
    }
    
    
    /*
    To find page references for a video using videoId
    */

    private Collection<Hit> getAssetReferencePath(String videoId) {
        final Map<String, String> map = new HashMap<>();
        map.put("path", "/content/texas-instruments");
        map.put("type", "cq:Page");
        map.put("1_property", "jcr:content/cq:template");
        map.put("1_property.value", "/conf/ti/settings/wcm/templates/video-series-page-template");
        map.put("2_property", "videoId");
        map.put("2_property.value" , videoId);
        map.put("2_property.depth" ,"6"); // "6" here is the depth of videoId node under video series page
        map.put("p.guessTotal", "10000");
        final Query query = this.queryBuilder.createQuery(PredicateGroup.create(map),
        this.resourceResolver.adaptTo(Session.class));
        query.setHitsPerPage(10000L);
        final SearchResult results = query.getResult();
        return results.getHits();
       
    }
    

    private void sendTemplatedEmail(String templatePath, Map<String, String> emailParams, List<String> members) {
	if (Objects.nonNull(members) && !members.isEmpty()) {
            String[] receipients = members.stream().filter(item -> !item.isEmpty()).toArray(String[]::new);
            List<String> failureList = emailService.sendEmail(templatePath, emailParams, receipients);
            if (failureList.isEmpty()) {
                log.info("---------------Mail delivery successfull---------------");
            } else {
                log.info("---------------Mail delivery failed---------------");
            }
        }
    }

    private List<String> getEmailRecipentsFromGroup(String userGroupName) {

        UserManager userManager = this.resourceResolver.adaptTo(UserManager.class); // allows to access users & groups
        List<Authorizable> users = new ArrayList<>();
        try {
            if (StringUtils.isNotBlank(userGroupName) && null != userManager
                    && null != userManager.getAuthorizable(userGroupName)) {
                Authorizable auth = userManager.getAuthorizable(userGroupName);
                if (!auth.isGroup()) {
                    return new ArrayList<>();
                }
                Group group = (Group) auth;
                Iterator<Authorizable> iter = group.getMembers();
                while (iter.hasNext()) {
                    users.add(iter.next());
                }
                return users.stream().map(user -> {
                    try {
                        return this.resourceResolver.getResource(user.getPath() + PROFILE);
                    } catch (RepositoryException e) {
                        log.error("RepositoryException {}", e);
                    }
                    return null;
                }).filter(Objects::nonNull).map(res -> res.adaptTo(ValueMap.class)).filter(Objects::nonNull)
                        .map(v -> v.get("email", StringUtils.EMPTY)).filter(Objects::nonNull)
                        .collect(Collectors.toCollection(ArrayList::new));

            }
        } catch (RepositoryException e) {
            log.error("Error in getEmailRecipentsFromGroup due to {}", e);
        }

        return new ArrayList<>();
    }

    private Collection<Asset> getExpiredAssets(final Collection<Hit> hits) throws RepositoryException {
        return hits.stream().map(h -> {
            try {
                return this.resourceResolver.getResource(h.getPath());
            } catch (RepositoryException e) {
                log.error("RepositoryException {}", e);
            }
            return null;
        }).filter(Objects::nonNull).map(r -> r.adaptTo(Asset.class)).filter(Objects::nonNull)
                .collect(Collectors.toCollection(ArrayList::new));
    }
    

    private Collection<Hit> getExpiredAssetHits() {
        final Map<String, String> map = new HashMap<>();
        map.put("path", "/content/dam");
        map.put("type", "dam:Asset");
        map.put("group.1_group.daterange.property", "jcr:content/dam:offTime");
        map.put("group.1_group.daterange.lowerBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("group.1_group.daterange.upperBound", String.valueOf(this.thisRun.getTimeInMillis()));
        map.put("group.p.or", "true");
        map.put("group.2_group.1_daterange.property", "jcr:content/metadata/dam:modified");
        map.put("group.2_group.1_daterange.lowerBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("group.2_group.1_daterange.upperBound", String.valueOf(this.thisRun.getTimeInMillis()));
        map.put("group.2_group.2_daterange.property", "jcr:content/dam:offTime");
        map.put("group.2_group.2_daterange.upperBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("p.guessTotal", "10000");
        final Query query = this.queryBuilder.createQuery(PredicateGroup.create(map),
        this.resourceResolver.adaptTo(Session.class));
        query.setHitsPerPage(10000L);
        final SearchResult results = query.getResult();
        return results.getHits();
    }

    @SuppressWarnings("deprecation")
    protected void activate(final Config config) throws Exception {
        try {
            this.lastRun = Calendar.getInstance();
            this.lastRun.set(Calendar.HOUR_OF_DAY, 0);
            this.lastRun.set(Calendar.MINUTE, 0);
            this.lastRun.set(Calendar.SECOND, 0);
            this.lastRun.set(Calendar.MILLISECOND, 0);
            final String expression = config.cqDamVideoExpiryNotificationSchedulerTimebasedRule();
            this.scheduler.addJob(VideoExpiryNotificationSchedulerJob.class.getName(), this, null, expression, false);
        } catch (Exception e) {
            log.error("Error in activate.", e);
        }
    }

    @SuppressWarnings("deprecation")
    protected void deactivate(final ComponentContext componentContext) {
        log.debug("Deactivating the video expiry notification scheduler");
        this.scheduler.removeJob(VideoExpiryNotificationSchedulerJob.class.getName());
    }
}