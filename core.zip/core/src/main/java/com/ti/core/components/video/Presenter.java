package com.ti.core.components.video;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Presenter extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

    private boolean needsAuthoring;
    public boolean getNeedsAuthoring() {
        return needsAuthoring;
    }

    private String presenter1ImageSrc;
    public String getPresenter1ImageSrc() {
        return presenter1ImageSrc;
    }
    private String presenter2ImageSrc;
    public String getPresenter2ImageSrc() {
        return presenter2ImageSrc;
    }
    
    private String presenter1EmployeeName;
    public String getPresenter1EmployeeName() {
        return presenter1EmployeeName;
    }

    private String presenter1EmployeeTitle;
    public String getPresenter1EmployeeTitle() {
        return presenter1EmployeeTitle;
    }
     private String presenter2EmployeeName;
    public String getPresenter2EmployeeName() {
        return presenter2EmployeeName;
    }

    private String presenter2EmployeeTitle;
    public String getPresenter2EmployeeTitle() {
        return presenter2EmployeeTitle;
    }

    @Override
    public void activate() {
        try {
            final var resourceResolver = getResourceResolver();

            final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
            final String videoId = matcher.find() ? matcher.group(1) : null;
            VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
    		Resource resource = AssetUtils.getDamResource(resourceResolver, videoService.getVideoPath(), videoId);
            
            if (null == resource)  {
                log.error("Resource not found for video id: {} ", videoId);
				return;
			}
            final var map = AssetUtils.getMetadata(resource);
            if (null == map)  {
                log.error("Metadata not found for video id: {} ", videoId);
				return;
			}
            presenter1ImageSrc = map.get("dam:presenter1", String.class);
            presenter2ImageSrc = map.get("dam:presenter2", String.class);
            if (StringUtils.isEmpty(presenter1ImageSrc) && StringUtils.isEmpty(presenter2ImageSrc)) {
                needsAuthoring = true;
                return;
            }
            needsAuthoring = false;
            if (!StringUtils.isEmpty(presenter1ImageSrc)) {
                final var presenter1ImageResource = resourceResolver.getResource(presenter1ImageSrc);
                if (presenter1ImageResource != null) {
                    Asset presenter1Asset = presenter1ImageResource.adaptTo(Asset.class);
                    if (presenter1Asset != null) {
                        presenter1EmployeeName = presenter1Asset.getMetadataValue("dam:employeeName");
                        presenter1EmployeeTitle = presenter1Asset.getMetadataValue("dam:employeeTitle");
                    }
                }
            }
            if (!StringUtils.isEmpty(presenter2ImageSrc)) {
                final var presenter2ImageResource = resourceResolver.getResource(presenter2ImageSrc);
                if (presenter2ImageResource != null) {
                    Asset presenter2Asset = presenter2ImageResource.adaptTo(Asset.class);
                    if (presenter2Asset != null) {
                        presenter2EmployeeName = presenter2Asset.getMetadataValue("dam:employeeName");          
                        presenter2EmployeeTitle = presenter2Asset.getMetadataValue("dam:employeeTitle");
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
}
