package com.ti.core.service.config;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name =  "Texas Instruments Silo Config Service",
description =  "Texas Instruments Silo Config Service")
public @interface SiloConfiguration {
	
	   @AttributeDefinition(name = "abouttisilourl", description = "About Ti Silo URL",type = AttributeType.STRING )
	   String abouttisilourl();
		
	  
	   
	  
}
