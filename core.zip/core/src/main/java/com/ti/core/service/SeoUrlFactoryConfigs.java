package com.ti.core.service;

import java.util.List;

public interface SeoUrlFactoryConfigs {

  List<SeoUrlTagging> getConfigs();

}
