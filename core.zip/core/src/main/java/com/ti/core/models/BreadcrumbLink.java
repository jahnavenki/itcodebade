/**
 * 
 */
package com.ti.core.models;

/**
 * @author x0262057
 *
 */
public class BreadcrumbLink {

	private String link;
	private String title;
	private String titleEN;
	
	public BreadcrumbLink(){}
	
	public BreadcrumbLink(String title, String link) {
		this.title = title;
		this.link = link;
	}

	public BreadcrumbLink(String title, String link, String titleEN) {
		this.title = title;
		this.link = link;
		this.titleEN = titleEN;
	}
	
	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}
	/**
	 * @param link the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the title in EN
	 */
	public String getTitleEN() {
		return titleEN;
	}
	/**
	 * @param title the title in EN to set
	 */
	public void setTitleEN(String titleEN) {
		this.title = titleEN;
	}

	public String getLinkProducts() {
		if (link.isEmpty()) return "";
		else return link.replace("overview.html","products.html");
	}
	
	public String getNavTitle() {
		String navTitle = titleEN != null && !titleEN.trim().isEmpty() ? titleEN : title;
		if (link.isEmpty()) return "";
		else return navTitle.replace(" ","_").toLowerCase();
	}
}