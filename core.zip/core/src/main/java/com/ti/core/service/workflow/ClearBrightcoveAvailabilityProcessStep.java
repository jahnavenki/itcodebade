package com.ti.core.service.workflow;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.jcr.Session;

import org.apache.commons.collections4.iterators.IteratorIterable;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.QueryBuilder;
import com.ti.core.service.WCMComponents;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set Availability to Always Available in Brightcove.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Clear Brightcove Availability" })
public class ClearBrightcoveAvailabilityProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private WCMComponents wcmService;

	private ResourceResolver resourceResolver;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			final var rootRes = resourceResolver.resolve(payload);
			if (null == rootRes) throw new Exception("Resource not found: " + payload);
			var videosProcessed = 0;
			var videosFailed = 0;
			for(final var videoId : getBrightcoveIds(rootRes)) {
				log.debug("ClearBrightcoveAvailabilityProcessStep: clearing availability for {}", videoId);
				final var json = new JSONObject();
				json.put("schedule", JSONObject.NULL);
				try {
					wcmService.updateBrightcoveVideo(videoId, json);
					++videosProcessed;
				} catch(Exception ex) {
					log.error("Error occurred in ClearBrightcoveAvailabilityProcessStep for video " + videoId, ex);
					++videosFailed;
				}
			}
			if (videosProcessed == 0 || videosFailed > 0) {
				log.warn("ClearBrightcoveAvailabilityProcessStep completed; {} videos processed, {} videos failed", videosProcessed, videosFailed);
			} else {
				log.info("ClearBrightcoveAvailabilityProcessStep completed; {} videos processed", videosProcessed);
			}
		} catch(Exception ex) {
			log.error("Error occurred in ClearBrightcoveAvailabilityProcessStep", ex);
		}
	}

	private String getBrightcoveId(Resource res) {
		final var metadataRes = res.getChild("jcr:content/metadata");
		if (null == metadataRes) return null;
		final var valueMap = metadataRes.getValueMap();
		final var videoId = valueMap.get("brc_id", String.class);
		if (StringUtils.isEmpty(videoId)) return null;
		else return videoId;
	}

	private Iterable<String> getBrightcoveIds(Resource rootRes) throws Exception {
		final var rootVideoId = getBrightcoveId(rootRes);
		if (StringUtils.isNotEmpty(rootVideoId)) return List.of(rootVideoId);
		final var builder = resourceResolver.adaptTo(QueryBuilder.class);
		if (null == builder) throw new NullPointerException();
		final var jcrSession = resourceResolver.adaptTo(Session.class);
		if (null == jcrSession) throw new NullPointerException();
		final var map = new HashMap<String, String>();
		map.put("path", rootRes.getPath());
		map.put("type", "dam:Asset");
		map.put("1_property", "jcr:content/metadata/brc_id");
		map.put("1_property.operation", "exists");
		map.put("p.limit", "-1");
		final var query = builder.createQuery(PredicateGroup.create(map), jcrSession);
		final var result = query.getResult();
		final var videoIds = new HashSet<String>( (int)result.getTotalMatches() );
		for (final var res : new IteratorIterable<>(result.getResources()) ) {
			final var videoId = getBrightcoveId(res);
			if (StringUtils.isNotEmpty(videoId)) videoIds.add(videoId);
		}
		return videoIds;
	}
}
