package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import java.util.Date;
import java.util.Calendar;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class HomePageBannersTimeline WCMUsePojo.
 */
public class HomePageBannersTimeline extends WCMUsePojo {

	protected static final Logger log = LoggerFactory.getLogger(HomePageBannersTimeline.class);

	private final List<String[]> monthList = new ArrayList<>();
	private final List<String[]> dateList = new ArrayList<>();
	private final List<Integer> dateNumBannersList = new ArrayList<>();

	public List<String[]> getMonthList() {
		return monthList;
	}

	public List<String[]> getDateList() {
		return dateList;
	}

	public List<Integer> getDateNumBannersList() {
		return dateNumBannersList;
	}

	@Override
	public void activate() {
		try {
			// Get list of all Home Page Banner components
			List<Resource> homePageBanners = new ArrayList<>();
			resourceListHelper(getResourceResolver().resolve(getProperties().get("homePageBannersUrl", StringUtils.EMPTY)),
					"sling:resourceType", "ti/components/homePageBanner", homePageBanners);

			Calendar now = Calendar.getInstance();
			now.set(Calendar.HOUR_OF_DAY, 0);
			now.set(Calendar.MINUTE, 0);
			now.set(Calendar.SECOND, 0);
			now.set(Calendar.MILLISECOND, 0);
			String sCurrentMonth = now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
			Integer daysInMonth = 0;
			for (int i = 0; i < 100; i++) {
				// Set 1st row: months
				if (!sCurrentMonth.equals(now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault()))) {
					monthList.add(new String[] { sCurrentMonth, daysInMonth.toString() });

					sCurrentMonth = now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
					daysInMonth = 0;
				}

				// Set 2nd row: date list
				dateList.add(new String[] { Integer.toString(now.get(Calendar.DATE)), now.getTime().toString() });

				// Set 3rd row: number of active banners on the given day
				dateNumBannersList.add(i, numOfActiveBanners(homePageBanners, now));

				now.add(Calendar.DATE, 1);
				daysInMonth++;
			}

			// Set the last month in the 1st row
			monthList.add(new String[] { sCurrentMonth, daysInMonth.toString() });

		} catch (Exception e) {
			log.error("Exception: {0}", e);
		}
	}

	private int numOfActiveBanners(List<Resource> homePageBanners, Calendar now) {
		int numBanners = 0;
		for (Resource res : homePageBanners) {
			ValueMap properties = res.adaptTo(ValueMap.class);
			if (properties != null) {
				Date startTime = properties.get("startTime", Date.class);
				Date endTime = properties.get("endTime", Date.class);

				if (startTime != null && endTime != null && startTime.getTime() <= now.getTimeInMillis()
						&& endTime.getTime() >= now.getTimeInMillis())
					numBanners++;
			}
		}

		return numBanners;
	}
	
	public void resourceListHelper(Resource parentResource, String targetSearchPropertyKey,
			String targetSearchPropertyValue, List<Resource> components) {
		Resource childResource;
		for (Iterator<Resource> resourceChildrenIter = parentResource.listChildren(); resourceChildrenIter
				.hasNext(); resourceListHelper(childResource, targetSearchPropertyKey, targetSearchPropertyValue,
						components)) {
			childResource = resourceChildrenIter.next();
			ValueMap childProperties = childResource.adaptTo(ValueMap.class);

			if (childProperties != null
					&& targetSearchPropertyValue.equals(childProperties.get(targetSearchPropertyKey, String.class))) {
				components.add(childResource);
			}
		}
	}
}
