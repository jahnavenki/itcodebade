package com.ti.core.service.config;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "TI Url Tagging Configuration ",
description = "TI Url Tagging Configuration")
public @interface SeoUrlTaggingConfiguration {
	
	   @AttributeDefinition(name = "contentPath", description = "Content Path",type = AttributeType.STRING  )
	   String contentPath() default "/content/texas-instruments/<lang-code>";
		
	   @AttributeDefinition(name = "domainName", description = "Domain name",type = AttributeType.STRING )
	   String domainName()  default "www.myhost.com";
		
	   @AttributeDefinition(name = "selectorLabel", description = "Selector Label",type = AttributeType.STRING )
	   String selectorLabel();
	   
		

	   @AttributeDefinition(name = "checkExistingPage", description = "Description for checkExistingPage", type = AttributeType.BOOLEAN  )
		boolean checkExistingPage() default false;
	   
	   @AttributeDefinition(name = "order", description = "Description for order", type = AttributeType.INTEGER )
		int order() default 0;
	   
	   

}
