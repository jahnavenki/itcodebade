package com.ti.core.models;

public class GenericModel {
  private String value;
  private String label;

  /**
   * get the value.
   * @return the value.
   */
  public String getValue() {
    return value;
  }

  /**
   * set the value.
   * @param value
   *          the value to set
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * get the label.
   * @return the label.
   */
  public String getLabel() {
    return label;
  }

  /**
   * @param label
   *          the label to set.
   */
  public void setLabel(String label) {
    this.label = label;
  }

}
