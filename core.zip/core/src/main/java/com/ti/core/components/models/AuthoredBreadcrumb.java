package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = {Resource.class},
	resourceType = { AuthoredBreadcrumb.RESOURCE_TYPE },
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class AuthoredBreadcrumb {
	public static final String RESOURCE_TYPE = "ti/components/authoredBreadcrumb";

	private final Logger log = LoggerFactory.getLogger(getClass());

	@ChildResource
	private Collection<AuthoredBreadcrumbNode> breadcrumbNodes;

	public Collection<AuthoredBreadcrumbNode> getBreadcrumbNodes() {
		return breadcrumbNodes;
	}

	@PostConstruct
	public void init() {
		try {
			breadcrumbNodes = CollectionUtils.emptyIfNull(breadcrumbNodes);
		} catch (Exception ex) {
			log.error( "Exception in AuthoredBreadcrumb", ex);
		}
	}

	private static Resource findResourceByType(Resource resource, String resourceType) {
		final var valueMap = resource.getValueMap();
		final var type = valueMap.get("sling:resourceType");
		if (resourceType.equals(type)) return resource;
		for (final var child : resource.getChildren()) {
			final var descendant = findResourceByType(child, resourceType);
			if (null != descendant) return descendant;
		}
		return null;
	}

	public static AuthoredBreadcrumb findResource(Resource root) {
		final var resource = findResourceByType(root, RESOURCE_TYPE);
		if (null == resource) return null;
		else return resource.adaptTo(AuthoredBreadcrumb.class);
	}
}
