package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;

import com.day.cq.search.QueryBuilder;
import javax.jcr.Session;
import java.util.Map;
import java.util.HashMap;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.result.SearchResult;


import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;

import javax.jcr.Node;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Update urls to new JP domain

 */
@Component( immediate=true, service = Servlet.class,   property = {
		SLING_SERVLET_PATHS + "=/bin/ti/updatedomainjp", 
		SLING_SERVLET_METHODS + "=GET"})
public class UpdateDomainJP extends SlingSafeMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(UpdateDomainJP.class);
	private static final String SLING_RESOURCE_TYPE = "sling:resourceType";
	
	@Reference
	private ResourceResolverFactory resolverFactory; //NOSONAR
	
	private ResourceResolver resourceResolver; //NOSONAR

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

				try {
					this.resourceResolver = request.getResourceResolver();
					Session session = this.resourceResolver.adaptTo(Session.class);

					SearchResult searchResult = null;
					final String path = "/content/texas-instruments/ja-jp";
					final QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class); 	//NOSONAR
					final Map<String, String> predicates = new HashMap<>();
					predicates.put("path", path);
					predicates.put("p.limit", "-1");
					predicates.put("1_property", SLING_RESOURCE_TYPE);
					predicates.put("1_property.value", "ti/components/richText");

					final Query query = queryBuilder.createQuery(PredicateGroup.create(predicates), session); //NOSONAR
					query.setStart(0);
					query.setHitsPerPage(0);
					searchResult = query.getResult();

					Iterator<Node> nodeItr = searchResult.getNodes();
					if (nodeItr.hasNext()) {
						while (nodeItr.hasNext()) {
							Node node = nodeItr.next();
							boolean hasTextProp = node.hasProperty("text");
							if (hasTextProp) {
								String text = node.getProperty("text").getString();
								if (text.indexOf("tij.co.jp") > -1) {
									text = text.replaceAll("www.tij.co.jp/ja-jp/","www.ti.com/ja-jp/");
									text = text.replaceAll("www.tij.co.jp","www.ti.com");
									node.setProperty("text", text);
									response.getWriter().println(node.getPath());
								}
							}
						}
					}

					session.save(); //NOSONAR
					session.refresh(true);
					response.getWriter().write("success");
				} catch (Exception e) {
					log.error("Error in UpdateDomainJP: ", e);
					response.getWriter().write(e.getMessage());
					log.error(e.getMessage());
				}

	}
}