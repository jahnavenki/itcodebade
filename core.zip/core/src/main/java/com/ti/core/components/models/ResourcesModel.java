package com.ti.core.components.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Required;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.ti.core.models.CtaModel;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.LanguageUtils;

@Model(adaptables = { SlingHttpServletRequest.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourcesModel {
	/**
	 * Standard logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ResourcesModel.class);

	private static final String LIT = "/lit/";
	private static final String DOWNLOAD = "download";
	private static final String EXTERNAL = "external";
	private static final String METADATA = "/jcr:content/metadata";
	private static final String PRESENTATION_QUIZ = "presentation-quiz";
	private static final String PRESENTATION_TEXT = "Presentation";
	private static final String PRESENTATION_QUIZ_TEXT = "Presentation & quiz";
	private static final String PDF = ".pdf";
	private static final String LITERATURE_NUMBER = "literatureNumber";
	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

	@Self
	@Required
	private SlingHttpServletRequest slingRequest;
	/**
	 * The current page.
	 */
	@ScriptVariable
	protected Page currentPage;

    @OSGiService
	private WCMComponents wcmService;

	@OSGiService
	private VideoConfigService videoService;

	List<CtaModel> ctaModelList = new ArrayList<>();

	private String subAssetText;
	private String subAssetLink;
	String localeString = "";
	String pagelanguage = "en-us";
	

	@PostConstruct
	protected void init() {
		if (currentPage == null) {
			LOGGER.debug("Current page is null");
			return;
		}
		localeString = currentPage.getLanguage(true).toString();
		final var matcher = SINGLE_VIDEO_PATH.matcher(slingRequest.getPathInfo());
		final String videoId = matcher.find() ? matcher.group(1) : null;
		ResourceResolver resolver = slingRequest.getResourceResolver();		
		if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
			LOGGER.debug("Video config null or Path not found");
			return;
		}
		Resource damRes = AssetUtils.getDamResource(resolver, videoService.getVideoPath(), videoId);
		if(damRes == null) {
			LOGGER.debug("Video resource is null");
			return;
		}
		Resource damMetaDataRes = resolver.getResource(damRes.getPath() + METADATA);
		if (damMetaDataRes == null) {
			LOGGER.debug("Video metadata is null");
			return;
		}
		LanguageUtils langUtils = new LanguageUtils(slingRequest);
		// Set CTA text and links
		setCTAList(damMetaDataRes, langUtils);

		// Sub-assets
		Resource subAssetsRes = damRes.getChild("subassets");
		if (subAssetsRes == null) {
			LOGGER.debug("Video subassets is null");
			return;
		}
		Iterator<Resource> subAssetsItr = subAssetsRes.listChildren();
		while (subAssetsItr.hasNext()) {
			Resource resource = subAssetsItr.next();
			String name = resource.getName();
			LOGGER.info("Sub Asset Name :: {}", name);
			if (name.contains(PDF)) {
				if (name.contains(PRESENTATION_QUIZ)) {
					subAssetText = langUtils.getI18nStr(PRESENTATION_QUIZ_TEXT);
				} else {
					subAssetText = langUtils.getI18nStr(PRESENTATION_TEXT);
				}
				subAssetLink = resource.getPath();
			}
		}
	}

	private void setCTAList(Resource metaDataRes, LanguageUtils langUtils) {	
		ValueMap metaDataProps = metaDataRes.getValueMap();
		for (int i=0; i < 4; i++) {
			int ctaIndex = i + 1;			
			String ctaUrl = metaDataProps.get("dam:url" + ctaIndex,"");
			if (StringUtils.isNotBlank(ctaUrl)) {
				ctaModelList.add(createCTAMap(metaDataProps, langUtils, ctaIndex));
			}
		}	
	}

	private CtaModel createCTAMap(ValueMap metaDataProps, LanguageUtils langUtils, int ctaIndex) {
		String cta1Url = metaDataProps.get("dam:url" + ctaIndex, "");
		String cta1Text = metaDataProps.get("dam:cta" + ctaIndex, "");
		String icon = EXTERNAL;
		CtaModel ctaModel = new CtaModel();
		if (cta1Url.contains(LIT)) {
			icon = DOWNLOAD;
		}
		ctaModel.setCtaUrl(cta1Url);
		ctaModel.setCtaText(cta1Text);
		ctaModel.setCtaIcon(icon);
		return ctaModel;
	}

	public Page getCurrentPage() {
		return currentPage;
	}

	public List<CtaModel> getCtaModelList() {
		return ctaModelList;
	}

	public String getSubAssetText() {
		return subAssetText;
	}

	public String getSubAssetLink() {
		return subAssetLink;
	}

}
