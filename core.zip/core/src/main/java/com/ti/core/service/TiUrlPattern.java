package com.ti.core.service;

public interface TiUrlPattern {
	String getUrlPattern();

	String[] getReplacementPatterns();

	String getKey();

	/**
	 * Returns the regex matching group number position
	 * @return 
	 */
	int getGroupNumber();
}
