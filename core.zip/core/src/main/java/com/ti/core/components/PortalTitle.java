package com.ti.core.components;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.SiloConfigService;
import com.ti.core.util.URLHelper;

/**
 * Portal Title WCMUSePojo.
 */
public class PortalTitle extends WCMUsePojo {

	private static final String JSON_NODE_TOP_LEVEL_PRODUCT_URL = "topLevelFamilyUrl";

	private static final String JSON_NODE_TOP_LEVEL_FAMILY_NAME = "topLevelFamilyName";

	private static final String FAMILY_ID = "familyId";

	private static final String PORTAL_TITLE = "portalTitle";
	private static final String JSON_KEY_PORTAL_NAME = "parentAppAreaName";
	private static final String JSON_KEY_PORTAL_URL = "parentAppAreaURL";
	private static final String APPLICATION_ID = "applicationId";
	private static final String PORTAL_TITLE_DATA_LID = "portalTitle";
	private static final String HTTP = "http://";
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String portalUrl;
	private String componentName;
	private String portalTitleStr;

	public String getPortalTitleStr() {
		return portalTitleStr;
	}

	public String getPortalUrl() {
		return portalUrl;
	}

	@Override
	public void activate() {
		try {
			setComponentName(PORTAL_TITLE_DATA_LID);
			ValueMap properties;
			properties = getProperties();
			/** Call method to get portal title from family or application is */
			getPortalTitleAndUrl();
			if (null != properties.get(PORTAL_TITLE, String.class)) {
				portalTitleStr = properties.get(PORTAL_TITLE, String.class);
			}

		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}

	private void getPortalTitleAndUrl() {

		WCMComponents wcmService;
		JSONObject jsonObject;
		portalUrl = "#";
		String language = null;
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		if (null != tabsService) {
			language = tabsService.getPageLanguage(getCurrentPage());
		}

		try {
			if (null != getPageProperties().get(FAMILY_ID)) {
				wcmService = getSlingScriptHelper().getService(WCMComponents.class);
				String familyId = (String) getPageProperties().get(FAMILY_ID);
				if (wcmService != null) {
					jsonObject = wcmService.getAllProductService(getRequest(), Integer.parseInt(familyId), language);
					portalTitleStr = jsonObject.get(JSON_NODE_TOP_LEVEL_FAMILY_NAME).toString();
					portalUrl = URLHelper.toScheme(jsonObject.get(JSON_NODE_TOP_LEVEL_PRODUCT_URL).toString(),
							URLHelper.getScheme(getRequest()));
				}
			} else if (null != getPageProperties().get(APPLICATION_ID)) {
				wcmService = getSlingScriptHelper().getService(WCMComponents.class);
				String appId = (String) getPageProperties().get(APPLICATION_ID);
				if (wcmService != null) {
					jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(appId), language);
					portalTitleStr = jsonObject.get(JSON_KEY_PORTAL_NAME).toString();
					portalUrl = URLHelper.toScheme(jsonObject.get(JSON_KEY_PORTAL_URL).toString(),
							URLHelper.getScheme(getRequest()));
				}

			} else {
				Page currentPage = this.getCurrentPage();
				if (null != currentPage) {
					String folder = StringUtils.substringAfter(currentPage.getPath(), language);
					String aemFolder = StringUtils.isNotBlank(folder) ? folder.split("/")[1].trim() : StringUtils.EMPTY;
					log.debug("aemFolder" + aemFolder);
					SiloConfigService siloconfigService = getSlingScriptHelper().getService(SiloConfigService.class);
					if (StringUtils.contains(aemFolder, "about-ti")) {
						String abouttisilourl = buildbreadcrumbfordesignResources(siloconfigService, language,
								currentPage);
						if (null != abouttisilourl) {
							portalUrl = URLHelper.toScheme(abouttisilourl, URLHelper.getScheme(getRequest()));
						}
					}
				}

			}

		} catch (

		Exception e) {
			log.error("Error getting portal title and url due to: ", e);
		}

	}

	private String buildbreadcrumbfordesignResources(SiloConfigService siloconfigService, String languageCode,
			Page currentPage) {
		log.debug("page name " + currentPage.getName());
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		String domain = DomainComponent.getDomainFromConfig(factoryConfigs, currentPage.getPath());
		String silourlconfig = siloconfigService.getabouttisilourl();
		log.debug("silourlconfig: {}", silourlconfig);
		String[] silourlArray = StringUtils.split(silourlconfig, ",");
		String silourl = null;
		for (int i = 0; i < silourlArray.length; i++) {
			String[] silourlArr = StringUtils.split(silourlArray[i], "|");
			if (currentPage.getPath().contains(silourlArr[0])) {
				if ("en-us".equals(languageCode)) {
					silourl = HTTP.concat(domain).concat(silourlArr[1]);
				} else {
					silourl = HTTP.concat(domain) + "/" + languageCode + silourlArr[1];
				}

				log.debug("silourl for about-ti: {}", silourl);
				return silourl;

			}
		}
		return silourl;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
}
