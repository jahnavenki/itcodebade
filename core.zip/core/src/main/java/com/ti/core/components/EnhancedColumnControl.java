package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * EnhancedColumnControl WCMUsePojo.
 */
public class EnhancedColumnControl extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String columnSelection;
	private String divClass;
	private String colsStr;
	private String style;
	private String columnName;
	private Map<String, String> advancedColumnsMap = new LinkedHashMap<>();

	private static final String REMOVE_PADDING = "./removePadding";
	private static final String PRESETS = "./presets";
	private static final String COLUMNS = "./columns";
	private static final String SPAN = "/span";
	private static final String OFFSET = "/offset";
	private static final String COL_XS = " col-xs-";
	private static final String COL = "./col";
	private static final String COL_XS_OFFSET = " col-xs-offset-";
	private static final String ADVC_COLUMN = "ContentPar";

	@Override
	public void activate() throws Exception {
		String prefix;
		Integer span;
		Integer offset;
		String isRemovePaddingChecked = getProperties().get(REMOVE_PADDING, "off");
		columnSelection = (String) getProperties().get(PRESETS);
		colsStr = getProperties().get(COLUMNS, String.class);
		StringBuilder styleSB = null;

		if (("on").equalsIgnoreCase(isRemovePaddingChecked)) {
			divClass = "";
		} else {
			divClass = "column-control aem-GridColumn--extra-Gutter";
		}
		if (StringUtils.isNotEmpty(colsStr)) {
			for (int i = 1; i <= Integer.parseInt(colsStr); i++) {
				style = "";
				styleSB = new StringBuilder();
				prefix = COL + i;
				span = getProperties().get(prefix + SPAN, 1);
				offset = getProperties().get(prefix + OFFSET, 0);
				if (span == 0) {
					span = 1;
				}
				styleSB.append(COL_XS).append(span);
				if (offset != 0) {
					styleSB.append(COL_XS_OFFSET).append(offset);
				}
				columnName = ADVC_COLUMN + (i);
				style = styleSB.toString();
				advancedColumnsMap.put(columnName, style);
			}
		}
	}

	public String getColumnName() {
		return columnName;
	}

	public Map<String, String> getAdvancedColumnsMap() {
		return advancedColumnsMap;
	}

	public String getColumnSelection() {
		return columnSelection;
	}

	public String getDivClass() {
		return divClass;
	}

	public String getColsStr() {
		return colsStr;
	}

	public String getStyle() {
		return style;
	}
}
