package com.ti.core.models;

import java.util.List;

public class NestedLevels {
  
  private String link;
  private String url;
  private String urlTarget;  
  private Boolean selected;
  
  private List<NestedLevels> level34Links;

  public String getLink() {
    return link;
  }

  public void setLink(String link) {
    this.link = link;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getUrlTarget() {
    return urlTarget;
  }

  public void setUrlTarget(String target) {
    this.urlTarget = target;
  }
  
  public List<NestedLevels> getLevel34Links() {
    return level34Links;
  }

  public void setLevel34Links(List<NestedLevels> level34Links) {
    this.level34Links = level34Links;
  }

  public Boolean getSelected() {
    return selected;
  }

  public void setSelected(Boolean selected) {
    this.selected = selected;
  }


  

  
  
}
