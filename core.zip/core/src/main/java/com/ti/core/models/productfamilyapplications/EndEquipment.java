package com.ti.core.models.productfamilyapplications;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EndEquipment {

  private String eeqName;
  private String eeqUrl;
  private String subsystem;
  private List<ReferenceDesign> referenceDesignsList;
  private static final Logger log = LoggerFactory.getLogger(EndEquipment.class);

	public String getEeqName() {
    return eeqName;
  }
  
  public void setEeqName(String eeqName) {
    this.eeqName = eeqName;
  }
  
  public String getEeqUrl() {
    String url = "";
    try {
      url =  URLDecoder.decode(this.eeqUrl, "UTF-8");
    } catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException in EndEquipment.java : ", e);
		}
    return url;
  }
  
  public void setEeqUrl(String eeqUrl) {
    this.eeqUrl = eeqUrl;
  }
  
  public List<ReferenceDesign> getReferenceDesignsList() {
    return referenceDesignsList;
  }
  
  public void setReferenceDesignsList(List<ReferenceDesign> referenceDesignsList) {
    this.referenceDesignsList = referenceDesignsList;
  }

    public String getSubsystem() {
        return subsystem;
    }

    public void setSubsystem(String subsystem) {
        this.subsystem = subsystem;
    }
  
}
