package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationListing extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	// WS requires application ID, but component does not.
	private static final int APPLICATION_ID_INDUSTRIAL = 120;
	private static final Pattern APP_URL = Pattern.compile("^(http[s]?:\\/\\/)?([^:\\/\\s]+)(:([^\\/]*))?(\\/\\w+\\.)*([^#?\\s]+)(\\?([^#]*))?(#(.*))?$", Pattern.CASE_INSENSITIVE);
	private static final String HTTPS = "https://";
	private final List<Link> links = new ArrayList<>();

	public List<Link> getLinks() {
		return links;
	}

	public List<Link> getLinksColumn1() {
		final var maxLen = links.size();
		final var col1Len = (int)Math.ceil( maxLen / 3.f );
		return links.subList( 0, col1Len );
	}

	public List<Link> getLinksColumn2() {
		final var maxLen = links.size();
		final var col1Len = (int)Math.ceil( maxLen / 3.f );
		final var col2Len = (int)Math.ceil( ( maxLen - 1 ) / 3.f );
		return links.subList( col1Len, col1Len + col2Len );
	}

	public List<Link> getLinksColumn3() {
		final var maxLen = links.size();
		final var col1Len = (int)Math.ceil( maxLen / 3.f );
		final var col2Len = (int)Math.ceil( ( maxLen - 1 ) / 3.f );
		final var col3Len = (int)Math.ceil( ( maxLen - 2 ) / 3.f );
		return links.subList( col1Len + col2Len, col1Len + col2Len + col3Len );

	}

	public boolean hasExpandCollapse() {
		for( final var link : links ) {
			if (link.hasChildren()) {
				return true;
			}
		}
		return false;
	}

	public static class AppHierarchyNode {
		public AppHierarchyNode( JSONObject jsonObject ) throws JSONException {
			String tempAppUrl = jsonObject.getString("appUrl");
			if ("null".equals(tempAppUrl)) {
				appUrl = null;
			} else {
				final var matcher = APP_URL.matcher(tempAppUrl);
				appUrl = matcher.find() ? matcher.group(6) : null;
			}
			childId = getInteger( jsonObject, "childId" );
			enSectionName = jsonObject.getString("enSectionName");
			parentAppId = getInteger( jsonObject, "parentAppId" );
			virtualParentId = getInteger( jsonObject, "virtualParentId" );
			sectionName = jsonObject.getString("sectionName");
		}

		private String appUrl;
		private Integer childId;
		private String enSectionName;
		private Integer parentAppId;
		private String sectionName;
		private Integer virtualParentId;
		private AppHierarchyNode parent;
		private final List<AppHierarchyNode> children = new ArrayList<>();

		private static Integer getInteger( JSONObject json, String key ) throws JSONException {
			if( json.isNull( key ) ) return null;
			else return json.getInt( key );
		}

		public String getAppUrl() {
			return appUrl;
		}

		public void setAppUrl( String appUrl ) {
			this.appUrl = appUrl;
		}

		public Integer getChildId() {
			return childId;
		}

		public void setChildId( Integer childId ) {
			this.childId = childId;
		}

		public String getEnSectionName() {
			return enSectionName;
		}

		public void setEnSectionName( String enSectionName ) {
			this.enSectionName = enSectionName;
		}

		public Integer getParentAppId() {
			return parentAppId;
		}

		public void setParentAppId( Integer parentAppId ) {
			this.parentAppId = parentAppId;
		}

		public Integer getVirtualParentId() {
			return virtualParentId;
		}

		public String getSectionName() {
			return sectionName;
		}

		public void setSectionName( String sectionName ) {
			this.sectionName = sectionName;
		}

		public AppHierarchyNode getParent() {
			return parent;
		}

		public void setParent( AppHierarchyNode parent ) {
			this.parent = parent;
		}

		public List<AppHierarchyNode> getChildren() {
			return children;
		}
	}

	public static class Link {
		private String text;
		private String href;
		private final List<Link> children = new ArrayList<>();

		public void setText( String text ) {
			this.text = text;
		}

		public void setHref( String href ) {
			this.href = href;
		}

		public String getText() {
			return text;
		}

		public String getHref() {
			return href;
		}

		public List<Link> getChildren() {
			children.sort((o1, o2) -> (o1.getText().compareToIgnoreCase(o2.getText())));
			return children;
		}

		public boolean hasChildren() {
			return !children.isEmpty();
		}
	}

	@Override
	public void activate() {
		try {
			final var pageProperties = getPageProperties();
			final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (null == wcmService) return;
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if (null == tabsService) return;
			final var language = tabsService.getPageLanguage(getCurrentPage());
			final var applicationId = pageProperties.get("applicationId", "");
			final var categoryId = pageProperties.get("categoryId", "");
			final var sectorId = pageProperties.get("sectorId", "");
			final var marketId = pageProperties.get("marketId", "");
			JSONObject jsonObject = null;
			if (StringUtils.isEmpty(applicationId)) {
				jsonObject = wcmService.getAllApplicationService(getRequest(), APPLICATION_ID_INDUSTRIAL, language);
			} else {
				jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(applicationId), language);
			}
			if( StringUtils.isNotEmpty(categoryId) ) { // category page
				links.addAll( buildTree( jsonObject, false, Integer.parseInt(categoryId) ) );
			} else if( StringUtils.isNotEmpty(sectorId) ) { // sector page
				links.addAll( buildTree( jsonObject, true, Integer.parseInt(sectorId) ) );
			} else if( StringUtils.isNotEmpty(marketId) ) { // market page
				links.addAll( buildTree( jsonObject, false, Integer.parseInt(marketId) ) );
			} else { // landing page
				links.addAll( buildTree( jsonObject, true, -1 ) );
			}
			if(links != null && !links.isEmpty()){
				links.sort((o1, o2) -> (o1.getText().compareToIgnoreCase(o2.getText())));
			}
			
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
	private String generateDomain() {
		String domain = "";
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		if (null != factoryConfigs) {
		  List<SeoUrlTagging>listConfig = factoryConfigs.getConfigs();
		  for (SeoUrlTagging seoUrlTagging : listConfig) {
			if(StringUtils.containsIgnoreCase(getCurrentPage().getPath(),seoUrlTagging.getContentPath())){
			  domain = seoUrlTagging.getDomainName();
			  domain = HTTPS.concat(domain);
			  break;
			}
		  }
		}
		return domain;
	  }

	private List<Link> buildTree( JSONObject jsonObject, boolean showSubnav, int pageId ) throws JSONException {
		final var retval = new ArrayList<Link>();
		if (null == jsonObject) return retval;
		final var appHierarchyMap = new HashMap<Integer, AppHierarchyNode>();
		final var appHierarchyList = new ArrayList<AppHierarchyNode>();
		final var jsonAppHierarchyList = jsonObject.getJSONArray("AppHierarchyList");
		for (var i = 0; i < jsonAppHierarchyList.length(); ++i ) {
			final var node = new AppHierarchyNode( jsonAppHierarchyList.getJSONObject(i) );
			appHierarchyList.add(node);
			appHierarchyMap.put(node.getChildId(), node);
		}
		AppHierarchyNode currentNode = null;
		final var topLevel = new ArrayList<AppHierarchyNode>();
		for (final var node : appHierarchyList) {
			if (null == node.getParentAppId()) {
				topLevel.add( node );
			} else {
				var parentNode = appHierarchyMap.get( node.getParentAppId() );
				if (null == parentNode) {
					topLevel.add( node );
				} else {
					node.setParent(parentNode);
					parentNode.getChildren().add(node);
				}
				if (null != node.getVirtualParentId() ) {
					var vParentNode = appHierarchyMap.get( node.getVirtualParentId() );
					vParentNode.getChildren().add(node);
				}
			}
			if (pageId == node.getChildId()) {
				currentNode = node;
			}
		}

		List<AppHierarchyNode> currentLevel;
		if (null == currentNode) {
			currentLevel = topLevel;
		} else {
			currentLevel = currentNode.getChildren();
		}
		final var domain = generateDomain();
		for (final var node : currentLevel) {
			final var link = new Link();
			var appUrl = node.getAppUrl();
			link.setText( node.getSectionName() );
			if (null != appUrl) {
				link.setHref( domain + appUrl );
			}
			if( showSubnav ) {
				for (final var child : node.getChildren()) {
					appUrl = child.getAppUrl();
					final var sublink = new Link();
					sublink.setText( child.getSectionName() );
					if (null != appUrl) {
						sublink.setHref( domain + appUrl );
					}
					link.getChildren().add(sublink);
				}
			}
			retval.add(link);
		}

		return retval;
	}
}
