package com.ti.core.schedulers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.email.EmailService;
import com.day.cq.commons.Externalizer;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.commons.ReferenceSearch;
import com.day.cq.wcm.commons.ReferenceSearch.Info;
import com.ti.core.util.EmailUtils;
import com.ti.core.util.PathBrowserHelper;

@Component(immediate = true, service = Job.class)
@Designate(ocd = ExpiryNotificationSchedulerJob.Config.class)
public class ExpiryNotificationSchedulerJob implements Job {

    private static final Logger log = LoggerFactory.getLogger(ExpiryNotificationSchedulerJob.class);
    private static final String PROFILE = "/profile";
    private static final String DAM_POWER_USERS_TEMPLATE = "/conf/global/settings/workflow/notification/email/ti/dam-email-notification-power-users.html";
    private static final String DAM_CONTENT_POWER_USERS_TEMPLATE = "/conf/global/settings/workflow/notification/email/ti/dam-email-notification-content-power-users.html";
    private static final String DAM_HOMEPAGE_USERS_TEMPLATE = "/conf/global/settings/workflow/notification/email/ti/dam-email-notification-homepage-users.html";
    private static final String FAMILY_ID = "familyId";
    private static final String APPLICATION_ID = "applicationId";
    private static final String HTTP = "http:";

    @Reference
    private EmailService emailService;

    @Reference
    private Scheduler scheduler;

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private QueryBuilder queryBuilder;

    @ObjectClassDefinition(name = "TI DAM Expiry Notification", description = "TI DAM Expiry Notification")
    public @interface Config {
        @AttributeDefinition(type = AttributeType.STRING, name = "cqDamExpiryNotificationSchedulerTimebasedRule",
                description = "Regular expression for time based Scheduler. Eg: '0 0 0 * * ?'. The example expression triggers the Job @ 00 hrs. This expression get picked if Time Based Scheduler is true (cqDamExpiryNotificationSchedulerTimebasedRule)")
        String cqDamExpiryNotificationSchedulerTimebasedRule() default "0 20 15 * * ?"; //cqDamExpiryNotificationSchedulerTimebasedRule
    }

    public static final String SCHEDULER_PERIOD = "cqDamExpiryNotificationSchedulerTimebasedRule";

    private Calendar lastRun;
    private Calendar thisRun;

    private ResourceResolver resourceResolver;

    public void execute(final JobContext arg0) {
        this.thisRun = Calendar.getInstance();
        try {
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            this.resourceResolver = this.resolverFactory.getServiceResourceResolver(param);
            final Collection<Hit> expiredAssets = this.getExpiredAssetHits();
            final Collection<Asset> expiredSinceLastRun = this.getExpiredAssets(expiredAssets);
            for (Asset asset : expiredSinceLastRun) {
                setEmailParameters(asset);
            }
        } catch (Exception e) {
            log.error("Error in execute.", (Throwable) e);
        } finally {
            if (null != this.resourceResolver) {
                this.resourceResolver.close();
            }
        }
        this.lastRun = this.thisRun;
    }

    private void setEmailParameters(Asset asset) {
        Externalizer externalizer = this.resourceResolver.adaptTo(Externalizer.class);
        if (externalizer == null) {
            return;
        }
        Map<String, String> emailParams = new HashMap<>();
        emailParams.put("assetPath", asset.getPath());
        List<String> members = getEmailRecipentsFromGroup("ti-dam-power-user");
        Map<String, String> transformedPaths = new HashMap<>();
        List<Page> list = getAssetReferencePath(asset);
        log.debug("Referenced pages by Asset " + list);
        for (Page page : list) {
            String pagePath = page.getPath();
            if (StringUtils.contains(pagePath, "homepagebanners")) {
                transformedPaths.put(pagePath,
                        externalizer.authorLink(resourceResolver, "/editor.html".concat(pagePath).concat(".html")));
            } else {
                transformedPaths.put(pagePath, getTransformedPath(pagePath));
            }
        }
        emailParams.put("paths", String.join("\n", transformedPaths.values()));
        sendTemplatedEmail(DAM_POWER_USERS_TEMPLATE, emailParams, members);
        if (!list.isEmpty()) {
            if (StringUtils.contains(list.get(0).getPath(), "homepagebanners")) {
                members = getEmailRecipentsFromGroup("ti-homepagebanners-approver");
                List<String> pagePaths = list.stream().map(l -> externalizer.authorLink(resourceResolver,
                        "/editor.html".concat(l.getPath()).concat(".html"))).collect(Collectors.toList());
                emailParams.put("paths", String.join("\n", pagePaths));
                sendTemplatedEmail(DAM_HOMEPAGE_USERS_TEMPLATE, emailParams, members);
            } else {
                sendEmailToPathApprovers(emailParams, transformedPaths);
            }
        }
    }

    private void sendEmailToPathApprovers(Map<String, String> emailParams, Map<String, String> transformedPaths) {
        Map<String, String> listMap = getApproverListWithPaths(transformedPaths);
        Iterator<Map.Entry<String, String>> iterator = listMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            List<String> members = getEmailRecipentsFromGroup(entry.getKey());
            emailParams.put("paths", entry.getValue());
            sendTemplatedEmail(DAM_CONTENT_POWER_USERS_TEMPLATE, emailParams, members);
        }
    }

    private String getTransformedPath(String path) {
        String mappedPath = HTTP + PathBrowserHelper.addHtmlIfContentPath(this.resourceResolver, path);
        mappedPath = mappedPath.replace("/content/texas-instruments/en-us", "");
        mappedPath = mappedPath.replace("/content/texas-instruments", "");
        return mappedPath;
    }

    private Map<String, String> getApproverListWithPaths(Map<String, String> transformedPaths) {
        Map<String, String> map = new HashMap<>();
        Iterator<Map.Entry<String, String>> iterator = transformedPaths.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String approver = returnApprover(entry.getKey());
            String path = transformedPaths.get(entry.getKey());
            if (StringUtils.isNotBlank(approver) && map.containsKey(approver)) {
                String value = map.get(approver);
                map.put(approver, value + "\n" + path);
            } else if (StringUtils.isNotBlank(approver)) {
                map.put(approver, path);
            }
        }
        return map;
    }

    private String returnApprover(String path) {
        try {
            PageManager pageManager = this.resourceResolver.adaptTo(PageManager.class);
            Session session = this.resourceResolver.adaptTo(Session.class);
            String approver;
            Node node = session != null ? session.getNode(path + "/" + JcrConstants.JCR_CONTENT) : null;
            if (node != null) {
                EmailUtils emailUtils = new EmailUtils(pageManager);
                if (node.hasProperty(FAMILY_ID)) {
                    approver = emailUtils.getApproverForProductFamilyPages(node);
                    log.debug("has family id and the approver is " + approver);
                } else if (node.hasProperty(APPLICATION_ID)) {
                    approver = emailUtils.getProductForApplicationPages(node);
                    log.debug("has App id and the approver is " + approver);
                } else {
                    approver = emailUtils.getApproverForPagePath(path);
                }
                if (StringUtils.isNotBlank(approver)) {
                    return approver;
                } else {
                    approver = emailUtils.getDefaultApprover();
                    return approver;
                }
            }
        } catch (Exception e) {
            log.error("RepositoryException thrown while setting the properties " + "on workflow payload metadata node"
                    + e);
        }
        return StringUtils.EMPTY;
    }

    private List<Page> getAssetReferencePath(Asset asset) {
        ReferenceSearch referenceSearch = new ReferenceSearch();
        referenceSearch.setExact(true);
        Collection<Info> resultSet = referenceSearch.search(this.resourceResolver, asset.getPath()).values();
        return resultSet.stream()
                .filter(p -> StringUtils.startsWith(p.getPage().getPath(), "/content/texas-instruments"))
                .map(Info::getPage).collect(Collectors.toList());
    }

    private void sendTemplatedEmail(String templatePath, Map<String, String> emailParams, List<String> members) {
        if (Objects.nonNull(members) && !members.isEmpty()) {
            String[] receipients = members.stream().filter(item -> !item.isEmpty()).toArray(String[]::new);
            List<String> failureList = emailService.sendEmail(templatePath, emailParams, receipients);
            if (failureList.isEmpty()) {
                log.info("---------------Mail delivery successfull---------------");
            } else {
                log.info("---------------Mail delivery failed---------------");
            }
        }
    }

    private List<String> getEmailRecipentsFromGroup(String userGroupName) {

        UserManager userManager = this.resourceResolver.adaptTo(UserManager.class);
        List<Authorizable> users = new ArrayList<>();
        try {
            if (StringUtils.isNotBlank(userGroupName) && null != userManager
                    && null != userManager.getAuthorizable(userGroupName)) {
                Authorizable auth = userManager.getAuthorizable(userGroupName);
                if (!auth.isGroup()) {
                    return new ArrayList<>();
                }
                Group group = (Group) auth;
                Iterator<Authorizable> iter = group.getMembers();
                while (iter.hasNext()) {
                    users.add(iter.next());
                }
                return users.stream().map(user -> {
                    try {
                        return this.resourceResolver.getResource(user.getPath() + PROFILE);
                    } catch (RepositoryException e) {
                        log.error("RepositoryException {}", e);
                    }
                    return null;
                }).filter(Objects::nonNull).map(res -> res.adaptTo(ValueMap.class)).filter(Objects::nonNull)
                        .map(v -> v.get("email", StringUtils.EMPTY)).filter(Objects::nonNull)
                        .collect(Collectors.toCollection(ArrayList::new));

            }
        } catch (RepositoryException e) {
            log.error("Error in getEmailRecipentsFromGroup due to {}", e);
        }

        return new ArrayList<>();
    }

    private Collection<Asset> getExpiredAssets(final Collection<Hit> hits) throws RepositoryException {
        return hits.stream().map(h -> {
            try {
                return this.resourceResolver.getResource(h.getPath());
            } catch (RepositoryException e) {
                log.error("RepositoryException {}", e);
            }
            return null;
        }).filter(Objects::nonNull).map(r -> r.adaptTo(Asset.class)).filter(Objects::nonNull)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    private Collection<Hit> getExpiredAssetHits() {
        final Map<String, String> map = new HashMap<>();
        map.put("path", "/content/dam");
        map.put("type", "dam:Asset");
        map.put("group.1_group.daterange.property", "jcr:content/metadata/prism:expirationDate");
        map.put("group.1_group.daterange.lowerBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("group.1_group.daterange.upperBound", String.valueOf(this.thisRun.getTimeInMillis()));
        map.put("group.p.or", "true");
        map.put("group.2_group.1_daterange.property", "jcr:content/metadata/jcr:lastModified");
        map.put("group.2_group.1_daterange.lowerBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("group.2_group.1_daterange.upperBound", String.valueOf(this.thisRun.getTimeInMillis()));
        map.put("group.2_group.2_daterange.property", "jcr:content/metadata/prism:expirationDate");
        map.put("group.2_group.2_daterange.upperBound", String.valueOf(this.lastRun.getTimeInMillis()));
        map.put("p.guessTotal", "10000");
        final Query query = this.queryBuilder.createQuery(PredicateGroup.create(map),
                this.resourceResolver.adaptTo(Session.class));
        query.setHitsPerPage(10000L);
        final SearchResult results = query.getResult();
        return results.getHits();
    }

    @SuppressWarnings("deprecation")
    protected void activate(final Config config) throws Exception {
        try {
            this.lastRun = Calendar.getInstance();
            this.lastRun.set(Calendar.HOUR_OF_DAY, 0);
            this.lastRun.set(Calendar.MINUTE, 0);
            this.lastRun.set(Calendar.SECOND, 0);
            this.lastRun.set(Calendar.MILLISECOND, 0);
            final String expression = config.cqDamExpiryNotificationSchedulerTimebasedRule();
            this.scheduler.addJob(ExpiryNotificationSchedulerJob.class.getName(), this, null, expression, false);
        } catch (Exception e) {
            log.error("Error in activate.", e);
        }
    }

    @SuppressWarnings("deprecation")
    protected void deactivate(final ComponentContext componentContext) {
        log.debug("Deactivating the expiry notification scheduler");
        this.scheduler.removeJob(ExpiryNotificationSchedulerJob.class.getName());
    }
}