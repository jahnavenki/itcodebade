package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.util.LanguageUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TechnologiesSelectionMetadata extends WCMUsePojo {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String browserTitle;
    private String metaDescription;
    private String keywords;

    public String getBrowserTitle() {
        return browserTitle;
    }

    public String getMetaDescription() {
        return metaDescription;
    }

    public String getKeywords() {
        return keywords;
    }

    @Override
    public void activate() throws Exception {
        setMetadata();
    }

    /**
     * Hardcoded for now
     */
    private void setMetadata() {
    try {
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        String applicationName = langUtils.getI18nStr("Functional safety");
        this.browserTitle = langUtils.getI18nStr("{} product selection | TI.com", applicationName);
        this.metaDescription =  langUtils.getI18nStr("Select from TI's {} family of devices. {} parameters, data sheets, and design resources.", applicationName);
        this.keywords = langUtils.getI18nStr("{} product selection", applicationName);
    } catch (Exception e) {
        logger.error("Exception : ", e);
    }
    }
}
