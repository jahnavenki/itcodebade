package com.ti.core.models;

public class CtaModel {

    private String ctaText;
    private String ctaUrl;
    private String ctaIcon;

    public String getCtaText() {
        return ctaText;
    }
    public void setCtaText(String ctaText) {
        this.ctaText = ctaText;
    }
    public String getCtaUrl() {
        return ctaUrl;
    }
    public void setCtaUrl(String ctaUrl) {
        this.ctaUrl = ctaUrl;
    }
    public String getCtaIcon() {
        return ctaIcon;
    }
    public void setCtaIcon(String ctaIcon) {
        this.ctaIcon = ctaIcon;
    }
}
