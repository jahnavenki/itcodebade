package com.ti.core.components.video;
import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

public class VideoSeriesNavigation extends WCMUsePojo {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    private final List<TopicsViewModel> topicsList = new ArrayList<>();
    private static final String TITLE="title";
    private static final String VIDEO_AND_DESCRIPTION = "videotitleanddescription";

    private String modalTitle;
    public String getModalTitle() {
        return modalTitle;
    }

    public List<TopicsViewModel> getTopicsList() {
        return topicsList;
    }
    
	 @Override
    public void activate() {
        try {
            
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("topics")) {
                    for (Resource resourceChild : nodeChild.getChildren()) {
                        TopicsViewModel topicsViewModel = buildTopicsViewModel(resourceChild);
                        if (topicsViewModel != null) {
                            topicsList.add(topicsViewModel);
                        }
                    }
                }
		    }

            final Resource pageResource = getResource();
            if (null == pageResource) {
                log.debug("Page resource is null");
                return;
            }

            final Resource rootResource = pageResource.getParent();
            if (null == rootResource) {
                log.debug("Page root is null");
                return;
            }
            Resource nodeTitle = getVideoTitleAndDescriptionComponent(rootResource);
            if (null == nodeTitle) {
                log.debug("VideoTitleAndDescription Component not found");
                return;
            }
            ValueMap map = nodeTitle.getValueMap();
            modalTitle= map.get(TITLE).toString();

        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    private Resource getVideoTitleAndDescriptionComponent(Resource rootResource) {
        for (Resource gridResource : rootResource.getChildren()) {
            if (gridResource != null && VIDEO_AND_DESCRIPTION.indexOf(gridResource.getName().toLowerCase()) > -1) {
                return gridResource;
            }
        } 
        return null;
    }
	
    public static class TopicsViewModel {
        private final List<VideoViewModel> videosList = new ArrayList<>();
        private String topicsBar;

        public String getTopicsBar() {
            return topicsBar;
        }
        public void setTopicsBar(String topicsBar) {
            this.topicsBar = topicsBar;
        }

        public List<VideoViewModel> getVideosList() {
            return videosList;
        }
    }
    public static class VideoViewModel {
        private String videoId;
        private String videoTitle;
        private String videoDuration;
       
        public String getVideoId() {
            return videoId;
        }

        public String getVideoTitle() {
            return videoTitle;
        }

        public String getVideoDuration() {
            return videoDuration;
        }

        public void setVideoTitle(String videoTitle) {
            this.videoTitle = videoTitle;
        }

        public void setVideoDuration(String videoDuration) {
            this.videoDuration = videoDuration;
        }
        
        public void setVideoId(String videoId) {
            this.videoId = videoId;
        }
        
    }

    private TopicsViewModel buildTopicsViewModel( Resource topicResource ) throws JSONException {
        ValueMap properties = topicResource.adaptTo(ValueMap.class);
        if (null == properties) {
            log.debug("Video properties are null");
            return null;
        }
        final var topicModel = new TopicsViewModel();
        topicModel.setTopicsBar(properties.get("topicsBar", "") );
        for (Resource nodeChild : topicResource.getChildren()) {
            if (nodeChild != null && nodeChild.getName().equalsIgnoreCase("videosList")) {
                for (Resource resourceChild : nodeChild.getChildren()) {
                    VideoViewModel videoViewModel = buildVideoViewModel(resourceChild);
                    if (videoViewModel != null) {
                        topicModel.getVideosList().add(videoViewModel);
                    }
                }
            }
        }
        return topicModel;
    }
    
    private VideoViewModel buildVideoViewModel( Resource videoResource ) throws JSONException {
        ValueMap properties = videoResource.adaptTo(ValueMap.class);
        if (null == properties) {
            log.debug("Video properties are null");
            return null;
        }
        var videoId = properties.get( "videoId", "" );
            
        VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            log.debug("Video config null or Path not found");
            return null;
        }
		Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
		if (damRes == null) {
			log.debug("Video resource is null for videoid {}", videoId);
			return null;
		}

        final var map = AssetUtils.getMetadata(damRes);
        String videoStatus  = map.get("dam:status", String.class);
        if("unpublished".equalsIgnoreCase(videoStatus) || null == map){
            log.error("Metadata not found for video id: {} ", videoId);
         return null;
        }
        String videoTitle = map.get("dc:title", String.class);
        String videoDuration = map.get("brc_duration", String.class); 
        final var videoModel = new VideoViewModel();
        videoModel.setVideoTitle(videoTitle);
        videoModel.setVideoDuration(videoDuration);
        videoModel.setVideoId(videoId);     
        return videoModel;
    }
}
