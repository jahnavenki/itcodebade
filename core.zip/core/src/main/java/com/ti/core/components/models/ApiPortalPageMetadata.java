package com.ti.core.components.models;

import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;

import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ApiPortalPageMetadata {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ProductNavigationTabsOrdering productNavigationTabsOrdering;

	@SlingObject
	private Resource currentResource;

	@ScriptVariable
	private Page currentPage;

	private String browserTitle;
	private String metaDescription;
	private String keywords;

	public String getBrowserTitle() {
		return browserTitle;
	}

	public String getMetaDescription() {
		return metaDescription;
	}

	public String getKeywords() {
		return keywords;
	}

	@PostConstruct
	public void init() {
		try {
			final var campaignLandingPageHeading = CampaignLandingPageHeading.findResource(currentResource);
			final var authoredBreadcrumb = AuthoredBreadcrumb.findResource(currentResource);
			final var richText = RichText.findResource(currentResource);
			if (null != campaignLandingPageHeading) {
				var titleSuffix = " | TI.com";
				final var language = productNavigationTabsOrdering.getPageLanguage(currentPage).toLowerCase();
				if ("zh-cn".equalsIgnoreCase(language)) {
					titleSuffix += ".cn";
				}
				browserTitle = campaignLandingPageHeading.getHeadline() + titleSuffix;
				metaDescription = campaignLandingPageHeading.getSubheadline();
			}
			if(StringUtils.isEmpty(browserTitle) && null != authoredBreadcrumb) {
				browserTitle =
					String.join( " | ",
						authoredBreadcrumb.getBreadcrumbNodes()
						.stream()
						.map(n -> n.getLabel())
						.collect(Collectors.toList())
					);
			}
			if(StringUtils.isEmpty(metaDescription) && null != richText) {
				final var doc = Jsoup.parse(richText.getText());
				final var paragraph = doc.selectFirst("p");
				if(null != paragraph) {
					metaDescription = paragraph.text().replaceAll( "\\..*$", "." );
				}
			}
			keywords = StringUtils.EMPTY;
		} catch(Exception ex) {
			log.error("Exception in ApiPortalPageMetadata", ex);
		}
	}
}
