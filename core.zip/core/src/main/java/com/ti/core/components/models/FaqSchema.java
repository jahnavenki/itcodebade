package com.ti.core.components.models;

import javax.annotation.PostConstruct;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	resourceType = FaqSchema.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class FaqSchema {
    protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/faqSchema";

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String description;

	@PostConstruct
	public void init(){
		try {
			title = StringUtils.defaultString(title);
			description = StringUtils.defaultString(description);
		} catch (Exception e) {
			log.error("Exception in FaqSchema", e);
		}
	}

	public String getSchema() throws JSONException{
        final var schemaObj = new JSONObject();
        schemaObj.put("@context", "https://schema.org");
        schemaObj.put("@type", "FAQPage");
        var faqSchema = new JSONArray();
        final var question = new JSONObject();
        question.put("@type", "Question");
        question.put("name",title);
        final var answer = new JSONObject();
        answer.put("@type", "Answer");
        answer.put("text", description);
        question.put("acceptedAnswer", answer);
        faqSchema.put(question);
        schemaObj.put("mainEntity", faqSchema);
        return schemaObj.toString();
	}   
}
