package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.HomePageBlogPost;
import com.ti.core.models.HomePageNewsItem;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.LanguageUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;

import java.net.MalformedURLException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.io.*;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.XMLConstants;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomePageBlogFeed extends WCMUsePojo {
	protected static final Logger log = LoggerFactory.getLogger(HomePageBlogFeed.class);
	private static final String FEATURE_LOAD_DTD = "http://apache.org/xml/features/nonvalidating/load-external-dtd";
	private static final String FEATURE_DISABLE_DOCTYPE_DECL = "http://apache.org/xml/features/disallow-doctype-decl";
	private static final String NEWS_URL_EN = "https://news.ti.com";
	private static final String NEWS_URL_CN = "https://news.ti.com.cn";

	private final HomePageBlogPost homePageBlogPost = new HomePageBlogPost();
	private final List<HomePageNewsItem> homePageNewsList = new ArrayList<>();
	private String homePageBlogUrl = "";
	private String homePageNewsUrl = "";

	public HomePageBlogPost getHomePageBlogPost() {
		return homePageBlogPost;
	}

	public List<HomePageNewsItem> getHomePageNewsList() {
		return homePageNewsList;
	}

	public String getHomePageBlogUrl() {
		return this.homePageBlogUrl;
	}

	public void setHomePageBlogUrl(String homePageBlogUrl) {
		this.homePageBlogUrl = homePageBlogUrl;
	}

	public String getHomePageNewsUrl() {
		return homePageNewsUrl;
	}

	public void setHomePageNewsUrl(String homePageNewsUrl) {
		this.homePageNewsUrl = homePageNewsUrl;
	}

	public boolean hasHomePageNewsList() {
		return !homePageNewsList.isEmpty();
	}

	private static final String PROXY_HOST = "webproxy.ext.ti.com";

	private static String readFeed(String feedUrl) {
		String result = "";
		try {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, 80));
			HttpURLConnection connection;
			URL rssUrl = new URL (feedUrl);
			connection = (HttpURLConnection) rssUrl.openConnection(proxy);
			connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF8"));
			String line;
			StringBuilder res = new StringBuilder();
            while((line=in.readLine()) != null){       
				res.append(line + '\n');
            }
			in.close();
			result = res.toString();
			
		} catch (MalformedURLException e){
			log.error("Homepage bad feed url : ", e);
        } catch (IOException e){
			log.error("Homepage Read Feed Error : ", e);
		}
		return result;
	}

	private static ArrayList<Element> parseBlogFeed(String blogString){
		ArrayList<Element> blogList = new ArrayList<>();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			factory.setFeature(FEATURE_DISABLE_DOCTYPE_DECL, true);
			factory.setFeature(FEATURE_LOAD_DTD, false);
			factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, " ");
			factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, " ");

			DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(blogString)));
			NodeList blogItems = doc.getElementsByTagName("item");
			blogList.add((Element) blogItems.item(0));
		} catch (Exception e) {
			log.error("Homepage Parse Feed Error : ", e);
		}
		return blogList;
	}

	private static ArrayList<Element> parseNewsFeed(String newsString) {
		ArrayList<Element> newsItems = new ArrayList<>();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			factory.setFeature(FEATURE_DISABLE_DOCTYPE_DECL, true);
			factory.setFeature(FEATURE_LOAD_DTD, false);
			factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, " ");
			factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, " ");
			DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(newsString)));
			NodeList newsItemsNodes = doc.getElementsByTagName("item");
			int newsItemsLength = newsItemsNodes.getLength();
			// should not have more than 3 items
			if (newsItemsLength > 3) newsItemsLength = 3;
			for (int i = 0; i < newsItemsLength; i++) {
				newsItems.add((Element) newsItemsNodes.item(i));
			}
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
		return newsItems;
	}

	@Override
	public void activate() {
		try {
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			String language = null != tabsService ? tabsService.getPageLanguage(getCurrentPage()) : null;
			String langCode = null != language ? StringUtils.substringBefore(language, "-") : null;
			final DateFormat feedFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z");
			final DateFormat myFormat = new SimpleDateFormat(LanguageUtils.getRegionDateFormat(language), new Locale(langCode));

			HashMap<String, String> newsFeedUrls = new HashMap<>();
			newsFeedUrls.put("en-us", NEWS_URL_EN.concat("/feeds/news-releases-product-technology-news.xml"));
			newsFeedUrls.put("zh-cn", NEWS_URL_CN.concat("/feeds/zh-cn-news-releases.xml"));
			newsFeedUrls.put("ja-jp", NEWS_URL_EN.concat("/feeds/ja-jp-news-releases.xml"));
			newsFeedUrls.put("ko-kr", NEWS_URL_EN.concat("/feeds/ko-kr-news-releases.xml"));
			newsFeedUrls.put("de-de", NEWS_URL_EN.concat("/feeds/de-de-news-releases.xml"));
			newsFeedUrls.put("zh-tw", NEWS_URL_EN.concat("/feeds/zh-tw-news-releases.xml"));
			newsFeedUrls.put("es-mx", NEWS_URL_EN.concat("/feeds/news-releases-product-technology-news.xml"));

			String blogFeedUrl = "";
			String newsFeedUrl = newsFeedUrls.get(language);
			String feedDate = "";
			String link = "";

			switch (language) {
				case "zh-cn":
					blogFeedUrl = NEWS_URL_CN.concat("/feeds/zh-cn-blog.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/zh-cn/blog/"));
					break;
				case "ja-jp":
					blogFeedUrl = NEWS_URL_EN.concat("/feeds/ja-jp-ti-blog.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/ja-jp/ti-blog/"));
					break;
				case "de-de":
					blogFeedUrl = NEWS_URL_EN.concat("/feeds/de-de-firmenblog.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/de-de/blog/"));
					break;
				case "ko-kr":
					blogFeedUrl = NEWS_URL_EN.concat("/feeds/ko-kr-blogs.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/ko-kr/"));
					break;
				case "zh-tw":
					blogFeedUrl = NEWS_URL_EN.concat("/feeds/zh-tw-blogs.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/zh-tw/"));
					break;
				default:
					blogFeedUrl = NEWS_URL_EN.concat("/feeds/blog.xml");
					setHomePageBlogUrl(NEWS_URL_EN.concat("/blog/"));
					break;
			}

			if ("en-us".equals(language) || "es-mx".equals(language)) {
				setHomePageNewsUrl(NEWS_URL_EN.concat("/news-releases/"));
			} else {
				setHomePageNewsUrl(newsFeedUrl.replace("/feeds","").replace("-news-releases.xml","/news-releases/"));
			}

			ArrayList<Element> blogFeedList = parseBlogFeed(readFeed(blogFeedUrl));
			if (blogFeedList.size() == 1) {
				Element el = blogFeedList.get(0);
				Element enclosure  = (Element)el.getElementsByTagName("enclosure").item(0);
				String desc = el.getElementsByTagName("description").item(0).getTextContent();
				link = el.getElementsByTagName("link").item(0).getTextContent();
				// feed has old jp url, replace
				if ("ja-jp".equals(language)) link = link.replace("news.tij.co.jp","news.ti.com");
				// take only 1st sentence in desc
				// eventually will be changed for subtitle when provided in feed
				if (!desc.isEmpty()) {
					desc = desc.indexOf(". ") > -1 ? desc.substring(0, desc.indexOf(". ") + 1) : desc;
				}
				feedDate = el.getElementsByTagName("pubDate").item(0).getTextContent();
				homePageBlogPost.setTitle(el.getElementsByTagName("title").item(0).getTextContent());
				homePageBlogPost.setDesc(desc);
				homePageBlogPost.setUrl(link);
				homePageBlogPost.setImage(enclosure.getAttribute("url"));
				homePageBlogPost.setPubDate(myFormat.format(feedFormat.parse(feedDate)));
			}
			
			ArrayList<Element> newsItems = parseNewsFeed(readFeed(newsFeedUrl));

			for (int i = 0; i < newsItems.size(); i++) {
				Element news = newsItems.get(i);
				feedDate = news.getElementsByTagName("pubDate").item(0).getTextContent();
				link = news.getElementsByTagName("link").item(0).getTextContent();
				// feed has old jp url, replace
				if ("ja-jp".equals(language)) link = link.replace("news.tij.co.jp","news.ti.com");
				homePageNewsList.add(new HomePageNewsItem());
				homePageNewsList.get(i).setTitle(news.getElementsByTagName("title").item(0).getTextContent());
				homePageNewsList.get(i).setUrl(link);
				homePageNewsList.get(i).setPubDate(myFormat.format(feedFormat.parse(feedDate)));
			}

		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}
	
}
