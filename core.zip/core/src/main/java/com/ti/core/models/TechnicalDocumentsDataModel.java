package com.ti.core.models;

import java.util.ArrayList;
import java.util.List;

public class TechnicalDocumentsDataModel {

	private String docCategoryName;
	private int litCategoryCount;
	private int totalCount;
	private String docCategoryId;

	private List<TechnicalDocumentsLiteratureModel> literatureValuesList = new ArrayList<>();

	public String getDocCategoryName() {
		return docCategoryName;
	}

	public void setDocCategoryName(String docCategoryName) {
		this.docCategoryName = docCategoryName;
	}

	public int getLitCategoryCount() {
		return litCategoryCount;
	}

	public void setLitCategoryCount(int litCategoryCount) {
		this.litCategoryCount = litCategoryCount;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public List<TechnicalDocumentsLiteratureModel> getLiteratureValuesList() {
		return literatureValuesList;
	}

	public void setLiteratureValuesList(List<TechnicalDocumentsLiteratureModel> literatureValuesList) {
		this.literatureValuesList = literatureValuesList;
	}

	public String getDocCategoryId() {
		return docCategoryId;
	}

	public void setDocCategoryId(String docCategoryId) {
		this.docCategoryId = docCategoryId;
	}

}
