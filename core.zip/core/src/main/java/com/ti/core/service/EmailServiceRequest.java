package com.ti.core.service;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.email.EmailService;
import com.adobe.acs.commons.wcm.AuthorUIHelper;
import com.day.cq.commons.Externalizer;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.mailer.MessageGatewayService;
import com.day.cq.wcm.api.Page;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.day.cq.workflow.model.WorkflowNode;

/**
 * 
 * EmailServiceRequest WorkflowProcess.
 *
 */

@Component(immediate = true, name = "EmailServiceRequest",
			service = WorkflowProcess.class, property= {"process.label=Email Service Request"} )
public class EmailServiceRequest implements WorkflowProcess {

	private static final String CONTRIBUTOR_AND_POWER_HTML = "contributor-and-power.html";
	private static final String REJECTION_HTML = "rejection.html";
	private static final String PUBLICATION_HTML = "publication.html";
	private static final String SUBMITTED_HTML = "submitted.html";
	private static final String FIRST_ESCALATION_HTML = "first-escalation.html";
	private static final String SECOND_ESCALATION_HTML = "second-escalation.html";
	private static final String ABSOLUTE_TIME = "absoluteTime";
	private static final String GIVEN_NAME = "givenName";
	private static final String FAMILY_NAME = "familyName";
	private static final String PROFILE2 = "/profile";
	private static final String DASH = "-";
	private static final Logger LOG = LoggerFactory.getLogger(EmailServiceRequest.class);
	@Reference
	ProductNavigationTabsOrdering tabsService;
	@Reference
	private ResourceResolverFactory rrFactory;
	@Reference
	private MessageGatewayService messageGatewayService;
	@Reference
	private SlingRepository slingRepository;
	@Reference
	private EmailService emailService;
	@Reference
	private AuthorUIHelper authorUiHelper;
	@Reference
	private Externalizer externalizer;

	private String listOfApprovers;
	private String workflowtitle;
	private boolean banner;

	private String sendWorkflowEmail(String templatePath, String pagePath, String userGroupName, WorkItem workItem,
			WorkflowSession wSession) {
		String results = "Success";
		listOfApprovers = "";

		ResourceResolver resourceResolver;
		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resourceResolver = rrFactory.getServiceResourceResolver(param);
			Date wfStartDate = workItem.getWorkflow().getTimeStarted();
			MetaDataMap metaDataMap = workItem.getWorkflow().getWorkflowData().getMetaDataMap();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm");
			String submissionDate = getWorkflowSubmissionDate(wfStartDate, metaDataMap, dateFormat);
			wSession.getUser();
			setEmailParameters(resourceResolver, templatePath, submissionDate, pagePath, userGroupName, workItem,
					wSession);
		} catch (Exception e) {
			LOG.error("Error sending notification email due to {}", e);

			results = "fail";
		}

		return results;
	}

	private String getWorkflowSubmissionDate(Date wfStartDate, MetaDataMap metaDataMap, SimpleDateFormat dateFormat) {
		String submissionDate = "";
		Set<String> keyset = metaDataMap.keySet();
		Iterator<String> i = keyset.iterator();
		while (i.hasNext()) {
			Object key = i.next();
			if (ABSOLUTE_TIME.equals(key.toString())) {
				submissionDate = dateFormat.format(wfStartDate);
			}
		}
		return submissionDate;
	}

	private String getPagePublishDate(String pagePath, ResourceResolver resourceResolver, SimpleDateFormat dateFormat) {
		String publishDate = "";
		Resource res = resourceResolver.getResource(pagePath);
		if (res != null && res.getChild("jcr:content") != null) {
			Resource childResource = res.getChild("jcr:content");
			if (childResource != null && childResource.getValueMap().get("cq:lastReplicated") != null) {
				Date dt = ((Calendar) childResource.getValueMap().get("cq:lastReplicated")).getTime();
				publishDate = dateFormat.format(dt);
			}
		}
		return publishDate;
	}

	private void setEmailParameters(ResourceResolver resourceResolver, String templatePath, String submissionDate,
			String pagePath, String userGroupName, WorkItem workItem, WorkflowSession wfSession) {

		String workflowInitiator = workItem.getWorkflow().getInitiator();
		String pageLanguageCode = null;
		String domain = null;
		String folder = null;

		Map<String, String> emailParams = new HashMap<>();
		String pageName = pagePath.substring(pagePath.lastIndexOf('/') + 1);
		String authorName = getUserNameFromId(resourceResolver, workflowInitiator);
		String userComment = workItem.getMetaDataMap().get("comment", String.class);

		Resource pageResource = resourceResolver.getResource(pagePath);

		if (pageResource != null && tabsService != null) {
			Page page = pageResource.adaptTo(Page.class);
			pageLanguageCode = tabsService.getPageLanguage(page);
			domain = tabsService.getDomainFromLanguageCode(pageLanguageCode);
			LOG.debug("pageLanguageCode  & Domain >>>>>>>>>> {} {} ",  pageLanguageCode , domain);
			if (pagePath != null && pageLanguageCode != null) {
				folder = StringUtils.substringAfter(pagePath, pageLanguageCode);
			}
		}

		LOG.debug("folder name  {} ",  folder);
		if (banner) {
			emailParams.put("pagecontent", "banner");
			emailParams.put("webpage", "banner");
			emailParams.put("page", "banner");
			emailParams.put("emailSubject", "AEM banner approved");
			emailParams.put("published", "approved");

		} else {
			emailParams.put("pagecontent", "page/content");
			emailParams.put("webpage", "web page");
			emailParams.put("page", "page");
			emailParams.put("emailSubject", "Published" + DASH + "AEM page/content published to TI.com");
			emailParams.put("published", "published");
		}
		emailParams.put("aemFolder", folder);
		emailParams.put("authorID", authorName);
		emailParams.put("pageName", folder);
		emailParams.put("link", pagePath);
		emailParams.put("submissionDate", submissionDate);
		emailParams.put("actualpageName", pageName);
		emailParams.put("workflowtitle", workflowtitle);

		Resource payloadRes = resourceResolver.getResource(pagePath);
		Map<String, String> urlParams = getUrls(payloadRes);
		emailParams.putAll(urlParams);

		List<String> members = new ArrayList<>();
		LOG.debug("Input userGroupName {} ",  userGroupName);
		if (templatePath.contains(PUBLICATION_HTML) || templatePath.contains(REJECTION_HTML)) {
			LOG.debug("publication or rejection {} ",  userGroupName);
			List<String> ccmembers = getEmailRecipentsFromGroup(resourceResolver, userGroupName);

			String ccrecipents = "";
			StringBuilder ccrecipentsSB = new StringBuilder();
			for (String member : ccmembers) {
				ccrecipentsSB.append("cc:").append(member).append("\n");
			}
			ccrecipents = ccrecipentsSB.toString();
			LOG.debug("members for the above group is {} ",  ccrecipents);
			String currentassignee = "";
			List<HistoryItem> history;
			try {
				history = wfSession.getHistory(workItem.getWorkflow());
				currentassignee = getCurrentUserName(resourceResolver, history);
				LOG.debug("Current assignee{} ",  currentassignee);

			} catch (WorkflowException e) {
				LOG.error("Error sending email due to {} ", e);
			}

			emailParams.put("currentUserId", currentassignee);

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm");
			String publishDate = getPagePublishDate(pagePath, resourceResolver, dateFormat);
			emailParams.put("publishDate", publishDate);
			emailParams.put("userComment", userComment);

			String authorEmail = getUserEmailFromId(resourceResolver, workflowInitiator);
			members.add(authorEmail);

		} else if (templatePath.contains(SECOND_ESCALATION_HTML) || templatePath.contains(FIRST_ESCALATION_HTML)) {
			LOG.debug("first or second escalation  {} ",  userGroupName);
			members = getEmailRecipentsFromGroup(resourceResolver, userGroupName);
			LOG.debug("list of APPROVERS  {} ",  listOfApprovers);
			emailParams.put("listOfApprovers", listOfApprovers);
		} else if (templatePath.contains(SUBMITTED_HTML)) {
			LOG.debug("Submitter   {} ",  userGroupName);
			members = getEmailRecipentsFromGroup(resourceResolver, userGroupName);
		} else if (templatePath.contains(CONTRIBUTOR_AND_POWER_HTML)) {
			LOG.debug("CONTRIBUTOR AND POWER USER  {} ",  userGroupName);
			members = getEmailRecipentsFromGroup(resourceResolver, userGroupName);
		}
		sendTemplatedEmail(templatePath, emailParams, members.toArray(new String[0]));

	}

	private String getCurrentUserName(ResourceResolver resourceResolver, List<HistoryItem> history) {
		String name = "";
		try {
			HistoryItem previousHistoryItem;
			String stepType;
			Iterator<HistoryItem> historyIterator = history.iterator();
			while (historyIterator.hasNext()) {
				previousHistoryItem = historyIterator.next();
				stepType = previousHistoryItem.getWorkItem().getNode().getType();
				if (stepType != null && stepType.equals(WorkflowNode.TYPE_DYNAMIC_PARTICIPANT)) {
					name = getUserNameFromId(resourceResolver, previousHistoryItem.getUserId());
				}
			}

		} catch (Exception e) {
			LOG.error("Error getting current user name due to : {}", e);
			return null;
		}

		return name;
	}

	private void sendTemplatedEmail(String templatePath, Map<String, String> emailParams, String[] receipients) {
		LOG.debug("TEMPLATE PATH {} ",  templatePath);
		List<String> failureList = emailService.sendEmail(templatePath, emailParams, receipients);

		if (failureList.isEmpty()) {
			LOG.info("---------------Mail delivery successfull---------------");
		} else {
			LOG.info("---------------Mail delivery failed---------------");
		}
	}

	private List<String> getEmailRecipentsFromGroup(ResourceResolver resourceResolver, String userGroupName) {

		UserManager userManager = resourceResolver.adaptTo(UserManager.class);
		final List<String> members = new ArrayList<>();
		List<Authorizable> users = new ArrayList<>();
		String email = null;

		try {
			if (userManager != null && null != userManager.getAuthorizable(userGroupName)) {
				Authorizable auth = userManager.getAuthorizable(userGroupName);
				if (auth.isGroup()) {
					Group group = (Group) auth;
					Iterator<Authorizable> iter = group.getMembers();
					while (iter.hasNext()) {
						users.add(iter.next());
					}
					StringBuilder stringBuilder = new StringBuilder();
					for (Authorizable user : users) {
						if (resourceResolver != null
								&& resourceResolver.getResource(user.getPath() + PROFILE2) != null) {
							Resource r = resourceResolver.getResource(user.getPath() + PROFILE2);
							if (r != null) {
								ValueMap profile = r.adaptTo(ValueMap.class);
								if (profile != null) {
									email = profile.get("email", "");
									String name = profile.get(GIVEN_NAME, "") + " " + profile.get(FAMILY_NAME, "");
									if (StringUtils.isEmpty(name.trim())) {
										name = user.getID();
									}
									stringBuilder.append(name).append("\n");
									if (StringUtils.isEmpty(email)) {
										continue;
									}
								}

							}
							members.add(email);
						}
					}
					listOfApprovers = stringBuilder.toString();
				}
			}
		} catch (Exception e) {
			LOG.error("Error in getEmailRecipentsFromGroup due to {}", e);
		}

		return members;
	}

	@Override
	public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
			throws WorkflowException {

		String processArgs = metaDataMap.get("PROCESS_ARGS", "");
		LOG.debug("WF Arguments {} ",  processArgs);
		com.day.cq.workflow.exec.WorkflowData workflowData = workItem.getWorkflowData();
		String userGroupName = "notFound";
		String[] args = processArgs.split(",");
		String templatePath = args[0];
		if (args.length > 1) {
			userGroupName = args[1];
		}
		LOG.debug("userGroupName from workflow argument {} ",  userGroupName);
		LOG.debug("templatePath : {} ",  templatePath);
		try {
			if (workflowData.getMetaDataMap().get("approver") != null && templatePath.contains(SUBMITTED_HTML)) {
				userGroupName = workflowData.getMetaDataMap().get("approver").toString();
				LOG.debug("userGroupName from workflow {} ",  userGroupName);
			}
			if (workflowData.getMetaDataMap().get("workflowTitle") != null) {
				workflowtitle = workflowData.getMetaDataMap().get("workflowTitle").toString();
				LOG.debug("workflowtitle {} ",  workflowtitle);
			}
		} catch (Exception e) {
			LOG.error("RepositoryException thrown while setting the properties on workflow  {} ",  "payload metadata node"
					+ e);
		}

		String pagePath = workItem.getWorkflowData().getPayload().toString();
		banner = false;

		if (pagePath.contains("/homepagebanners/")) {
			banner = true;
		}
		sendWorkflowEmail(templatePath, pagePath, userGroupName, workItem, wfSession);
	}

	private Map<String, String> getUrls(Resource payloadRes) {
		Map urlParams = new HashMap();
		if (payloadRes == null) {
			return urlParams;
		}

		String payloadPath = payloadRes.getPath();
		LOG.debug("page path  {} ",  payloadPath);
		ResourceResolver resolver = payloadRes.getResourceResolver();
		String assetDetailsUrl;

		if (DamUtil.isAsset(payloadRes)) {
			assetDetailsUrl = this.authorUiHelper.generateEditAssetLink(payloadPath, true, resolver);
			urlParams.put("authorLink", assetDetailsUrl);

			String publishUrl = this.externalizer.publishLink(resolver, payloadPath);
			if (banner) {
				urlParams.put("publishLink", assetDetailsUrl);
			} else {
				urlParams.put("publishLink", publishUrl);
			}

		} else {
			assetDetailsUrl = this.authorUiHelper.generateEditPageLink(payloadPath, true, resolver);
			LOG.debug("assetDetailsUrl  {} ",  assetDetailsUrl);
			urlParams.put("authorLink", assetDetailsUrl);

			String publishUrl = this.externalizer.publishLink(resolver, payloadPath + ".html");
			if (banner) {
				urlParams.put("publishLink", assetDetailsUrl);
			} else {
				urlParams.put("publishLink", publishUrl);
			}
		}

		try {
			String host;
			String protocol;
			URL authorUrl = new URL(assetDetailsUrl);
			LOG.debug("author URL  {} ",  authorUrl);
			host = authorUrl.getHost();
			protocol = authorUrl.getProtocol();
			LOG.debug("protocol from author URL  {} ",  protocol);
			urlParams.put("protocol", protocol);
			urlParams.put("host", protocol + "://" + host);
		} catch (Exception e) {
			LOG.error("Error in getURLs due to {}", e);
		}

		return urlParams;
	}

	private String getUserNameFromId(ResourceResolver resourceResolver, String workflowInitiator) {
		String userName = "";
		try {
			List<String> recipents = new ArrayList<>();
			recipents.add(workflowInitiator);
			UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			if (userManager != null) {
				Authorizable auth = userManager.getAuthorizable(workflowInitiator);
				if (!auth.isGroup() && resourceResolver.getResource(auth.getPath() + PROFILE2) != null) {
					Resource r = resourceResolver.getResource(auth.getPath() + PROFILE2);
					if (r != null) {
						ValueMap profile = r.adaptTo(ValueMap.class);
						if (profile != null) {
							userName = profile.get(GIVEN_NAME, "") + " " + profile.get(FAMILY_NAME, "");
							if (StringUtils.isEmpty(userName.trim())) {
								return workflowInitiator;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Error getting userName from Id due to  {} ", e);
		}
		return userName;
	}

	private String getUserEmailFromId(ResourceResolver resourceResolver, String workflowInitiator) {
		String email = "";

		try {
			List<String> recipents = new ArrayList<>();
			recipents.add(workflowInitiator);
			UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			if (userManager != null) {
				Authorizable auth = userManager.getAuthorizable(workflowInitiator);
				if (!auth.isGroup() && resourceResolver.getResource(auth.getPath() + PROFILE2) != null) {
					ValueMap profile;
					Resource r = resourceResolver.getResource(auth.getPath() + PROFILE2);
					if (r != null) {
						profile = r.adaptTo(ValueMap.class);
						if (profile != null) {
							email = profile.get("email", "");
							if (StringUtils.isEmpty(email.trim())) {
								return workflowInitiator;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Error getting userName from Id due to {} {} ",  e);
		}
		return email;
	}
}