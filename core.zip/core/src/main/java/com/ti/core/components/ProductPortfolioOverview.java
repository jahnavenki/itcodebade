package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductPortfolioOverview extends WCMUsePojo {
    private static final String FAMILY_ID = "familyId";
    private static final String FAMILY_NAME = "familyName";
    protected static final Logger log = LoggerFactory.getLogger(ProductPortfolioOverview.class);

    private String familyName;
    private String browserTitle;
    private String metaDescription;
    private String keywords;

    @Override
    public void activate() throws Exception {
        try {  
            if (null != getPageProperties().get(FAMILY_ID)) {
                String language = "en-us";
                final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                    ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    language = tabsService.getPageLanguage(getCurrentPage());
                }
                setFamilyName(getPageProperties().get(FAMILY_ID).toString(), language);
                setMetadata(familyName, language);
            }
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }
    }

    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = <Family name> + “|” + “TI.com”
                                For CN, it should be <Family name> + “|” + “TI.com.cn”
            2. Meta description = Sub-headline
            3. Keywords: <Family name>
    */
    private void setMetadata(String familyName, String language) {  
        if("zh-cn".equals(language)) {
            browserTitle = familyName + " | TI.com.cn";
        } else {
            browserTitle = familyName + " | TI.com";
        }
        keywords = familyName;
        final Resource pageResource = getResource();
        if (null == pageResource) {
            log.debug("resource is null");
            return;
        }
        final Resource rootResource = pageResource.getChild("root"); 
        if (null == rootResource) {
            log.debug("root is null");
            return;
        }
        for (Resource nodeChild : rootResource.getChildren()) {
            for (Resource nodeChild2 : nodeChild.getChildren()) {
                if (nodeChild2.getName().startsWith("productportfoliohead")) {
                    final ValueMap map = nodeChild2.getValueMap();
                    metaDescription = map.get("subheadline").toString();
                    if (null != metaDescription && metaDescription.length() > 160) {
                        metaDescription = metaDescription.substring(0, 160) + "...";
                    }
                    break;
                }
            }
        }
    }

    /**
     * This method calls the service for Family and returns the associated family
     * name for provided family id.
     * 
     * @param familyId family id set from page properties.
     */
    private void setFamilyName(String familyId, String language) {
        try {
            final WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
            if (wcmComponents != null) {
                final JSONObject prodData = wcmComponents.getAllProductService(this.getRequest(), 
                    Integer.parseInt(familyId), language);
                if (prodData != null) {
                    familyName = prodData.getString(FAMILY_NAME);
                }
            }
        } catch (Exception e) {
            log.error("Could not get family name from json", e);
        }
    }

    public String getBrowserTitle() {
        return browserTitle;
    }

    public String getMetaDescription() {
        return metaDescription;
    }

    public String getKeywords() {
        return keywords;
    }
}
