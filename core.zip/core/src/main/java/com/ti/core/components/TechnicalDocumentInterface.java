package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.commons.jcr.JcrUtil;
import com.ti.core.models.Application;
import com.ti.core.models.GenericModel;
import com.ti.core.models.Silo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

// TODO: Auto-generated Javadoc
/**
 * TechnicalDocumentInterface WCMUsePojo.
 */
public class TechnicalDocumentInterface extends WCMUsePojo {

	/** The log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	/** The silo family response. */
	private String siloFamilyResponse = "";

	/** The silo list. */
	private List<Silo> siloList = new ArrayList<>();

	/** The app list. */
	private List<Application> appList = new ArrayList<>();

	/** The doc category list. */
	private List<GenericModel> docCategoryList = new ArrayList<>();

	/** The Constant DATA. */
	private static final String CONTENT = "content";

	/** The Constant FAMILY_ID. */
	private static final String FAMILY_ID = "familyId";

	/** The Constant APP_ID. */
	private static final String APP_ID = "appId";

	/** The Constant FAMILY_NAME. */
	private static final String FAMILY_NAME = "familyName";

	/** The Constant FAMILY_URL. */
	private static final String FAMILY_URL = "familyUrl";

	/** The Constant SORT_ORDER. */
	private static final String SORT_ORDER = "sortOrder";

	/** The Constant APP_NAME. */
	private static final String APP_NAME = "appAreaName";

	/** The Constant DOC_FIELD. */
	private static final String DOC_FIELD = "documentTypes";

	/** The Constant RESOURCE_TYPE. */
	private static final String RESOURCE_TYPE = "ti/components/technicalDocumentInterface";

	/** The doc types. */
	private String[] docTypes = new String[] {};

	/** The doc type string. */
	private String docTypeString = "";

	/** The template. */
	private String template = "";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.adobe.cq.sightly.WCMUsePojo#activate()
	 */
	@Override
	public void activate() throws RepositoryException {
		JSONObject siloJsonObject = null;
		JSONObject appObject = null;

		try {
			template = getCurrentPage().getProperties().get("cq:template", "");

			Resource currentResource = getResource();

			StringBuilder documentType = readDocumentTypes();

			if ("product".equalsIgnoreCase(getTemplate())) {
				documentType.append(",13");
			}

			String[] finaldocumentType = documentType.toString().split(",");

			if (null != currentResource) {
				String resourcePath = currentResource.getPath();
				log.debug(" current resource ", resourcePath);
				Node currentNode = currentResource.adaptTo(Node.class);
				log.debug(" current node ", currentNode);
				if (null == currentNode) {
					currentNode = createNode(resourcePath);
					try {
						if (null != currentNode) {
							currentNode.setProperty(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, RESOURCE_TYPE);
							currentNode.setProperty("documentTypes", finaldocumentType);
							currentNode.getSession().refresh(true);
							currentNode.getSession().save();
						}
					} catch (RepositoryException e) {
						log.error("Repository Exception: ", e);
					}
				}
			}

			WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (wcmService == null)
				throw new NullPointerException("Could not find wcmService while activating TechnicalDocumentInterface");
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);
			String language = "";
			if (tabsService != null) {
				language = tabsService.getPageLanguage(getCurrentPage());
			}
			if ("application".equalsIgnoreCase(getTemplate())) {
				appObject = wcmService.getApplicationListService(getRequest(), language);
				setApplicationData(appObject);
			} else if ("product".equalsIgnoreCase(getTemplate())) {
				log.debug("Inside Silo Else");
				if (null != wcmService) {
					this.siloFamilyResponse = wcmService.getSilo(language);
				}
				if (StringUtils.isNotEmpty(siloFamilyResponse)) {
					String siloString = StringEscapeUtils.unescapeHtml4(siloFamilyResponse);
					siloJsonObject = new JSONObject(siloString);

					setSiloData(siloJsonObject);
				}
			}

			log.debug(" recieved response from json");
			this.docTypes = getProperties().get(DOC_FIELD, String[].class);
			setDocTypes();

		} catch (JSONException e) {
			log.error("JSONException: ", e);
		} catch (Exception e) {
			log.error("Generic Exception: ", e);
		}
	}

	/**
	 * Sets the doc types.
	 */
	private void setDocTypes() {
		String pipe = "|";
		StringBuilder sb = new StringBuilder();
		if (this.docTypes != null) {
			for (int i = 0; i < docTypes.length; i++) {
				String docCategory = docTypes[i];
				GenericModel gm = new GenericModel();
				gm.setValue(docCategory);
				docCategoryList.add(gm);
				if (i == docTypes.length - 1)
					pipe = "";
				sb.append(docCategory + pipe);
			}
		}
		docTypeString = sb.toString();
	}

	private StringBuilder readDocumentTypes() {
		StringBuilder documentType = new StringBuilder();
		WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		if (null != wcmService)
			documentType.append(wcmService.getDefaultDocumentCategories());

		return documentType;
	}

	/**
	 * Sets the silo data.
	 *
	 * @param siloJsonObject
	 *            the new silo data
	 * @throws JSONException
	 *             the JSON exception
	 */
	private void setSiloData(JSONObject siloJsonObject) throws JSONException {
		JSONArray families = (JSONArray) siloJsonObject.get(CONTENT);

		for (int i = 0; i < families.length(); i++) {
			JSONObject jsonObject = families.getJSONObject(i);

			Silo silo = new Silo();
			silo.setFamilyId(jsonObject.getString(FAMILY_ID));
			String familyName = StringEscapeUtils.unescapeHtml4(jsonObject.getString(FAMILY_NAME));
			silo.setFamilyName(familyName);
			silo.setFamilyUrl(jsonObject.getString(FAMILY_URL));
			silo.setSortOrder(SORT_ORDER);
			siloList.add(silo);
		}
	}

	/**
	 * Sets the application data.
	 *
	 * @param appObject
	 *            the new application data
	 * @throws JSONException
	 *             the JSON exception
	 */
	private void setApplicationData(JSONObject appObject) throws JSONException {
		JSONArray appFamilies = null;
		appFamilies = appObject.getJSONArray(CONTENT);
		for (int i = 0; i < appFamilies.length(); i++) {
			JSONObject jsonObject = appFamilies.getJSONObject(i);

			Application app = new Application();
			app.setAppId(jsonObject.getString(APP_ID));
			String appName = StringEscapeUtils.unescapeHtml4(jsonObject.getString(APP_NAME));
			app.setAppName(appName);

			appList.add(app);
		}
	}

	/**
	 * This method will create a new node in JCR.
	 *
	 * @param nodePath
	 *            the node path
	 * @return the node
	 */
	private Node createNode(String nodePath) {
		Node node = null;
		ResourceResolver resourceResolver;
		Session session;
		try {
			resourceResolver = getRequest().getResourceResolver();
			session = resourceResolver.adaptTo(Session.class);
			log.debug("session ", session);
			if (null != session) {
				Node existingNode = getExistingNode(session, nodePath);
				if (null == existingNode) {
					node = JcrUtil.createPath(nodePath, JcrConstants.NT_UNSTRUCTURED, session);
					node.getSession().refresh(true);
					node.getSession().save();
					log.debug("  node saved");

				} else {
					node = existingNode;
				}
			}
		} catch (RepositoryException re) {
			log.error("Error creating node:", re);
		}
		return node;
	}

	/**
	 * Gets the existing node.
	 *
	 * @param session
	 *            the session
	 * @param nodePath
	 *            the node path
	 * @return the existing node
	 */
	private Node getExistingNode(Session session, String nodePath) {
		Node existingNode = null;
		try {
			existingNode = session.getNode(nodePath);
			log.debug(" existing node ", existingNode);
		} catch (PathNotFoundException e) {
			log.error("Path Not Found:", e);
		} catch (RepositoryException e) {

			log.error("Repository exception :", e);
		}
		return existingNode;
	}

	/**
	 * Gets the silo list.
	 *
	 * @return the silo list
	 */
	public List<Silo> getSiloList() {
		return this.siloList;
	}

	/**
	 * Gets the app list.
	 *
	 * @return the app list
	 */
	public List<Application> getAppList() {
		return this.appList;
	}

	/**
	 * Gets the doc category list.
	 *
	 * @return the doc category list
	 */
	public List<GenericModel> getDocCategoryList() {
		return this.docCategoryList;
	}

	/**
	 * Gets the doc type string.
	 *
	 * @return the doc type string
	 */
	public String getDocTypeString() {
		return docTypeString;
	}

	/**
	 * Gets the template.
	 *
	 * @return the template
	 */
	public String getTemplate() {
		String type;
		if (template.contains("product"))
			type = "product";
		else if (template.contains("application"))
			type = "application";
		else
			type = "";
		return type;
	}
}
