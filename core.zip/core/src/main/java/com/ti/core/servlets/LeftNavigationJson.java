package com.ti.core.servlets;

import com.google.gson.Gson;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;
import java.util.Iterator;

import static org.apache.sling.api.servlets.ServletResolverConstants.*;

@Component(service = Servlet.class, immediate = true, property = {
        SLING_SERVLET_RESOURCE_TYPES + "=sling/servlet/default", SLING_SERVLET_EXTENSIONS + "=json",
        SLING_SERVLET_METHODS + "=GET", SLING_SERVLET_SELECTORS + "=leftnav"})
public class LeftNavigationJson extends SlingSafeMethodsServlet {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private static final Logger log = LoggerFactory.getLogger(LeftNavigationJson.class);

    private static final String LEFT_NAV_RES_TYPE = "ti/components/leftNavigationAuthored";
    private static final String IPARSYS_PATH = "/jcr:content/parleft";
    private static final String JCR_CONTENT = "jcr:content";
    private static final String EN_URL_PATH = "/content/texas-instruments/en-us/";
    private static final String URL_PATH = "/content/texas-instruments/";
    private static final String SLASH = "/";

    @Override
    protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response) {
        try {
            Resource currentRes = request.getResource();
            if (null != currentRes) {
                Resource childRes = currentRes.getChild(JCR_CONTENT);
                if (childRes != null) {
                    ResourceResolver resolver = request.getResourceResolver();
                    JSONObject leftParJSON = new JSONObject();
                    leftParJSON.put("parleft", generateLeftNavJSON(currentRes, resolver));
                    //write results to response
                    response.setContentType("text/x-json;charset=UTF-8");
                    response.getWriter().write(leftParJSON.toString());
                }
            }
        } catch (IOException | JSONException e) {
            log.error("Error in Quality Left Navigation API : ", e);
        }
    }

    private JSONObject generateLeftNavJSON(Resource currentRes, ResourceResolver resolver) throws JSONException {
        JSONObject object = new JSONObject();
        Resource leftNavRes = resolver.getResource(currentRes.getPath().concat(IPARSYS_PATH));
        if (leftNavRes != null && !ResourceUtil.isNonExistingResource(leftNavRes)) {
            Iterator<Resource> iterator = leftNavRes.listChildren();
            while (iterator.hasNext()) {
                Resource resource = iterator.next();
                getItemJson(object,resource);
            }
        } else {
            generateLeftNavJSON(currentRes.getParent(), resolver);
        }
        return object;
    }

    private void getItemJson(JSONObject object, Resource resource) throws JSONException {
        if (resource.isResourceType(LEFT_NAV_RES_TYPE)) {
            ValueMap map = resource.getValueMap();
            Gson gson = new Gson();
            String json = gson.toJson(map);
            if (null != json) {
                if (json.contains(EN_URL_PATH)) {
                    json = json.replace(EN_URL_PATH, SLASH);
                } else {
                    json = json.replace(URL_PATH, SLASH);
                }
            }
            JSONObject nodeJson = new JSONObject(json);
            JSONArray multiFiledArray = getMultifieldJsonArray(resource);
            if (multiFiledArray.length() > 0) {
                nodeJson.put("level2MultiFields", multiFiledArray);
            }
            object.put(resource.getName(), nodeJson);
        }
    }

    //Formation of JSON for leftNavigation Multifield
    private JSONArray getMultifieldJsonArray(Resource multiFieldResource) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        Iterator<Resource> itemsIterator = multiFieldResource.listChildren();
        while (itemsIterator.hasNext()) {
            Resource eachItemResource = itemsIterator.next();
            Iterator<Resource> multifiedIterator = eachItemResource.listChildren();
            while (multifiedIterator.hasNext()) {
                getLevel3ItemsJson(jsonArray, multifiedIterator);
            }
        }
        return jsonArray;
    }

    private void getLevel3ItemsJson(JSONArray jsonArray, Iterator<Resource> multifiedIterator) throws JSONException {
        Resource eachItemMultifiedResource = multifiedIterator.next();
        ValueMap map = eachItemMultifiedResource.getValueMap();
        Gson gson = new Gson();
        String json = gson.toJson(map);
        if (null != json) {
            if (json.contains(EN_URL_PATH)) {
                json = json.replace(EN_URL_PATH, SLASH);
            } else {
                json = json.replace(URL_PATH, SLASH);
            }
        }
        JSONObject nodeJson = new JSONObject(json);
        JSONArray multiFiledArray = getMultifieldJsonArrayLevel3(eachItemMultifiedResource);
        if (multiFiledArray.length() > 0) {
            nodeJson.put("level3MultiFields", multiFiledArray);
        }

        nodeJson.remove("jcr:primaryType");
        jsonArray.put(nodeJson.toString());
    }

    private JSONArray getMultifieldJsonArrayLevel3(Resource multiFieldResource) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        Iterator<Resource> itemsIterator = multiFieldResource.listChildren();
        while (itemsIterator.hasNext()) {
            Resource eachItemResource = itemsIterator.next();
            Iterator<Resource> multifiedIterator = eachItemResource.listChildren();
            while (multifiedIterator.hasNext()) {
                fetchingJsonArrayValues(jsonArray, multifiedIterator);
            }
        }
        return jsonArray;
    }

    private void fetchingJsonArrayValues(JSONArray jsonArray, Iterator<Resource> multifiedIterator) throws JSONException {
        Resource eachItemMultifiedL3Resource = multifiedIterator.next();
        ValueMap map = eachItemMultifiedL3Resource.getValueMap();
        Gson gson = new Gson();
        String json = gson.toJson(map);
        if (null != json) {
            if (json.contains(EN_URL_PATH)) {
                json = json.replace(EN_URL_PATH, SLASH);
            } else {
                json = json.replace(URL_PATH, SLASH);
            }
        }
        JSONObject nodeJson = new JSONObject(json);

        nodeJson.remove("jcr:primaryType");
        jsonArray.put(nodeJson);
    }

}