package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.PathBrowserHelper;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EcosystemDiagram extends WCMUsePojo {
	private static final String FAMILY_ID = "familyId";
	protected final Logger log = LoggerFactory.getLogger(getClass());
	private LanguageUtils languageUtils;
	private String familyNameEn;
	private String sectionTitle;
	private String sectionDescription;
	private String sectionCtaText;
	private String sectionCtaLink;
	private final List<ListItemViewModel> listItems = new ArrayList<>();

	public String getFamilyNameEn() {
		return familyNameEn;
	}

	public String getSectionTitle() {
		return sectionTitle;
	}

	public String getSectionDescription() {
		return sectionDescription;
	}

	public String getSectionCtaText() {
		return sectionCtaText;
	}

	public String getSectionCtaLink() {
		return sectionCtaLink;
	}

	public List<ListItemViewModel> getListItems() {
		return listItems;
	}

	public static class ListItemViewModel {
		private String title;
		private String titleEn;
		private String urlLink;
		private String imageSrc;
		private String description;

		public String getTitle() {
			return title;
		}

		public String getTitleEn() {
			return titleEn;
		}

		public String getUrlLink() {
			return urlLink;
		}

		public String getImageSrc() {
			return imageSrc;
		}

		public String getDescription() {
			return description;
		}
	}

	private String getNavbarId(String typeAndTitle) {
		switch(typeAndTitle) {
		case "hardware": return "#hardware";
		case "software": return "#software";
		case "developerZone": return "#ti-developer-zone";
		case "educationalResources": return "#educational-resources";
		case "partners": return "#partners";
		case "opticalModules": return "#optical-modules";
		case "designTools": return "#design-tools";
		default: return "";
		}
	}

	private ListItemViewModel buildListItemViewModel(Resource listItemResource) {
		final var valueMap = listItemResource.getValueMap();
		final var typeAndTitle = valueMap.get("typeAndTitle", "");
		final var listItem = new ListItemViewModel();
		final var titleKey = "designResources:" + typeAndTitle;
		listItem.title = languageUtils.getI18nStr(titleKey);
		listItem.titleEn = languageUtils.getI18nStrEn(titleKey);
		listItem.urlLink = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), valueMap.get("urlLink", "")) + getNavbarId(typeAndTitle);
		switch (typeAndTitle) {
		case "hardware":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/products/hardware-icon.png";
			break;
		case "software":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/software/open-source-icon.png";
			break;
		case "developerZone":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/products/developer-zone-icon.png";
			break;
		case "educationalResources":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/resources/support-materials-icon.png";
			break;
		case "partners":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/business/partners-icon.png";
			break;
		case "opticalModules":
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/products/optical-module-icon.png";
			break;
		case "designTools":
			listItem.imageSrc = "";
			break;
		default:
			listItem.imageSrc = "https://www.ti.com/content/dam/ticom/images/icons/illustrative-icons/miscellaneous/no-image-available-icon.png";
			break;
		}
		listItem.description = valueMap.get("description", "");
		return listItem;
	}

	@Override
	public void activate() {
		try {
			languageUtils = new LanguageUtils(getRequest());
			var language = "en-us";
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if (null != tabsService) {
				language = tabsService.getPageLanguage(getCurrentPage());
			}
			final var wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			final var properties = getProperties();
			final var pageProperties = getPageProperties();
			var familyName = "<familyName>";
			if (null != wcmComponents && pageProperties.containsKey(FAMILY_ID)) {
				final var familyId = pageProperties.get(FAMILY_ID, Integer.class);
				final var prodData = wcmComponents.getAllProductService(getRequest(), familyId, language);
				if (null != prodData) {
					familyName = prodData.getString("familyName");
					familyNameEn = prodData.getString("enFamilyName");
				}
			}
			sectionTitle = languageUtils.getI18nStr("{} design & development", familyName);
			sectionDescription = properties.get("sectionDescription", "");
			sectionCtaText = languageUtils.getI18nStr("Get started");
			sectionCtaLink = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get("sectionCta", ""));
			final var listItemsResource = getResourceResolver().getResource(getResource(), "listItems");
			if (null != listItemsResource) {
				for (final var listItemResource : listItemsResource.getChildren()) {
					listItems.add(buildListItemViewModel(listItemResource));
				}
			}
		} catch (Exception e) {
			log.error("Exception:", e);
		}
	}
}
