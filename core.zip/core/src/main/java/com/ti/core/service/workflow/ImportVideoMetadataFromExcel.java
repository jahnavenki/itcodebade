package com.ti.core.service.workflow;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set  fields in Metadata and Brightcove tabs from Excel.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Import Metadata and Brightcove tabs" })
public class ImportVideoMetadataFromExcel implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());
    private static final String BRC_CUSTOM_FIELDS = "brc_custom_fields";
    private ResourceResolver resourceResolver;
	private TagManager tagManager;
	private Session jcrSession;

	@Reference
	private WCMComponents wcmService;
    @Reference
	private VideoConfigService videoService;
	@Reference
    private Replicator replicator;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		String videoPath = "";
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
                throw new NullPointerException("resourceResolver");
            }
			Resource resource = resourceResolver.getResource(payload);
			if (null == resource) {
                throw new NullPointerException("resource");
            }
            videoPath = videoService.getVideoPath();
            if (videoPath == null || videoPath.length() <= 0) {
                log.error("Video path not found in the config");
                return;
            }             

            InputStream stream = createInputStreamFromResource(resource);
			if (null == stream) {
                log.error("Error creating strema for Excel");
                return;
            }
			tagManager = resourceResolver.adaptTo(TagManager.class); 
			jcrSession = resourceResolver.adaptTo(Session.class);
			readExcelAndImportMetadata(stream, videoPath);			
			resourceResolver.commit(); 
		} catch (Exception e) {
            log.error("Error occurred in ImportVideoMetadataFromExcel - video path = {}", videoPath, e);
		}
	}

    private InputStream createInputStreamFromResource(Resource resource) {
        try {
            Asset asset = resource.adaptTo(Asset.class);
            InputStream stream = null;
            if (asset != null) {
                Rendition original = asset.getOriginal();
                if (original !=null) {
                    stream = original.getStream();
                }
            }
            return stream;
        } catch (Exception e) {
			log.error("Error occurred in ImportCtaProcessStep createInputStreamFromResource", e);
		} 
        return null;   
    }

    private void readExcelAndImportMetadata(InputStream stream, String videoPath) {
		int rowNum = 0;
        try (XSSFWorkbook workbook = new XSSFWorkbook(stream)) {
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.rowIterator();
			ArrayList<String> fieldNames = new ArrayList<>();
			
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
				rowNum = row.getRowNum();
				if (rowNum == 0) {
					// get field names from first row
					fieldNames = getFieldNames(row);
				} else {
					// import data from second row onwards
					// if the row is with duplicate brc_id, then it will have all blank fields, except CTAs
					// skip that row
					Cell cell2 = row.getCell(2); // check 2nd field 'dc:title'
					// skip the row with duration = 0
					Cell cell27 = row.getCell(27); // duration is cell 27
					if (cell2 != null && StringUtils.isNotEmpty(cell2.toString())
						&& cell27 != null && StringUtils.isNotEmpty(cell27.toString())
						) {
						importMetadataFields(videoPath, fieldNames, row);
					}
				}
            }      
        } catch (Exception e) {
            log.error("Error occurred in ImportVideoMetadataFromExcel - readExcelAndImportMetadata - row - {}", rowNum, e);
        }            
    }

	private ArrayList<String> getFieldNames(Row row) {
		ArrayList<String> fieldNames = new ArrayList<>();
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			fieldNames.add(cell.getStringCellValue().trim());
		}
		return fieldNames;
	}

	private String getVideoId(Row row) {
		// First cell is video id
		Cell cell0 = row.getCell(0);
		if (cell0 == null || StringUtils.isEmpty(cell0.toString())) {
			log.error("Video id not found in the Excel for row - {}", row.getRowNum());
			return null;
		}

		DataFormatter dataFormatter = new DataFormatter();
		return dataFormatter.formatCellValue(cell0);
	}
	
	private ModifiableValueMap getMetadataMap(Resource videoResource, String videoId) {
		// properties under metadata node
		ModifiableValueMap metaDataMap = AssetUtils.getModifiableMetadata(videoResource);
		if (metaDataMap == null) {
			log.debug("Metadata not found for id - {}", videoId);
			return null;
		}
		return metaDataMap;
	}

	private ModifiableValueMap getJcrContentMap(Resource videoResource, String videoId) {
		// properties under jcr:content node
		Resource jcrContentNode = videoResource.getChild("jcr:content");
		if (jcrContentNode == null) {
			log.debug("jcr:content node not found for id - {}", videoId);
			return null;
		}
		final ModifiableValueMap jcrMap = jcrContentNode.adaptTo(ModifiableValueMap.class);
		if (null == jcrMap) {
			throw new NullPointerException("Metadata jcrMap");
		}

		return jcrMap;
	}
	
	private void importMetadataFields(String videoPath, ArrayList<String> fieldNames, Row row) {
		String videoId = getVideoId(row);
		try {
			Resource videoResource =  AssetUtils.getDamResource(resourceResolver, videoPath, videoId);
			if (videoResource == null) {
				log.error("Video asset not found for id - {}", videoId);
				return;
			}
			ModifiableValueMap metaDataMap = getMetadataMap(videoResource, videoPath);
			ModifiableValueMap jcrMap = getJcrContentMap(videoResource, videoPath);

			if (metaDataMap == null || jcrMap == null) {
				String err = "jcr";
				if (metaDataMap == null && jcrMap == null) {
					err = "Metadata and jcr";
				} else if (metaDataMap == null) {
					err = "Metadata";
				} 		
				log.error("{} map is null", err);
				return;		
			}
			setStandardFields(metaDataMap);
			setFieldsFromExcel(fieldNames, row, metaDataMap, jcrMap, videoResource);
			// publish the video asset		
			replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE, videoResource.getPath());
		} catch (Exception e) {
			log.error("Error occurred in ImportVideoMetadataFromExcel - importMetadataFields - videoId = {}", videoId + 
				", Row = " + row.getRowNum(), e);
		} 
	}

	// set properties from Excel data
	private void setFieldsFromExcel(ArrayList<String> fieldNames, Row row, ModifiableValueMap metaDataMap, ModifiableValueMap jcrMap, Resource videoResource) {
		String fieldName = "";
		try {
			// First cell is video id, so start after cell 2
			for (int i=1; i<fieldNames.size(); i++) {
				fieldName = fieldNames.get(i);
				Cell cell = row.getCell(i);
				if (cell != null) {
					if (fieldName.equalsIgnoreCase("brc_duration")) {
						// convert duration to hh:mm:ss from milliseconds
						String durationInHhMmSs = DurationFormatUtils.formatDuration((long) cell.getNumericCellValue(), "HH:mm:ss");
						metaDataMap.put(fieldName, durationInHhMmSs);
					} else {
						String cellValue  = row.getCell(i).getStringCellValue();
						if (!StringUtils.isEmpty(cellValue)) {
							processCell(fieldName, cellValue, metaDataMap, jcrMap, videoResource);
						}  
					}
				}  
			}
		} catch (Exception e) {
			log.error("Error occurred in ImportVideoMetadataFromExcel - setFieldsFromExcel - Row = " + row.getRowNum() + ", Field = " + fieldName, e);
		} 
	}

	private void processCell(String fieldName, String cellValue, ModifiableValueMap metaDataMap, ModifiableValueMap jcrMap, Resource videoResource) {		
		if (fieldName.equalsIgnoreCase("dam:presenter1")) {
			String image = getPresenterImageFromName(cellValue);
			if (StringUtils.isNotEmpty(image)) {
				metaDataMap.put(fieldName, image);
			}
		} else {
			processFields(fieldName, cellValue, metaDataMap, jcrMap, videoResource);
		}
	}

	private String getPresenterImageFromName(String cellValue) {
		Resource resource = AssetUtils.getDamResourceFromProperty(resourceResolver, "/content/dam/ticom/images/people/employees/headshots/", 
					"./jcr:content/metadata/dam:employeeName", cellValue);
		if (resource != null) {
			return resource.getPath();
		} 
		return "";	
	}

	private void setStandardFields(ModifiableValueMap metaDataMap) {
		metaDataMap.put("dam:status", "published");
		metaDataMap.put("dc:format", "video/mp4");
		metaDataMap.put("dam:videoPage", "yes");
		metaDataMap.put("brc_lastsync", java.util.Calendar.getInstance());
	}

	private void processFields(String fieldName, String cellValue, ModifiableValueMap metaDataMap, ModifiableValueMap jcrMap, Resource videoResource) {	
		try {
			// For 'additional tags' field, add to standard tags if it does not exist
			if (fieldName.equalsIgnoreCase("additionalTags")) {					
				String[] tags = addTagsToDefaultNamespace(cellValue, tagManager);
				metaDataMap.put(fieldName, tags);
			} else if (fieldName.equalsIgnoreCase("brc_tags")) {
				// remove extra spaces
				String[] tagStrArr = cellValue.trim().split("\\s*,\\s*");
				metaDataMap.put(fieldName, tagStrArr);
			} else if (fieldName.equalsIgnoreCase("dam:offTime") || fieldName.equalsIgnoreCase("onTime")) {
				// add under jcr:content node
				jcrMap.put(fieldName, cellValue);
			} else if (fieldName.indexOf(BRC_CUSTOM_FIELDS) > -1) {
				// Can't use metadata map here for fields under the folder 'brc_custom_fields'
				// because AEM doesn't create brc_custom_fields folder automatically
				// So create a folder 'brc_custom_fields' under metadata 	
				Node brcCustomFieldsNode = getBrcCustomFieldsNode(videoResource);
				if (brcCustomFieldsNode != null) {
					// remove 'brc_custom_fields/' from field name 	
					brcCustomFieldsNode.setProperty(fieldName.substring(18), cellValue);
				}
			} else {
				metaDataMap.put(fieldName, cellValue);
			}
		} catch (Exception e) {
			log.error("Error occurred in ImportVideoMetadataFromExcel - processFields - videoId - {} - field - {}",
					metaDataMap.get("brc_id"), e);
		}
	}

	private String[] addTagsToDefaultNamespace(String additionalTags, TagManager tagManager) {
		String[] tagStrArr = additionalTags.trim().split("\\s*\\|\\s*");
		ArrayList<String> tagList = new ArrayList<>();
		for (String tagStr: tagStrArr) {
			if (tagStr.length() > 0) { 
				Tag tag = tagManager.resolve(tagStr);
				if (tag == null) {
					createTag(tagStr, tagManager);
				}
				tagList.add(tagStr);
			}
		}
		return tagList.toArray(new String[0]);
	}
    
    private void createTag(String tagStr, TagManager tagManager) {
        try {
			String tagId = tagStr.toLowerCase().trim();
			//createTag(tagID,title,description,autoSave)
			tagManager.createTag(tagId, tagStr, tagStr, true);
		} catch(Exception e) {
			log.error("Error occurred in ImportVideoMetadataFromExcel - createTag", e);
		}
	}
		
	private Node getBrcCustomFieldsNode(Resource resource) {
		Node brcCustomFieldsNode = null;	
		try {			
			Resource metadataRes = resource.getChild("jcr:content/metadata");
			if (metadataRes == null) {
				throw new NullPointerException("metadataNode is null");
			}
			Node metadataNode = metadataRes.adaptTo(Node.class);
			if (metadataNode == null) {
				throw new NullPointerException("metadataNode is null");
			}

			// Can't use metadata map here for fields under the folder 'brc_custom_fields'
			// because AEM doesn't create brc_custom_fields folder automatically
			// So create a folder 'brc_custom_fields' under metadata 	
			if (metadataNode.hasNode(BRC_CUSTOM_FIELDS)) {
				brcCustomFieldsNode = metadataNode.getNode(BRC_CUSTOM_FIELDS);
			} else {
				brcCustomFieldsNode = metadataNode.addNode(BRC_CUSTOM_FIELDS);
			} 
		} catch (Exception e) {
			log.error("Error occurred in ImportVideoMetadataFromExcel - getBrcCustomFieldsNode", e);
		}
		return brcCustomFieldsNode;
	}
}
