package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.ValueMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by ryan.mccullough on 2015-11-26.
 * Modified for TI by andy.doerr on 2017-05-08
 */
public class TableSawHeaderUse extends WCMUsePojo {
	@SuppressWarnings("unused")
	private static final Logger LOG = LoggerFactory.getLogger(TableSawUse.class);

    /* Dialog Properties */
    public static final String PROP_TITLE = "title";
    public static final String PROP_COLSPAN = "colspan";
    
    public static final long DEFAULT_COLSPAN = 1;

    private static final int[] priorityMap = new int[]{1,1,2,3,4,5,6,6,6};
    
    /* Property Values */
    private String title;
    private long colspan;
    private int priority = -1;

    @Override
    public void activate() {
        ValueMap properties = getProperties();
        colspan = properties.get(PROP_COLSPAN, DEFAULT_COLSPAN);
        title = properties.get(PROP_TITLE, getWcmMode().isDisabled() ? " ":"Enter Column Header");
	    if(StringUtils.isEmpty(title))
            title = "Enter Column Header";
        initPriority();
    }

    private void initPriority(){
        //Get priority from node name
        int colNum = TableSawUse.getColumnNumberFromName(getResource().getName());
        if( colNum > priorityMap.length) {
            colNum = priorityMap.length;
        }
        priority = priorityMap[colNum - 1];
    }

    public int getPriority(){
        return priority;
    }

    public String getTitle(){
        return title;
    }
    
    public long getColspan(){
        return colspan;
    }

    /*
        had to do some funky stuff for it to work as expected in edit mode.
        For edit mode, we use a "div" (and dont unwrap the including th element)
        For non-edit mode, we use "th" (and unwrap the including th element)
     */
    public String getElement() {	
        return getWcmMode().isEdit() ? "div":"th";
    }
}
