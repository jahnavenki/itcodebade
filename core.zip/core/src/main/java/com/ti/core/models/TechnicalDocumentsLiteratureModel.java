package com.ti.core.models;

public class TechnicalDocumentsLiteratureModel {

	private String literatureId;
	private String literatureNumber;
	private String litDescription;
	private String downloadLink;
	private String downloadFileExtension;
	private String sizeInKB;
	private String date;
	private String sortOrder;

	public String getLiteratureId() {
		return literatureId;
	}

	public void setLiteratureId(String literatureId) {
		this.literatureId = literatureId;
	}

	public String getLiteratreNumber() {
		return literatureNumber;
	}

	public void setLiteratreNumber(String literatreNumber) {
		this.literatureNumber = literatreNumber;
	}

	public String getLitDescription() {
		return litDescription;
	}

	public void setLitDescription(String litDescription) {
		this.litDescription = litDescription;
	}

	public String getDownloadLink() {
		return downloadLink;
	}

	public void setDownloadLink(String downloadLink) {
		this.downloadLink = downloadLink;
	}

	public String getDownloadFileExtension() {
		return downloadFileExtension;
	}

	public void setDownloadFileExtension(String downloadFileExtension) {
		this.downloadFileExtension = downloadFileExtension;
	}

	public String getSizeInKB() {
		return sizeInKB;
	}

	public void setSizeInKB(String sizeInKB) {
		this.sizeInKB = sizeInKB;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

}
