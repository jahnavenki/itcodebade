package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.xfa.ut.StringUtils;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationSelectionTool extends WCMUsePojo {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String appId;
	private String destination;
	private String domain;
	private String locale;

	public String getAppId() {
		return appId;
	}

	public String getDestination() {
		return destination;
	}

	public String getDomain() {
		return domain;
	}

	public String getLocale() {
		return locale;
	}

	@Override
	public void activate() {
		try {
			final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if(null == tabsService) return;
			final SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
			if(null == factoryConfigs) return;
			final Page currentPage = getCurrentPage();
			final ValueMap pageProperties = getPageProperties();
			final String pagePath = currentPage.getPath();
			final boolean isTechnology = pagePath.contains("/technologies/");

			// set application id
			appId = isTechnology ? "0" : (String) pageProperties.get("applicationId");
			if (null == appId || StringUtils.isEmpty(appId)) return;

			// set destination
			destination = isTechnology ? "Technology" : "MSE";

			// set domain
			domain = DomainComponent.getDomainFromConfig(factoryConfigs, pagePath);

			// set locale
			locale = tabsService.getPageLanguage(currentPage);


		} catch (Exception e) {
			log.error("Error setting app selection tool: ", e);
		}
	}
}
