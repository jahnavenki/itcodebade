package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;
import com.ti.core.util.URLHelper;

@Component(name = "LiteratureServletService",immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_RESOURCE_TYPES + "=ti/components/technicalDocumentListing", 
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_SELECTORS+"=literature",
		SLING_SERVLET_EXTENSIONS+"=json"})
public class TechnicalDocumentsGetLiteraturesServlet extends SlingSafeMethodsServlet {
  /** The log. */
  private static final Logger log = LoggerFactory.getLogger(TechnicalDocumentsGetLiteraturesServlet.class);

  private static final String PROPERTY_COUNT = "count";
  private static final String PROPERTY_SEARCH_TYPES = "searchTerm";
  private static final String PROPERTY_FAMILYID = "familyId";
  private static final String PROPERTY_APPLICATIONID = "applicationId";
  private static final String PROPERTY_DOC_TYPES = "doctypes";
  private static final String CONTENT_TYPE = "text/x-json;charset=UTF-8";

  private String count;
  private String familyId;
  private String applicationId;
  private String documentType;
  private String searchTerm;


  @Reference
  private transient WCMComponents wcmService;

  @Override
  protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
      throws ServletException, IOException {

	familyId = null;
	applicationId = null;
	documentType = null;
	searchTerm = null;
    documentType = request.getParameter(PROPERTY_DOC_TYPES);
    if (null != request.getParameter(PROPERTY_FAMILYID)) {
      familyId = request.getParameter(PROPERTY_FAMILYID);
    } else if (null != request.getParameter(PROPERTY_APPLICATIONID)) {
      applicationId = request.getParameter(PROPERTY_APPLICATIONID);
    }

    log.debug("family and application id: {} {} ", familyId, applicationId);

    String path = request.getRequestURI();
    String language = "en-us";
    if(path.contains("ja-jp")){
    	language = "ja-jp";
    }
    else if(path.contains("zh-cn")){
    	language = "zh-cn";
    }
    if (null != request.getParameter(PROPERTY_SEARCH_TYPES)) {

      searchTerm = request.getParameter(PROPERTY_SEARCH_TYPES);

      if (null != request.getParameter(PROPERTY_COUNT)) {
        count = request.getParameter(PROPERTY_COUNT);
      } else {
        count = "";
      }

      getLiteraturesBySearchTerm(request, response, language);
    } else if (null != request.getParameter(PROPERTY_COUNT)) {
      count = request.getParameter(PROPERTY_COUNT);

      getLiteraturesByCount(request, response, language);
    } else {

      getLiteraturesByDocumentType(request, response, language);
    }

  }

  /**
   * getLiteraturesByCount is called when search is performed based on the products and count
   *
   * @param response
   */
  private void getLiteraturesByCount(SlingHttpServletRequest request, SlingHttpServletResponse response, String language) {
    String technicalDocumentsListingResponse = null;
    try {

    	log.debug("search by count familyid and application id: {} {} ", familyId, applicationId);
      if (null != wcmService) {
        if (StringUtils.isNumeric(familyId)) {

          technicalDocumentsListingResponse = wcmService.getLiteraturesByCount(count,
              familyId, documentType, language, true);

        } else if (StringUtils.isNumeric(applicationId)) {
        	  technicalDocumentsListingResponse = wcmService.getLiteraturesByCount(count,
              applicationId, documentType, language, false);
        }

        response.setContentType(CONTENT_TYPE);
        response.getWriter().write(URLHelper.toScheme(technicalDocumentsListingResponse, URLHelper.getScheme(request)));
      }

    } catch (Exception e) {
      log.error("Exception in getLiteraturesByCount: ", e);
    }
  }

  /**
   * getLiteraturesBySearchTerm is called when search is performed using Document Title
   *
   * @param response
   */
  private void getLiteraturesBySearchTerm(SlingHttpServletRequest request, SlingHttpServletResponse response, String language) {
    String technicalDocumentsListingResponse = null;
    try {
      if (null != wcmService) {
        if (StringUtils.isNumeric(familyId)) {
          technicalDocumentsListingResponse = wcmService.getLiteraturesBySearchTerm(
              searchTerm, familyId, documentType, count, language, true);
        } else if (StringUtils.isNumeric(applicationId)) {
          technicalDocumentsListingResponse = wcmService.getLiteraturesBySearchTerm(
              searchTerm, applicationId, documentType, count, language, false);
        }
        response.getWriter().write(URLHelper.toScheme(technicalDocumentsListingResponse, URLHelper.getScheme(request)));
      }
    } catch (Exception e) {
      log.error("Exception in getLiteraturesBySearchTerm: ", e);
    }
  }

  /**
   * getLiteraturesByDocumentType is called when search is performed based on the products and count
   *
   * @param response
   */
  private void getLiteraturesByDocumentType(SlingHttpServletRequest request, SlingHttpServletResponse response, String language) {
    String technicalDocumentsListingResponse = null;
    try {
      if (null != wcmService) {
        if (StringUtils.isNumeric(familyId)) {
          technicalDocumentsListingResponse = wcmService
              .getLiteraturesByDocumentType(documentType, familyId, language, true);
        } else if (StringUtils.isNumeric(applicationId)) {
          technicalDocumentsListingResponse = wcmService
              .getLiteraturesByDocumentType(documentType, applicationId, language, false);
        }
        response.setContentType("text/x-json;charset=UTF-8");
        response.getWriter().write(URLHelper.toScheme(technicalDocumentsListingResponse, URLHelper.getScheme(request)));
      }
    } catch (Exception e) {
      log.error("Exception in getLiteraturesByDocumentType: ", e);
    }
  }
}
