package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.WCMComponents;
import com.ti.core.util.Constants;


@SuppressWarnings("serial")
@Component(service = Servlet.class, immediate=true, property = {
		SLING_SERVLET_RESOURCE_TYPES + "=ti/components/technicalDocumentInterface", 
		SLING_SERVLET_EXTENSIONS + "=json",
		SLING_SERVLET_METHODS + "=GET", 
		SLING_SERVLET_SELECTORS + "=family",
		SLING_SERVLET_PATHS + "=/bin/ti/productfamily"})
public class ProductFamilyServlet extends SlingSafeMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(ProductFamilyServlet.class);

	@Reference
	private transient WCMComponents wcmService;

	private String productFamilyResponse = "";

	private static final String FAMILY_ID = "familyId";

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		String familyId = request.getParameter(FAMILY_ID);
		log.debug("url for ProductFamilyServlet : {}", request.getRequestURI());
		String path = request.getRequestURI();
		String[] langList = StringUtils.split(Constants.LANG_REGION_CODES_ALL, "|");
		
		String language = "en-us";

		for (int i=0; i < langList.length; i++) {
			if (path.contains(langList[i])) {
				language = langList[i];
				break;
			}
		}

		log.debug("language for ProductFamilyServlet : {}", language);
		if (StringUtils.isNotEmpty(familyId)) {

			this.productFamilyResponse = null != wcmService ? wcmService.getProductFamily(familyId, language) : "";
			response.setContentType("text/html; charset=UTF-8");

			response.getWriter().write(StringEscapeUtils.unescapeHtml4(productFamilyResponse));
		}
	}

}