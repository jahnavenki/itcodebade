package com.ti.core.models;

public class TextLayoutLinks {
	private String literatureNumber;
	private String conciseDescription;
	private String fileExtension;
	private String byteSize;
	private Boolean valid;
	private String fileType;
	private String downloadUrl;	

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getLiteratureNumber() {
		return literatureNumber;
	}

	public void setLiteratureNumber(String literatureNumber) {
		this.literatureNumber = literatureNumber;
	}

	public String getConciseDescription() {
		return conciseDescription;
	}

	public void setConciseDescription(String conciseDescription) {
		this.conciseDescription = conciseDescription;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getByteSize() {
		return byteSize;
	}

	public void setByteSize(String byteSize) {
		this.byteSize = byteSize;
	}

	public Boolean getValid() {
		return valid;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}
	
	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}

}
