package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ProductFamilyDatasource WCMUsePojo.
 */
public class ProductFamilyDatasource extends WCMUsePojo {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Override
	@SuppressWarnings("unchecked")
	public void activate() throws Exception {

		final Map<String, String> languages = new LinkedHashMap<>();

		DataSource ds = new SimpleDataSource(new TransformIterator(languages.keySet().iterator(), new Transformer() {
			@Override
			public Object transform(final Object o) {
				String language = (String) o;
				ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());

				vm.put("value", language);
				vm.put("text", languages.get(language));
				log.debug(" language " + language);
				log.debug(" language text " + languages.get(language));
				return new ValueMapResource(getResource().getResourceResolver(), new ResourceMetadata(),
						"nt:unstructured", vm);
			}
		}));
		getRequest().setAttribute(DataSource.class.getName(), ds);
	}
}
