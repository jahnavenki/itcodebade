package com.ti.core.components.models;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.LanguageUtils;

@Model(
adaptables = { SlingHttpServletRequest.class, Resource.class },
resourceType = { Event.RESOURCE_TYPE },
defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class Event { 	
	public static final String RESOURCE_TYPE = "ti/components/event";

	private static final String DATE_STRING = "date";
	private static final String TIME_STRING = "time";
	private static final String DATE_RANGE = "daterange";
	private static final String TIME_RANGE = "timerange";
	private static final String YEARS = "years";
	private static final String MONTHS = "months";
	private static final String DAYS = "days";
	private static final String DE_DE = "de-de";
	private static final String ZH_CN = "zh-cn";
	private static final String DD_MMM_YYYY = "dd MMM YYYY";

	protected static final Logger log = LoggerFactory.getLogger(Event.class);

	@ScriptVariable
	private Page currentPage;
	
	@ScriptVariable
	private ResourceResolver resolver;

	@ScriptVariable
	private SlingHttpServletRequest request;

	@OSGiService
	ProductNavigationTabsOrdering productNavigationTabsOrdering;
   
	@ValueMapValue
	private String dateType;
	
    @ValueMapValue
	private String timeType;

	@ValueMapValue
	private String eventTitle;

	@ValueMapValue
	private String location;
	
	@ValueMapValue
	private String eventDescription;

	@ValueMapValue
	private String[] eventType;

	@ValueMapValue
	private String[] region;

	@ValueMapValue
	private String[] language;

	@ValueMapValue
    private String attendanceType;

	@ValueMapValue
	private String eventImgReference;

	@ValueMapValue
	private String ctaTitle;

	@ValueMapValue
	private String ctaUrl;

	private LanguageUtils langUtils;

	private Calendar date;

	private boolean isUpcoming;

	private Calendar startdate;

	private Calendar enddate;
	
	private String altText;

	private String formattedValue;
	
	private String eventStartDateFormat;

	private String eventEndDateFormat;

	private String startDateVal;

	private String endDateVal;
	
	private String eventStartTimeFormat;

	private String eventEndTimeFormat;

	private String startTimeVal;

	private String endTimeVal;

	private String lang;

	private String[] regionTagTitle;

    private String[] languageTagTitle;

    private String[] eventTagTitle;

	public String getEventTitle() {
		return eventTitle;
	}

	public String getLocation() {
		return location;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public String[] getEventType() {
		return eventType;
	}	

	public String getAltText() {
		return altText;
	}

	public String getEventImgReference() {
		return eventImgReference;
	}

	public String getCtaTitle() {
		return ctaTitle;
	}

	public String getCtaUrl() {
		return ctaUrl;
	}

		public String getFormattedValue() {
		return formattedValue;
	}

	public String getEventStartDateFormat() {
		return eventStartDateFormat;
	}
	
		public String getEventStartTimeFormat() {
		return eventStartTimeFormat;
	}

	public String getEventEndDateFormat() {
		return eventEndDateFormat;
	}
	
	public String getEventEndTimeFormat() {
		return eventEndTimeFormat;
	}

	public String getStartDateVal() {
		return startDateVal;
	}
	
	
	public String getStartTimeVal() {
		return startTimeVal;
	}


	public String getEndDateVal() {
		return endDateVal;
	}
	
	public String getEndTimeVal() {
		return endTimeVal;
	}

	public String getLang() {
		return lang;
	}

	public String[] getEventTagTitle() {
        return eventTagTitle;
    }

    public String[] getRegionTagTitle() {
        return regionTagTitle;
    }

    public String[] getLanguageTagTitle() {
        return languageTagTitle;
    }

    public void setAttendanceType(String attendanceType) {
        this.attendanceType = attendanceType;
    }
    public String getAttendanceType() {
        return attendanceType;
	}
	public boolean isUpcoming() {
        return isUpcoming;
    }

	@Inject
	public Event(@SlingObject @Named("slingHttpServletRequest") final SlingHttpServletRequest request,
		@ValueMapValue @Named("eventDate") Date eventDate, 
		@ValueMapValue @Named("eventStartDate") Date eventStartDate, 
		@ValueMapValue @Named("eventEndDate") Date eventEndDate,
        @ValueMapValue @Named("eventTime") String eventTime, 
        @ValueMapValue @Named("eventStartTime") String eventStartTime, 
        @ValueMapValue @Named("eventEndTime") String eventEndTime) {
			
		langUtils = new LanguageUtils(request);
         // Use the server's default time zone
         TimeZone eventTimeZone = TimeZone.getTimeZone("UTC");
		date = (eventDate != null) ? getCalendarFromDate(eventDate, eventTimeZone) : Calendar.getInstance(eventTimeZone);
		startdate = (eventStartDate != null) ? getCalendarFromDate(eventStartDate, eventTimeZone) : Calendar.getInstance(eventTimeZone);
		enddate = (eventEndDate != null) ? getCalendarFromDate(eventEndDate, eventTimeZone) : Calendar.getInstance(eventTimeZone);

		parseTimeAndSet(StringUtils.trimToEmpty(eventTime), date);
		parseTimeAndSet(StringUtils.trimToEmpty(eventStartTime), startdate);
		parseTimeAndSet(StringUtils.trimToEmpty(eventEndTime), enddate);
	}
	private Calendar getCalendarFromDate(Date date, TimeZone timeZone) {
		Calendar calendar = Calendar.getInstance(timeZone);
		calendar.setTime(date);
		return calendar;
	}
	@PostConstruct
	protected void init() {		
		try{
			if(StringUtils.isNotBlank(eventImgReference) && resolver != null 
			&& resolver.getResource(eventImgReference + "/jcr:content/metadata") != null) {
			Resource metadataRes = resolver.getResource(eventImgReference + "/jcr:content/metadata");
			if (metadataRes != null) {
				altText = metadataRes.getValueMap().get("jcr:title","");
			}
			}
			if(null == currentPage){
				lang = "en-us";
			}
			else{
				lang = productNavigationTabsOrdering.getPageLanguage(currentPage);
			}

			if(lang == null){
				lang = "en-us";
			}
			
			// if event is on a specific date, then format that date
			if (dateType != null && dateType.equals(DATE_STRING)) {
				setDateFormattedValue();
			} else if (dateType != null && dateType.equals(DATE_RANGE)) {			
			// if event is between date range, then format start and end date
				formatStartEndDates();
			}
			// if event is on a specific time, then format that time
			if (timeType != null && timeType.equals(TIME_STRING)) {
			setTimeFormattedValue();
			}
			else if (timeType != null && timeType.equals(TIME_RANGE)) {			
			// if event is between time range, then format start and end time
				formatStartEndTimes();
			}
			
			setTagTitles();
			calculateIsUpcoming();
		} catch(Exception ex) {
			log.error("Exception in Events", ex);
		}
	}
   private void setTagTitles() {
    eventTagTitle = getTagTitles(eventType);
    regionTagTitle = getTagTitles(region);
    languageTagTitle = getTagTitles(language);
}
private String[] getTagTitles(String[] tagIds) {
    if (tagIds != null && tagIds.length > 0) {
        List<String> tagTitles = new ArrayList<>();
        TagManager tagManager = resolver.adaptTo(TagManager.class);

        for (String tagId : tagIds) {
			Tag tag = tagManager.resolve(StringUtils.trimToEmpty(tagId));
            if (tag != null) {
                Locale locale = java.util.Locale.forLanguageTag(lang);
                if (!"en-us".equals(lang)) {
                    String localizedTitle = tag.getLocalizedTitle(locale);
                    if (StringUtils.isNotBlank(localizedTitle)) {
                        tagTitles.add(localizedTitle);
                    }
                } else {
                    tagTitles.add(tag.getTitle());
                }
            }
        }

        return tagTitles.toArray(new String[0]);
    }

    return new String[0];
}


	/**
	 * The method to format the event date 
	 */
	private void setDateFormattedValue() {	
		String dateFormat = "";
		dateFormat = langUtils.getI18nStr(DD_MMM_YYYY, currentPage, request);
		SimpleDateFormat formatter = null;
		if (Objects.nonNull(dateFormat)) {
			formatter = new SimpleDateFormat(dateFormat);
			if (Objects.nonNull(date)) {
				formattedValue = formatter.format(date.getTime());		
				if (lang.equals(DE_DE)) {
					formattedValue = updateDEMonth(formattedValue);
				}
			}
		}
	}
	/**
	 * The method to format the event time 
	 */
    private void setTimeFormattedValue() {
		if (StringUtils.isNotBlank(timeType)) {
			String timeFormat = langUtils.getI18nStr("hh:mm a", currentPage, request);
			SimpleDateFormat timeFormatter = null;
			if (Objects.nonNull(timeFormat)) {
				timeFormatter = new SimpleDateFormat(timeFormat);
				if (Objects.nonNull(date)) {
					timeFormatter.format(date.getTime());
				}
			}
		}
	}

	/**
	 * The method to format start and end dates of the event
	 */
	private void formatStartEndDates() {
	    eventStartDateFormat = langUtils.getI18nStr(DD_MMM_YYYY, currentPage, request);
		eventEndDateFormat = eventStartDateFormat;
	
		if (Objects.nonNull(eventStartDateFormat)) {
			startDateVal = formatDate(eventStartDateFormat, startdate);
		}
	
		if (Objects.nonNull(eventEndDateFormat)) {
			endDateVal = formatDate(eventEndDateFormat, enddate);
		}
	}
	
	private void formatStartEndTimes() {
    String diff = getTimeDiff(startdate, enddate);

    if (diff.equals("hours")) {
        eventStartTimeFormat = langUtils.getI18nStr("hh:mm a", currentPage, request);
    } else if (diff.equals("minutes")) {
        eventStartTimeFormat = langUtils.getI18nStr("hh:mm a", currentPage, request);
    }
    eventEndTimeFormat = langUtils.getI18nStr("hh:mm a", currentPage, request);
    if (Objects.nonNull(eventStartTimeFormat)) {
        startTimeVal = formatTime(eventStartTimeFormat, startdate);
    }
    if (Objects.nonNull(eventEndTimeFormat)) {
        endTimeVal = formatTime(eventEndTimeFormat, enddate);
    }
}

/**
 *
 * @param eventTimeFormat
 * @param calTime 
 * @return formatted time value
 */
private String formatTime(String eventTimeFormat, Calendar calTime) {
    SimpleDateFormat formatter = null;
    formatter = new SimpleDateFormat(eventTimeFormat);
    String timeVal = formatter.format(calTime.getTime());
    return timeVal;
}

/**
 * @param eventStartTime
 * @param eventEndTime
 */
   private String getTimeDiff(Calendar eventStartTime, Calendar eventEndTime) {
    if (Objects.nonNull(eventStartTime) && Objects.nonNull(eventEndTime)) {
        if (eventStartTime.get(Calendar.HOUR_OF_DAY) != eventEndTime.get(Calendar.HOUR_OF_DAY)) {
            return "hours";
        } else if (eventStartTime.get(Calendar.MINUTE) != eventEndTime.get(Calendar.MINUTE)) {
            return "minutes";
        }
    }
    return StringUtils.EMPTY;
   } 

	/**
	 * The method to format the start or end date
	 * @param eventDateFormat formatted start or end date
	 * @param calDate start or end date
	 * @return formatted date value
	 */
	private String formatDate(String eventDateFormat, Calendar calDate) {
		SimpleDateFormat formatter = null;
		formatter = new SimpleDateFormat(eventDateFormat);
		String dateVal = formatter.format(calDate.getTime());		
		if (lang.equals(DE_DE)) {
			dateVal = updateDEMonth(dateVal);
		}
		return dateVal;
	}

	/**
	 * @param eventStartDate
	 * @param eventEndDate
	 * @return one of the below: <<days>> <<months> <<years>> 
	 */
	private String getDateDiff(Calendar eventStartDate, Calendar eventEndDate) {
		if (Objects.nonNull(eventStartDate) && Objects.nonNull(eventEndDate)) {
			if (eventStartDate.get(Calendar.YEAR) != eventEndDate.get(Calendar.YEAR)) {
				return YEARS;
			} else if (eventStartDate.get(Calendar.YEAR) == eventEndDate.get(Calendar.YEAR)
					&& eventStartDate.get(Calendar.MONTH) != eventEndDate.get(Calendar.MONTH)) {
				return MONTHS;
			} else if (eventStartDate.get(Calendar.YEAR) == eventEndDate.get(Calendar.YEAR)
					&& eventStartDate.get(Calendar.MONTH) == eventEndDate.get(Calendar.MONTH) && eventStartDate.get(Calendar.DAY_OF_MONTH) != eventEndDate.get(Calendar.DAY_OF_MONTH)) {
				return DAYS;
			}

		}
		return StringUtils.EMPTY;
	}
	
	/**
	 * @param date
	 * @return
	 */
	private String updateDEMonth(String date) {	
		date = date.replace("May.", "MAI");
		date = date.replace("Oct.", "OKT.");
		date = date.replace("Dec.", "DEZ.");
		return date;		
	}
	
	private void parseTimeAndSet(String timeString, Calendar calendar) {
        if (StringUtils.isNotBlank(timeString)) {
            try {
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                Date parsedTime = timeFormat.parse(timeString);
                if (Objects.nonNull(parsedTime)) {
                    calendar.set(Calendar.HOUR_OF_DAY, parsedTime.getHours());
                    calendar.set(Calendar.MINUTE, parsedTime.getMinutes());
                }
            } catch (ParseException e) {
                 log.error("Error parsing time string '{}'. Expected format: 'hh:mm a'. Error message: {}", timeString, e.getMessage());
              
            }
        }
    }
	public String getTimeFormattedValue() {
        if (Objects.nonNull(date)) {
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
            return timeFormat.format(date.getTime());
        }
        return StringUtils.EMPTY;
    }
	private void calculateIsUpcoming() {
		Calendar currentCalendar = Calendar.getInstance();
		isUpcoming = (date != null && date.compareTo(currentCalendar) >= 0);
	}
	
	private static Resource findResourceByType(Resource resource, String resourceType) {
		final var valueMap = resource.getValueMap();
		final var type = valueMap.get("sling:resourceType");
		if (resourceType.equals(type)) return resource;
		for (final var child : resource.getChildren()) {
			final var descendant = findResourceByType(child, resourceType);
			if (null != descendant) return descendant;
		}
		return null;
	}


	public static Resource findResource(Resource root) {
		return findResourceByType(root, RESOURCE_TYPE);
	}
}