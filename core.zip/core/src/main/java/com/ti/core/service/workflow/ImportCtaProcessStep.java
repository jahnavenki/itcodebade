package com.ti.core.service.workflow;

import java.io.InputStream;
import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to import cta from excel.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Import CTA" })
public class ImportCtaProcessStep implements WorkflowProcess {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference
	private WCMComponents wcmService;
    @Reference
	private VideoConfigService videoService;


    private ResourceResolver resourceResolver;

    @Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
                throw new NullPointerException("resourceResolver");
            }
			Resource resource = resourceResolver.getResource(payload);
			if (null == resource) {
                return;
            }
            String videoPath = videoService.getVideoPath();
            if (videoPath == null || videoPath.length() <= 0) {
                log.debug("Video path not found in the config");
                return;
            }             
            InputStream stream = createInputStreamFromResource(resource);
            readExcelAndImportCta(stream,videoPath);
            resourceResolver.commit(); 
		} catch (Exception e) {
			log.error("Error occurred in ImportCtaProcessStep", e);
		  }
    }    

    private InputStream createInputStreamFromResource(Resource resource) {
        try {
            Asset asset = resource.adaptTo(Asset.class);
            InputStream stream = null;
            if(asset != null) {
                Rendition original = asset.getOriginal();
                if(original !=null) {
                    stream = original.getStream();
                }
            }
            return stream;
        } catch (Exception e) {
			log.error("Error occurred in ImportCtaProcessStep createInputStreamFromResource", e);
		  } 
        return null;   
    }

    private void readExcelAndImportCta(InputStream stream, String videoPath) {
		int rowNum = 0;
        try (XSSFWorkbook workbook = new XSSFWorkbook(stream)) {
            XSSFSheet sheet = workbook.getSheetAt(0);
            DataFormatter dataFormatter = new DataFormatter();
            Iterator<Row> rowIterator = sheet.iterator();
            // first row is header, so skip that row
            rowIterator.next();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
				rowNum = row.getRowNum();
                // import data from second row onwards
                // First cell is video id
                Cell cell0 = row.getCell(0);
                if (cell0 == null || StringUtils.isEmpty(cell0.toString())) {
                    log.error("Video id not found in the Excel for row - {}", row.getRowNum());
                    continue;
                }
                String videoId = dataFormatter.formatCellValue(cell0);
                importCTAFields(videoPath, videoId, row);
            }      
        } catch (Exception e) {
            log.error("Error occurred in ImportCtaProcessStep - readExcelAndImportCta - row - {}", rowNum, e);
        }            
    }

    private void importCTAFields(String videoPath, String videoId, Row row) {
        Resource videoResource =  AssetUtils.getDamResource(resourceResolver, videoPath, videoId);
        if (videoResource == null) {
            log.error("Video asset not found for id - {}", videoId);
            return;
        }
        ModifiableValueMap metaDataMap = AssetUtils.getModifiableMetadata(videoResource);
        if (metaDataMap == null) {
            log.error("MetaData not found for id - {}", videoId);
            return;
        }
        Cell cell3 = row.getCell(3);
        Cell cell4 = row.getCell(4);
        if (cell3 != null && StringUtils.isNotEmpty(cell3.getStringCellValue())
            && cell4 != null && StringUtils.isNotEmpty(cell4.getStringCellValue())) {
            String ctaLink = cell3.getStringCellValue();
            String ctaText = cell4.getStringCellValue();
            setCtaFields(metaDataMap, ctaText, ctaLink);
        }
    }

    private void setCtaFields(ModifiableValueMap metaDataMap, String ctaText, String ctaLink) {
        for (int i=1; i<=4; i++) {
            // check if there are existing CTAs
            String ctaTextExisting = metaDataMap.get("dam:cta"+i, "");
            // When blank spot found, populate that
            if (StringUtils.isBlank(ctaTextExisting)) {
                metaDataMap.put("dam:cta" + i, ctaText);
                metaDataMap.put("dam:url" + i, ctaLink);
                break;
            }
        }
    }
}
