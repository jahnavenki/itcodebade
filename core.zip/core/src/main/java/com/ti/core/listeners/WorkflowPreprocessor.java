package com.ti.core.listeners;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Session;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Preprocessor;
import com.day.cq.replication.ReplicationAction;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import com.ti.core.service.config.VideoConfigService;

@Component(immediate = true)
public class WorkflowPreprocessor implements Preprocessor {
    private static final Logger log = LoggerFactory.getLogger(WorkflowPreprocessor.class);

    @Reference
    private ResourceResolverFactory resourceResolverFactory;    
    @Reference
	private SlingRepository repository;
	@Reference
	private WorkflowService workflowService;
	@Reference
	private VideoConfigService videoService;

	private Session session;

	@Activate
	protected void activate(ComponentContext componentContext) {
		try {
			session = repository.loginService( "writeService", null );
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	@Deactivate
	protected void deactivate() {
		if (null != session) {
			session.logout();
			session = null;
		}
	}

	@Override
	public void preprocess(final ReplicationAction replicationAction,
							final ReplicationOptions replicationOptions) throws ReplicationException {
	
		String videoPath = videoService.getVideoPath();
		if (videoPath == null || videoPath.length() <= 0) {
			log.debug("Video path not found in the config");
			return;
		}
		final String path = replicationAction.getPath();

		if (replicationAction.getPath().contains("/subassets")) {
			log.info("Video publish workflow is not triggered for this path");
	    } else if (replicationAction.getPath().contains(videoPath) && ReplicationActionType.ACTIVATE.equals(replicationAction.getType())) {
			startPublishWorkflow(path);	            
	    } else if(replicationAction.getPath().contains(videoPath) && ReplicationActionType.DEACTIVATE.equals(replicationAction.getType())) {
			startUnpublishWorkflow(path);	
		}
	}	

	public void startPublishWorkflow(String path) {
		ResourceResolver resolver = null;
		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			resolver = resourceResolverFactory.getServiceResourceResolver(param);
			
			// Get the workflow session from the resource resolver
			final var workflowSession = workflowService.getWorkflowSession(session);

			// Workflow model path - This is the already created workflow
			final String model = "/var/workflow/models/ti-video-publish-workflow";

			// Get the workflow model object
			final WorkflowModel workflowModel = workflowSession.getModel(model);

			// Create a workflow Data (or Payload) object pointing to a resource via JCR
			final WorkflowData workflowData = workflowSession.newWorkflowData("JCR_PATH", path);
			
			// Start the workflow!
			workflowSession.startWorkflow(workflowModel, workflowData);

			log.info("Workflow: {} started", model);

		} catch (LoginException e) {
			log.error("Login Exception {}",e.getMessage());
		} catch (WorkflowException e) {
			log.error("WorkflowException {}",e.getMessage());
		} finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
			}
		}
	}

	public void startUnpublishWorkflow(String path) {
		ResourceResolver resolver = null;
	    try {
	        Map<String, Object> param = new HashMap<>();
	        param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
	        resolver = resourceResolverFactory.getServiceResourceResolver(param);
	                
	        // Get the workflow session from the resource resolver
	        final var workflowSession = workflowService.getWorkflowSession(session);

	        // Workflow model path - This is the already created workflow
	        final String model = "/var/workflow/models/ti-video-unpublish-workflow";

	        // Get the workflow model object
	        final WorkflowModel workflowModel = workflowSession.getModel(model);

	        // Create a workflow Data (or Payload) object pointing to a resource via JCR
	        final WorkflowData workflowData = workflowSession.newWorkflowData("JCR_PATH", path);
	                
	        // Start the workflow!
	        workflowSession.startWorkflow(workflowModel, workflowData);

	        log.info("Workflow: {} started", model);

	    } catch (LoginException e) {
	        log.error("Login Exception {}",e.getMessage());
	    } catch (WorkflowException e) {
	        log.error("WorkflowException {}",e.getMessage());
		} finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
			}
		}
	}

}