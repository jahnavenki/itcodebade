package com.ti.core.service;

public interface SeoUrlTagging {

  String getDomainName();
  String getContentPath();
  String getSelectorLabel();
  Boolean getCheckExistingPage();
  int getOrder();
}
