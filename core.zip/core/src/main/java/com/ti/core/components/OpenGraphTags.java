package com.ti.core.components;
import com.adobe.cq.sightly.WCMUsePojo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.foundation.Image;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

public class OpenGraphTags extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String fileReference;
	@Override
	public void activate() throws Exception {
        try {
			final Page currentPage = getCurrentPage();
			final String pagePath = currentPage.getPath();
			final ResourceResolver resourceResolver = getResourceResolver();
			Resource ImageRes = resourceResolver.getResource(pagePath + "/jcr:content/image");
			if(ImageRes != null){
				Image image = new Image(ImageRes);
				fileReference = image.getFileReference();
			}
		  } catch (Exception e) {
			log.error("Exception : ", e);
		 }
	}	
	public String getFileReference(){
		return fileReference;
	}
}