package com.ti.core.service.workflow;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Wait",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Wait" })
public class WaitProcessStep implements WorkflowProcess {
	private static final long DEFAULT_WAIT_TIME = 5000;
	private static final String PROCESS_ARGS = "PROCESS_ARGS";

	private static class WaitProcessStepArgs {
		private long time;
	}

	private WaitProcessStepArgs parseArgs(String argsStr) {
		final var args = new WaitProcessStepArgs();
		args.time = DEFAULT_WAIT_TIME;
		final var map =
			Arrays.stream(
				StringUtils.split(argsStr, ",")
			)
			.map(String::trim)
			.map(s -> s.split("=", 2))
			.filter(s -> s.length > 1)
			.collect(Collectors.toMap(s -> s[0], s -> s[1]));
		if (map.containsKey("time")) {
			args.time = Long.parseLong(map.get("time"));
		}
		return args;
	}

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap arguments) throws WorkflowException {
		final var args = parseArgs(arguments.get(PROCESS_ARGS, ""));
		try {
			Thread.sleep( args.time );
		} catch(InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}
}
