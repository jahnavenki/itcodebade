package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Component(service = Servlet.class, immediate = true, property = {
		SLING_SERVLET_RESOURCE_TYPES + "=sling/servlet/default", SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_SELECTORS + "=ti", SLING_SERVLET_EXTENSIONS + "=json" })
@Designate(ocd = TiCustomJson.Config.class)
public class TiCustomJson extends SlingSafeMethodsServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger log = LoggerFactory.getLogger(TiCustomJson.class);

	private String[] excludedProperties;

	private String[] jsonOrder;

	private String resType;

	@ObjectClassDefinition(name = "TiCustomJson Configuration Properties", description = "TiCustomJson Configuration Properties")
	public @interface Config {

		@AttributeDefinition(name = "excludedProperties", description = "Excluded Properties")
		String[] excludedProperties();

		@AttributeDefinition(name = "jsonOrder", description = "JSON Structure Order")
		String[] jsonOrder();

		@AttributeDefinition(name = "resourceType", description = "Page Resource Type")
		String resourceType();

	}

	private String resourcePath;

	@Override
	protected void doGet(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
			throws ServletException, IOException {
		log.debug("Inside Get method");
		resp.setContentType("application/json");
		this.resourcePath = req.getResource().getPath();
		JsonObject jsonObject = formPageJSON(req.getResource());
		resp.getWriter().println(jsonObject);
	}

	@Activate
	protected void activate(Config config) {
		this.excludedProperties = config.excludedProperties();
		this.jsonOrder = config.jsonOrder();
		this.resType = config.resourceType();
	}

	private JsonObject formPageJSON(Resource resource) {
		JsonObject jsonObject = new JsonObject();
		Resource jcrRes = resource.getChild(JcrConstants.JCR_CONTENT);
		if (jcrRes != null) {
			ValueMap map = jcrRes.adaptTo(ValueMap.class);
			Map<String, Object> valueMap = new HashMap<>();
			if (map != null && !map.isEmpty()) {
				filterMap(map, valueMap);
				jsonObject.add(jcrRes.getName(), convertMapToJsonElement(valueMap));
			}
			addRecoursivly(jcrRes, jsonObject);
			if (map != null && StringUtils.equalsIgnoreCase(resType, map.get("sling:resourceType", String.class))) {
				jsonObject = rearrangeJson(jsonObject, jcrRes, valueMap);
			}
		}
		return jsonObject;
	}

	private void addRecoursivly(Resource resource, JsonObject object) {
		Iterator<Resource> iterator = resource.listChildren();
		while (iterator.hasNext()) {
			Resource res = iterator.next();
			ValueMap map = res.adaptTo(ValueMap.class);
			if (map != null && !map.isEmpty() && !(isFileNode(res))) {
				Map<String, Object> valueMap = new HashMap<>();
				filterMap(map, valueMap);
				String path = StringUtils.substring(resource.getPath(),
						StringUtils.substringBefore(resource.getPath(), "jcr:content").length());
				List<String> keys = new ArrayList<>();
				if (path.contains("/")) {
					keys.addAll(Arrays.asList(path.split("/")));
				} else {
					keys.add(path);
				}
				findJsonKey(object, keys, res.getName(), convertMapToJsonElement(valueMap));
			}
			addRecoursivly(res, object);
		}
	}

	private boolean isFileNode(Resource resource) {
		Resource jcrResource = resource;
		do {
			if (StringUtils.equalsIgnoreCase(jcrResource.getValueMap().get(JcrConstants.JCR_PRIMARYTYPE, String.class),
					JcrConstants.NT_FILE)) {
				return true;
			}
			jcrResource = jcrResource.getParent();
		} while (jcrResource != null && jcrResource.getParent() != null
				&& StringUtils.contains(jcrResource.getPath(), this.resourcePath));
		return false;
	}

	private JsonElement convertMapToJsonElement(Map<String, Object> valueMap) {
		Gson gson = new Gson();
		return new JsonParser().parse(gson.toJson(valueMap));
	}

	private void filterMap(ValueMap map, Map<String, Object> filterMap) {
		for (Entry<String, Object> e : map.entrySet()) {
			if (!getExcludedPropertiesList().contains(e.getKey())) {
				if (StringUtils.equalsIgnoreCase(e.getKey(), "cq:lastModified")) {
					GregorianCalendar gcal = (GregorianCalendar) e.getValue();
					filterMap.put(e.getKey(), modifyDate(gcal));
				} else {
					filterMap.put(e.getKey(), e.getValue());
				}
			}
		}
	}

	private String modifyDate(GregorianCalendar gcal) {
		String month[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		return gcal.get(Calendar.YEAR) + " " + month[gcal.get(Calendar.MONTH)] + " " + gcal.get(Calendar.DATE) + " "
				+ gcal.get(Calendar.HOUR) + ":" + gcal.get(Calendar.MINUTE) + ":" + gcal.get(Calendar.SECOND) + " "
				+ gcal.getTimeZone().getDisplayName();
	}

	private void findJsonKey(JsonObject jsonObject, List<String> keys, String name, JsonElement value) {
		for (String key : keys) {
			jsonObject = jsonObject.getAsJsonObject(key);
		}
		jsonObject.add(name, value);
	}

	private List<String> getExcludedPropertiesList() {
		if (this.excludedProperties != null && this.excludedProperties.length > 0) {
			return Arrays.asList(this.excludedProperties);
		}
		return new ArrayList<>();
	}

	private JsonObject rearrangeJson(JsonObject jsonObject, Resource jcrRes, Map<String, Object> valueMap) {
		JsonObject modifiedJson = new JsonObject();
		modifiedJson.add(jcrRes.getName(), convertMapToJsonElement(valueMap));
		JsonObject jcrJson = jsonObject.get(JcrConstants.JCR_CONTENT).getAsJsonObject();
		for (String jsonKey : Arrays.asList(this.jsonOrder)) {
			if (jcrJson.has(jsonKey)) {
				modifiedJson.get(JcrConstants.JCR_CONTENT).getAsJsonObject().add(jsonKey, jcrJson.get(jsonKey));
			}
		}
		return modifiedJson;
	}
}