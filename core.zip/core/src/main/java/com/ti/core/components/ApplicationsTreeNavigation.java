package com.ti.core.components;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.models.ProductTreeModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.URLHelper;

/**
 * ApplicationsTreeNavigation WCMUsePojo.
 */
public class ApplicationsTreeNavigation extends WCMUsePojo {

	private boolean applicationSet = false;
	private String componentName;
	private int iApplicationId;
	private String sectorId = "";
	private String marketId = "";

	/** The log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	/** The Constant FAMILYID_PROP. */
	private static final String APPLICATIONID_PROP = "applicationId";

	/** The Constant PRODUCT_TREE. */
	private static final String JSON_NODE_APPLICATION_TREE = "AppHierarchyList";

	/** The Constant FAMILY_NAME. */
	private static final String JSON_NODE_SECTION_NAME = "sectionName";

	/** The Constant PRODUCT_URL. */
	private static final String JSON_NODE_APPLICATION_URL = "appUrl";

	/** The Constant PRODUCT_URL. */
	private static final String JSON_NODE_CHILD_ID = "childId";

	/** The Constant PRODUCT_URL. */
	private static final String JSON_NODE_NAV_AVAIL = "navAvailability";

	/** The Constant PRODUCT_URL. */
	private static final String JSON_NODE_NAV_LINK = "navLink";

	/** The Constant LEVEL. */
	private static final String JSON_NODE_LEVEL = "typeLevel";

	private static final String SECTOR_PROP = "sectorId";

	private static final String MARKET_PROP = "marketId";

	private static final String JSON_NODE_PARENT_APP_ID = "parentAppId";

	private static final String CATEGORY_PROP = "categoryId";

	/** The product tree model. */
	LinkedList<ProductTreeModel> applicationTreeList = null;

	/*
	 * (non-Javadoc)
	 *
	 * @see com.adobe.cq.sightly.WCMUsePojo#activate()
	 */
	@Override
	public void activate() {
		Resource resource = this.getResource();
		setComponentName(resource.getName());
		applicationTree();
	}

	public boolean getIsApplicationSet() {
		return this.applicationSet;
	}

	/**
	 * Application tree.
	 */
	private void applicationTree() {
		try {
			WCMComponents wcmService;
			JSONObject jsonObject;
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);
			String language = null;
			if (tabsService != null) {
				language = tabsService.getPageLanguage(getCurrentPage());
			}
			ValueMap prop = getCurrentPage().getProperties();
			wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (wcmService != null && prop != null && checkFamilyId(prop) && null != tabsService) {
				this.applicationSet = true;
				jsonObject = wcmService.getAllApplicationService(getRequest(), iApplicationId, language);
			} else {
				log.error("Could not initialize wcmService (null)");
				return;
			}

			if (jsonObject == null) {
				log.error("Product service returned null");
				return;
			}

			this.applicationTreeList = new LinkedList<>();

			JSONArray jsonarr = jsonObject.getJSONArray(JSON_NODE_APPLICATION_TREE);
			processApplicationTree(0, jsonarr, this.applicationTreeList);

		} catch (Exception e) {
			log.error("Exception:", e);
		}
	}

	private boolean checkFamilyId(ValueMap prop) {
		if (prop.get(APPLICATIONID_PROP, String.class) != null) {
			iApplicationId = Integer.parseInt(prop.get(APPLICATIONID_PROP, String.class));
			if (prop.get(MARKET_PROP) != null) {
				this.marketId = (String) prop.get(MARKET_PROP);
			}
			if (prop.get(SECTOR_PROP) != null) {
				this.sectorId = (String) prop.get(SECTOR_PROP);
			}
			return true;
		} else {
			return false;
		}
	}

	public String getMarketId() {
		return marketId;
	}

	public String getSectorId() {
		return this.sectorId;
	}

	private int processApplicationTree(int index, JSONArray jsonarr, List<ProductTreeModel> productTreeList) {

		if (jsonarr.length() <= index)
			return index;

		JSONObject currentNode;
		ProductTreeModel model = null;
		int currentNodeLevel = -1, startLevel = -1;
		try {

			// Get the current node
			currentNode = jsonarr.getJSONObject(index);

			// Set the start level to the current node level
			startLevel = currentNodeLevel = currentNode.getInt(JSON_NODE_LEVEL);

			// Repeat while we are at the same or deeper node level
			// exit this function if we are now shallower
			while (currentNodeLevel >= startLevel) {
				// If the current node is deeper that the start level dive
				// deeper
				if (currentNodeLevel > startLevel && model != null) {

					// Process deeper and get the new index
					index = processApplicationTree(index, jsonarr, model.getChildren());
				} else {
					// otherwise this node is at the current level so lets add
					// it to our list
					model = this.createModel(currentNode, getCurrentPage());
					productTreeList.add(model);
				}

				// Get the next node and its level if next node exists
				if (index + 1 < jsonarr.length()) {
					currentNode = jsonarr.getJSONObject(++index);
					currentNodeLevel = currentNode.getInt(JSON_NODE_LEVEL);
				} else {
					// otherwise exit
					break;
				}
			}

		} catch (JSONException e) {
			log.error("Error processeing json product tree", e);
		}

		if (currentNodeLevel > 0 && currentNodeLevel < startLevel) {
			// back up a level so above level can process this node
			return --index;
		} else
			return index;

	}

	public ProductTreeModel createModel(JSONObject currentNode, Page currentPage) throws JSONException {
		ProductTreeModel retval = new ProductTreeModel();

		retval.setFamilyName(currentNode.getString(JSON_NODE_SECTION_NAME));
		retval.setProductNodeUrl(URLHelper.toScheme(currentNode.getString(JSON_NODE_APPLICATION_URL),
				URLHelper.getScheme(getRequest())));
		retval.setTreelevel(currentNode.getInt(JSON_NODE_LEVEL));
		retval.setChildId(currentNode.getString(JSON_NODE_CHILD_ID));
		retval.setNavAvailability(currentNode.getString(JSON_NODE_NAV_AVAIL));
		retval.setNavLink(currentNode.getString(JSON_NODE_NAV_LINK));
		int id = currentNode.has(JSON_NODE_CHILD_ID) ? currentNode.getInt(JSON_NODE_CHILD_ID) : 0;
		ValueMap map = currentPage.getProperties();
		String currentPageId = StringUtils.EMPTY;
		if (!StringUtils.equalsIgnoreCase(StringUtils.EMPTY, map.get(CATEGORY_PROP, StringUtils.EMPTY))) {
			currentPageId = map.get(CATEGORY_PROP, StringUtils.EMPTY);
		} else if (!StringUtils.equalsIgnoreCase(StringUtils.EMPTY, map.get(SECTOR_PROP, StringUtils.EMPTY))) {
			currentPageId = map.get(SECTOR_PROP, StringUtils.EMPTY);
		} else if (!StringUtils.equalsIgnoreCase(StringUtils.EMPTY, map.get(MARKET_PROP, StringUtils.EMPTY))) {
			currentPageId = map.get(MARKET_PROP, StringUtils.EMPTY);
		}

		retval.setSelected(StringUtils.equalsIgnoreCase(StringUtils.EMPTY + id, currentPageId));
		if (StringUtils.isNotEmpty(currentNode.getString(JSON_NODE_PARENT_APP_ID))
				&& !"null".equalsIgnoreCase(currentNode.getString(JSON_NODE_PARENT_APP_ID))) {
			retval.setParentAppId(currentNode.getString(JSON_NODE_PARENT_APP_ID));
		}
		return retval;
	}

	public List<ProductTreeModel> getApplicationTree() {
		return this.applicationTreeList;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

}
