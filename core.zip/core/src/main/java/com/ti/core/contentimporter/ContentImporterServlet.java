package com.ti.core.contentimporter;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.commons.JcrUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.ti.core.models.MigrationContentModel;

/**
 * This class is responsible for creating the pages based on the csv file that's
 * uploaded via content importer tool present under Tools->Importers
 * 
 * @author harini.kandadai
 *
 */


@Component(service = Servlet.class,  configurationPolicy = ConfigurationPolicy.REQUIRE, property = {
		SLING_SERVLET_PATHS + "=/bin/timigration", 
		SLING_SERVLET_METHODS + "=POST" })

public class ContentImporterServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(ContentImporterServlet.class);

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		LOG.debug("in do post method od ContentImporterServlet**********");
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		Session session = null;
		ResourceResolver resourceResolver = null;
		try {
			if (isMultipart) {
				Map params = request.getRequestParameterMap();
				resourceResolver = request.getResourceResolver();
				PageManager pm = (PageManager) resourceResolver.adaptTo(PageManager.class);
				session = (Session) resourceResolver.adaptTo(Session.class);
				if (pm.getPage("/content/texas-instruments") == null) {
					pm.create("/content", "texas-instruments", null, "Texas Instruments");
				}
				for (Iterator iterator = params.entrySet().iterator(); iterator.hasNext();) {
					java.util.Map.Entry pairs = (java.util.Map.Entry) iterator.next();
					RequestParameter pArr[] = (RequestParameter[]) pairs.getValue();
					RequestParameter param = pArr[0];
					InputStream stream = param.getInputStream();
					BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
					CellProcessor processors[] = { new Optional(), new Optional(), new Optional(), new Optional(),
							new Optional(), new Optional(), new Optional(), new Optional(), new Optional(),
							new Optional(), new Optional() };
					LOG.debug("instantiated cell processor");
					ICsvBeanReader beanReader = new CsvBeanReader(br, CsvPreference.STANDARD_PREFERENCE);
					String[] header = beanReader.getHeader(false);
					MigrationContentModel contentBean = null;
					while ((contentBean = (MigrationContentModel) beanReader.read(MigrationContentModel.class, header,
							processors)) != null) {
						String parentPath = contentBean.getPath().trim().substring(0,
								contentBean.getPath().trim().lastIndexOf("/"));
						LOG.debug("parent path is" + parentPath);
						if (pm.getPage(parentPath) == null) {
							LOG.debug("inside parent path");
							String parentPage = parentPath.substring(0, parentPath.lastIndexOf("/"));
							String title = parentPath.substring(parentPath.lastIndexOf("/") + 1);
							pm.create(parentPage, title, contentBean.getTargetTemplate().trim(), title);
						}
						if (pm.getPage(contentBean.getPath().trim()) == null) {
							Page page = pm.create(parentPath,
									contentBean.getPath().substring(contentBean.getPath().lastIndexOf("/") + 1).trim(),
									contentBean.getTargetTemplate().trim(), contentBean.getPageTitle().trim());
							LOG.debug("page after page creation is" + page);
							Node node = JcrUtils.getNodeIfExists(
									(new StringBuilder()).append(page.getPath()).append("/jcr:content").toString(),
									session);
							LOG.debug((new StringBuilder()).append("node is").append(node).toString());
							node.setProperty("cq:designPath", "/apps/settings/wcm/designs/ti");
							LOG.debug("setting path");
							if (StringUtils.isNotEmpty(contentBean.getSourceUrl())
									&& !"NIL".equalsIgnoreCase(contentBean.getSourceUrl())) {
								node.setProperty("sourceUrl", contentBean.getSourceUrl());
							}

							if (StringUtils.isNotEmpty(contentBean.getMigrationStatus())) {
								node.setProperty("migrationStatus", contentBean.getMigrationStatus());
							} else {
								node.setProperty("migrationStatus", "seeded");
							}
							if (StringUtils.isNotEmpty(contentBean.getTargetTemplate())
									&& !"NIL".equalsIgnoreCase(contentBean.getTargetTemplate())) {
								node.setProperty("targetTemplate", contentBean.getTargetTemplate());
							}
							if (StringUtils.isNotEmpty(contentBean.getWebPM())
									&& !"NIL".equalsIgnoreCase(contentBean.getWebPM())) {
								node.setProperty("webPM", contentBean.getWebPM());
							}
							if (StringUtils.isNotEmpty(contentBean.getDmPM())
									&& !"NIL".equalsIgnoreCase(contentBean.getDmPM())) {
								node.setProperty("DMPM", contentBean.getDmPM());
							}
							if (StringUtils.isNotEmpty(contentBean.getHideInNav())
									&& "true".equalsIgnoreCase(contentBean.getHideInNav())) {
								node.setProperty("hideInNav", "true");
							}
							if (StringUtils.isNotEmpty(contentBean.getPageTitle())
									&& !"NIL".equalsIgnoreCase(contentBean.getPageTitle())) {
								node.setProperty("jcr:title",
										new String(contentBean.getPageTitle().getBytes("ISO-8859-1")));
							}
							if (StringUtils.isNotEmpty(contentBean.getDescription())
									&& !"NIL".equalsIgnoreCase(contentBean.getDescription())) {
								node.setProperty("jcr:description",
										new String(contentBean.getDescription().getBytes("ISO-8859-1")));
							}
							if (StringUtils.isNotEmpty(contentBean.getDestinationUrl())
									&& !"NIL".equalsIgnoreCase(contentBean.getDestinationUrl())) {
								node.setProperty("destinationUrl", contentBean.getDestinationUrl());
							}
							LOG.debug("setting final path ");
						}
					}
				}

			}
			resourceResolver.commit();
			LOG.debug((new StringBuilder()).append("request.getRequestURL().toString()")
					.append(request.getHeader("referer")).toString());
			response.sendRedirect(
					(new StringBuilder()).append(request.getHeader("referer")).append("?r=success").toString());
		} catch (Exception e) {
			LOG.error((new StringBuilder()).append("exception is").append(e).toString());
		}
	}

	@Override
	protected void doGet(SlingHttpServletRequest slinghttpservletrequest,
			SlingHttpServletResponse slinghttpservletresponse) throws ServletException, IOException {

		throw new UnsupportedOperationException();
	}

}
