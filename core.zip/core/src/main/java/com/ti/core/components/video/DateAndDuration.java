package com.ti.core.components.video;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.LanguageUtils;

public class DateAndDuration extends WCMUsePojo {
    
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    private static final String DD_MMM_YYYY = "dd MMM YYYY";
    private static final String DE_DE = "de-de";
    private static final String PUBLICATION_DATE = "dam:published";
    private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);
    
    private String formattedDate;
    private String duration;
    
    public String getFormattedDate() {
		return formattedDate;
	}
    public String duration() {
		return duration;
	}
   
    @Override
    public void activate() {
        try {	
			VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
			if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
				log.debug("Video config null or Path not found");
				return;
			}
            final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
            final String videoId = matcher.find() ? matcher.group(1) : null;
            Resource resource = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
            if (resource == null) {   
                log.error("Resource not found for video id: {} ", videoId);
				return;
			}
            final var map = AssetUtils.getMetadata(resource);
            if (null == map)  {   
                log.error("Metadata not found for video id: {} ", videoId);
				return;
			}
            duration = map.get("brc_duration", String.class); 
            if (map.containsKey(PUBLICATION_DATE)) {
                Date pubDate = map.get(PUBLICATION_DATE, Date.class); 
                if (pubDate != null) {
                    setDateFormattedValue(pubDate);
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    private void setDateFormattedValue(Date theDate) {	
        LanguageUtils langUtils = new LanguageUtils(this.getRequest());
        String dateFormat = langUtils.getI18nStr(DD_MMM_YYYY, this.getCurrentPage(), this.getRequest());
        if (StringUtils.isNotEmpty(dateFormat)) {
            SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
            formattedDate = formatter.format(theDate.getTime());

            // Formatting for German
            ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);
            String lang = "en-us";
            if (null != tabsService) {
                lang = tabsService.getPageLanguage(getCurrentPage());
            }		
            if (lang.equals(DE_DE)) {
                formattedDate = updateDEMonth(formattedDate);
            }
            formattedDate = formattedDate.toUpperCase();
        }
    }
    /**
	 * 
	 * @param date
	 * 
	 * 	The Method will take date and return month name in DE
	 * @return
	 */
    private String updateDEMonth(String date) {	
        date = date.replace("May.", "MAI");
        date = date.replace("Oct.", "OKT.");
        date = date.replace("Dec.", "DEZ.");
        date = date.replace("Mar.", "MÄR.");
        return date;		
    }
}
