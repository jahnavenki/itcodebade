package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DesignDevelopmentPageHeading extends WCMUsePojo {

    private static final String FEATURE_OPTIONS = "featureOptions";
    private static final String IMAGE_PATH = "fileReference";
    protected static final Logger log = LoggerFactory.getLogger(DesignDevelopmentPageHeading.class);

    private String imageAltText;

    public String getImageAltText() {
        return imageAltText;
    }

    @Override
    public void activate() throws Exception {
        try {
            if ("imageOption".equals(getProperties().get(FEATURE_OPTIONS, ""))) {
                setImageAltText();
            }
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }
    }

    private void setImageAltText() {
        // Get title from DAM property and set as alt text for image
        Resource resource = getResourceResolver().getResource(getProperties().get(IMAGE_PATH, ""));
        if (resource != null) {
            Asset asset = resource.adaptTo(Asset.class);
            if (asset != null) {
                this.imageAltText = asset.getMetadataValue("dc:title");
            }
        }
    }
}
