package com.ti.core.components.video;

import com.ti.core.models.AppHierarchyNode;
import com.ti.core.models.Link;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import acscommons.com.google.common.collect.Comparators;

/**
 * BrowseVideoCategories return listing of video categories
 *
 */
public class BrowseVideoCategories extends WCMUsePojo {

	protected static final Logger log = LoggerFactory.getLogger(BrowseVideoCategories.class);

	// WS requires application ID, but component does not.
	private static final int APPLICATION_ID_INDUSTRIAL = 120;

	private List<String> siloLinks;
	private List<Link> appLinks=new ArrayList<>();
	private List<String> enSiloLinks;

	public List<Link> getAppLinks() {
		return appLinks;
	}
	
	public List<String> getSiloLinks() {
		return siloLinks;
	}

	public List<String> getEnSiloLinks() {
		return enSiloLinks;
	}

	@Override
	public void activate() {
		try {
			WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);

			if (wcmService == null) {
				log.debug("wcmService is null");
				return;
			}
			if (tabsService == null) {
				log.debug("tabsService is null");
				return;
			}
			
			String language = tabsService.getPageLanguage(getCurrentPage());
			if (StringUtils.isEmpty(language)) {
				log.debug("language is empty");
				return;				
			}

			initCategories(wcmService, language); 

		} catch (Exception e) {
			log.error("Error in BrowseVideoCategories.activate()", e);
		}
	}

	/**
	 * @param wcmService
	 * @param language
	 * @throws JSONException
	 */
	private void initCategories(WCMComponents wcmService, String language) throws JSONException {		
		try {
			JSONArray siloJson = new JSONObject(wcmService.getSilo(language)).getJSONArray("content");
			final var jsonObject = wcmService.getAllApplicationService(getRequest(), APPLICATION_ID_INDUSTRIAL, language);
			if (null == jsonObject){
				 return;
			}
			final var appHierarchyList = new ArrayList<AppHierarchyNode>();
			final var jsonAppHierarchyList = jsonObject.getJSONArray( "AppHierarchyList" );
	
			final List<JSONObject> silos = new ArrayList<>(siloJson.length());
			for (int k = 0; k < siloJson.length(); k++) {
				silos.add(siloJson.getJSONObject(k));
			}

			final Set<Integer> familyIds =
					silos.stream()
					.map(s -> s.optInt("familyId"))
					.filter(s -> s != 0)
					.collect(Collectors.toSet());

			siloLinks = silos.stream()
					.filter(s -> !familyIds.contains(s.optInt("parentId")))
					.map(s -> s.optString("familyName").replace("&amp;", "&"))
					.collect(Collectors.toList());

			enSiloLinks = silos.stream()
					.filter(s -> !familyIds.contains(s.optInt("parentId")))
					.map(s -> s.optString("enFamilyName").replace("&amp;", "&"))
					.collect(Collectors.toList());

			for (var i = 0; i < jsonAppHierarchyList.length(); ++i ) {
				final var node = new AppHierarchyNode( jsonAppHierarchyList.getJSONObject(i) );
				appHierarchyList.add(node);
			}
			
			// Find top level applications categories
			for (final var node : appHierarchyList) {
				var parentId = node.getParentAppId();
				final var link = new Link();
				if(parentId==0){
					link.setText(node.getSectionName());
					link.setEnText(node.getEnSectionName());
					appLinks.add(link);
				}
			}
		} catch (JSONException e) {
			log.error("JSONException: ", e);
		}
	}
}