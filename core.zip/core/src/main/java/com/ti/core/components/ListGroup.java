package com.ti.core.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import java.util.Map;
import java.util.Comparator;

import java.util.HashMap;
import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.util.PathBrowserHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

public class ListGroup extends WCMUsePojo {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private List<Map<String, String>> basicList = new ArrayList<>();
    private List<Map<String, String>> accordionList = new ArrayList<>();

    private static final String LINK_TEXT = "linkText";
    private static final String LINK_URL = "linkURL";

    private List<CategoryViewModel> categoryViewModel = new ArrayList<>();
    private List<Map<String, String>> listLeft = new ArrayList<>();
    private List<Map<String, String>> listRight = new ArrayList<>();
    private List<CategoryViewModel> listLeftAccordion = new ArrayList<>();
    private List<CategoryViewModel> listRightAccordion = new ArrayList<>();
    private String linkText;
	private String linkUrl;

    public String getLinkText() {
        return linkText;
    }
    public String getLinkUrl() {
        return linkUrl;
    }

    public List<Map<String, String>> getAccordionList() {
        return accordionList;
    }

    public List<Map<String, String>> getListLeft() {
        return listLeft;
    }

    public List<CategoryViewModel> getListRightAccordion() {
        return listRightAccordion;
    }
    public List<CategoryViewModel> getListLeftAccordion() {
        return listLeftAccordion;
    }

    public List<Map<String, String>> getListRight() {
        return listRight;
    }

    public List<CategoryViewModel> getCategoryViewModel() {
		return categoryViewModel;
	}

    public class CategoryViewModel {
		private String categoryName;
		private String categoryLink;
        private List<Map<String, String>> accordionList = new ArrayList<>();

        public String getCategoryName() {
			return categoryName;
		}
        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

		public String getCategoryLink() {
			return categoryLink;
		}
        public void setCategoryLink(String categoryLink) {
            this.categoryLink = categoryLink;
        }

		public List<Map<String, String>> getAccordionList() {
			return accordionList;
		}
        public void setAccordionList(List<Map<String, String>> accordionList) {
            this.accordionList = accordionList;
        }
        public boolean hasChildren() {
			return !accordionList.isEmpty();
		}


	}
    private CategoryViewModel buildCategoryViewModel( Resource categoryResource ) {
        final var valueMap = categoryResource.getValueMap();
		final var category = new CategoryViewModel();
        accordionList = new ArrayList<>();
        category.setCategoryName( valueMap.get( "categoryName", "" ) );
        category.setCategoryLink( valueMap.get( "categoryUrl","" ) );
        final var resourceResolver = getResourceResolver();
        final var childLinks = resourceResolver.getResource(categoryResource, "childLinks");
        if(null != childLinks ){
            for (Resource childLink : childLinks.getChildren()) {
                ValueMap properties = childLink.adaptTo(ValueMap.class);
                if (null != properties) {
                    Map<String, String> accordionListMap = new HashMap<>();
                    final var linkTextAcc = properties.get("childLinkText", "");
                    final var linkUrlAcc = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, properties.get("childLinkURL", ""));
                    accordionListMap.put(LINK_TEXT, linkTextAcc);
                    accordionListMap.put(LINK_URL, linkUrlAcc);
                    accordionList.add(accordionListMap);
                }
		    }
            Collections.sort(accordionList,listGroupsort);
            category.setAccordionList(accordionList);
        }

        return category;
	}

    @Override
    public void activate() throws Exception {
        try {
            final String listType = getProperties().get("listType", "");
            final var resourceResolver = getResourceResolver();
            final var listLink = resourceResolver.getResource(getResource(), "listLink");
            final var categories = resourceResolver.getResource(getResource(), "categories");
            if (("basicList").equals(listType) && null!=listLink) {
                for (Resource resourceChild : listLink.getChildren()) {
                    ValueMap properties = resourceChild.adaptTo(ValueMap.class);
                    if (null != properties) {
                        Map<String, String> basicListMap = new HashMap<>();
                        linkText = properties.get(LINK_TEXT, "");
                        linkUrl = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, properties.get(LINK_URL, ""));
                        basicListMap.put(LINK_TEXT, linkText);
                        basicListMap.put(LINK_URL, linkUrl);
                        basicList.add(basicListMap);
                    }
                }
                Collections.sort(basicList,listGroupsort);
                makeTwoLists(basicList);
            }
            else if (("accordionList").equals(listType) && null!=categories) {
                for (Resource resourceChild : categories.getChildren()) {
                    categoryViewModel.add(buildCategoryViewModel( resourceChild ));
                }
                Collections.sort(categoryViewModel,categorySort);
                makeTwoListsCategory(categoryViewModel);
            }
        } catch (Exception e) {
            log.error("Exception:", e);
        }
    }


    private void makeTwoLists(List<Map<String, String>> basicList) {
        //divide the list into 2 sections
        int listSize = basicList.size();
        if (listSize % 2 == 1) {
            listSize++;
        }
        listLeft = basicList.subList(0, listSize/2);
        listRight = basicList.subList(listSize/2, basicList.size());
    }
    private void makeTwoListsCategory(List<CategoryViewModel> basicList) {
        //divide the list into 2 sections
        int listSize = basicList.size();
        if (listSize % 2 == 1) {
            listSize++;
        }
        listLeftAccordion = basicList.subList(0, listSize/2);
        listRightAccordion = basicList.subList(listSize/2, basicList.size());
    }


    Comparator<Map<String, String>> listGroupsort = new Comparator <Map<String, String>>(){
        @Override
        public int compare(Map<String, String> map1, Map<String, String> map2) {
            return map1.get(LINK_TEXT).compareTo(map2.get(LINK_TEXT));
        }
    };
    Comparator<CategoryViewModel> categorySort = new Comparator <CategoryViewModel>(){
        @Override
        public int compare(CategoryViewModel categoryViewModel1, CategoryViewModel categoryViewModel2) {
            return categoryViewModel1.getCategoryName().compareTo(categoryViewModel2.getCategoryName());
        }
    };
}
