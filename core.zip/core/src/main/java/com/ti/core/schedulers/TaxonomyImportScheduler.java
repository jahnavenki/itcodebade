package com.ti.core.schedulers;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.commons.datasource.poolservice.DataSourcePool;
import com.day.cq.tagging.InvalidTagFormatException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.ti.core.service.WCMComponents;
@Designate(ocd= TaxonomyImportScheduler.Config.class)
@Component(service = Runnable.class)

public class TaxonomyImportScheduler implements Runnable {


    @ObjectClassDefinition(name = "A Taxonomy Import Scheduler", description = "Taxonomy updates for Product, Applications, and Tools & Software silos will be performed on a scheduled basis")
    public @interface Config {


        @AttributeDefinition( name = "schedulerExpression", description = "Scheduler will apply the current renditions mappings for Next run time (in cron expression)", type = AttributeType.STRING )
        String scheduler_expression() default "0 0 12 * * ?";

        @AttributeDefinition( name = "overrideTags", description = "Override Tags", type = AttributeType.BOOLEAN )
        boolean overrideTags() default true;


    }

    public static final String DEFAULT_LANGUAGE = "en-us";
    private final Logger log = LoggerFactory.getLogger(getClass());
    private static final String ROOTPATH = "/content/cq:tags/imported/";
    private static final String PRODUCTS = "products/";
    private static final String MARKETS = "markets/";
    private static final String TOOLS = "tools";
    private static final String MARKET_SEGMENT_ID = "marketSegmentId";
    private static final String MARKET_SEGMENT_NAME = "marketSegmentName";
    private static final String SECTOR_ID = "sectorId";
    private static final String SECTOR_NAME = "sectorName";
    private static final String FAMILY_ID = "familyId";
    private static final String FAMILY_NAME = "familyName";
    private static final String WEB_CATEGORY_ID = "webCategoryId";
    private static final String WEB_CATEGORY_NAME = "webCategoryName";
    private static final String EE_ID = "eeId";
    private static final String EE_NAME = "eeName";
    private static final String PARENT_ID = "parentId";
    private static final String INDUSTRIAL = "Industrial";
    private boolean overrideTags;

    @Reference
    private WCMComponents wcmService;
    @Reference
    private ResourceResolverFactory resourceFactory;
    @Reference
    private DataSourcePool dataSourceService;

    private ResourceResolver resourceResolver;

    private int schedulerID;

    @Reference
    protected Scheduler scheduler;

    /**
     * The Constant DBSOURCE.
     */

    @Activate
    protected void activate(Config config) {
        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        addScheduler(config);
        this.overrideTags = config.overrideTags();
    }


    private void overrideTags() {
        try {
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            resourceResolver = resourceFactory.getServiceResourceResolver(param);
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            if (tagManager != null) {
                Tag productTag = tagManager.resolve("/content/cq:tags/imported/products");
                if (productTag != null) {
                    tagManager.deleteTag(productTag);
                }

                Tag marketTag = tagManager.resolve("/content/cq:tags/imported/markets");
                if (marketTag != null) {
                    tagManager.deleteTag(marketTag);
                }

                Tag toolTag = tagManager.resolve("/content/cq:tags/imported/tools");
                if (toolTag != null) {
                    tagManager.deleteTag(toolTag);
                }
            }
        } catch (java.security.AccessControlException e) {
            log.error("****Access Control Exception", e);
        } catch (LoginException e) {
            log.error("****Login Exception", e);
        }
    }

    public void createTag(String tagName, String tagTitle, String tagDescription) {
        try {
            Map<String, Object> param = new HashMap<>();
            param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            resourceResolver = resourceFactory.getServiceResourceResolver(param);
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            if (null != tagManager && !StringUtils.isEmpty(tagName) && !StringUtils.isEmpty(tagTitle))
                tagManager.createTag(tagName, tagTitle, tagDescription);
        } catch (java.security.AccessControlException e) {
            log.error("****Access Control Exception", e);
        } catch (InvalidTagFormatException e) {
            log.error("****Invalid tag Format Exception", e);
        } catch (Exception e) {
            log.error("****Invalid tag Format Exception{} ", e);
        }
    }


    @Modified
    protected void modified(Config config) {

        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        removeScheduler();
        addScheduler(config);
    }

    @Deactivate
    protected void deactivate(Config config) {
        removeScheduler();
    }

    /**
     * Remove a scheduler based on the scheduler ID
     */
    private void removeScheduler() {
        log.debug("Removing Scheduler Job '{}'", schedulerID);
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    /**
     * Add a scheduler based on the scheduler ID
     */
    private void addScheduler(Config config) {
        ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
        sopts.name(String.valueOf(schedulerID));
        sopts.canRunConcurrently(false);
        scheduler.schedule(this, sopts);
        log.debug("Scheduler added succesfully");
    }


    @Override
    public void run() {
        log.debug("TaxonomyImportScheduler is now running");

        if (wcmService == null) {
            log.debug("wcmService is null.  Exiting.");
            return;
        }

        if (this.overrideTags) {
            this.overrideTags();
        }

        createProductsTags(PRODUCTS);
        createMarketsTags(MARKETS);
        createToolTypesTags(TOOLS);
    }

    public String createMarketsTags(String marketPath) {
        String createMarketsTagsStatus = "";
        try {
            JSONArray marketIdJsonArray = wcmService.getBoomiApplicationMarket();
            if (marketIdJsonArray != null) {
                for (int i = 0; i < marketIdJsonArray.length(); i++) {
                    JSONObject jsonobject = marketIdJsonArray.getJSONObject(i);
                    if (jsonobject != null) {
                        String marketId = jsonobject.getString(MARKET_SEGMENT_ID);
                        String marketLable = jsonobject.getString(MARKET_SEGMENT_NAME);
                        boolean isIndustrial = false;
                        if (StringUtils.isNotBlank(INDUSTRIAL) && marketLable.equalsIgnoreCase(INDUSTRIAL)) {
                            isIndustrial = true;
                        }
                        if (marketId != null && marketLable != null) {
                            String cleanTagName = cleanTagName(marketId);
                            createTag(ROOTPATH + marketPath + cleanTagName, marketLable, StringUtils.EMPTY);
                            createSectorsTags(ROOTPATH + marketPath + cleanTagName + "/", marketId, isIndustrial);
                        }

                    }
                }
            }
            createMarketsTagsStatus = "TagsCreated";
        } catch (JSONException e) {
            createMarketsTagsStatus = "TagsNotCreated";
            log.error("Error Creating market tags due to {}" + e);
        }
        return createMarketsTagsStatus;
    }

    protected String createSectorsTags(String sectorsPath, String marketId, boolean isIndustrial) {
        String createMarketsTagsStatus = "";
        try {
            JSONArray sectorsIdJsonArray = wcmService.getBoomiApplicationSector(marketId);

            if (sectorsIdJsonArray != null) {
                for (int i = 0; i < sectorsIdJsonArray.length(); i++) {
                    JSONObject jsonobject = sectorsIdJsonArray.getJSONObject(i);
                    if (jsonobject != null) {
                        String sectorsId = jsonobject.getString(SECTOR_ID);
                        String sectorsLable = jsonobject.getString(SECTOR_NAME);
                        if (sectorsId != null && sectorsLable != null) {
                            String cleanTagName = cleanTagName(sectorsId);
                            createTag(sectorsPath + cleanTagName, sectorsLable, StringUtils.EMPTY);
                            createToolsTags(sectorsPath + cleanTagName + "/", sectorsId, isIndustrial);
                        }
                    }
                }
            }
            createMarketsTagsStatus = "TagsCreated";
        } catch (JSONException e) {
            createMarketsTagsStatus = "TagsNotCreated";
            log.error("Error Creating sector tags due to {}" + e);

        }
        return createMarketsTagsStatus;
    }

    protected String createToolsTags(String toolsPath, String sectorsId, boolean isIndustrial) {
        String createMarketsTagsStatus = "";
        try {
            if (isIndustrial) {
                JSONArray webCategoriesArray = wcmService.getBoomiApplicationCategory(sectorsId);
                if (webCategoriesArray != null) {
                    for (int i = 0; i < webCategoriesArray.length(); i++) {
                        JSONObject jsonobject = webCategoriesArray.getJSONObject(i);
                        if (jsonobject != null) {
                            String webCategoryId = jsonobject.getString(WEB_CATEGORY_ID);
                            String webCategoryName = jsonobject.getString(WEB_CATEGORY_NAME);
                            if (webCategoryId != null && webCategoryName != null) {
                                String cleanTagName = cleanTagName(webCategoryId);
                                createTag(toolsPath + cleanTagName, webCategoryName, StringUtils.EMPTY);
                                createEndEquipmentsTags(toolsPath + cleanTagName + "/", sectorsId, webCategoryId);
                            }
                        }
                    }
                }
            } else {
                createEndEquipmentsTags(toolsPath, sectorsId, null);
            }
            createMarketsTagsStatus = "TagsCreated";
        } catch (JSONException e) {
            createMarketsTagsStatus = "TagsNotCreated";
            log.error("Error Creating tools tags due to {}" + e);
        }
        return createMarketsTagsStatus;
    }

    protected void createEndEquipmentsTags(String endEquipmentsPath, String sectorsId, String webCategoryId) {
        try {
            JSONArray endEquipmentArray = wcmService.getBoomiApplicationEndEquipments(sectorsId, webCategoryId);
            if (endEquipmentArray != null) {
                for (int i = 0; i < endEquipmentArray.length(); i++) {
                    JSONObject jsonobject = endEquipmentArray.getJSONObject(i);
                    if (jsonobject != null) {
                        String eeId = jsonobject.getString(EE_ID);
                        String eeName = jsonobject.getString(EE_NAME);
                        if (eeId != null && eeName != null) {
                            String cleanTagName = cleanTagName(eeId);
                            createTag(endEquipmentsPath + cleanTagName, eeName, StringUtils.EMPTY);
                        }
                    }
                }
            }
        } catch (JSONException e) {
            log.error("Error Creating end equipments tags due to {}" + e);
        }
    }

    protected String createProductsTags(String productPath) {
        String createProductsTagsStatus = "";
        try {
            JSONArray siloIDJson = wcmService.getBoomiSiloFamilies();
            if (siloIDJson != null) {
                for (int i = 0; i < siloIDJson.length(); i++) {
                    JSONObject jsonobject = siloIDJson.getJSONObject(i);
                    String siloId = jsonobject.getString(FAMILY_ID);
                    String siloLable = jsonobject.getString(FAMILY_NAME);
                    String cleanTagName = cleanTagName(siloId);
                    createTag(ROOTPATH + productPath + cleanTagName, replaceSpecialMarks(siloLable), StringUtils.EMPTY);
                    JSONArray jsonSubFamily = null;
                    jsonSubFamily = wcmService.getBoomiProductFamilyAll(siloId);
                    if (jsonSubFamily != null) {
                        for (int j = 0; j < jsonSubFamily.length(); j++) {
                            JSONObject jsonobjectSubFamily = jsonSubFamily.getJSONObject(j);
                            if (jsonobjectSubFamily == null) {
                                continue;
                            }
                            String subFamily = jsonobjectSubFamily.getString(FAMILY_ID);
                            String level = jsonobjectSubFamily.getString("level");
                            if (null != level && "1".equals(level)) {
                                String subTagRootPath = ROOTPATH + productPath + cleanTagName;
                                createSubfamilyChilds(jsonSubFamily, subFamily, subTagRootPath);
                            }
                        }
                    }
                }
            }
            createProductsTagsStatus = "TagsCreated";
        } catch (JSONException e) {
            log.error("Error Creating Product Tags  due to {}" + e);
            createProductsTagsStatus = "TagsCreatedNotCreated";
        }
        return createProductsTagsStatus;
    }

    private void createSubfamilyChilds(JSONArray jsonSubFamily, String subFamily, String subTagRootPath) {
        try {
            if (jsonSubFamily != null) {
                for (int j = 0; j < jsonSubFamily.length(); j++) {
                    JSONObject jsonobjectSubFamily = jsonSubFamily.getJSONObject(j);
                    String subFamilyId = null;
                    if (jsonobjectSubFamily != null && jsonobjectSubFamily.has(PARENT_ID)) {
                        subFamilyId = jsonobjectSubFamily.getString(PARENT_ID);
                        if (subFamilyId != null && subFamilyId.equals(subFamily)) {
                            String familyId = jsonobjectSubFamily.getString(FAMILY_ID);
                            String familyName = jsonobjectSubFamily.getString(FAMILY_NAME);
                            String rootPath = subTagRootPath + "/" + familyId;
                            createTag(rootPath, replaceSpecialMarks(familyName), StringUtils.EMPTY);
                            boolean level3Exists = false;
                            for (int k = 0; k < jsonSubFamily.length(); k++) {
                                JSONObject jsonobjectSubFamilyLevel3 = jsonSubFamily.getJSONObject(k);
                                String parentLevel3 = jsonobjectSubFamilyLevel3.getString(PARENT_ID);
                                String familyIdLevel3 = jsonobjectSubFamilyLevel3.getString(FAMILY_ID);
                                String familyNameLevel3 = jsonobjectSubFamilyLevel3.getString(FAMILY_NAME);
                                if (familyId.equals(parentLevel3)) {
                                    level3Exists = true;
                                    String tagPathLevel3 = rootPath + "/" + familyIdLevel3; 
                                    createTag(tagPathLevel3, replaceSpecialMarks(familyNameLevel3), StringUtils.EMPTY);
                                    boolean level4Exists = false;

                                    // Level 4 Code - Start
                                    for (int i = 0; i < jsonSubFamily.length(); i++) {
                                        JSONObject jsonobjectSubFamilyLevel4 = jsonSubFamily.getJSONObject(i);
                                        String parentLevel4 = jsonobjectSubFamilyLevel4.getString(PARENT_ID);
                                        String familyIdLevel4 = jsonobjectSubFamilyLevel4.getString(FAMILY_ID);
                                        String familyNameLevel4 = jsonobjectSubFamilyLevel4.getString(FAMILY_NAME);
                                        if (familyIdLevel3.equals(parentLevel4)) {
                                            level4Exists = true;
                                            String tagPathLevel4 = tagPathLevel3 + "/" + familyIdLevel4;
                                            createTag(tagPathLevel4, replaceSpecialMarks(familyNameLevel4), StringUtils.EMPTY);
                                            createproductFamilyGPNTags(tagPathLevel4.concat("/"), familyIdLevel4);
                                        }
                                    }
                                    // Level 4 Code - End
                                    if (!level4Exists)
                                        createproductFamilyGPNTags(tagPathLevel3.concat("/"), familyIdLevel3);
                                }
                            }
                            if (!level3Exists)
                                createproductFamilyGPNTags(rootPath.concat("/"), familyId);
                        }
                    }
                }
            }

        } catch (JSONException e) {
            log.error("createSubfamilyChilds >> Error :: ", e);
        }
    }

    private void createproductFamilyGPNTags(String tagPath, String familyId) {
        try {
            JSONArray productFamilyGPNsJsonArray = wcmService.getBoomiProductFamilyGPNs(familyId);
            if (productFamilyGPNsJsonArray == null) {
                log.debug("createProductFamilyGPNTags: wcmService.getBoomiProductFamilyGPNs() returns null");
                return;
            }

            for (int i = 0; i < productFamilyGPNsJsonArray.length(); i++) {
                JSONObject gpn = productFamilyGPNsJsonArray.getJSONObject(i);
                createTag(tagPath+gpn.getString("genericPartNumberId"), gpn.getString("genericPartNumber"), gpn.getString("gpnDescription"));
            }
        } catch (JSONException e) {
            log.error("Error while creating gpn tags", e);
        }
    }

    private void createToolTypesTags(String toolPath) {
        try {
            JSONArray toolTypesJsonArray = wcmService.getBoomiToolType();
            if (toolTypesJsonArray == null) {
                log.debug("createToolTypesTags: wcmService.getBoomiToolType() returns null");
                return;
            }

            final int toolTypesLength = toolTypesJsonArray.length();
            final int FOUR = 4;
            String[] lastParentLevelId = new String[FOUR];
            final String rootPath = ROOTPATH + toolPath;
            StringBuilder tagPath;
            JSONObject jsonObject = null;
            JSONObject nextJsonObject = null; 
            for (int i = 0; i < toolTypesLength; i++) {
                jsonObject = (nextJsonObject != null ? nextJsonObject : toolTypesJsonArray.getJSONObject(i));
                if (jsonObject == null)
                    continue;
                nextJsonObject = (i < (toolTypesLength-1) ? toolTypesJsonArray.getJSONObject(i+1) : null);

                int level = jsonObject.getInt("level") - 1;
                String toolTypeId = jsonObject.getString("toolTypeId"); 
                tagPath = new StringBuilder(rootPath);
                for (int j = 0; j < level; j++)
                    tagPath.append('/').append(lastParentLevelId[j]);
                tagPath.append('/').append(toolTypeId);
                createTag(tagPath.toString(), jsonObject.getString("toolType"), StringUtils.EMPTY);

                if (nextJsonObject == null || nextJsonObject.getInt("level") - 1 <= level)
                    createToolTypeTPNTags(tagPath.append('/').toString(), toolTypeId);

                lastParentLevelId[level] = toolTypeId;
            }
        } catch (JSONException e) {
            log.error("Error while creating tooltype tags", e);
        }
    }

    private void createToolTypeTPNTags(String tagPath, String toolTypeId) {
        try {
            JSONArray toolTypeTPNsJsonArray = wcmService.getBoomiToolTypeTPNs(toolTypeId);
            if (toolTypeTPNsJsonArray == null) {
                log.debug("createToolTypeTPNTags: wcmService.getBoomiToolTypeTPNs() returns null");
                return;
            }

            for (int i = 0; i < toolTypeTPNsJsonArray.length(); i++) {
                JSONObject tpn = toolTypeTPNsJsonArray.getJSONObject(i);
                createTag(tagPath+tpn.getString("toolId"), tpn.getString("toolPartNumber"), tpn.getString("toolDescription"));
            }
        } catch (JSONException e) {
            log.error("Error while creating tooltype tags", e);
        }
    }

    private String cleanTagName(String siloLable) {
        if (!siloLable.trim().isEmpty()) {
            return siloLable.toLowerCase().replaceAll("( )+", " ").replaceAll("™|@|\\(|\\)|\\>|\\<|:", "")
                    .replace("&amp;", "&").replace(" ", "_").replace("/", "\\").replace("*", "").replace("(", "")
                    .replace(")", "").replace("&#153;", "™");
        }
        return "";
    }

    private String replaceSpecialMarks(String tagTitle) {
        if (!tagTitle.trim().isEmpty()) {
            return tagTitle.replace("&#153;", "™").replace("&#174;", "®");
        }
        return "";
    }
}