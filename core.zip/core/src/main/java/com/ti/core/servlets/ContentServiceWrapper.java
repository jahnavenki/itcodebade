package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.caconfig.annotation.Property;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;

/**
 * Service to provide list of pages available as json.
 */

@Component(immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_PATHS + "=/bin/ti/contentservice", 
		SLING_SERVLET_METHODS + "=GET" })
@Designate(ocd = ContentServiceWrapper.Config.class)
public class ContentServiceWrapper extends SlingSafeMethodsServlet {

	private static final String QB_PROP_PROPERTY_SUFFIX = "_property";
	private static final String QB_JCR_PREFIX = "@jcr:content/";
	private static final String JSON_URL = "url";
	private static final String JSON_FAMILYID = "familyid";
	private static final String JSON_APPLICATIONID = "applicationid";
	private static final String JSON_PAGE_TYPE = "pagetype";
	private static final String JSON_PAGE_NAME = "pagename";
	private static final String JSON_NAVIGATION_TITLE = "navigationtitle";
	private static final String JSON_LANGUAGE = "language";
	private static final String JSON_DISPLAY_ORDER = "displayorder";
	private static final String JSON_HIDE_IN_NAV = "hideinnavigation";
	private static final String JSON_TAGS = "tags";

	private static final String TYPE_CQ_PAGE = "cq:Page";

	/**
	 * version id.
	 */

	private static final long serialVersionUID = -712935149135076741L;

	/**
	 * The log.
	 */
	private static final Logger log = LoggerFactory.getLogger(ContentServiceWrapper.class);

	//@Property(label = "Site Path", value = "/content/texas-instruments")
	@ObjectClassDefinition(name = "TI Content service wrapper", description ="Configure service wrapper")
	public @interface Config {

		
		@AttributeDefinition( name = "sitePath", description = "Site Paths")
		String sitePath() default "/content/texas-instruments";

	
		
	}
	
	private String sitePath;

	private static final Object PROP_APPLICATION_ID = "applicationId";
	private static final String PROP_FAMILY_ID = "familyId";
	private static final Object PROP_TEMPLATE = "cq:template";
	private static final Object PROP_PAGE_NAME = "jcr:title";
	private static final Object PROP_NAVIGATION_TITLE = "navTitle";
	private static final Object PROP_HIDE_IN_NAV = "hideInNav";
	private static final Object PROP_TAGS = "cq:tags";
	private static final String REQ_PARAM_FAMILYID = "familyid";
	private static final String REQ_PARAM_APPID = "applicationid";
	private static final String REQ_PARAM_CATEGORY = "category";
	private static final String REQ_PARAM_LANG = "language";
	private static final String REQ_PARAM_PAGE_TYPE = "pagetype";
	private static final String QB_PROP_PROPERTY_VALUE_SUFFIX = "_property.value";
	private static final String QB_PROP_PROPERTY_OP_SUFFIX = "_property.operation";
	private static final String EXISTS = "exists";

	@Reference
	private transient ProductNavigationTabsOrdering tabService;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		executeQuery(request, response);
	}

	/**
	 * Perform AEM Query to find pages.
	 *
	 * @param response
	 *            the response
	 * @param request
	 *            the request
	 * @throws IOException
	 *             io
	 */
	public void executeQuery(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

		Map<String, Object> map = null;

		map = new HashMap<>();

		map.put("type", TYPE_CQ_PAGE);
		map.put("p.limit", "-1");

		// Get Properties
		String familyId = request.getParameter(REQ_PARAM_FAMILYID);
		String applicationId = request.getParameter(REQ_PARAM_APPID);
		String pageType = request.getParameter(REQ_PARAM_PAGE_TYPE);
		String category = request.getParameter(REQ_PARAM_CATEGORY);
		String language = request.getParameter(REQ_PARAM_LANG);
		String path = this.sitePath;

		if (language != null) {
			path = path + "/" + language;

		}
		log.debug("path {}" ,  path);
		map.put("path", path);
		log.debug("familyid, applicationid, pagetype, category, language {} {}" ,  familyId , applicationId);
		log.debug(" pagetype, category,  {} {}" ,   pageType, category );
		log.debug(" language {} " ,  familyId );

		// Add filters
		if (familyId != null) {
			addSearchToQuery(map, "1", QB_JCR_PREFIX + PROP_FAMILY_ID, familyId);
			log.debug("family id not null");
		} else if (applicationId != null) {
			addSearchToQuery(map, "2", QB_JCR_PREFIX + PROP_APPLICATION_ID, applicationId);
			log.debug("app id not null");
		} else if (category != null) {

			if (StringUtils.equalsIgnoreCase(category, "family")) {
				addPropertyOperation(map, "1", QB_JCR_PREFIX + PROP_FAMILY_ID, EXISTS);
				log.debug("for all familes");

			} else if (StringUtils.equalsIgnoreCase(category, "application")) {
				addPropertyOperation(map, "1", QB_JCR_PREFIX + PROP_APPLICATION_ID, EXISTS);
				log.debug("for all apps");
			} else if (StringUtils.equalsIgnoreCase(category, "other")) {
				addPropertyOperation(map, "1", QB_JCR_PREFIX + PROP_FAMILY_ID, "not");
			    addPropertyOperation(map, "2", QB_JCR_PREFIX + "hideInNav", "not");
				addPropertyOperation(map, "3", QB_JCR_PREFIX + PROP_APPLICATION_ID, "not");
				log.debug("for others");
			} else if (StringUtils.equalsIgnoreCase(category, "all")) {
				log.debug("for all");
			}
		} else if (pageType != null) {
			addSearchToQuery(map, "1", QB_JCR_PREFIX + PROP_TEMPLATE, pageType);
			log.debug("pagetype not null");
		}

		// Build and execute query
		ResourceResolver resolver = request.getResourceResolver();
		QueryBuilder builder = null;

		builder = request.getResourceResolver().adaptTo(QueryBuilder.class);
		Query query = null;
		query = builder.createQuery(PredicateGroup.create(map), resolver.adaptTo(Session.class));
		SearchResult result = null;
		result = query.getResult();

		// Build results
		JSONArray resultArray = new JSONArray();

		log.debug("Found: {}" ,  result.getTotalMatches());

		for (Hit hit : result.getHits()) {
			try {
				log.debug("processing: {} ",hit.getPath());
				Page page = hit.getResource().adaptTo(Page.class);
				JSONObject pageObj = new JSONObject();
				if (null != page && page.getContentResource()!=null ) {
					ValueMap props = page.getContentResource().getValueMap();
					Locale locale = page.getLanguage(true);
					pageObj.put(JSON_URL, URLHelper.toHttps(PathBrowserHelper.addHtmlIfContentPath(hit.getResource().getResourceResolver(), page.getPath())));
					pageObj.put(JSON_FAMILYID, props.getOrDefault(PROP_FAMILY_ID, StringUtils.EMPTY));
					pageObj.put(JSON_APPLICATIONID, props.getOrDefault(PROP_APPLICATION_ID, StringUtils.EMPTY));
					pageObj.put(JSON_PAGE_TYPE, props.getOrDefault(PROP_TEMPLATE, StringUtils.EMPTY));
					pageObj.put(JSON_PAGE_NAME, props.getOrDefault(PROP_PAGE_NAME, StringUtils.EMPTY));
					pageObj.put(JSON_NAVIGATION_TITLE, props.getOrDefault(PROP_NAVIGATION_TITLE, StringUtils.EMPTY));
					pageObj.put(JSON_LANGUAGE, locale.toString());
					pageObj.put(JSON_DISPLAY_ORDER, this.tabService.getTabOrderIndexForPage(page));
					pageObj.put(JSON_HIDE_IN_NAV, getBoolean(props.getOrDefault(PROP_HIDE_IN_NAV, false)));
					String[] tags = (String[]) props.getOrDefault(PROP_TAGS, new String[0]);
					pageObj.put(JSON_TAGS, new JSONArray(Arrays.asList(tags)));

					resultArray.put(pageObj);
				}
				log.debug("finished: {}" ,  hit.getPath());
			} catch (RepositoryException e) {
				log.error("Could not get resource {}", e);
			} catch (JSONException e) {
				log.error("Error building JSON {} ", e);
			}
		}

		// write results to response
		response.setContentType("text/x-json;charset=UTF-8");
		response.getWriter().write(resultArray.toString());

	}

	private boolean getBoolean(Object orDefault) {

		boolean retval = false;

		if (orDefault instanceof Boolean)
			retval = (Boolean) orDefault;
		else if (orDefault instanceof String)
			retval = StringUtils.equalsIgnoreCase(orDefault.toString(), "true");

		return retval;
	}

	private void addSearchToQuery(Map<String, Object> map, String propPrefix, String fieldName, String fieldValue) {

		map.put(propPrefix + QB_PROP_PROPERTY_SUFFIX, fieldName);
		map.put(propPrefix + QB_PROP_PROPERTY_VALUE_SUFFIX, fieldValue);

	}

	private void addPropertyOperation(Map<String, Object> map, String propPrefix, String propName,
			String propoperation) {

		map.put(propPrefix + QB_PROP_PROPERTY_SUFFIX, propName);
		map.put(propPrefix + QB_PROP_PROPERTY_OP_SUFFIX, propoperation);

	}

	@Activate
	protected void activate(Config config) {
		this.sitePath = config.sitePath();
		}
}