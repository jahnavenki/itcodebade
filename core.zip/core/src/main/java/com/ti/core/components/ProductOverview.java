package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductOverview extends WCMUsePojo {
    protected static final Logger log = LoggerFactory.getLogger(ProductOverview.class);

    private String browserTitle;
    private String metaDescription;
    private String keywords;

    @Override
    public void activate() throws Exception {
        try {  
            String language = "en-us";
            final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                language = tabsService.getPageLanguage(getCurrentPage());
            }
            setMetadata(language);
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }
    }

    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = Headline + “|” + “TI.com”
                                For CN, it should be Headline + “|” + “TI.com.cn”
            2. Meta description = Sub-headline
            3. Keywords: Headline
    */
    private void setMetadata(String language) {  
        final Resource pageResource = getResource();
        if (null == pageResource) {
            log.debug("resource is null");
            return;
        }
        final Resource rootResource = pageResource.getChild("root"); 
        if (null == rootResource) {
            log.debug("root is null");
            return;
        }
        String headline = null;
        for (Resource nodeChild : rootResource.getChildren()) {
            for (Resource nodeChild2 : nodeChild.getChildren()) {
                if (nodeChild2.getName().startsWith("productoverviewheadi")) {
                    final ValueMap map = nodeChild2.getValueMap();
                    headline = map.get("headline", "");
                    metaDescription = map.get("subheadline", "");
                    if (metaDescription.length() > 160) {
                        metaDescription = metaDescription.substring(0, 160) + "...";
                    }
                    break;
                }
            }
        }
        if("zh-cn".equals(language)) {
            browserTitle = headline + " | TI.com.cn";
        } else {
            browserTitle = headline + " | TI.com";
        }
        keywords = headline;
    }

    public String getBrowserTitle() {
        return browserTitle;
    }

    public String getMetaDescription() {
        return metaDescription;
    }

    public String getKeywords() {
        return keywords;
    }
}
