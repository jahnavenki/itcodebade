package com.ti.core.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.commons.jcr.JcrConstants;
import com.ti.core.util.WorkflowUtils;

/**
 * 
 * ExpiryPropertyProcessStep
 * 
 */

/**
 * 
 * ExpiryPropertyProcessStep
 * 
 */

@Component(service = WorkflowProcess.class, property = {
"service.description=Expired Status workflow step",
"chooser.label=Asset Expired Status workflow step"})
public class ExpiryPropertyProcessStep implements WorkflowProcess {

	private static final Logger log = LoggerFactory.getLogger(ExpiryPropertyProcessStep.class);

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
		final WorkflowData workflowData = item.getWorkflowData();
		String payload = workflowData.getPayload().toString();

		try {
			Map<String, Object> param = new HashMap<>();
			param.put(ResourceResolverFactory.SUBSERVICE, "writeService");
			ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(param);
			Resource resource = resourceResolver.getResource(payload);
			Resource assetJcrRes = Objects.nonNull(resource) ? resource.getChild(JcrConstants.JCR_CONTENT) : null;

			WorkflowUtils.updateExpiredAssetProperty(assetJcrRes, resourceResolver);
		} catch (LoginException e) {
			log.error("Error connecting to repository in ExpiryPropertyProcessStep due to {}", e);
		}
	}
}
