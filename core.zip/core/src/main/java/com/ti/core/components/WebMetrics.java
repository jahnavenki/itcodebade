package com.ti.core.components;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.PageManager;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

/**
 * This class will determine the webmetrics parameters that need to be added in
 * the head of the page
 *
 * @author pyusha.privi
 *
 */
public class WebMetrics extends WCMUsePojo {
	private String tiPageName;
	private String familyId;
	private String applicationId;
	private String tiContentGroup = "";
	private String tiProductPathID = "";
	private String tiProductPathName = "";
	private String tiAppPathID = "";
	private String tiAppPathName = "";
	private String tiUserGeo;
	private String pageTitle;
	private String navigationTitle;
	private String tiPageTranslationStatus;
	private String pageLanguage;
	private String languageCode;
	private String pageStatus;
	private String publishDate;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String PARAM_NAVTITLE = "navTitle";
	private static final String HYPHEN_VALUE = "-";
	private static final String TAB_VAUE = " Tab-";
	private static final String FAMILYID_PROP = "familyId";
	private static final String ROOT_FAMILY = "rootFamily";
	private static final String FAMILY_NAME = "enFamilyName";
	private static final String ANCESTOR_VAUE = "ancestors";
	private static final String SLASH_VALUE = "/";
	private static final String AMP_VALUE = "&";
	private static final String ENCODED_AMP_VALUE = "&amp;";
	private static final String CHILDID_PROP = "childId";
	private static final String APPID_PROP = "applicationId";
	private static final String SPACE_VALUE = " ";
	private static final String APP_AREA_NAME = "enSectionName";
	private static final String TRANSLATED_PROP = "translated";
	private static final String CQ_LASTMODIFIED = "cq:lastModified";
	private static final String CQ_LAST_REPLICATED = "cq:lastReplicated";
	private static final int LANGUAGE_CODE_LENGTH = 5;
	private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

	/**
	 * activate method
	 */
	@Override
	public void activate() throws Exception {
		ValueMap prop = getCurrentPage().getProperties();
		ResourceResolver resourceResolver;
		resourceResolver = getRequest().getResourceResolver();
		PageManager pm = resourceResolver.adaptTo(PageManager.class);
		String webmetricSelector = "";
		String[] selectors = getRequest().getRequestPathInfo().getSelectors();
		if (selectors.length > 0) {
			webmetricSelector = selectors[0];
		}
		if (prop != null) {
			familyId = prop.get(FAMILYID_PROP, String.class);
			applicationId = prop.get(APPID_PROP, String.class);
			String translated = prop.get(TRANSLATED_PROP, String.class);
			String lastModified = null;
			if (prop.containsKey(CQ_LASTMODIFIED)) {
				lastModified = prop.get(CQ_LASTMODIFIED, String.class);
				setPageStatus(changeDateFormat(lastModified));
			}
			if (prop.containsKey(CQ_LAST_REPLICATED)) {
				publishDate = prop.get(CQ_LAST_REPLICATED, String.class);
				setPublishDate(changeDateFormat(publishDate));
			}
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);

			pageTitle = getCurrentPage().getTitle();
			navigationTitle = getCurrentPage().getProperties().get(PARAM_NAVTITLE, String.class);
			WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			// changing this to fix the translation issue, this is returning
			// wrong language code
			if (tabsService != null) {
				pageLanguage = tabsService.getPageLanguage(getCurrentPage());
				languageCode = tabsService.getLanguageCodeForPage(getCurrentPage()).toUpperCase();
			}
			// getting tiUserGeo parameter
			tiUserGeo = (getRequest().getHeader("tiUserGeo") != null) ? getRequest().getHeader("tiUserGeo") : "";

			// getting tiPageTranslationStatus
			log.debug("translated property values " + translated);

			if (null != translated) {
				tiPageTranslationStatus = languageCode.toLowerCase() + SPACE_VALUE + changeDateFormat(translated);
			}

			String pagePath = getCurrentPage().getPath();
			if (!"en-us".equals(pageLanguage)) {
				String enPagePath = pagePath.replace(pageLanguage, "en-us");

				if (pm.getPage(enPagePath) != null) {
					navigationTitle = pm.getPage(enPagePath).getProperties().get(PARAM_NAVTITLE, String.class);
				} else {
					navigationTitle = getCurrentPage().getProperties().get(PARAM_NAVTITLE, String.class);
				}
			} else {
				navigationTitle = getCurrentPage().getProperties().get(PARAM_NAVTITLE, String.class);
			}

			// family id parameters
			if (!StringUtils.isEmpty(familyId)) {
				if (tabsService != null && wcmService != null) {
					JSONObject jsonObject = wcmService.getAllProductService(getRequest(), Integer.parseInt(familyId), pageLanguage);
					setFamilyIdParameters(jsonObject);
				}
			}
			// application id parameters
			else if (!StringUtils.isEmpty(applicationId)) {
				if (tabsService != null && wcmService != null) {
					JSONObject jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(applicationId),
							pageLanguage);
					setApplicationIdParameters(jsonObject);
				}
			}
			// training and video pages
			else if (webmetricSelector.equals("training and video")) {
				setTrainingAndVideoParameters();
			}
			// single video pages
			else if (webmetricSelector.equals("single video")) {
				setSingleVideoParameters();
			}
			// video series pages
			else if (webmetricSelector.equals("video series")) {
				setVideoSeriesParameters();
            }
			else if (webmetricSelector.equals("product portfolio")) {
				setProductPortfolioParameters();
			}
			else if (webmetricSelector.equals("new product selection")) {
				setNewProductsSelectionParameters();
			}
			else {

				// Automate the ticontentgroup & tipagename for non-GPT/MSE pages
				// If no GPT/MSE association:
				// 1. tiPageName will pull the page name (Title) of the folder/directory
				// in which the page is located + the page name (Title) for the page
				// + a country code to denote the region of the page (ex. -en, -cn, -jp, -kr,
				// -de)
				// Ex: tiPageName = "company what we do-en"
				String parentPath = getCurrentPage().getParent().getPath();
				String parent = parentPath.substring(parentPath.lastIndexOf('/') + 1);
				String page = pagePath.substring(pagePath.lastIndexOf('/') + 1);
				tiPageName = parent.replace("-", " ") + " " + page.replace('-', ' ') + "-" + languageCode.toLowerCase();
				// 2. tiContentGroup will pull the full directory path that the page is located
				// within
				// Ex: tiContentGroup = "/about-ti/company"
				tiContentGroup = getDefaultContentGroup();

			}
			log.debug("Before encoding tiContentGroup" + tiContentGroup);
			tiContentGroup = converttoUnicode(tiContentGroup);
			log.debug("final tiContentGroup" + tiContentGroup);
		}
	}

	private String getDefaultContentGroup() {
		final var pagePath = getCurrentPage().getPath();
		final var startIndex = pagePath.indexOf(pageLanguage) + LANGUAGE_CODE_LENGTH;
		return pagePath.substring(startIndex, pagePath.lastIndexOf('/') + 1);
	}

	private void setFamilyIdParameters(JSONObject jsonObject) throws JSONException {
		StringBuilder tiContentGroupSB = new StringBuilder();
		StringBuilder tiProductPathIDSB = new StringBuilder();
		String rootFamily = jsonObject.getString(ROOT_FAMILY).replace(ENCODED_AMP_VALUE, AMP_VALUE);
		JSONArray ancestorArray = jsonObject.getJSONArray(ANCESTOR_VAUE);
		// getting tiPageName value for familyId
		setPageName(FAMILY_NAME, ancestorArray, languageCode);

		// getting tiContentGroup value for familyId
		tiContentGroupSB.append(SLASH_VALUE).append(((rootFamily != null && !"null".equals(rootFamily)) ? (rootFamily + SLASH_VALUE) : ""));

		int index = ancestorArray.length() - 1;
		tiProductPathIDSB.append(SLASH_VALUE);
		while (index >= 0) {
			log.debug("ticontentgroup from service"
					+ ancestorArray.getJSONObject(index).getString(FAMILY_NAME).replace(ENCODED_AMP_VALUE, AMP_VALUE).toLowerCase());
			tiContentGroupSB
					.append(ancestorArray.getJSONObject(index).getString(FAMILY_NAME).replace(ENCODED_AMP_VALUE, AMP_VALUE).toLowerCase())
					.append(SLASH_VALUE);

			// getting tiProductPathID value for familyId
			tiProductPathIDSB.append(ancestorArray.getJSONObject(index).getString(FAMILYID_PROP)).append(SLASH_VALUE);
			index--;
		}
		tiContentGroup = tiContentGroupSB.toString();
		tiProductPathID = tiProductPathIDSB.toString();
	}

	private void setApplicationIdParameters(JSONObject jsonObject) throws JSONException {
		StringBuilder tiContentGroupSB = new StringBuilder();
		StringBuilder tiAppPathIDSB = new StringBuilder();
		JSONArray ancestorArray = jsonObject.getJSONArray(ANCESTOR_VAUE);

		// getting tiPageName value for applicationId
		setPageName(APP_AREA_NAME, ancestorArray, languageCode);

		int index = ancestorArray.length() - 1;
		tiContentGroupSB.append(SLASH_VALUE);
		tiAppPathIDSB.append(SLASH_VALUE);
		while (index >= 0) {
			// getting tiContentGroup value for applicationId

			tiContentGroupSB.append(ancestorArray.getJSONObject(index).getString(APP_AREA_NAME).replace(ENCODED_AMP_VALUE, AMP_VALUE))
					.append(SLASH_VALUE);

			log.debug("final tiContentGroup" + tiContentGroupSB.toString());
			// getting tiAppPathID value for applicationId
			tiAppPathIDSB.append(ancestorArray.getJSONObject(index).getString(CHILDID_PROP)).append(SLASH_VALUE);
			index--;
		}
		tiContentGroup = tiContentGroupSB.toString();
		tiAppPathID = tiAppPathIDSB.toString();
	}

	private void setSingleVideoParameters() {
		VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
		if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
			log.debug("Video config null or Path not found");
			return;
		}
		final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
		final String videoId = matcher.find() ? matcher.group(1) : null;
		Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);
		String title = "";
		if (null != damRes) {
			final var map = AssetUtils.getMetadata(damRes);
			if (null != map) {
				title = map.get("dc:title", String.class);
				final var tagsProductsPrimary = map.get("dam:tagsProductsPrimary", String.class);
				if (StringUtils.isNotEmpty(tagsProductsPrimary)) {
					tiProductPathID = tagsProductsPrimary.replace("imported:products", "") + "/";
				}
				tiProductPathName = map.get("dam:tagsProductsPrimaryName", String.class);
				final var tagsApplicationsPrimary = map.get("dam:tagsApplicationsPrimary", String.class);
				if (StringUtils.isNotEmpty(tagsApplicationsPrimary)) {
					tiAppPathID = tagsApplicationsPrimary.replace("imported:markets", "") + "/";
				}
				tiAppPathName = map.get("dam:tagsApplicationsPrimaryName", String.class);
			}
		}
		if (StringUtils.isNotEmpty(tiProductPathName)) {
			tiContentGroup = "/Analog and Mixed-Signal" + tiProductPathName;
		} else if (StringUtils.isNotEmpty(tiAppPathName)) {
			tiContentGroup = tiAppPathName;
		}
		tiPageName = getCurrentPage().getParent().getName() + " " + title + "-" + languageCode.toLowerCase();
		log.debug("tipagename = {}", tiPageName);
	}

	private void setTrainingAndVideoParameters() {
		String pagePath = getCurrentPage().getPath();
		String page = pagePath.substring(pagePath.lastIndexOf('/') + 1);
		tiPageName = page.replace('-', ' ') + "-" + languageCode.toLowerCase();
		int startIndex = pagePath.indexOf(pageLanguage) + LANGUAGE_CODE_LENGTH;
		tiContentGroup = pagePath.substring(startIndex, pagePath.lastIndexOf('/') + 1);
		log.debug("tipagename " + tiPageName);
	}

	private void setVideoSeriesParameters() {
		String pagePath = getCurrentPage().getPath();
		String page = pagePath.substring(pagePath.lastIndexOf('/') + 1);
		tiPageName = "video series" + " " + page.replace('-', ' ') + "-" + languageCode.toLowerCase();
		tiContentGroup = "/video/series/";
	}

	private void setProductPortfolioParameters() {
		tiPageName = "products overview-" + languageCode.toLowerCase();
		tiContentGroup = getDefaultContentGroup();
	}

	private void setNewProductsSelectionParameters() {
		tiPageName = "new product selection-" + languageCode.toLowerCase();
		tiContentGroup = getDefaultContentGroup();
	}

	private String converttoUnicode(String str) {
		String replacedValue = null;

		log.debug("before encoding " + str);

		if (str != null) {
			replacedValue = str.replace("&gt;", "\\u003E");
			replacedValue = replacedValue.replace("&lt;", "\\u003C");
			log.debug("before encoding " + replacedValue);
			replacedValue = replacedValue.replace("+", "\\u002B");
			replacedValue = replacedValue.replace("<", "\\u003C");
			replacedValue = replacedValue.replace("=", "\\u003D");
			replacedValue = replacedValue.replace(">", "\\u003E");
			replacedValue = replacedValue.replace("(", "\\u0028");
			replacedValue = replacedValue.replace(")", "\\u0029");
			replacedValue = replacedValue.replace("\"", "\\u0022");
			replacedValue = replacedValue.replace("& ", "\\u0026 ");
		}
		log.debug("replacedValue string is " + replacedValue);
		return replacedValue;
	}

	private String changeDateFormat(String lastModified) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d;
		try {
			d = sdf.parse(lastModified);
			return output.format(d);
		} catch (ParseException e) {
			log.error("Error In Date Format Changer Method{}" + e);
			return null;
		}
	}

	private void setPageName(String parameterName, JSONArray ancestorArray, String languageCode) {
		try {

			log.debug("parameterName" + parameterName);
			log.debug("value from service for pagename " + ancestorArray.getJSONObject(0).getString(parameterName));
			if (!StringUtils.isEmpty(navigationTitle) && navigationTitle != null) {
				this.tiPageName = ancestorArray.getJSONObject(0).getString(parameterName).replace(ENCODED_AMP_VALUE, AMP_VALUE)
						+ SPACE_VALUE + navigationTitle + TAB_VAUE + languageCode;

			} else if (!StringUtils.isEmpty(pageTitle) && pageTitle != null) {
				this.tiPageName = ancestorArray.getJSONObject(0).getString(parameterName).replace(ENCODED_AMP_VALUE, AMP_VALUE)
						+ SPACE_VALUE + pageTitle + HYPHEN_VALUE + languageCode;
			} else {
				this.tiPageName = ancestorArray.getJSONObject(0).getString(parameterName).replace(ENCODED_AMP_VALUE, AMP_VALUE)
						+ HYPHEN_VALUE + languageCode;
			}
			this.tiPageName = converttoUnicode(this.tiPageName);
			log.debug("tipagename " + this.tiPageName);

		} catch (JSONException e) {
			log.error("Exception: ", e);
		}
	}

	public String getApplicationId() {
		return applicationId;
	}

	public String getTiPageName() {
		if (("/").equals(tiPageName)) {
			return "";
		}
		return tiPageName;
	}

	public void setTiPageName(String tiPageName) {
		this.tiPageName = tiPageName;
	}

	public void setTiContentGroup(String tiContentGroup) {
		this.tiContentGroup = tiContentGroup;
	}

	public String getFamilyId() {
		return familyId;
	}

	public String getTiContentGroup() {
		return tiContentGroup;
	}

	public String getTiProductPathID() {
		if (("/").equals(tiProductPathID)) {
			return "";
		}
		return tiProductPathID;
	}

	public String getTiProductPathName() {
		return tiProductPathName;
	}

	public String getTiAppPathID() {
		if (("/").equals(tiAppPathID)) {
			return "";
		}
		return tiAppPathID;
	}

	public String getTiAppPathName() {
		return tiAppPathName;
	}

	public String getTiUserGeo() {
		return tiUserGeo;
	}

	public void setTiUserGeo(String tiUserGeo) {
		this.tiUserGeo = tiUserGeo;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public String getNavigationTitle() {
		return navigationTitle;
	}

	public String getTiPageTranslationStatus() {
		return tiPageTranslationStatus;
	}

	public String getPageStatus() {
		return pageStatus;
	}

	public void setPageStatus(String pageStatus) {
		this.pageStatus = pageStatus;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

}
