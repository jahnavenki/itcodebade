package com.ti.core.components;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.HomePageFeaturedProduct;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomePageFeaturedProducts extends WCMUsePojo {
	protected static final Logger log = LoggerFactory.getLogger(HomePageFeaturedProducts.class);

	private final List<HomePageFeaturedProduct> homePageFeaturedProductsList = new ArrayList<>();

	public List<HomePageFeaturedProduct> getHomePageFeaturedProducts() {
		return homePageFeaturedProductsList;
	}

	public boolean hasHomePageFeaturedProducts() {
		return !homePageFeaturedProductsList.isEmpty();
	}

	public int homePageFeaturedProductsCount() {
		return homePageFeaturedProductsList.size();
	}

	public static final String RESOURCE_NAME = "homePageFeaturedProducts";
	public static final String JSON_PROPERTY = "homePageFeaturedProductsJson";

	private JSONObject getResponseFromWs() {
		try {
			final WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if(null == wcmService) throw new NullPointerException("wcmService is null");
			final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if(null == tabsService) throw new NullPointerException("tabsService is null");
			final String language = tabsService.getPageLanguage(getCurrentPage());
			final JSONObject jsonResponse = wcmService.getHomePageFeaturedProducts(language.equals("ru-ru") ? "en-us" : language);
			if(null == jsonResponse) throw new NullPointerException("jsonResponse is null");
			return jsonResponse;
		} catch(Exception ex) {
			log.error("getResponseFromWs", ex);
			return null;
		}
	}

	private JSONObject getJsonResponse() {
		final Resource parentResource = getCurrentPage().adaptTo(Resource.class);
		if(null == parentResource) throw new NullPointerException("parentResource");
		final Resource resource = parentResource.getChild(RESOURCE_NAME);
		if(null == resource) return getResponseFromWs();
		final ValueMap valueMap = resource.getValueMap();
		JSONObject jsonResponse = null;
		if(valueMap.containsKey(JSON_PROPERTY)) {
			final String jsonString = valueMap.get(JSON_PROPERTY).toString();
			try {
				jsonResponse = new JSONObject(jsonString);
			} catch(JSONException ex) {
				log.error("getResponse", ex);
				jsonResponse = null;
			}
		}
		if(null == jsonResponse) return getResponseFromWs();
		else return jsonResponse;
	}

	@Override
	public void activate() {
		try {
			final JSONObject jsonResponse = getJsonResponse();
			if(null == jsonResponse) return; // failed to get response, should already be logged
			final JSONObject jsonFeaturedProductInfo = jsonResponse.getJSONObject("featuredProductInfo");
			final JSONArray jsonPartNumberInformation = jsonFeaturedProductInfo.getJSONArray("partNumberInformation");
			final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy'T'hh:mm:ss");
			for(int i = 0; i < jsonPartNumberInformation.length(); ++i) {
				final HomePageFeaturedProduct homePageFeaturedProduct = new HomePageFeaturedProduct();
				final JSONObject data = jsonPartNumberInformation.getJSONObject(i);
				homePageFeaturedProduct.setId(data.getInt("id"));
				homePageFeaturedProduct.setGenericPartId(data.getInt("genericPartId"));
				homePageFeaturedProduct.setGenericPartNumber(data.getString("genericPartNumber"));
				homePageFeaturedProduct.setDeviceDescription(data.getString("deviceDescription"));
				homePageFeaturedProduct.setReleaseDate(dateFormat.parse(data.getString("releaseDate")));
				homePageFeaturedProduct.setMarketingStatus(data.getString("marketingStatus"));
				homePageFeaturedProduct.setMarketingStatusId(data.getInt("marketingStatusId"));
				homePageFeaturedProduct.setMarketingStatusDescription(data.getString("marketingStatusDescription"));
				homePageFeaturedProduct.setNewFlag(data.getBoolean("newFlag"));
				homePageFeaturedProduct.setPartImageAvailable(data.getBoolean("partImageAvailable"));
				homePageFeaturedProduct.setPartImageUrl(data.getString("partImageUrl"));
				homePageFeaturedProduct.setGpnUrl(data.getString("gpnUrl"));
				homePageFeaturedProduct.setLanguage(data.getString("language"));
				homePageFeaturedProduct.setDatasheetUrl(data.getString("datasheetUrl"));
				homePageFeaturedProduct.setFamilyName(data.getString("familyName"));
				homePageFeaturedProduct.setFamilyNameEnglish(data.getString("familyNameEn"));
				homePageFeaturedProduct.setCurrency(data.getString("currency"));
				homePageFeaturedProduct.setDisplayQuantity(data.getString("displayQuantity"));
				homePageFeaturedProduct.setApproximatePrice(data.getString("approximatePrice"));
				homePageFeaturedProduct.setSelectionToolUrl(data.getString("selectionToolUrl"));
				// if required fields are missing, skip product
				if(StringUtils.isBlank(homePageFeaturedProduct.getGenericPartNumber())
				|| StringUtils.isBlank(homePageFeaturedProduct.getDeviceDescription())
				|| StringUtils.isBlank(homePageFeaturedProduct.getGpnUrl())
				) {
					continue;
				}
				homePageFeaturedProductsList.add(homePageFeaturedProduct);
			}
		} catch(Exception ex) {
			log.error("activate", ex);
		}
	}
}