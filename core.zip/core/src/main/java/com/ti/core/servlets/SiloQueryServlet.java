package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_EXTENSIONS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ti.core.service.WCMComponents;

@SuppressWarnings("serial")
@Component(service = Servlet.class, immediate=true,  property = {
		SLING_SERVLET_RESOURCE_TYPES + "=/apps/ti/components/structure/product-family",
		SLING_SERVLET_RESOURCE_TYPES + "=ti/components/structure/product-family", 
		SLING_SERVLET_RESOURCE_TYPES + "=/apps/ti/components/structure/portfolioBasePage",
		SLING_SERVLET_RESOURCE_TYPES + "=ti/components/structure/portfolioBasePage",
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_EXTENSIONS+"=json",
		SLING_SERVLET_SELECTORS+"=silo"})
public class SiloQueryServlet extends SlingSafeMethodsServlet {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(SiloQueryServlet.class);

	@Reference
	private transient WCMComponents wcm;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response){
		JSONArray boomiSiloFamilies = wcm.getBoomiSiloFamilies();
		try {
			if (boomiSiloFamilies != null && boomiSiloFamilies.length() > 0) {
				response.getWriter().write(boomiSiloFamilies.toString());
			}
		} catch (IOException e) {
			log.error("IOException:",e);
		}
	}

}