package com.ti.core.models;

import java.util.Date;

public class HomePageFeaturedProduct {
	private int id;
	private int genericPartId;
	private String genericPartNumber;
	private int familyId;
	private String familyName;
	private String familyNameEnglish;
	private String deviceDescription;
	private Date releaseDate;
	private int marketingStatusId;
	private String marketingStatus;
	private String marketingStatusDescription;
	private boolean newFlag;
	private boolean partImageAvailable;
	private String partImageUrl;
	private String gpnUrl;
	private String language;
	private String datasheetUrl;
	private String currency;
	private String displayQuantity;
	private String approximatePrice;
	private String selectionToolUrl;

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGenericPartId() {
		return this.genericPartId;
	}

	public void setGenericPartId(int genericPartId) {
		this.genericPartId = genericPartId;
	}

	public String getGenericPartNumber() {
		return this.genericPartNumber;
	}

	public void setGenericPartNumber(String genericPartNumber) {
		this.genericPartNumber = genericPartNumber;
	}

	public int getFamilyId() {
		return this.familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

	public String getFamilyName() {
		return this.familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getFamilyNameEnglish() {
		return this.familyNameEnglish;
	}

	public void setFamilyNameEnglish(String familyNameEnglish) {
		this.familyNameEnglish = familyNameEnglish;
	}
	public String getDeviceDescription() {
		return this.deviceDescription;
	}

	public void setDeviceDescription(String deviceDescription) {
		this.deviceDescription = deviceDescription;
	}

	public Date getReleaseDate() {
		return this.releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getMarketingStatusId() {
		return this.marketingStatusId;
	}

	public void setMarketingStatusId(int marketingStatusId) {
		this.marketingStatusId = marketingStatusId;
	}

	public String getMarketingStatus() {
		return this.marketingStatus;
	}

	public void setMarketingStatus(String marketingStatus) {
		this.marketingStatus = marketingStatus;
	}

	public String getMarketingStatusDescription() {
		return this.marketingStatusDescription;
	}

	public void setMarketingStatusDescription(String marketingStatusDescription) {
		this.marketingStatusDescription = marketingStatusDescription;
	}

	public boolean isNewFlag() {
		return this.newFlag;
	}

	public void setNewFlag(boolean newFlag) {
		this.newFlag = newFlag;
	}

	public boolean isPartImageAvailable() {
		return this.partImageAvailable;
	}

	public void setPartImageAvailable(boolean partImageAvailable) {
		this.partImageAvailable = partImageAvailable;
	}

	public String getPartImageUrl() {
		return this.partImageUrl;
	}

	public void setPartImageUrl(String partImageUrl) {
		this.partImageUrl = partImageUrl;
	}

	public String getGpnUrl() {
		return this.gpnUrl;
	}

	public void setGpnUrl(String gpnUrl) {
		this.gpnUrl = gpnUrl;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getDatasheetUrl() {
		return this.datasheetUrl;
	}

	public void setDatasheetUrl(String datasheetUrl) {
		this.datasheetUrl = datasheetUrl;
	}
	
	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDisplayQuantity() {
		return this.displayQuantity;
	}

	public void setDisplayQuantity(String displayQuantity) {
		this.displayQuantity = displayQuantity;
	}

	public String getApproximatePrice() {
		return this.approximatePrice;
	}

	public void setApproximatePrice(String approximatePrice) {
		this.approximatePrice = approximatePrice;
	}

	public String getSelectionToolUrl() {
		return this.selectionToolUrl;
	}

	public void setSelectionToolUrl(String selectionToolUrl) {
		this.selectionToolUrl = selectionToolUrl;
	}
}
