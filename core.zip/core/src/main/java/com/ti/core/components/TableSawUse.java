package com.ti.core.components;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.SightlyWCMMode;
import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.tablesaw.BodyRow;
import com.ti.core.models.tablesaw.Cell;
import com.ti.core.models.tablesaw.HeaderCell;
import com.ti.core.models.tablesaw.HeaderRow;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceResolver;

/**
 * Created by ryan.mccullough on 2015-11-26. Modified for TI by andy.doerr on 2017-05-08
 */
public class TableSawUse extends WCMUsePojo {
  private static final Logger LOG = LoggerFactory.getLogger(TableSawUse.class);

  /*
   * Dialog Properties
   *
   * If you change these, please ensure the JS file and dialog is changed accordingly:
   *
   * author-clientlibs/js/Perficient.Authoring.TableSaw.js dialog.xml
   */
  public static final String PROP_NUM_COLUMNS = "numColumns";
  public static final String PROP_NUM_ROWS = "numRows";
  public static final String PROP_COMPARISON_NUM_COLUMNS = "numColumnsComparison";
  public static final String PROP_COMPARISON_NUM_ROWS = "numRowsComparison";
  public static final String PROP_TITLE = "title";
  public static final String PROP_VARIATION = "variation";
  public static final String PROP_DESCRIPTION = "description";
  public static final String PROP_NUM_HEADER_ROWS = "numHeaderRows";
  public static final String PROP_HEADER_SORTABLE = "headerSortable";
  public static final int MIN_ROWS_SORTABLE = 3;
  public static final String COMPARISON_VARIATION = "comparison";
  public static final String DATA_VARIATION = "data";
  public static final String REGEX_CHECK_FOR_ANCHOR_TAG = "<a[^>]*>([^<]+)</a>";
  public static final String UPDATE_ACTION = "updateAction";
  public static final String ROW = "row";
  public static final String HEADER = "header";
  public static final String PROP_RICHTEXT = "richText";
  public static final String PROP_CURRENT_ROW = "currentRow";
  public static final String PROP_CURRENT_COLUMN = "currentColumn";

  /* Dialog Defaults */
  private static final int DEFAULT_ROWS = 1;
  private static final int DEFAULT_COLS = 1;
  private static final int DEFAULT_HEADER_ROWS = 1;
  private static final boolean DEFAULT_HEADER_SORTABLE = true;

  /* Property Values */
  private String title;
  private String display;
  private String description;
  private int numCols;
  private int numRows;
  private Integer numHeaderRows;
  private boolean sortingAllowed;
  private int currentRowUpdate;
  private int currentColumnUpdate;
  private String updateAction;
  
  /*
   * table-cell include prefixes
   * 
   * td-1-1 = first column, first row th-1 = first header
   */
  private static final String TH_ELEMENT = "th";
  private static final String TD_ELEMENT = "td";
  private static final String TABLE_CELL_FORMAT = TD_ELEMENT + "-%s-%s";
  private static final String TABLE_HEADER_FORMAT = TH_ELEMENT + "-%d-%d";
  public static final String TABLE_HEADER_COL_REGEX = TH_ELEMENT + "-(\\d)-(\\d)";//make sure this matches format ^
  public static final String TABLE_ROW_REGEX = "("+TH_ELEMENT+"|"+TD_ELEMENT+")-(\\d)-(\\d)";//make sure this matches format ^

  List<HeaderRow> tableHeaders;
  List<BodyRow> tableRows;
  Map<String, HeaderCell> headerCells = new HashMap<>();
  Map<String, Cell> bodyCells = new HashMap<>();
  List<String> imageList = null;
  String variation = null;
  Resource tableResource;
  ResourceResolver resolver;
  
  @Override
  public void activate() {

    ValueMap properties = getProperties();
    title = properties.get(PROP_TITLE, String.class);
    description = properties.get(PROP_DESCRIPTION, String.class);
    tableResource = getResource();
    resolver = getResourceResolver();
    if(properties.containsKey(PROP_VARIATION)){
      variation = properties.get(PROP_VARIATION, String.class);      
    } else {
      if (getWcmMode().isEdit())
        setDefaultVariation(tableResource);
    }
    boolean imageRow = false;

    if (COMPARISON_VARIATION.equalsIgnoreCase(variation)) {
      imageRow = properties.get("imageRow", Boolean.class);
      numCols = properties.get(PROP_COMPARISON_NUM_COLUMNS, DEFAULT_COLS);
      numRows = properties.get(PROP_COMPARISON_NUM_ROWS, DEFAULT_ROWS);
    } else {
      numCols = properties.get(PROP_NUM_COLUMNS, DEFAULT_COLS);
      numRows = properties.get(PROP_NUM_ROWS, DEFAULT_ROWS);
    }
    numHeaderRows = properties.get(PROP_NUM_HEADER_ROWS, DEFAULT_HEADER_ROWS);
    sortingAllowed = (numRows >= MIN_ROWS_SORTABLE && numHeaderRows == DEFAULT_HEADER_ROWS && properties.get(PROP_HEADER_SORTABLE, DEFAULT_HEADER_SORTABLE));

	setPropertiesForUpdate(properties);
    resetUpdateAction();
    if(updateAction.equals("removeRow"))
        numRows++;
    else if(updateAction.equals("removeColumn"))
        numCols++;

    loadConfiguredNodes();
    if (null != numHeaderRows && numHeaderRows > Integer.valueOf(0)) {
      initTableHeaders();
    }
    initTableRows();
    updateImageRow(imageRow);
    
    switch (updateAction) {
        case "addRow":
            addRow();
            break;
        case "removeRow":
            removeRow();
            break;
        case "addColumn":
            addColumn();
            break;
        case "removeColumn":
            removeColumn();
            break;
        default:
            break;
      }	
  }

  private void setDefaultVariation(Resource currentResource) {
    if (null != currentResource) {
      Node currentNode = currentResource.adaptTo(Node.class);
      try {
        if(null != currentNode){
          currentNode.setProperty(PROP_VARIATION, DATA_VARIATION);
          currentNode.getSession().refresh(true);
          currentNode.getSession().save();
        }
      } catch (RepositoryException e) {
        LOG.error("Repository Exception: ",e);
      }
    }
  }
  
  private void setPropertiesForUpdate(ValueMap properties) {
    if(properties.containsKey(PROP_CURRENT_ROW)){
	  currentRowUpdate = properties.get(PROP_CURRENT_ROW,Integer.class);
	}
	else
	  currentRowUpdate = 0;
	
	if(properties.containsKey(PROP_CURRENT_COLUMN)){
	  currentColumnUpdate = properties.get(PROP_CURRENT_COLUMN,Integer.class);
	}
	else
	  currentColumnUpdate = 0;
	
	if(properties.containsKey(UPDATE_ACTION)){
	  updateAction = properties.get(UPDATE_ACTION, "");
	}
	else
	  updateAction = "";
  }

  /**
   * Load the configured nodes and sort them into header and body cells maps.
   */
  private void loadConfiguredNodes() {
    getResource().getChildren().forEach(resource -> {
      if (resource.getName().startsWith(TD_ELEMENT))
        bodyCells.put(resource.getName(), resource.adaptTo(Cell.class));
      else
        headerCells.put(resource.getName(), resource.adaptTo(HeaderCell.class));
    });
  }

  private void initTableHeaders() {
    // Table will be reverse ordered because headings will be reversed 3-2-1
    tableHeaders = new ArrayList<>();
    HeaderRow rowHeaders;
    for (int i = numHeaderRows - 1; i >= 0; i--) {
      rowHeaders = new HeaderRow();
      long columnsAvail = numCols;
      for (int j = 0; j < numCols; j++) {
        String tableHeader;
        tableHeader = String.format(TABLE_HEADER_FORMAT, i + 1, j + 1);

        HeaderCell headerCell = headerCells.get(tableHeader);

        if (headerCell == null) {
          headerCell = new HeaderCell();
          headerCell.setTitle(StringUtils.EMPTY);
          headerCell.setColspan(TableSawHeaderUse.DEFAULT_COLSPAN);
          headerCell.setName(tableHeader);
          headerCell.setResource(getNewResource(tableHeader,HEADER));
        }

        if (i == 0)
          checkSortingAllowedInHeader(headerCell);

        rowHeaders.getHeaders().add(headerCell);

        columnsAvail -= headerCell.getColspan();

        if (columnsAvail <= 0)
          break;

      }
      if (!rowHeaders.getHeaders().isEmpty())
        tableHeaders.add(rowHeaders);
    }
  }

  /**
   * To check is sorting is allowed
   * @param colspan
   * @param rowspan
   */
  private void checkSortingAllowed(long colspan, long rowspan) {
    if (rowspan > 1 || colspan > 1)
      this.sortingAllowed = false;
  }
  
  private void checkSortingAllowedInHeader(HeaderCell headerCell)
  {	
	// Only validate bottom header
	checkSortingAllowed(headerCell.getColspan(), 1);
	
	if (headerCell.getTitle().matches(REGEX_CHECK_FOR_ANCHOR_TAG))
		this.sortingAllowed = false;
  }

    /**
     * Init table rows
     */
    private void initTableRows() {
        List<Integer> availableColumns = new ArrayList<>();

        for (int i = 0; i < numRows; i++) {
            availableColumns.add(numCols);
        }

        tableRows = new ArrayList<>();
        BodyRow bodyRows;
        for (int i = 0; i < numRows; i++) {
            bodyRows = new BodyRow();

            if (availableColumns.get(i) > 0) {
                initTableRow(availableColumns, bodyRows, i);
            }

            if (bodyRows.getBodyRows() != null && !bodyRows.getBodyRows().isEmpty()) {
                tableRows.add(bodyRows);
            }
        }
    }

/**
 * Initialized a table row
 * 
 * @param availableColumns List of available Columns
 * @param bodyRow the bodyRow we are building
 * @param currentRow the current row we are on.
 */
    private void initTableRow(List<Integer> availableColumns, BodyRow bodyRow, int currentRow) {
        for (int j = 0; j < numCols; j++) {
            int rowIndex = currentRow + 1;
            boolean stopProcessing = false;

            String cellName = String.format(TABLE_CELL_FORMAT, rowIndex, j + 1);

            Cell currentCell = bodyCells.get(cellName);

            if (currentCell == null) {
                currentCell = new Cell();
                currentCell.setColumnNumber(String.valueOf(j));
                currentCell.setColspan(1);
                currentCell.setName(cellName);
                currentCell.setRowspan(1);
                currentCell.setText(StringUtils.EMPTY);
                currentCell.setResource(getNewResource(cellName,ROW));

            }
            bodyRow.getBodyRows().add(currentCell);

            boolean ctaStyle = currentCell.getText().contains("cta-style");
            if (ctaStyle) {
                bodyRow.setStyle("mod-cta");
            }

            if (j == 0 && currentCell.getSubHeaderRow()) {
                bodyRow.setSubHeaderRowClass("ti_table-row mod-subheader");

                checkSortingAllowed(99, 1);

                stopProcessing = true;
            } else {

                // Cancel sorting if any colspan or rowspan in rows
                checkSortingAllowed(currentCell.getColspan(), currentCell.getRowspan());

                updateAvailableColumns(availableColumns, currentRow, rowIndex, currentCell);

                if (availableColumns.get(currentRow) <= 0) {
                    stopProcessing = true;
                }
            }
            if (stopProcessing) {
                break;
            }
        }
    }

  /**
   * Update Image Cell Row Name
   * @param imageRow
   */
  private void updateImageRow(boolean imageRow) {
    imageList = new ArrayList<>();

    if (imageRow) {
      for (int i = 0; i < numCols; i++) {
        String imageCellName = String.format("image-td-%s", i + 1);
        imageList.add(imageCellName);
      }
    }
  }

  /**
   * @param availableColumns
   * @param i
   * @param rowIndex
   * @param currentCell
   */
  private void updateAvailableColumns(List<Integer> availableColumns, int i, int rowIndex,
      Cell currentCell) {
    availableColumns.set(i, (int) (availableColumns.get(i) - currentCell.getColspan()));

    for (int row = 0; row < currentCell.getRowspan() - 1; row++) {
      if (row + rowIndex < availableColumns.size())
        availableColumns.set(row + rowIndex,
            (int) (availableColumns.get(row + rowIndex) - 1 * currentCell.getColspan()));
    }
  }

  public String getTitle() {
    return title;
  }

  public String getDescription() {
    return description;
  }

  public List<HeaderRow> getHeaders() {
    return tableHeaders;
  }

  public long getNumHeaderRows() {
    return this.numHeaderRows;
  }

  public List<BodyRow> getRows() {
    return tableRows;
  }

  public List<String> getImageList() {
    return imageList;
  }

  public String getDisplay() {
    return display;
  }

  public String getTDElement() {
    return TD_ELEMENT;
  }

  /**
   * This method will return the column number
   * @param name
   * @return
   */
  public static int getColumnNumberFromName(String name){
    int colNum = -1;
    Matcher colNumMatcher = Pattern.compile(TableSawUse.TABLE_HEADER_COL_REGEX).matcher(name);
    if (colNumMatcher.find()) {
      colNum = Integer.parseInt(colNumMatcher.group(2));
    }
    if (colNum <= 0) {
      LOG.warn("Could not find a valid column number from node name.  Defaulting to 1.");
      colNum = 1;
    }
    return colNum;
  }

  /**
   * This method will return the row number
   * @param name 
   * @return
   */
  public static int getRowNumberFromName(String name){
    int colNum = -1;
    Matcher colNumMatcher = Pattern.compile(TableSawUse.TABLE_ROW_REGEX).matcher(name);
    if (colNumMatcher.find()) {
      colNum = Integer.parseInt(colNumMatcher.group(2));
    }
    if (colNum <= 0) {
      LOG.warn("Could not find a valid column number from node name.  Defaulting to 1.");
      colNum = 1;
    }
    return colNum;
  }

  public boolean getHideHeaders() {
    return this.getHeaders().isEmpty();
  }

  public boolean getSortingAllowed() {
    return this.sortingAllowed;
  }

  public boolean getIsPreview() {
    SightlyWCMMode mode = this.getWcmMode();

    return mode == null || mode.isPreview() || mode.isDisabled();
  }
  
  private void addRow() {
        for (int i = tableRows.size() - 1; i > currentRowUpdate; i--) {
            BodyRow currentRow = tableRows.get(i);
            BodyRow previousRow = tableRows.get(i - 1);
            List<Cell> cellList = currentRow.getBodyRows();
            for (int j = 0; j < cellList.size(); j++) {
                Resource cell = cellList.get(j).getResource();
                ModifiableValueMap mvm = cell.adaptTo(ModifiableValueMap.class);
                try {
                    if(null != mvm) {
                        mvm.put(PROP_RICHTEXT, previousRow.getBodyRows().get(j).getText());
                        cell.getResourceResolver().commit();
                    }
                } catch (PersistenceException e) {
                    LOG.error("Exception while adding row: ", e);
                }
            }
        }
        BodyRow currentIndexRow = tableRows.get(currentRowUpdate);
        resetRow(currentIndexRow);
    }

    private void removeRow() {
        for (int i = currentRowUpdate - 1; i < tableRows.size() - 1; i++) {
            BodyRow currentRow = tableRows.get(i);
            BodyRow nextRow = tableRows.get(i + 1);
            List<Cell> cellList = currentRow.getBodyRows();
            for (int j = 0; j < cellList.size(); j++) {
                Resource cell = cellList.get(j).getResource();
                ModifiableValueMap mvm = cell.adaptTo(ModifiableValueMap.class);
                try {
                    if(null != mvm) {
                        mvm.put(PROP_RICHTEXT, nextRow.getBodyRows().get(j).getText());
                        cell.getResourceResolver().commit();
                    }    
                } catch (PersistenceException e) {
                    LOG.error("Exception while deleting row: ", e);
                }
            }
        }

        int lastIndex = tableRows.size() - 1;
        BodyRow toReset = tableRows.get(lastIndex);
        tableRows.remove(lastIndex);
        
        resetRow(toReset);
    }

    private void addColumn() {
        for (int i = 0; i < tableRows.size(); i++) {
            BodyRow currentRow = tableRows.get(i);
            List<Cell> cellList = currentRow.getBodyRows();
            for (int j = numCols - 1; j > currentColumnUpdate; j--) {
                Resource rowCell = cellList.get(j).getResource();
                ModifiableValueMap mvm = rowCell.adaptTo(ModifiableValueMap.class);
                if(null != mvm) {
                    mvm.put(PROP_RICHTEXT, cellList.get(j - 1).getText());    
                    try {
                        rowCell.getResourceResolver().commit();
                    }
                    catch (PersistenceException e) {
                        LOG.error("Exception while adding column for row: ", e);
                    }
                }                    
            }
            resetColumnCell(cellList.get(currentColumnUpdate).getResource(),ROW);
        }
        addColumnForHeader();     
    }

    private void removeColumn() {
        for (int i = 0; i < tableRows.size(); i++) {
            BodyRow currentRow = tableRows.get(i);
            List<Cell> cellList = currentRow.getBodyRows();
            for (int j = currentColumnUpdate - 1; j < numCols - 1; j++) {
                Resource cell = cellList.get(j).getResource();
                ModifiableValueMap mvm = cell.adaptTo(ModifiableValueMap.class);
                try {
                    if(null != mvm) {
                        mvm.put(PROP_RICHTEXT, cellList.get(j + 1).getText());
                        cell.getResourceResolver().commit();
                    }
                } catch (PersistenceException e) {
                    LOG.error("Exception while deleting column for row: ", e);
                }
            }
			int lastIndexCell = cellList.size() - 1;
            resetColumnCell(cellList.get(lastIndexCell).getResource(),ROW);
            cellList.remove(cellList.size() - 1);
        }      
        removeColumnForHeader();                
    }
    
    private Resource getNewResource(String resourceName, String cellType) {
        
        Resource newResource = null;
        String resourceType = "ti/components/dataTableEnhanced/";
        resourceType = cellType.equals(ROW) ? resourceType+"table-cell" : resourceType+"table-header";
        Map<String, Object> cellResourceprops = new HashMap<>();
        cellResourceprops.put("jcr:primaryType", "nt:unstructured");
        cellResourceprops.put("sling:resourceType", resourceType);
        try {
            newResource = resolver.create(tableResource, resourceName, cellResourceprops);
            } catch (PersistenceException e) {
                LOG.error("Exception while creating cell resource: ", e);
            }
        return newResource;
    }
    
    private void resetUpdateAction()
    {
        ModifiableValueMap mvm = tableResource.adaptTo(ModifiableValueMap.class);
        try {
            if(null != mvm) {
                mvm.put(UPDATE_ACTION, "");
                tableResource.getResourceResolver().commit();
            }    
        } catch (PersistenceException e) {
            LOG.error("Exception while resetting update action: ", e);
        }
        
    }
    
    private void resetRow(BodyRow toReset)
    {        
        List<Cell> toResetCellList = toReset.getBodyRows();
        for (int j = 0; j < toResetCellList.size(); j++) {
            Resource cell = toResetCellList.get(j).getResource();
            ModifiableValueMap mvm = cell.adaptTo(ModifiableValueMap.class);
            try {
                if(null != mvm) {
                    mvm.put(PROP_RICHTEXT, StringUtils.EMPTY);
                    cell.getResourceResolver().commit();
                }    
            } catch (PersistenceException e) {
                LOG.error("Exception while resetting row: ", e);
            }
        }
        
    }
    private void resetColumnCell(Resource resource,String cellType){
        
        String prop = cellType.equals(ROW) ? PROP_RICHTEXT: PROP_TITLE;
        ModifiableValueMap mvm = resource.adaptTo(ModifiableValueMap.class);
        try {
                if(null != mvm) {
                    mvm.put(prop, StringUtils.EMPTY);
                    resource.getResourceResolver().commit();
                }    
            } catch (PersistenceException e) {
                LOG.error("Exception while resetting column cell: ", e);
            }        
    }
    private void addColumnForHeader()
    {
        for (int i = 0; i < tableHeaders.size(); i++) {
            HeaderRow currentRow = tableHeaders.get(i);
            List<HeaderCell> headerCellList = currentRow.getHeaders();
            for (int j = numCols - 1; j > currentColumnUpdate; j--) {
                Resource headerCell = headerCellList.get(j).getResource();
                ModifiableValueMap mvm = headerCell.adaptTo(ModifiableValueMap.class);
                if(null != mvm) {
                    mvm.put(PROP_TITLE, headerCellList.get(j - 1).getTitle());
                    try {
                        headerCell.getResourceResolver().commit();
                    } catch (PersistenceException e) {
                        LOG.error("Exception while adding column for header: ", e);
                    }
                }     
            }
            resetColumnCell(headerCellList.get(currentColumnUpdate).getResource(),HEADER);
        }
        
    }
    private void removeColumnForHeader()
    {
        for (int i = 0; i < tableHeaders.size(); i++) {
            HeaderRow currentRow = tableHeaders.get(i);
            List<HeaderCell> headerCellList = currentRow.getHeaders();
            for (int j = currentColumnUpdate - 1; j < numCols - 1; j++) {
                Resource headerCell = headerCellList.get(j).getResource();
                ModifiableValueMap mvm = headerCell.adaptTo(ModifiableValueMap.class);
                try {
                    if(null != mvm) {
                        mvm.put(PROP_TITLE, headerCellList.get(j + 1).getTitle());
                        headerCell.getResourceResolver().commit();
                    }
                } catch (PersistenceException e) {
                    LOG.error("Exception while deleting column for header: ", e);
                }
            }
	    int lastIndexHeader = headerCellList.size() - 1;
	    resetColumnCell(headerCellList.get(lastIndexHeader).getResource(),HEADER);
        headerCellList.remove(headerCellList.size() - 1);
        }
    }
    
}
