package com.ti.core.models.assets;

import java.util.Iterator;

import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * Model for one renditions mapping.  A renditions mapping consists of asset matching criteria: imageType, path, sourceFormats, etc.  A mapping also consists of one or more rendition settings   
 *
 * @author Richard Chan
 */
public class RenditionsMapping extends JSONObject{
  private static final Logger log = LoggerFactory.getLogger(RenditionsMapping.class);
	
  public static final String IMAGE_TYPE = "imageType";
  public static final String IMAGE_PATH = "path";
  public static final String IMAGE_SOURCE_FORMATS = "sourceFormats";
  public static final String IMAGE_SOURCE_MINSIZE = "sourceMinSize";
  public static final String IMAGE_SOURCE_AR = "sourceAR";
  public static final String IMAGE_SOURCE_AR_OPERATOR = "sourceAROperator";
  public static final String IMAGE_SOURCE_WIDTH = "sourceWidth";
  public static final String IMAGE_SOURCE_WIDTH_OPERATOR = "sourceWidthOperator";
  public static final String IMAGE_SOURCE_HEIGHT = "sourceHeight";
  public static final String IMAGE_SOURCE_HEIGHT_OPERATOR = "sourceHeightOperator";
  public static final String RENDITIONS = "renditions";
  public static final String RENDITION_NAME_DEF = "name_def";
  public static final String RENDITION_OVERRIDE = "override";
  public static final String RENDITION_REGENERATE = "regenerate";  
  public static final String RENDITION_DEFAULTRENDITION = "default";
  public static final String RENDITION_FORMAT = "format";
  public static final String RENDITION_RESIZE_TO = "resizeTo";  
  public static final String RENDITION_CANVAS_SIZE = "canvasSize";
  
  public static final String RENDITION_DELETED = "[renditiondeleted]";
  public static final String RENDITION_KEY_ISDEFAULT = "_def";
  public static final String RENDITION_STRING_TO_DELETE_FRONT = "\"[renditiondeleted]\",";
  public static final String RENDITION_STRING_TO_DELETE_BACK = ",\"[renditiondeleted]\"";
	
  private String imageType;
  private String path;
  private String sourceFormats;
  private long sourceMinSize;
  private String sourceAR;
  private String sourceAROperator;
  private String sourceWidth;
  private String sourceWidthOperator;
  private String sourceHeight;
  private String sourceHeightOperator;
  private Boolean isModified = false;
  
  /**
   * Constructor
   * @param string is the string representation of a JSONObject
   * @throws JSONException - 
   */
  public RenditionsMapping(String string) throws JSONException {
    super(string);
    imageType = super.optString(IMAGE_TYPE);
    path = super.optString(IMAGE_PATH);
    sourceFormats = super.optString(IMAGE_SOURCE_FORMATS);
    sourceMinSize = super.optLong(IMAGE_SOURCE_MINSIZE);
    sourceAR = super.optString(IMAGE_SOURCE_AR);
    sourceAROperator = super.optString(IMAGE_SOURCE_AR_OPERATOR);
    sourceWidth = super.optString(IMAGE_SOURCE_WIDTH);
    sourceWidthOperator = super.optString(IMAGE_SOURCE_WIDTH_OPERATOR);
    sourceHeight = super.optString(IMAGE_SOURCE_HEIGHT);
    sourceHeightOperator = super.optString(IMAGE_SOURCE_HEIGHT_OPERATOR);
  }

  public String getImageType() {
	return imageType;
  }

  public String getPath() {
	return path;
  }

  public String getSourceFormats() {
	return sourceFormats;
  }

  public long getSourceMinSize() {
	return sourceMinSize;
  }

  public String getSourceAR() {
	return sourceAR;
  }

  public String getSourceAROperator() {
	return sourceAROperator;
  }

  public String getSourceWidth() {
	return sourceWidth;
  }

  public String getSourceWidthOperator() {
	return sourceWidthOperator;
  }

  public String getSourceHeight() {
	return sourceHeight;
  }

  public String getSourceHeightOperator() {
	return sourceHeightOperator;
  }

  /**
   * If this mapping has been modified since its initial creation, e.g. through copyFrom() method
   * @return true if mapping has been modified since initial creation
   */
  public Boolean isModified() {
    return isModified;
  }

  /**
   * JSONObject.toString() but removes deleted rendition entries
   * @return cleansed string representation of JSONObject
   */
  @Override
  public String toString() {
    return super.toString().replace(RENDITION_STRING_TO_DELETE_FRONT, "").replace(RENDITION_STRING_TO_DELETE_BACK, "");
  }
  
  /**
   * Update this mapping from another mapping.  It is assumed that values of this mapping will be overwritten from the supplied mapping.  However, if both mappings are identical in values, then no copy action will occur and 'isModified' will be false after the copy (otherwise, 'isModified' will be true)
   * @param mapping
   *          The supplied source mapping to copy from (to update this mapping).
   */
  public void copyFrom(RenditionsMapping mapping) {
	    copyFromHelper(mapping, this);
  }

  /**
   * Helper function for the main copyFrom method.  Allows to be called recursively to parse sub JSONObjects.
   * @param src
   *          The supplied source mapping to copy from
   * @param target
   *          The target mapping to be updated
   */
  private void copyFromHelper(JSONObject src, JSONObject target) {
	  
      try {
    	  Iterator<String> keys = src.keys();
    	  boolean override = target.optBoolean(RENDITION_OVERRIDE);
    	  boolean fieldAddedOrModified = false;
    	  while(keys.hasNext()) {
    	    String key = keys.next();
      		Object value = src.get(key);
      		fieldAddedOrModified = copyFromHelperWhileLoopHelper(target, key, value, override) || fieldAddedOrModified;
    	  }
    	  
    	  if (fieldAddedOrModified) {
    		  isModified = true;
    		  
    		  // If any key is added or modified, and this JSONObject is a rendition setting, then also set its 'regenerate' flag to true
    		  if (target.has(RENDITION_REGENERATE)) {
    			  target.put(RENDITION_REGENERATE, "true");
    			  log.debug("Rendition:{} set to regenerate", target.getString(RENDITION_NAME_DEF));
    		  }
    	  }
    	  
    	  // Delete target attributes that are not part of the source mapping (unless target has 'override' flag set to true)
    	  copyFromHelperDeleteHelper(src, target);
      }
      catch (JSONException e) {
    	  log.error("Error in copyFromHelper", e);
	  }
  }
  
  /**
   * This is a portion of code logic inside the copyFromHelper function to handle the While loop logic to copy the key's value or not.  Created separately to satisfy Sonar cyclomatic complexity...
   * @param target
   *          The same target as copyFromHelper()
   * @param key
   *          The current key in the loop to determine whether to update it or not
   * @param value
   *          If key is to update, then update it with this value
   * @param targetOverride
   *          Specifies whether the target rendition's Override flag is set to true or not
   */
  private boolean copyFromHelperWhileLoopHelper(JSONObject target, String key, Object value, boolean targetOverride) {
	  try {
			// Check if target JSONObject also has this attribute(key) - this would indicate an update instead of an add
	    	if (target.has(key)) {
	    		// No need to update the following attributes: override; regenerate; rendition current values if the target specified 'override' (so update only the default values)
	    		if (!RENDITION_OVERRIDE.equals(key) && !RENDITION_REGENERATE.equals(key) && (!targetOverride || key.contains(RENDITION_KEY_ISDEFAULT))) {
	  		      if (RENDITIONS.equals(key)) {
	  		    	  // If attribute is 'renditions', treat this as an array of JSONObject, use recursion to update the individual settings
	  		    	  copyFromHelperRenditionsHelper((JSONArray) value, target.getJSONArray(key));
	  		      }
	  		      else if (!value.toString().equals(target.get(key).toString())) {
	  		    	  // All other attributes should be normal strings, so simply compare the source and target values to determine whether we need to update this attribute or not
			    	  target.put(key, value);
			    	  log.debug("Updating key:{}, value: {}", key, value);
			    	  return true;				    	  
	  		      }
	    		}
		    }
		  	else {
		    	  // This is a new key, just add it to the target JSONObject
		    	  target.put(key, value);
		    	  log.debug("Adding key: {}, value: {}", key, value);
		    	  return true;
		  	}
	  }
      catch (JSONException e) {
			log.error("Error in copyFromHelper", e);
	  }

	  return false;	  
  }
  
  
  /**
   * This is a portion of code logic inside the copyFromHelper function to handle the 'renditions' case.  Created separately to satisfy Sonar cyclomatic complexity...
   * @param srcArr
   *          source 'renditions' from supplied mapping is a JSONArray
   * @param targetArr
   *          target 'renditions' from metadata mapping is a JSONArray
   */
  private void copyFromHelperRenditionsHelper(JSONArray srcArr, JSONArray targetArr) throws JSONException {
	  for (int i = 0; i < srcArr.length(); i++) {
		 boolean existsInTarget = false;
		 JSONObject obj = srcArr.getJSONObject(i);
		 for (int j = 0; j < targetArr.length(); j++) {
			 JSONObject targetObj = targetArr.getJSONObject(j);
			 
			 if (obj.has(RENDITION_NAME_DEF) && obj.getString(RENDITION_NAME_DEF).equals(targetObj.optString(RENDITION_NAME_DEF))) {
				copyFromHelper(obj, targetObj);
				targetArr.put(j, targetObj);
				existsInTarget = true;
				break;
			 }
		 }
		 if (!existsInTarget) {
			 // If a rendition from source is not found in the target (as based on the NAME_DEF attribute), then this is a new rendition so add it to the target
			 targetArr.put(obj);
			 isModified = true;
			 log.debug("Added rendition: {} ", obj.getString(RENDITION_NAME_DEF));
		 }
	  }
	  
	  // Lastly, delete any renditions only found in the target but not in the source, meaning they are deleted.  (overridden renditions excepted)
	  //    (Note: there is no remove() method for JSONArray, so has to do it in a long way)
	  copyFromHelperDeleteRenditionsHelper(srcArr, targetArr);
  }
  
  
  /**
   * This is helper function to the copyFromHelperRenditionsHelper function. It deletes redundant renditions from the target JSONArray if they are not found in the supplied source JSONArray.  This helper is needed because JSONArray doesn't support remove()
   * @param srcArr
   *          source 'renditions' from supplied mapping is a JSONArray
   * @param targetArr
   *          target 'renditions' from metadata mapping is a JSONArray
   */
  private void copyFromHelperDeleteRenditionsHelper(JSONArray srcArr, JSONArray targetArr) throws JSONException {     
	  for (int i = 0; i < targetArr.length(); i++) {
		 JSONObject obj = targetArr.getJSONObject(i);

		 if (obj.optBoolean(RENDITION_OVERRIDE))
			 continue;
		 
		 boolean existsInSrc = false;		 
		 // Check if all renditions in the target JSONArray exists in the source as well.  A target rendition which is not in the source, but it has the 'override' flag set to true is also considered not deletable. 
		 for (int j = 0; j < srcArr.length(); j++) {
			 JSONObject srcObj = srcArr.getJSONObject(j);
			 
			 if (obj.has(RENDITION_NAME_DEF) && obj.getString(RENDITION_NAME_DEF).equals(srcObj.optString(RENDITION_NAME_DEF))) {
				 existsInSrc = true;				 
				 break;
			 }
		 }

		 // If rendition is found only in target but not in source, "delete" it.  (Since JSONArray doesn't have remove(), need to do it by inserting a "delete placeholder" in that spot)
		 if (!existsInSrc) {
			 log.debug("Deleting rendition: {} ", obj.getString(RENDITION_NAME_DEF));
			 targetArr.put(i, RENDITION_DELETED);
			 isModified = true;
		 }
	  }
  }

  /**
   * This is a helper function to the copyFromHelper function. This is the second half of the code logic that deletes extra attributes from the target JSONObject if it doesn't exist in the source JSONObject.  Exception is if JSONObject is a 'rendition' object and it is overridden.
   * @param srcArr
   *          source 'renditions' from supplied mapping is a JSONArray
   * @param targetArr
   *          target 'renditions' from metadata mapping is a JSONArray
   */
  private void copyFromHelperDeleteHelper(JSONObject src, JSONObject target) {
	  // Don't delete any of the target object keys if it contains an 'override' flag and it is true
	  if (target.optBoolean(RENDITION_OVERRIDE))
		  return;

	  // Otherwise, delete any keys in target object not found in the source object
	  Iterator<String> keys = target.keys();
	  while(keys.hasNext()) {
	    String key = keys.next();
  			
  		// Check if source JSONObject also has this attribute(key), if not, delete it from target
      	if (!src.has(key)) {      		
      		if (!key.contains("@"))	// special case: deleting redundant keys saved by metadata schema doesn't count as a real key change
          		isModified = true;
      		
      		keys.remove();
      		log.debug("Deleting key: {}", key);
      	}
	  }
  }
}