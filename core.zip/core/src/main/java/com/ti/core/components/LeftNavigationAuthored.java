package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.NestedLevels;
import com.ti.core.util.PathBrowserHelper;

public class LeftNavigationAuthored extends WCMUsePojo {

    /* LEVEL 0 */
    private static final String LEVEL_ZERO_TITLE = "level0Title";
    /* LEVEL 1 */
    private static final String LEVEL_ONE_LINK = "level1Link";
    private static final String LEVEL_ONE_URL = "level1URL";
    private static final String LEVEL_ONE_URL_NEWWINDOW = "level1URLNewWindow";
    /* LEVEL 2 */
    private static final String LEVELTWO_FIELDS = "level2MultiFields";
    private static final String LEVEL_TWO_LINK = "level2Link";
    private static final String LEVEL_TWO_URL = "level2URL";
    private static final String LEVEL_TWO_URL_NEWWINDOW = "level2URLNewWindow";
    /* LEVEL 3 */
  
    private static final String LEVEL_THREE_LINK = "level3Link";
    private static final String LEVEL_THREE_URL = "level3URL";
    private static final String LEVEL_THREE_URL_NEWWINDOW = "level3URLNewWindow";

    private static final String SLASH = "/";
    private static final String HTML = ".html";
    private static final String URL_TARGET = "_blank";

    /**
     * The log.
     */
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * Level Zero Title.
     */
    private String level0Title;
    /**
     * Level 1 Link.
     */
    private String level1Link;
    /**
     * Level 1 URL.
     */
    private String level1Url;

    /**
     * The level 2 list.
     */
    List<NestedLevels> levels = new ArrayList<>();

    private String urlTarget;

    private Boolean selected;

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    public String getLevel0Title() {
        return level0Title;
    }

    public void setLevel0Title(String level0Title) {
        this.level0Title = level0Title;
    }

    public String getLevel1Link() {
        return level1Link;
    }

    public void setLevel1Link(String level1Link) {
        this.level1Link = level1Link;
    }

    public String getLevel1Url() {
        return level1Url;
    }

    public void setLevel1Url(String level1Url) {
        this.level1Url = level1Url;
    }

    public String getUrlTarget() {
        return urlTarget;
    }

    public void setUrlTarget(String target) {
        this.urlTarget = target;
    }

    public List<NestedLevels> getLevels() {
        return levels;
    }

    public void setLevels(List<NestedLevels> levels) {
        this.levels = levels;
    }

    @Override
    public void activate() throws Exception {

        boolean level2HasExactMatch = false;
        boolean level2NoHighlight = false;
        boolean level3HasExactMatch = false;
        boolean level3NoHighlight = false;
        String level1SecondIndex = "";

        setLevel0Title(getProperties().get(LEVEL_ZERO_TITLE, String.class));
        setLevel1Link(getProperties().get(LEVEL_ONE_LINK, String.class));
        String pagePath = getCurrentPage().getPath();
        log.debug("pagePath>>>> {}", pagePath);

        String level1 = getProperties().get(LEVEL_ONE_URL, String.class);
        if (StringUtils.isNotEmpty(level1)) {
            level1 = level1.replace(HTML, StringUtils.EMPTY).trim();
            log.debug("level1>>>> {}", level1);
            level1SecondIndex = getOrdinalIndexValue(level1, 2);
            log.debug("level1SecondIndex>>>>> {}", level1SecondIndex);
        }

        String pagePathSecondIndex = getOrdinalIndexValue(pagePath, 2);
        log.debug("pagePathSecondIndex>>>>> {}", pagePathSecondIndex);
        String pagePathThirdIndex = getOrdinalIndexValue(pagePath, 3);
        log.debug("pagePathThirdIndex>>>>> {}", pagePathThirdIndex);

        selected = (StringUtils.isNotEmpty(level1) && StringUtils.equals(pagePathSecondIndex, level1SecondIndex));

        String url = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),
                getProperties().get(LEVEL_ONE_URL, String.class));
        setLevel1Url(url);

        setUrlTarget(getProperties().get(LEVEL_ONE_URL_NEWWINDOW, false) ? URL_TARGET : StringUtils.EMPTY);

        // updated begin
        for (Resource nodeChild : getResource().getChildren()) {
            if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(LEVELTWO_FIELDS)) {
                for (Resource level2Field : nodeChild.getChildren()) {
                    ValueMap properties = level2Field.adaptTo(ValueMap.class);
                    if (null != properties) {
                        String level2Url = StringUtils.isNotBlank(properties.get(LEVEL_TWO_LINK, String.class)) && StringUtils.isNotBlank(properties.get(LEVEL_TWO_URL, String.class))
                                ? properties.get(LEVEL_TWO_URL, String.class).replace(HTML, StringUtils.EMPTY).trim() : StringUtils.EMPTY;
                        String level2UrlSecondIndex = getOrdinalIndexValue(level2Url, 2);
                        log.debug("level2UrlSecondIndex>>>>> {}", level2UrlSecondIndex);
                        if (StringUtils.contains(level2Url, "#")) {
                            level2NoHighlight = true;
                        }
                        if (StringUtils.equals(pagePathSecondIndex, level2UrlSecondIndex)) {
                            level2HasExactMatch = true;
                            break;
                        }
                    }
                }
            }
        }
        for (Resource nodeChild : getResource().getChildren()) {
            if (nodeChild != null && nodeChild.toString().contains("level2MultiFields")) {
                for (Resource level2Field : nodeChild.getChildren()) {
                    NestedLevels level2 = new NestedLevels();
                    ValueMap properties = level2Field.adaptTo(ValueMap.class);
                    if (null != properties) {
                        if (!StringUtils.isBlank(properties.get(LEVEL_TWO_LINK, String.class))) {
                            level2.setLink(properties.get(LEVEL_TWO_LINK, String.class));
                            String level2Url = properties.get(LEVEL_TWO_URL, String.class);
                            level2Url = Optional.ofNullable(level2Url).orElseGet(() -> "");
                            level2.setUrl(level2Url.trim());
                           
                            setlevelData(level2HasExactMatch, level2NoHighlight, pagePath, pagePathSecondIndex, pagePathThirdIndex,
                                    level2, LEVEL_TWO_URL);
                            String url2 = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),
                                    properties.get(LEVEL_TWO_URL, String.class));
                            level2.setUrl(url2);
                            level2.setUrlTarget(properties.get(LEVEL_TWO_URL_NEWWINDOW, String.class) != null && Boolean.valueOf(properties.get(LEVEL_TWO_URL_NEWWINDOW, String.class)) ? URL_TARGET : StringUtils.EMPTY);
                            if (level2Field.hasChildren()) {
                                List<NestedLevels> level3Links = new ArrayList<>();
                                for (Resource level3Field : level2Field.getChildren()) {
                                    if (level3Field.hasChildren()) {
                                        for (Resource level3FieldItems : level3Field.getChildren()) {
                                            ValueMap level3properties = level3FieldItems.adaptTo(ValueMap.class);
                                            String level3Url = StringUtils.isNotBlank(level3properties.get(LEVEL_THREE_LINK, String.class))
                                                    ? level3properties.get(LEVEL_THREE_URL, String.class).replace(HTML, StringUtils.EMPTY).trim()
                                                    : StringUtils.EMPTY;
                                            String level3UrlSecondIndex = getOrdinalIndexValue(level3Url, 2);
                                            if (StringUtils.contains(level3Url, "#")) {
                                                level3NoHighlight = true;
                                            }
                                            if (StringUtils.equals(pagePathSecondIndex, level3UrlSecondIndex)) {
                                                level3HasExactMatch = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                                for (Resource level3Field : level2Field.getChildren()) {
                                    if (level3Field.hasChildren()) {
                                        for (Resource level3FieldItems : level3Field.getChildren()) {
                                            ValueMap level3properties = level3FieldItems.adaptTo(ValueMap.class);
                                            NestedLevels level3 = new NestedLevels();
                                            if (!StringUtils.isBlank(level3properties.get(LEVEL_THREE_LINK, String.class))) {
                                                level3.setLink(level3properties.get(LEVEL_THREE_LINK, String.class));
                                                level3.setUrl(level3properties.get(LEVEL_THREE_URL, String.class).trim());
                                                setlevelData(level3HasExactMatch, level3NoHighlight, pagePath, pagePathSecondIndex,
                                                        pagePathThirdIndex, level3, LEVEL_THREE_URL);
                                                String url3 = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),
                                                        level3properties.get(LEVEL_THREE_URL, String.class));
                                                level3.setUrl(url3);
                                                level3.setUrlTarget(level3properties.get(LEVEL_THREE_URL_NEWWINDOW, String.class) != null && Boolean.valueOf(level3properties.get(LEVEL_THREE_URL_NEWWINDOW, String.class)) ? URL_TARGET : StringUtils.EMPTY);
                                                level3Links.add(level3);
                                            }
                                        }
                                    }
                                }
                                level2.setLevel34Links(level3Links);
                            }
                            levels.add(level2);
                        }
                    }
                }
            }
        }
    }

    private void setlevelData(boolean levelHasExactMatch, boolean levelNoHighlight, String pagePath,
                              String pagePathSecondIndex, String pagePathThirdIndex, NestedLevels nestedLevel, String level) {
        log.debug("pagePath>>>> {}", pagePath);
        log.debug("{}Link>>>> {}", level, nestedLevel.getLink());
        log.debug("{}>>>> {}", level, nestedLevel.getUrl());
        String url = StringUtils.remove(nestedLevel.getUrl(), HTML);
        String secondIndex = getOrdinalIndexValue(url, 2);
        log.debug("{}secondIndex>>>>> {}", level, secondIndex);
        String thirdIndex = getOrdinalIndexValue(url, 3);
        log.debug("{}thirdIndex>>>>> {}", level, thirdIndex);
        if (!levelNoHighlight) {
            if (!levelHasExactMatch) {
                // look if current page has Navigation Title and level
                // url not equals to pagePath, then compare page Path Third
                // Index with level Url 3rd Index
                if (!selected && StringUtils.isNotBlank(getCurrentPage().getNavigationTitle())
                        && !StringUtils.equals(pagePathSecondIndex, secondIndex)) {
                    nestedLevel.setSelected(StringUtils.equals(pagePathThirdIndex, thirdIndex));
                }

            } else if (StringUtils.equals(pagePathSecondIndex, secondIndex)) {
                nestedLevel.setSelected(true);
            }
        }

    }

    private String getOrdinalIndexValue(String url, int indexValue) {
        String ordinalIndexValue = "";
        if (StringUtils.lastOrdinalIndexOf(url, SLASH, indexValue) >= 0) {
            if (indexValue == 2) {
                ordinalIndexValue = url.substring(StringUtils.lastOrdinalIndexOf(url, SLASH, indexValue));
            } else {
                ordinalIndexValue = url.substring(0, url.lastIndexOf(SLASH))
                        .substring(StringUtils.lastOrdinalIndexOf(url, SLASH, indexValue));
            }
        }
        return ordinalIndexValue;
    }
}
