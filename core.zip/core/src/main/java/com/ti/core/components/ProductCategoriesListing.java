package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.Silo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Automated component to populate families listed under the immediate level down within the GPT
 */
public class ProductCategoriesListing extends WCMUsePojo {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String FAMILY_ID = "familyId";
    private static final String JSON_NODE_CONTENT = "content";
	private static final String JSON_NODE_PRODUCT_TREE = "tree";
	private static final String JSON_NODE_PARENT_ID = "parentId";
	private static final String JSON_NODE_FAMILY_NAME = "familyName";
    private static final String JSON_NODE_FAMILY_NAME_ENGLISH = "enFamilyName";
	private static final String JSON_NODE_TREE_LEVEL = "treelevel";
	private static final String JSON_NODE_FAMILY_URL = "productNodeUrl";
    private List<Silo> productCategories = new ArrayList<>();
    private List<Silo> productCategoriesLeft = new ArrayList<>();
    private List<Silo> productCategoriesRight = new ArrayList<>();

    public List<Silo> getProductCategories() {
        return productCategories;
    }

    public List<Silo> getProductCategoriesLeft() {
        return productCategoriesLeft;
    }

    public List<Silo> getProductCategoriesRight() {
        return productCategoriesRight;
    }

    @Override
    public void activate() throws Exception {
        var familyId = "";
        var iFamilyId = 0;
        if (getPageProperties().containsKey(FAMILY_ID)) {
            familyId = getPageProperties().get(FAMILY_ID).toString();
            iFamilyId = Integer.parseInt(familyId);
        }
        WCMComponents wcm = getSlingScriptHelper().getService(WCMComponents.class);
        if (wcm == null) {
            log.error("Could not get WCM Service");
            return;
        }
        String language = "";
        ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                .getService(ProductNavigationTabsOrdering.class);
        if (tabsService != null) {
            language = tabsService.getPageLanguage(getCurrentPage());
        }
        if (StringUtils.isEmpty(language)) {
            language = "en-us";
        }
        this.createLists(wcm, iFamilyId, language);
    }

    private void createLists(WCMComponents wcm, int iFamilyId, String language) {
        try {
            //get all products
            JSONObject jsonAllProd = wcm.getAllProductService(getRequest(), iFamilyId, language);
            if (jsonAllProd == null) {
                log.error("Could not get All products from WCM service");
                return;
            }
            if (iFamilyId == 0) {
                JSONArray jsonProdContentArr = jsonAllProd.getJSONArray(JSON_NODE_CONTENT);
                if (jsonProdContentArr == null || jsonProdContentArr.length() <= 0) {
                    log.error("Could not get Product Content array from WCM service");
                    return;
                }
                for (int i = 0; i < jsonProdContentArr.length(); i++) {
                    final JSONObject family = jsonProdContentArr.getJSONObject(i);
                    Silo silo = createSilo(family, iFamilyId, -1);
                    if (silo != null) {
                        productCategories.add(silo);
                    }
                }
            } else {
                JSONArray jsonProdTreeArr = jsonAllProd.getJSONArray(JSON_NODE_PRODUCT_TREE);
                if (jsonProdTreeArr == null || jsonProdTreeArr.length() <= 0) {
                    log.error("Could not get Product Tree array from WCM service");
                    return;
                }
                //get tree level of current family
                int currentLevel = getFamilyTreeLevel(jsonProdTreeArr, iFamilyId);
                for (int i = 0; i < jsonProdTreeArr.length(); i++) {
                    final JSONObject family = jsonProdTreeArr.getJSONObject(i);
                    //build a list of families under the immediate level down within the GPT
                    Silo silo = createSilo(family, iFamilyId, currentLevel);
                    if (silo != null) {
                        productCategories.add(silo);
                    }
                }
            }
            this.makeTwoLists();
        } catch (Exception e) {
            log.error("Exception:", e);
        }
    }

    private int getFamilyTreeLevel(JSONArray jsonProdTreeArr, int familyId) {
        int currentLevel = -1;
        try {
            for (int i = 0; i < jsonProdTreeArr.length(); i++) {
                final JSONObject family = jsonProdTreeArr.getJSONObject(i);
                if (family.has(FAMILY_ID) && family.getInt(FAMILY_ID) == familyId
                    && family.has(JSON_NODE_TREE_LEVEL)) {
                    currentLevel = family.getInt(JSON_NODE_TREE_LEVEL);
                    break;
                }
            }
        } catch (Exception e) {
            log.error("Exception:", e);
        }

        return currentLevel;
    }

    private Silo createSilo(JSONObject family, int familyId, int level) {
        Silo silo = null;
        try {
            final var parentId = family.isNull(JSON_NODE_PARENT_ID) ? 0 : family.getInt(JSON_NODE_PARENT_ID);
            final var treeLevel = family.isNull(JSON_NODE_TREE_LEVEL) ? 0 : family.getInt(JSON_NODE_TREE_LEVEL);
            if (
               family.has(JSON_NODE_PARENT_ID)
            && parentId == familyId
            && family.has(JSON_NODE_TREE_LEVEL)
            && treeLevel == level + 1
            ) {
                silo = new Silo();
                silo.setFamilyId(family.getString(FAMILY_ID));
                if (family.has(JSON_NODE_FAMILY_NAME) && !family.isNull(JSON_NODE_FAMILY_NAME)) {
                    String familyName = StringEscapeUtils.unescapeHtml4(family.getString(JSON_NODE_FAMILY_NAME));
                    silo.setFamilyName(familyName);
                    silo.setFamilyNameEnglish(familyName);
                }
                if (family.has(JSON_NODE_FAMILY_NAME_ENGLISH) && !family.isNull(JSON_NODE_FAMILY_NAME_ENGLISH)) {
                    String familyNameEnglish = StringEscapeUtils.unescapeHtml4(family.getString(JSON_NODE_FAMILY_NAME_ENGLISH));
                    silo.setFamilyNameEnglish(familyNameEnglish);
                }
                if (family.has(JSON_NODE_FAMILY_URL) && !family.isNull(JSON_NODE_FAMILY_URL)) {
                    silo.setFamilyUrl(family.getString(JSON_NODE_FAMILY_URL));
                }
            }
        } catch (Exception e) {
            log.error("Exception:", e);
        }
        return silo;
    }

    private void makeTwoLists() {
        //divide the list into 2 sections
        int listSize = productCategories.size();
        if (listSize % 2 == 1) {
            listSize++;
        }
        productCategoriesLeft = productCategories.subList(0, listSize/2);
        productCategoriesRight = productCategories.subList(listSize/2, productCategories.size());
    }
}
