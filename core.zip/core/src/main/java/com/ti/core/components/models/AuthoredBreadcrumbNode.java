package com.ti.core.components.models;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.util.PathBrowserHelper;

@Model(
	adaptables = { Resource.class },
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class AuthoredBreadcrumbNode {
	private final Logger log = LoggerFactory.getLogger(getClass());

    @SlingObject
	private ResourceResolver resourceResolver;

	@ValueMapValue
	private String label;

	@ValueMapValue
	private String url;

	public String getLabel() {
		return label;
	}

	public String getUrl() {
		return url;
	}

	@PostConstruct
	public void init() {
		try {
			label = StringUtils.defaultString(label);
			url = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, url);
		} catch (Exception ex) {
			log.error( "Exception in AuthoredBreadcrumbNode", ex);
		}
	}
}
