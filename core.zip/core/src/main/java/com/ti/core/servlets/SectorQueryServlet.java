package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.commons.datasource.poolservice.DataSourcePool;

@SuppressWarnings("serial")
@Component(service = Servlet.class, immediate=true, property = {
		SLING_SERVLET_PATHS + "=/bin/ti/sectorquery", 
		SLING_SERVLET_METHODS + "=GET" })
public class SectorQueryServlet extends SlingSafeMethodsServlet {
	private static final Logger log = LoggerFactory.getLogger(SectorQueryServlet.class);

	public static final String DBSOURCE = "aem";
	@Reference
	private DataSourcePool dataSourceService; //NOSONAR

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		executeQuery(response, request);
	}

	/**
	 * This is getDataBaseConnection.
	 * 
	 * @param dataSourceName
	 *            - String Parameter
	 * @return Connection
	 */
	public Connection getDataBaseConnection(String dataSourceName) {
		Connection conn = null;
		try {
			DataSource dataSource = (DataSource) dataSourceService.getDataSource(dataSourceName);
			conn = dataSource.getConnection();
		} catch (Exception e) {
			log.error(" Unable to get connection ", e);
		}
		return conn;
	}

	/**
	 * This is executeQuery.
	 * 
	 * @param response
	 *            - SlingHttpServletResponse
	 * @param request
	 *            - SlingHttpServletRequest
	 */
	@SuppressWarnings("unchecked")
	public void executeQuery(SlingHttpServletResponse response, SlingHttpServletRequest request) {
		ResultSet rs = null;
		String id = request.getParameter("marketId");
		JSONArray json = new JSONArray();
		boolean isNumber = StringUtils.isNumeric(id);

		try {
			if (!isNumber) {
				response.getWriter().write(json.toString());
				return;
			}

			String qry = " SELECT b.app_ee_category_id VALUE, category_name LABEL " + "FROM device.app_c_category a, "
					+ "device.app_ee_category b, " + " device.APP_EE_CATEGORY_MARKET_ASSOC c "
					+ " WHERE     a.app_category_id = c.app_category_id "
					+ "  AND c.app_ee_category_id = b.app_ee_category_id " + " AND TYPE = 2 "
					+ " AND a.app_category_id = ? " + "UNION "
					+ " SELECT app_category_id VALUE, app_category_name LABEL " + " FROM device.app_c_category "
					+ "  WHERE     TYPE = 1 " + " AND parent_app_area_id IS NOT NULL " + " AND parent_app_area_id = ? "
					+ " ORDER BY LABEL ";

			try (Connection con = getDataBaseConnection(DBSOURCE); 
				PreparedStatement ps = con.prepareStatement(qry)) {
				ps.setString(1, id);
				ps.setString(2, id);

				rs = ps.executeQuery();

				ResultSetMetaData metadata = rs.getMetaData();
				int numColumns = metadata.getColumnCount();
				while (rs.next()) {

					JSONObject obj = new JSONObject(); // extends HashMap
					for (int i = 1; i <= numColumns; ++i) { // iterate columns

						String columnName = metadata.getColumnName(i);
						obj.put(columnName, rs.getObject(columnName));
					}
					json.put(obj);
				}
				response.setCharacterEncoding("UTF-8");
				response.getWriter().write(json.toString());
			} catch (JSONException e) {
				log.error("JSONException", e);
			} catch (SQLException e) {
				log.error(" Error getting query ", e);
			}
		} catch (IOException e) {
			log.error("SQLException", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

			} catch (SQLException e) {
				log.error(" Exception closing connection", e);
			}
		}
	}
}
