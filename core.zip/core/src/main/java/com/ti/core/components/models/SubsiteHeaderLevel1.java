package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.ApiPortalService;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SubsiteHeaderLevel1 {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	@OSGiService(injectionStrategy = InjectionStrategy.REQUIRED)
	private ApiPortalService apiPortalService;

	@ValueMapValue(name = "level1Title")
	private String title;

	@ValueMapValue(name = "level1URL")
	private String url;

	private Boolean secure;
	private Boolean selected;

	@ChildResource(name = "level2Links")
	private Collection<SubsiteHeaderLevel2> children;

	@PostConstruct
	public void init() {
		try {
			children = CollectionUtils.emptyIfNull(children);
			if (StringUtils.isEmpty(url)) {
				secure = children.stream().allMatch(c -> c.isSecure());
				url = "";
			} else {
				secure = apiPortalService.isSecureUrl(url);
				url = apiPortalService.getUrl(url);
			}
			selected = false;
		} catch(Exception ex) {
			log.error( "Exception in SubsiteHeaderLevel1", ex );
		}
	}

	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}

	public Boolean isSecure() {
		return secure;
	}

	public Boolean isSelected() {
		return selected;
	}

	public void setSelected(Boolean value) {
		selected = value;
	}

	public Collection<SubsiteHeaderLevel2> getChildren() {
		return children;
	}
}
