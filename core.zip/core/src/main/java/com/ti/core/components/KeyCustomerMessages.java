package com.ti.core.components;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Overview WCMUsePojo.
 */
public class KeyCustomerMessages extends WCMUsePojo {
	protected static final Logger log = LoggerFactory.getLogger(KeyCustomerMessages.class);
  private static final String BENEFIT_ITEMS = "benefitsItems";
  private int benefitCount = 0;
  private int[] itemDelay;

  public int getBenefitCount() {
    return benefitCount;
  }

  public int[] getItemDelay() {
    return itemDelay;
  }


  @Override
  public void activate() throws Exception {
    try {        
      Resource listItemsRes = getResource().getChild(BENEFIT_ITEMS);
      if (Objects.nonNull(listItemsRes) && listItemsRes.hasChildren()) {
        ArrayList<Integer> itemDelayList = new ArrayList<>();
        int i = 0;
        Iterator<Resource> iterator = listItemsRes.listChildren();
        while (iterator.hasNext()) {
          itemDelayList.add(200 + (300*i));
          benefitCount++;
          i++;
          iterator.next();
        }
        itemDelay = new int[itemDelayList.size()];
        for (int j=0; j < itemDelayList.size(); j++)
        {
          itemDelay[j] = itemDelayList.get(j).intValue();
        }
      }
    } catch (Exception e) {
      log.error("Exception: ", e);
    }
  }

}
