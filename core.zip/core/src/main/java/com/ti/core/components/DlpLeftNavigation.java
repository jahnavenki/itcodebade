package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.NestedLevels;
import com.ti.core.util.PathBrowserHelper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DlpLeftNavigation extends WCMUsePojo {

    /* LEVEL 0 */
    private static final String LEVEL_ZERO_TITLE = "level0Title";
    /* LEVEL 1 */
    private static final String LEVEL_ONE_LINK = "level1Link";
    private static final String LEVEL_ONE_URL = "level1URL";
    /* LEVEL 2 */
    private static final String LEVELTWO_FIELDS = "level2MultiFields";
    private static final String LEVEL_TWO_LINK = "level2Link";
    private static final String LEVEL_TWO_URL = "level2URL";
    /* LEVEL 3 */
  
    private static final String LEVEL_THREE_LINK = "level3Link";
    private static final String LEVEL_THREE_URL = "level3URL";

    private static final String SLASH = "/";

    /**
     * The log.
     */
    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * Level Zero Title.
     */
    private String level0Title;
    /**
     * Level 1 Link.
     */
    private String level1Link;
    /**
     * Level 1 URL.
     */
    private String level1Url;
 
    /**
     * The level 2 list.
     */
    List<NestedLevels> levels = new ArrayList<>();

    private Boolean selected;

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    public String getLevel0Title() {
        return level0Title;
    }

    public void setLevel0Title(String level0Title) {
        this.level0Title = level0Title;
    }

    public String getLevel1Link() {
        return level1Link;
    }

    public void setLevel1Link(String level1Link) {
        this.level1Link = level1Link;
    }

    public String getLevel1Url() {
        return level1Url;
    }

    public void setLevel1Url(String level1Url) {
        this.level1Url = level1Url;
    }

    public List<NestedLevels> getLevels() {
        return levels;
    }

    public void setLevels(List<NestedLevels> levels) {
        this.levels = levels;
    }

    @Override
    public void activate() throws JSONException {
        setLevel0Title(getProperties().get(LEVEL_ZERO_TITLE, String.class));
        setLevel1Link(getProperties().get(LEVEL_ONE_LINK, String.class));
        String pagePath = getCurrentPage().getPath();
        String level1 = getProperties().get(LEVEL_ONE_URL, String.class);
        setSelected(StringUtils.equals(pagePath.substring(0, pagePath.lastIndexOf(SLASH)), level1.substring(0, level1.lastIndexOf(SLASH))));
        String url = PathBrowserHelper
                .addHtmlIfContentPath(getResourceResolver(), getProperties().get(LEVEL_ONE_URL, String.class));
        setLevel1Url(url);

        for (Resource nodeChild : getResource().getChildren()) {
            if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(LEVELTWO_FIELDS)) {
                for (Resource level2Field : nodeChild.getChildren()) {
                    NestedLevels level2 = new NestedLevels();
                    ValueMap properties = level2Field.adaptTo(ValueMap.class);
                    if (null != properties) {
                        if (!StringUtils.isBlank(properties.get(LEVEL_TWO_LINK, String.class))) {
                            level2.setLink(properties.get(LEVEL_TWO_LINK, String.class));
                            level2.setUrl(properties.get(LEVEL_TWO_URL, String.class));
                            level2.setSelected(StringUtils.equals(pagePath.substring(0, pagePath.lastIndexOf(SLASH)), level2.getUrl().substring(0, level2.getUrl().lastIndexOf(SLASH))));
                            String url2 = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get(LEVEL_TWO_URL, String.class));
                            level2.setUrl(url2);
                        }
                        if (level2Field.hasChildren()) {
                            List<NestedLevels> level3Links = new ArrayList<>();
                            for (Resource level3Field : level2Field.getChildren()) {
                                if (level3Field.hasChildren()) {
                                    for (Resource level3FieldItems : level3Field.getChildren()) {
                                        ValueMap level3properties = level3FieldItems.adaptTo(ValueMap.class);
                                        NestedLevels level3 = new NestedLevels();
                                        if (!StringUtils.isBlank(level3properties.get(LEVEL_THREE_LINK, String.class))) {
                                            level3.setLink(level3properties.get(LEVEL_THREE_LINK, String.class));
                                            level3.setUrl(level3properties.get(LEVEL_THREE_URL, String.class));
                                            level3.setSelected(StringUtils.equals(pagePath.substring(0, pagePath.lastIndexOf(SLASH)), level3.getUrl().substring(0, level3.getUrl().lastIndexOf(SLASH))));
                                            String url3 = PathBrowserHelper
                                                    .addHtmlIfContentPath(getResourceResolver(), level3properties.get(LEVEL_THREE_URL, String.class));
                                            level3.setUrl(url3);
                                            level3Links.add(level3);

                                        }
                                    }
                                    level2.setLevel34Links(level3Links);
                                }
                            }
                        }
                        levels.add(level2);
                    }
                }
            }
        }
    }
}
