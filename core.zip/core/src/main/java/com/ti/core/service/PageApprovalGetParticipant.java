package com.ti.core.service;

import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.ParticipantStepChooser;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.metadata.MetaDataMap;

/**
 * PageApprovalGetParticipant ParticipantStepChooser.
 * 
 * @author abhishek.bhusari
 *
 */

@Component(service = ParticipantStepChooser.class, property = {
		"service.description=Page approval get workflow participant.",
		"chooser.label=Page Approval Get Workflow Participant" })
public class PageApprovalGetParticipant implements ParticipantStepChooser {
	protected final Logger log = LoggerFactory.getLogger(PageApprovalGetParticipant.class);

	@Override
	public String getParticipant(WorkItem item, WorkflowSession wfsession, MetaDataMap args) throws WorkflowException {
		final WorkflowData workflowData = item.getWorkflowData();
		String approver = "notFound";
		try {
			if (workflowData.getMetaDataMap().get("approver") != null) {
				approver = workflowData.getMetaDataMap().get("approver").toString();
			}
		} catch (Exception e) {
			log.error("RepositoryException thrown while setting the properties on workflow payload metadata node" + e);
			return null;
		}
		return approver;
	}
}
