package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.Asset;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApplicationStory extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(ApplicationStory.class);

    private String imageAltText;

    public String getImageAltText() {
        return imageAltText;
    }

    @Override
    public void activate() throws Exception {
        try {
            // Get title from DAM property and set as alt text for image
            Resource resource = getResourceResolver().getResource(getProperties().get("fileReference").toString());
            if (resource != null) {
                Asset asset = resource.adaptTo(Asset.class);
                if (asset != null) {
                    this.imageAltText = asset.getMetadataValue("dc:title");
                }
            }

        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
}
