package com.ti.core.models;

import org.apache.sling.api.resource.ResourceResolver;

import com.ti.core.util.PathBrowserHelper;

/**
* @param ctaText,ctaUrl
*          the ctaText to set.
*          the ctaUrl to set.
*          
*     get ctaText,ctaUrl.
* @return the ctaText,ctaUrl.
*         
**/

public class LinkListModel {
  private String ctaText;
  private String ctaUrl;
  private String editModeUrl;
  private String language;
  private Integer order;
  private ResourceResolver resolver;
  public String getCtaText() {
    return ctaText;
  }

  public void setCtaText(final String ctaText) {
    this.ctaText = ctaText;
  }

  public String getCtaUrl() {
    return PathBrowserHelper.addHtmlIfContentPath(this.resolver,ctaUrl);
  }

  public void setCtaUrl(final String ctaUrl) {
    this.ctaUrl = ctaUrl;
	}

  public String getEditModeUrl() {
    return editModeUrl;
  }

  public void setEditModeUrl(final String editModeUrl) {
    this.editModeUrl = editModeUrl;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(final String language) {
    this.language = language;
  }
  
	/**
	 * @return the order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * @param order
	 *            the order to set
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}

	public ResourceResolver getResolver() {
		return resolver;
	}

	public void setResolver(ResourceResolver resolver) {
		this.resolver = resolver;
	}
}
