package com.ti.core.service;

public interface ApiPortalService {
	public Boolean isSecureUrl(String url);

	public String getUrl(String url);
}
