package com.ti.core.util;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * WorkflowUtils
 */
public class WorkflowUtils {

	private WorkflowUtils() {
	}

	private static final Logger log = LoggerFactory.getLogger(WorkflowUtils.class);

	public static void updateExpiredAssetProperty(Resource assetJcrRes, ResourceResolver resolver) {
		try {
			Resource metadataRes = Objects.nonNull(assetJcrRes) ? assetJcrRes.getChild("metadata") : null;
			ValueMap map = Objects.nonNull(metadataRes) ? metadataRes.getValueMap() : null;
			Date assetExpiredDate = Objects.nonNull(map) ? map.get("prism:expirationDate", Date.class) : null;
			Date currentDate = Calendar.getInstance().getTime();
			ModifiableValueMap modifiedMap = Objects.nonNull(assetJcrRes)
					? assetJcrRes.adaptTo(ModifiableValueMap.class) : null;
			if (Objects.nonNull(modifiedMap)) {
				modifiedMap.put("cq:expirationStatus",
						(!Objects.isNull(assetExpiredDate) && assetExpiredDate.compareTo(currentDate) <= 0) ? "Expired"
								: "Not Expired");
				resolver.commit();
			}
		} catch (PersistenceException e) {
			log.error("PersistenceException {}", e);
		}
	}
}