package com.ti.core.components;
import com.ti.core.models.AppHierarchyNode;
import com.ti.core.models.Link;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FeaturedEEApplications extends WCMUsePojo {
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	// WS requires application ID, but component does not.
	private static final int APPLICATION_ID_INDUSTRIAL = 120;
	private static final String URL_PATH = "/content/texas-instruments/";
	private static final String APPLICATIONS_LANDING_PAGE_HEADING = "applicationpageheadi";
	private static final String SUB_HEADLINE = "subheadline";

	private final List<Link> links = new ArrayList<>();

	public List<Link> getLinks() {
		links.sort((o1, o2) -> (o1.getText().compareToIgnoreCase(o2.getText())));
		return links;
	}

	public boolean hasHref() {
		for( final var link : links ) {
			if (StringUtils.isNotEmpty(link.getHref())) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public void activate() {
		try {
			final var pageProperties = getPageProperties();
			final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (null == wcmService) {
				return;
			}
			final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if (null == tabsService) {
				return;
			}
			final var language = tabsService.getPageLanguage(getCurrentPage());
			final var applicationId = pageProperties.get("applicationId", "");
			final var sectorId = pageProperties.get("sectorId", "");
			JSONObject jsonObject = null;
			if (StringUtils.isEmpty(applicationId)) {
				jsonObject = wcmService.getAllApplicationService(getRequest(), APPLICATION_ID_INDUSTRIAL, language);
			} else {
				jsonObject = wcmService.getAllApplicationService(getRequest(), Integer.parseInt(applicationId), language);
			}
			if( StringUtils.isNotEmpty(sectorId) ) { // sector page
				links.addAll( buildData( jsonObject, Integer.parseInt(sectorId), language ) );
			} else { // landing page
				links.addAll( buildData( jsonObject, -1 ,language ));
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
	//Seraching for heading component on overview page for Sub headline
	private Resource getHeadingComponent(Resource rootResource) {
        for (Resource gridResource : rootResource.getChildren()) {
            for (Resource nodeChild : gridResource.getChildren()) { 
                if (nodeChild != null && APPLICATIONS_LANDING_PAGE_HEADING.indexOf(nodeChild.getName().toLowerCase()) > -1) {
                    return nodeChild;
                }
            }
        } 
        return null;
    }

	/* Find EE categores on sector page that have a published EE Category page 
	(those that have a Learn more link in the Application listing component) */

	private List<Link> buildData( JSONObject jsonObject, int pageId, String language ) throws JSONException {
		final var retval = new ArrayList<Link>();
		if (null == jsonObject) return retval;
		final var appHierarchyMap = new HashMap<Integer, AppHierarchyNode>();
		final var appHierarchyList = new ArrayList<AppHierarchyNode>();
		final var jsonAppHierarchyList = jsonObject.getJSONArray("AppHierarchyList");
		for (var i = 0; i < jsonAppHierarchyList.length(); ++i ) {
			final var node = new AppHierarchyNode( jsonAppHierarchyList.getJSONObject(i) );
			appHierarchyList.add(node);
			appHierarchyMap.put(node.getChildId(), node);
		}
		AppHierarchyNode currentNode = null;
		final var topLevel = new ArrayList<AppHierarchyNode>();
		for (final var node : appHierarchyList) {
			if (null == node.getParentAppId()) {
				topLevel.add( node );
			} else {
				var parentNode = appHierarchyMap.get( node.getParentAppId() );
				if (null == parentNode) {
					topLevel.add( node );
				} else {
					node.setParent(parentNode);
					parentNode.getChildren().add(node);
				}
				if (null != node.getVirtualParentId() ) {
					var vParentNode = appHierarchyMap.get( node.getVirtualParentId() );
					vParentNode.getChildren().add(node);
				}
			}
			if (pageId == node.getChildId()) {
				currentNode = node;
			}
		}

		List<AppHierarchyNode> currentLevel;
		if (null == currentNode) {
			currentLevel = topLevel;
		} else {
			currentLevel = currentNode.getChildren();
		}

		for (final var node : currentLevel) {
			final var link = new Link();
			link.setText( node.getSectionName() );
			link.setEnText( node.getEnSectionName() );
			if(StringUtils.isNotEmpty(node.getAppUrl())){
				String pageUrl;
				pageUrl= node.getAppUrl();
				pageUrl= URL_PATH + language+"/" + pageUrl.substring(pageUrl.indexOf("applications"), pageUrl.lastIndexOf('.'));
				final Resource resource = getResourceResolver().getResource(pageUrl);
				if (null == resource) {
					log.debug("Page resource is null");
					return retval;
				}
				final Resource rootResource= resource.getChild("jcr:content/root");
				if (null == rootResource) {
					log.debug("Page root is null");
					return retval;
				}
				Resource nodeHeading = getHeadingComponent(rootResource);
				if (null == nodeHeading) {
					log.debug("Heading component not found");
					return retval;
				}
				ValueMap map = nodeHeading.getValueMap();
				if(map.get(SUB_HEADLINE)!=null){
					link.setHref( node.getAppUrl() );
					link.setDescription(map.get(SUB_HEADLINE).toString());
				}

			}
			retval.add(link);
		}
		return retval;
	}
}
