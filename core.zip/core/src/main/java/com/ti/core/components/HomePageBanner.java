package com.ti.core.components;

import org.apache.commons.lang3.StringUtils;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.text.SimpleDateFormat;
import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Overview WCMUsePojo.
 */
public class HomePageBanner extends WCMUsePojo {

	protected static final Logger log = LoggerFactory.getLogger(HomePageBanner.class);
	protected ValueMap properties;
	protected String primaryCtaUrl;
	protected String campaignAlias;
	protected Date startTime;
	protected Date timelineStartTime;
	protected Date endTime;
	protected Date timelineEndTime;
	protected Date jackExpirationTime;
	protected SimpleDateFormat format;

	enum BannerStatus {
		NOT_ACTIVE, ACTIVE, EXPIRED, JACK_EXPIRED;
	}

	private BannerStatus status;

	@Override
	public void activate() {
		try {
			status = BannerStatus.NOT_ACTIVE;

			properties = getProperties();
			primaryCtaUrl = properties.get("primaryCtaUrl", String.class);
			campaignAlias = properties.get("campaignAlias", String.class);
			format = new SimpleDateFormat("EEE, d MMM yyyy"); // "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
			Date currentTime = new Date();
			startTime = properties.get("startTime", Date.class);
			endTime = properties.get("endTime", Date.class);
			Calendar tmpDate = Calendar.getInstance();
			tmpDate.set(Calendar.HOUR_OF_DAY, 0);
			tmpDate.set(Calendar.MINUTE, 0);
			tmpDate.set(Calendar.SECOND, 0);
			tmpDate.set(Calendar.MILLISECOND, 0);
			timelineStartTime = tmpDate.getTime();
			tmpDate.add(Calendar.DATE, 99);
			timelineEndTime = tmpDate.getTime();
			jackExpirationTime = properties.get("jackExpirationTime", Date.class);

			// Determine the banner status
			if (startTime != null && startTime.before(currentTime))
				status = BannerStatus.ACTIVE;

			if (status == BannerStatus.ACTIVE && endTime != null) {
				if (!endTime.after(startTime))
					status = BannerStatus.NOT_ACTIVE;
				else if (!currentTime.before(endTime))
					status = BannerStatus.EXPIRED;	
			}

			if (status == BannerStatus.EXPIRED && jackExpirationTime != null && !currentTime.before(jackExpirationTime))
				status = BannerStatus.JACK_EXPIRED;
			
			processCampaignAlias();
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
	}

	public Boolean isNotActive() {
		return (status == BannerStatus.NOT_ACTIVE);
	}

	public Boolean isActive() {
		return (status == BannerStatus.ACTIVE);
	}

	public Boolean isExpired() {
		return (status == BannerStatus.EXPIRED);
	}

	public Boolean isJackExpired() {
		return (status == BannerStatus.JACK_EXPIRED);
	}
	
	public String getBannerStatus() {
		switch (status) {
			case JACK_EXPIRED: return "banner_jackexpired";
			case EXPIRED: return "banner_expired";
			case ACTIVE: return "banner_active";
			default: return "banner_inactive";
		}
	}
	
	void processCampaignAlias() {
		// Process campaign alias by adding country code ending
		if (!StringUtils.isEmpty(campaignAlias)) {
			Locale loc = getCurrentPage().getLanguage(true);
			String region = "wwe";
			if (loc != null) {
				region = loc.getCountry().toLowerCase();
			}
			if ("vn".equals(region))
				region = "vi";
			else if ("us".equals(region))
				region = "wwe";
			campaignAlias += "-" + region;
		}
	}
	
	public String getCampaignAlias() {	
		return (StringUtils.isEmpty(campaignAlias) ? StringUtils.EMPTY : campaignAlias);
	}
	
	public String getCampaignUrl() {
		String url = primaryCtaUrl;

		if (!StringUtils.isEmpty(url) && !StringUtils.isEmpty(campaignAlias)) {
			String hashValue = StringUtils.EMPTY;
			if (url.indexOf('#') > 1) {
				hashValue = url.substring(url.indexOf('#'),url.length());
				url = url.substring(0, url.indexOf('#'));
			}
			url += (url.contains("?") ? "&" : "?") + "HQS=" + campaignAlias + hashValue;
		}
		return url;
	}
	
	public String getStarttime() {
		if (startTime != null) {
			return format.format(startTime);
		}
		return StringUtils.EMPTY;
	}

	public String getEndtime() {
		if (endTime != null) {
			return format.format(endTime);
		}
		return StringUtils.EMPTY;
	}

	public String getJackExpirationTime() {
		if (jackExpirationTime != null) {
			return format.format(jackExpirationTime);
		}
		return StringUtils.EMPTY;
	}
	
	public long getTimelineStartOffset() {
		try {
			if (startTime == null || timelineStartTime == null || timelineEndTime == null)
				return 0;
				
			long startdiff = TimeUnit.MILLISECONDS.toDays(startTime.getTime()) - TimeUnit.MILLISECONDS.toDays(timelineStartTime.getTime());

			if (startdiff > 0) {
				long enddiff = TimeUnit.MILLISECONDS.toDays(timelineEndTime.getTime()) - TimeUnit.MILLISECONDS.toDays(startTime.getTime());

				if (enddiff > 0)
					return startdiff;
			}
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
		return 0;
	}

	public long getTimelineDuration() {
		try {
			if (startTime != null && timelineStartTime != null && timelineEndTime != null) {
				if (endTime == null)
					endTime = timelineEndTime;
				
				long maxStartTime = Math.max(startTime.getTime(), timelineStartTime.getTime());
				long minEndTime = Math.min(endTime.getTime(), timelineEndTime.getTime());

				return TimeUnit.MILLISECONDS.toDays(minEndTime) - TimeUnit.MILLISECONDS.toDays(maxStartTime) + 1;
			}			
		} catch (Exception e) {
			log.error("Exception: ", e);
		}
		return 0;
	}

}