package com.ti.core.models;

import java.util.LinkedList;
import java.util.List;

public class ProductTreeModel {

	private String familyName;
	private int deviceCount;
	private String productNodeUrl;
	private int treelevel;
	private boolean selected;
	private LinkedList<ProductTreeModel> children;
	private String altProductTreeFlag;
	private String inputMode;
	private String childId;
	private String navAvailability;
	private String navLink;
	private String parentAppId;

	public String getParentAppId() {
		return parentAppId;
	}

	public void setParentAppId(String parentAppId) {
		this.parentAppId = parentAppId;
	}

	public String getInputMode() {
		return inputMode;
	}

	public void setInputMode(String inputMode) {
		this.inputMode = inputMode;
	}

	public String getAltProductTreeFlag() {
		return altProductTreeFlag;
	}

	public void setAltProductTreeFlag(String altProductTreeFlag) {
		this.altProductTreeFlag = altProductTreeFlag;
	}

	public ProductTreeModel() {
		children = new LinkedList<>();
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public int getDeviceCount() {
		return deviceCount;
	}

	public void setDeviceCount(int deviceCount) {
		this.deviceCount = deviceCount;
	}

	public String getProductNodeUrl() {
		return productNodeUrl;
	}

	public void setProductNodeUrl(String productNodeUrl) {
		this.productNodeUrl = productNodeUrl;
	}

	public int getTreelevel() {
		return treelevel;
	}

	public void setTreelevel(int treelevel) {
		this.treelevel = treelevel;
	}

	public List<ProductTreeModel> getChildren() {
		return children;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getChildId() {
		return childId;
	}

	public void setChildId(String childId) {
		this.childId = childId;
	}

	public String getNavAvailability() {
		return navAvailability;
	}

	public void setNavAvailability(String navAvailability) {
		this.navAvailability = navAvailability;
	}

	public String getNavLink() {
		return navLink;
	}

	public void setNavLink(String navLink) {
		this.navLink = navLink;
	}
}
