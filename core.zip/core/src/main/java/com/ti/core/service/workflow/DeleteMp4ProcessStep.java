package com.ti.core.service.workflow;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.apache.sling.api.resource.Resource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.ModifiableValueMap;


import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.ti.core.util.AssetUtils;

import javax.jcr.Node;



@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step for delete mp4.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Delete mp4" })
public class DeleteMp4ProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	public void execute(WorkItem item, WorkflowSession wfsession, MetaDataMap args) {
		try {
			ResourceResolver resourceResolver = wfsession.adaptTo(ResourceResolver.class);
			final var workflowData = item.getWorkflowData();
			var payload = workflowData.getPayload().toString();
			var path = payload.concat("/jcr:content/renditions/original"); 
			Resource payloadRes = resourceResolver.getResource(path); 
			Node renditionNode = payloadRes.adaptTo(Node.class);
			renditionNode.remove();
			final var resource = resourceResolver.getResource(payload);
			ModifiableValueMap metadata = AssetUtils.getModifiableMetadata(resource);
			metadata.put("dam:size","");
		}
			catch (Exception e) {
			log.error("Error occurred in DeleteMp4ProcessStep", e);
		}
	}
}
