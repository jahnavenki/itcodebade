package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.PathBrowserHelper;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SupportCarousel extends WCMUsePojo {
    private static final Logger log = LoggerFactory.getLogger(SupportCarousel.class);

    private LanguageUtils languageUtils;
    private String heading;
    private String anchorLinkId;

    public String getHeading() {
        return heading;
    }

    public String getAnchorLinkId() {
        return anchorLinkId;
    }

    private final List<SupportCarouselCard> supportCarouselCards = new ArrayList<>();
    public List<SupportCarouselCard> getSupportCarouselCards() {
        return supportCarouselCards;
    }

    public class SupportCarouselCard {
        private String dialogResourceType;
        private String resourceType;
        private String title;
        private String description;
        private String resourceUrl;
        private String resourceTypeEnglish;
        private String litNumber;

        public String getDialogResourceType() {
            return dialogResourceType;
        }

        public String getResourceType() {
            return resourceType;
        }

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getResourceUrl() {
            return resourceUrl;
        }

        public String getResourceTypeEnglish() {
            return resourceTypeEnglish;
        }

        public String getLitNumber() {
            return litNumber;
        }
    }

    @Override
    public void activate() {
        try {
            languageUtils = new LanguageUtils(getRequest());
            final var res = getResource();
            final var valueMap = res.adaptTo(ValueMap.class);
            if ("authored".equals(valueMap.get("sectionHeadingRadio", String.class))) {
                heading = valueMap.get("sectionHeading", String.class);
            } else {
                heading = languageUtils.getI18nStr("designResources:educationalResources");
            }
            anchorLinkId = valueMap.get("anchorLinkId", String.class);
            final var cardsRes = res.getChild("cards");
            if (null != cardsRes) {
                for (final var cardRes : cardsRes.getChildren()) {
                    final var supportCarouselCard = buildSupportCarouselCard(cardRes);
                    if (null != supportCarouselCard) {
                        supportCarouselCards.add(supportCarouselCard);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    private SupportCarouselCard fetchLiteratureResponse(ValueMap properties) {
        final var supportCarouselCard = new SupportCarouselCard();
        final var wcmService = getSlingScriptHelper().getService(WCMComponents.class);
        if (null != wcmService) {
            var pageLanguage = "en-us";
            final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                pageLanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
            }
            final var litNumber = properties.get("litNumber", String.class);
            try {
                final var litResponse = wcmService.getFeaturedliterature(litNumber, pageLanguage);
                if (StringUtils.isNotEmpty(litResponse)) {
                    final var jsonLiterature = new JSONObject(litResponse);
                    final var litNumberFromDB = jsonLiterature.getString("literatureNumber").substring(0,7);
                    final var resourceUrl = languageUtils.getI18nStr("https://www.ti.com/lit/") + litNumberFromDB;
                    final var resourceType = properties.get("resourceType", String.class);
                    supportCarouselCard.dialogResourceType = resourceType;
                   	if ("technicalDocs".equals(resourceType) && !jsonLiterature.isNull("documentCategory")) {
                        var docCategory = jsonLiterature.getJSONObject("documentCategory").getString("docCategory");
                        supportCarouselCard.resourceType = languageUtils.getI18nStr( docCategory );
                    } else {
                        supportCarouselCard.resourceType = languageUtils.getI18nStr( "resourceType:" + resourceType );
                    }
                    supportCarouselCard.title = jsonLiterature.getString("conciseDescription");
                    supportCarouselCard.description = properties.get("description", String.class);
                    supportCarouselCard.resourceUrl = resourceUrl;
                    supportCarouselCard.resourceTypeEnglish = resourceType;
                    supportCarouselCard.litNumber = litNumber;
                } else {
                    log.debug("Json response is empty or null");
                }
            } catch (Exception e) {
                log.error("Exception : ", e);
            }
        }
        return supportCarouselCard;
    }

    private SupportCarouselCard buildSupportCarouselCard(Resource resource) {
        final var properties = resource.adaptTo(ValueMap.class);
        final var resourceType = properties.get("resourceType",String.class);
        if ("technicalDocs".equals(resourceType)) {
            return fetchLiteratureResponse(properties);
        } else {
            final var supportCarouselCard = new SupportCarouselCard();
            supportCarouselCard.resourceType = languageUtils.getI18nStr( "resourceType:" + resourceType );
            supportCarouselCard.title = properties.get("title", "");
            supportCarouselCard.description = properties.get("description", "");
            supportCarouselCard.resourceUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get("resourceUrl", ""));
            supportCarouselCard.resourceTypeEnglish = resourceType;
            return supportCarouselCard;
        }
    }
}
