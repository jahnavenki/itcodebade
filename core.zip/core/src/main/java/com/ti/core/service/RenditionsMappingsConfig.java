package com.ti.core.service;

/**
 * Service Interface to interact with Renditions Mappings service.
 * 
 * @author Richard Chan
 */
public interface RenditionsMappingsConfig {

	
	/**
	 * Returns the renditions mappings, each mapping is a string representation of an JSONObject
	 * 
	 * @return String[]
	 */
	public String[] getRenditionsMappings();
}