package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.ReportingUtils;

/**
 * This class will return reports in JSON Format based on the one requested.
 * Reports can be requested by adding the value as part of the query parameter
 * ?report=
 *
 * @author saryu.sukumar
 */


@SuppressWarnings("serial")
@Component(service = Servlet.class, immediate=true, property = {
		SLING_SERVLET_PATHS + "=/bin/tireporting", 
		SLING_SERVLET_METHODS + "=GET" })
public class ReportingExport extends SlingSafeMethodsServlet {

	private static final String PROPERTY_LAST_MODIFIED = "lastModified";
	private static final String PROPERTY_TAG = "TAG";
	private static final String PROPERTY_I18NDICTIONARY = "I18NDICTIONARY";
	private static final String PROPERTY_CONTENTFRAGMENT = "CONTENTFRAGMENT";
	private static final String PROPERTY_PAGE = "PAGE";
	private static final String PROPERTY_ASSET = "ASSET";

	private static final String EXCEPTION_MESSAGE = "Exception: ";
	private static final String REPORT_PARAMETER = "report";
	private static final String AEM_USER_REPORT = "aemuser";
	private static final String COMPONENT_REPORT = "component";
	private static final String PAGE_ACTIVITY_REPORT = "pageactivity";
	private static final String WORKFLOW_REPORT = "workflow";
	private static final String TRANSLATION_REPORT = "translation";
	private static final String METADATA_REPORT = "metadata";
	private static final String SOURCE_LANGUAGE = "sourceLanguage";
	private static final String DESTINATION_LANGUAGE = "destinationLanguage";
	private static final String ASSET_REPORT = "assetreport";
	private static final String DAM_ANALYTICS_REPORT = "damassetanalytics";
	private static final String DAM_ASSET_UPLOADED = "damassetuploaded";
	private static final String DAM_ASSET_EVMBOARD = "damasset-evm-board";
	private static final String AEM_HIERARCHY_PAGES = "aem-hierarchy-pages";
	private static final String AEM_PAGE_COMPONENTS_REPORT = "aem-page-components";
	private static final String REPORT_TYPE = "output";
	private static final String REPORT_PATH = "path";
	private static final String DAM_ASSET_DETAILS = "damassetdetails";

	private String output_type_value;
	private Date startedtime = null;
	private String path;
	private static final Set<String> compExcludelist = new HashSet<>(
			Arrays.asList("table-cell", "table-header", "table-cell-image"));
	private transient ResourceResolver resourceResolver;
	private transient Session session;

	/** The log. */
	protected static final Logger log = LoggerFactory.getLogger(ReportingExport.class);

	@Reference
	private transient Externalizer externalizer;

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	@Reference
	private transient ProductNavigationTabsOrdering tabsService;

	@Reference
	private transient SeoUrlFactoryConfigs factoryConfigs;

	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		resourceResolver = request.getResourceResolver();
		session = resourceResolver.adaptTo(Session.class);

		String reportType = request.getParameter(REPORT_PARAMETER);
		this.output_type_value = request.getParameter(REPORT_TYPE);
		this.path = request.getParameter(REPORT_PATH);

		log.debug("output type " + this.output_type_value);
		log.debug("report type " + reportType);
		if (ReportingUtils.isNotNull(reportType)) {
			switch (reportType) {
				case AEM_USER_REPORT:
					ReportingUtils.getAemUser(request, response, this.output_type_value);
					break;
				case COMPONENT_REPORT:
					getComponentReport(request, response);
					break;
				case PAGE_ACTIVITY_REPORT:
					getPageActivityReport(request, response);
					break;
				case WORKFLOW_REPORT:
					getWorkflowReport(request, response);
					break;
				case TRANSLATION_REPORT:
					getTranslationReport(request, response);
					break;
				case METADATA_REPORT:
					ReportingUtils.getMetadataReport(request, response, this.output_type_value, session);
					break;
				case DAM_ANALYTICS_REPORT:
					ReportingUtils.getDamAnalyticsReport(request, response, externalizer, this.output_type_value);
					break;
				case ASSET_REPORT:
					ReportingUtils.getAssetReport(request, response, externalizer, this.output_type_value);
					break;
				case DAM_ASSET_UPLOADED:
					ReportingUtils.getDAMAssetUploadedReport(request, response, externalizer, this.output_type_value);
					break;
				case DAM_ASSET_EVMBOARD:
					ReportingUtils.getDAMAssetEvmboard(request, response, externalizer, this.output_type_value);
					break;
				case AEM_HIERARCHY_PAGES:
					ReportingUtils.getAemHierachyPages(request, response, externalizer, this.output_type_value);
					break;
				case AEM_PAGE_COMPONENTS_REPORT:
					ReportingUtils.getAemPageComponentsReport(request, response, wcmService, tabsService, factoryConfigs, this.output_type_value);
					break;
				case DAM_ASSET_DETAILS:
					ReportingUtils.getDAMAssetDetails(request, response, externalizer, this.output_type_value);
					break;
				default:
					response.getWriter().write("Pass Report Type in Query Parameter ?report=");
					break;
			}
		}
	}

	/**
	 * This report will return a list of all the components and also the pages
	 * that they are used in
	 *
	 * @param request
	 * @param response
	 */

	private void getComponentReport(SlingHttpServletRequest request, SlingHttpServletResponse response) {

		resourceResolver = request.getResourceResolver();
		// This query will return the list of components under
		// /apps/ti/components
		String sqlStatement = "select * from [cq:Component] AS c WHERE ISCHILDNODE([/apps/ti/components])";
		JSONObject componentJSON = new JSONObject();
		JSONArray componentArray = new JSONArray();
		try {

			NodeIterator nodeIter = ReportingUtils.executeQuery(sqlStatement, session);
			while (ReportingUtils.isNotNull(nodeIter) && nodeIter.hasNext()) {
				// For each node-- get the path of the node
				Node node = nodeIter.nextNode();
				String nodePath = node.getPath();

				// Using substring to ignore the /apps/ from the nodePath
				nodePath = nodePath.substring(6);

				// This query will loop through each page that uses this
				// component
				String sqlStatement2 = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s,'/content/texas-instruments') AND [sling:resourceType] LIKE '"
						+ nodePath + "'";
				NodeIterator componentNodeIter = ReportingUtils.executeQuery(sqlStatement2, session);

				while (ReportingUtils.isNotNull(componentNodeIter) && componentNodeIter.hasNext()) {
					JSONObject compJSON = new JSONObject();
					// For each node-- get the path of the node
					Node componentNode = componentNodeIter.nextNode();

					// Getting the resource in order to retrieve the Value Map
					Resource resource = resourceResolver.getResource(componentNode.getPath());
					ValueMap properties = null != resource ? resource.getValueMap() : null;
					if (null != properties) {
						compJSON = ReportingUtils.createComponentJSON(compJSON, componentNode, properties,
								resourceResolver);
						componentArray.put(compJSON);
					}
				}
				componentJSON.put("Components", componentArray);
			}
			if (StringUtils.equalsIgnoreCase(this.output_type_value, "csv")) {

				CsvListWriter beanWriter = null;

				final String[] header = new String[] { "componentType", "componentPath", "author", "lastModified",
						"image_source", "altText", "Category", "page", "CompletePageUrl" };

				String csvFileName = "Components.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);

				JSONArray array = componentJSON.getJSONArray("Components");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);

					myList.add(json_data.getString("componentType"));
					myList.add(json_data.getString("componentPath"));
					if (!json_data.isNull("author")) {
						myList.add(json_data.getString("author"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("lastModified")) {
						myList.add(json_data.getString("lastModified"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("image_source")) {
						myList.add(json_data.getString("image_source"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("altText")) {
						myList.add(json_data.getString("altText"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("Category")) {
						myList.add(json_data.getString("Category"));
					} else {
						myList.add("NULL");
					}
					myList.add(json_data.getString("page"));
					myList.add(json_data.getString("CompletePageUrl"));
					beanWriter.write(myList);
					myList.clear();
				}

			} else {
				response.getWriter().write(componentJSON.toString());
			}
		} catch (RepositoryException | JSONException | IOException | NullPointerException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * This report will return all the page activity under
	 * /content/texas-instruments
	 *
	 * @param request
	 * @param response
	 * @throws ParseException
	 */
	private void getPageActivityReport(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		String day = request.getParameter("day");
		DateFormat jcrFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 1);
		Date endDate = cal.getTime();
		cal.setTime(today);
		if (StringUtils.isNotBlank(day)) {
			cal.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(day));
		} else {
			cal.add(Calendar.DAY_OF_MONTH, -30);
		}
		Date startDate = cal.getTime();
		JSONObject pageActivityJSON = new JSONObject();
		JSONArray pageActivityArray = new JSONArray();
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String sqlStatement = "SELECT p.* FROM [cq:PageContent] AS p where isdescendantnode(p,'" + (StringUtils.isEmpty(path)?"/content/texas-instruments":path) + "') and p.[cq:lastModified] >= CAST('"
					+ jcrFormat.format(startDate) + "' AS DATE) AND p.[cq:lastModified] <= CAST('"
					+ jcrFormat.format(endDate) + "' AS DATE)";
			NodeIterator nodeIter = ReportingUtils.executeQuery(sqlStatement, session);
			Map<String, Page> map = new HashMap<>();
			while (ReportingUtils.isNotNull(nodeIter) && nodeIter.hasNext()) {
				// For each node-- get the path of the node
				Node node = nodeIter.nextNode().getParent();
				Resource resource = resourceResolver.getResource(node.getPath());
				Page page = resource != null ? resource.adaptTo(Page.class) : null;
				if (Objects.nonNull(page)) {
					String jcrPath = page.getPath() + "/jcr:content";
					if (!StringUtils.isEmpty(jcrPath)) {
						String sqlStatement2 = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s,'" + jcrPath
								+ "')";
						NodeIterator componentIter = ReportingUtils.executeQuery(sqlStatement2, session);

						while (ReportingUtils.isNotNull(componentIter) && componentIter.hasNext()) {
							JSONObject pageJSON = new JSONObject();
							Node componentNode = componentIter.nextNode();
							String slingResourceType = ReportingUtils.getProperties("sling:resourceType",
									componentNode);
							String compname = StringUtils.substringAfterLast(slingResourceType, "/");
							if (compExcludelist.contains(compname)) {
								Property property = componentNode.hasProperty("jcr:lastModified")
										? componentNode.getProperty("jcr:lastModified") : null;
								if (Objects.nonNull(property) && property.getDate().getTime().after(startDate)
										&& !map.containsKey(componentNode.getParent().getPath())) {
									map.put(componentNode.getParent().getPath(), page);
								}
							} else if (createChangesJSON(componentNode, pageJSON, startDate, false)) {
								createPageActivityJson(pageJSON, page, format1, pageActivityArray);
							}
						}
					}
				}
			}
			for (Map.Entry<String, Page> entry : map.entrySet()) {
				JSONObject dataTableJSONObj = new JSONObject();
				Resource dataTableRes = resourceResolver.getResource(entry.getKey());
				if (Objects.nonNull(dataTableRes)) {
					Node dataTableNode = dataTableRes.adaptTo(Node.class);
					if (createChangesJSON(dataTableNode, dataTableJSONObj, startDate, true)) {
						createPageActivityJson(dataTableJSONObj, entry.getValue(), format1, pageActivityArray);
					}
				}
			}
			pageActivityJSON.put("pages", pageActivityArray);
			if (StringUtils.equalsIgnoreCase(this.output_type_value, "csv")) {

				CsvListWriter beanWriter = null;

				final String[] header = new String[] { "pagePath", "CompletePageUrl", "lastModified", "lastModifiedBy",
						"translationDate", "locale", "changes" };

				String csvFileName = "pageactivity.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);

				JSONArray array = pageActivityJSON.getJSONArray("pages");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);

					myList.add(json_data.getString("pagePath"));
					myList.add(json_data.getString("CompletePageUrl"));
					if (!json_data.isNull("lastModified")) {
						myList.add(json_data.getString("lastModified"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("lastModifiedBy")) {
						myList.add(json_data.getString("lastModifiedBy"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("translationDate")) {
						myList.add(json_data.getString("translationDate"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("locale")) {
						myList.add(json_data.getString("locale"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("changed")) {
						myList.add(json_data.getString("changed"));
					} else {
						myList.add("NULL");
					}
					beanWriter.write(myList);

					myList.clear();
				}

			} else {
				response.getWriter().write(pageActivityJSON.toString());
			}
		} catch (RepositoryException | JSONException | IOException | NullPointerException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}

	private void createPageActivityJson(JSONObject pageJSON, Page page, SimpleDateFormat format1,
										JSONArray pageActivityArray) throws JSONException {
		pageJSON.put("pagePath", StringUtils.defaultString(page.getPath()));
		String mappedPath = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, page.getPath()).replaceAll("/content/texas-instruments(/en-us)?", StringUtils.EMPTY);
		pageJSON.put("CompletePageUrl", mappedPath);

		pageJSON.put(PROPERTY_LAST_MODIFIED, format1.format(page.getLastModified().getTime()));
		pageJSON.put("lastModifiedBy", page.getLastModifiedBy());
		Locale locale = page.getLanguage(true);
		pageJSON.put("locale", locale.getLanguage());
		ValueMap properties = page.getProperties();
		if (ReportingUtils.isNotNull(properties.get("cq:lastTranslationUpdate"))) {
			String translatedDate = properties.get("cq:lastTranslationUpdate", String.class);
			pageJSON.put("translationDate", translatedDate);
		} else {
			pageJSON.put("translationDate", "");
		}
		pageActivityArray.put(pageJSON);
	}

	private boolean createChangesJSON(Node componentNode, JSONObject pageJSON, Date startDate, boolean isDataTable)
			throws JSONException, RepositoryException {
		String slingResourceType = ReportingUtils.getProperties("sling:resourceType", componentNode);
		String title = ReportingUtils.getProperties("jcr:title", componentNode);
		Property property = componentNode.hasProperty("jcr:lastModified")
				? componentNode.getProperty("jcr:lastModified") : null;
		if (property == null) {
			return false;
		}
		if (!isDataTable) {
			if (property.getDate().getTime().after(startDate)) {
				pageJSON.put("changed", StringUtils.isEmpty(title) ? slingResourceType : componentNode.getPath());
				return true;
			}
		} else {
			pageJSON.put("changed", StringUtils.isEmpty(title) ? slingResourceType : componentNode.getPath());
			return true;
		}
		return false;
	}
	/**:
	 * This report will return a list of all the workflows
	 *
	 * @param request
	 * @param response
	 */
	private JSONObject createwfJSON(ValueMap properties, String payload, String workflowid, String approver)
			throws JSONException {
		JSONObject wfJSON = new JSONObject();
		String start = properties.get("startTime", String.class);
		String end = properties.get("endTime", String.class);

		log.debug("start and end time " + start + end);

		DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ENGLISH);
		Date startTime = null;
		Date endTime = null;

		String initiator = (String) properties.get("initiator");
		String status = (String) properties.get("status");
		String modelId = (String) properties.get("modelId");
		String model = StringUtils.substringBefore(modelId, "/jcr:content");
		model = model.substring(model.lastIndexOf('/') + 1).trim();

		long duration = 0;

		try {
			if (start != null) {
				startTime = format.parse(start);
			}
			startedtime = startTime;

			if (end != null) {
				endTime = format.parse(end);
			}
			if (StringUtils.equalsIgnoreCase(status, "RUNNING")) {
				Date currentDate = Calendar.getInstance().getTime();
				if (null != startTime)
					duration = Math.abs(currentDate.getTime() - startTime.getTime());

			} else {
				if (endTime != null && startTime != null) {

					duration = Math.abs(endTime.getTime() - startTime.getTime());

				}
			}
			long diffDays = duration / (24 * 60 * 60 * 1000);
			long diffSeconds = duration / 1000 % 60;
			long diffMinutes = duration / (60 * 1000) % 60;
			long diffHours = duration / (60 * 60 * 1000) % 24;
			String finalduration = diffDays + "days" + diffHours + "hrs" + diffMinutes + "mins" + diffSeconds + "secs";
			String started = null;
			String endded = null;
			if (null != startTime)
				started = format.format(startTime.getTime());
			if (null != endTime)
				endded = format.format(endTime.getTime());
			wfJSON.put("duration", finalduration);
			wfJSON.put("initiator", ReportingUtils.isNotNull(initiator) ? initiator : "");
			wfJSON.put("model", model);
			wfJSON.put("payload", payload);
			wfJSON.put("started", started);
			wfJSON.put("ended", endded);
			wfJSON.put("workflowId", workflowid);
			wfJSON.put("state", status);
			wfJSON.put("approver", approver);

		} catch (JSONException | ParseException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}

		return wfJSON;

	}

	private void getWorkflowReport(SlingHttpServletRequest request,

								   SlingHttpServletResponse response) {
		String days = request.getParameter("days");
		boolean daysFilter = false;
		if (ReportingUtils.isNotNull(days) && Long.valueOf(days) > 0) {
			daysFilter = true;
		}
		long diffDays = 0;

		JSONObject workflowJSON = new JSONObject();
		JSONArray workflowArray = new JSONArray();
		String sqlStatement = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s,'/var/workflow/instances/') AND [jcr:primaryType] ='cq:Workflow'";

		try {
			NodeIterator NodeIter = ReportingUtils.executeQuery(sqlStatement, session);

			while (ReportingUtils.isNotNull(NodeIter) && NodeIter.hasNext()) {

				log.debug("got the top level node for workflow");
				// For each node-- get the path of the node
				Node workNode = NodeIter.nextNode();
				String nodePath = workNode.getPath();
				String sqlStatement1 = "select * from [nt:base] AS s WHERE ISDESCENDANTNODE(s, '" + nodePath
						+ "') AND ( [jcr:primaryType] ='cq:WorkItem' OR [jcr:primaryType] ='cq:Payload' OR approver is NOT NULL)";
				log.debug("sql stm for workflow node" + sqlStatement1);
				NodeIterator payloadNodeIter = ReportingUtils.executeQuery(sqlStatement1, session);

				JSONObject wfJSON = new JSONObject();
				log.debug("got the Workflow node");

				Resource resource = resourceResolver.getResource(nodePath);
				ValueMap properties = null != resource ? resource.getValueMap() : null;

				String payload = null;
				String workflowId = null;
				String approver = null;
				while (ReportingUtils.isNotNull(payloadNodeIter) && payloadNodeIter.hasNext()) {
					log.debug("got the payload/workitem node");
					Node payloadNode = payloadNodeIter.nextNode();
					Resource resource1 = resourceResolver.getResource(payloadNode.getPath());
					ValueMap payloadpro = null != resource1 ? resource1.getValueMap() : null;
					if (null != payloadpro) {

						if ((String) payloadpro.get("path") != null) {
							payload = (String) payloadpro.get("path");

						}
						if ((String) payloadpro.get("workflowId") != null) {
							workflowId = (String) payloadpro.get("workflowId");

						}
						if ((String) payloadpro.get("approver") != null) {
							approver = (String) payloadpro.get("approver");

						}
					}

				}
				if (null != properties) {
					wfJSON = createwfJSON(properties, payload, workflowId, approver);
				}
				if (daysFilter) {

					Date currentDate = Calendar.getInstance().getTime();
					long diff = Math.abs(currentDate.getTime() - startedtime.getTime());
					diffDays = diff / (24 * 60 * 60 * 1000);
					if (diffDays > Long.valueOf(days)) {
						continue;
					}
				}
				workflowArray.put(wfJSON);

			}
			workflowJSON.put("workflows", workflowArray);
			if (StringUtils.equalsIgnoreCase(this.output_type_value, "csv")) {
				log.debug("csv output");
				CsvListWriter beanWriter = null;

				final String[] header = new String[] { "duration", "initiator", "model", "payload", "started", "ended",
						"workflowId", "state", "approver" };

				String csvFileName = "workflow.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);

				JSONArray array = workflowJSON.getJSONArray("workflows");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);

					myList.add(json_data.getString("duration"));
					myList.add(json_data.getString("initiator"));
					myList.add(json_data.getString("model"));
					myList.add(json_data.getString("payload"));
					myList.add(json_data.getString("started"));
					if (!json_data.isNull("ended")) {
						myList.add(json_data.getString("ended"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("workflowId")) {
						myList.add(json_data.getString("workflowId"));
					} else {
						myList.add("NULL");
					}
					myList.add(json_data.getString("state"));
					if (!json_data.isNull("approver")) {
						myList.add(json_data.getString("approver"));
					}
					beanWriter.write(myList);

					myList.clear();
				}

			} else {
				response.getWriter().write(workflowJSON.toString());
			}
		} catch (IOException | JSONException | NullPointerException | RepositoryException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}

	/**
	 * This report will return a list of all the translated projects and their
	 * details
	 *
	 * @param request
	 * @param response
	 */
	private void getTranslationReport(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		String days = request.getParameter("days");
		boolean daysFilter = false;
		if (ReportingUtils.isNotNull(days) && Long.valueOf(days) > 0) {
			daysFilter = true;
		}
		long diffDays = 0;
		JSONObject translationJSON = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		String sqlStatement = "select * from [nt:unstructured] where isdescendantnode('/content/projects') AND [cq:template] = '/libs/cq/core/content/projects/templates/translation-project'";
		try {
			NodeIterator nodeIter = ReportingUtils.executeQuery(sqlStatement, session);
			while (ReportingUtils.isNotNull(nodeIter) && nodeIter.hasNext()) {

				Node node = nodeIter.nextNode();

				Resource resource = resourceResolver.getResource(node.getPath());
				String projectTitle = null;
				ValueMap properties = null;
				Resource translationResource = null;
				ValueMap translationProperties = null;
				if (null != resource) {
					properties = resource.getValueMap();
				}
				String dueDate = null;
				String TranslationRetrievalDate = null;
				if (null != properties) {
					if (properties.get("jcr:title", String.class) != null) {
						projectTitle = properties.get("jcr:title", String.class);
						dueDate = properties.get("project.dueDate", String.class);
						log.debug("projectTitle1" + projectTitle);
					}
					if (ReportingUtils.isNotNull(properties.get("jcr:lastModified"))) {
						TranslationRetrievalDate = properties.get("jcr:lastModified", String.class);
					}
				}
				if (null != resource) {
					translationResource = resource.getChild("dashboard/gadgets/translationjob");
					if (null != translationResource) {
						translationProperties = translationResource.getValueMap();
					}
				}
				Resource pageResource = resourceResolver.getResource(node.getPath().subSequence(0, node.getPath().length() - 12).toString());
				Node pageNode = null;
				Resource childPageResource = null;
				if (null != pageResource) {
					pageNode = pageResource.adaptTo(Node.class);

				}
				if (null != translationResource) {
					childPageResource = translationResource.getChild("child_pages");
				}
				if (childPageResource != null && childPageResource.hasChildren()) {
					Iterator<Resource> assetsIter = childPageResource.listChildren();
					while (ReportingUtils.isNotNull(assetsIter) && assetsIter.hasNext()) {
						JSONObject jsonObject = new JSONObject();
						log.debug("projectTitle" + projectTitle);
						if (null != projectTitle) {
							jsonObject.put("projectTitle", projectTitle);
						} else {
							jsonObject.put("projectTitle", "NULL");
						}

						jsonObject.put("status",
								ReportingUtils.isNotNull(translationProperties.get("translationStatus"))
										? (String) translationProperties.get("translationStatus") : "");
						jsonObject.put("dueDate", ReportingUtils.isNotNull(dueDate) ? dueDate : "");
						if (null != TranslationRetrievalDate) {
							jsonObject.put("TranslationRetrievalDate", TranslationRetrievalDate);
						} else {
							jsonObject.put("TranslationRetrievalDate", "NULL");
						}
						jsonObject.put("initiator", ReportingUtils.getProperties("*:lastModifiedBy", pageNode));
						jsonObject.put(SOURCE_LANGUAGE, ReportingUtils.isNotNull(properties.get(SOURCE_LANGUAGE))
								? properties.get(SOURCE_LANGUAGE) : "");
						jsonObject.put("targetLanguage", ReportingUtils.isNotNull(properties.get(DESTINATION_LANGUAGE))
								? properties.get(DESTINATION_LANGUAGE) : "");

						// Iterate through all child pages under translationJob
						Resource childResource = assetsIter.next();
						ValueMap assetsProperties = childResource.getValueMap();
						String sourcePath;
						String translationFileType = (String) assetsProperties.get("translationFileType");
						if (ReportingUtils.isNotNull(translationFileType)
								&& PROPERTY_PAGE.equalsIgnoreCase(translationFileType)) {

							sourcePath = (String) assetsProperties.get("sourcePath");
							if (ReportingUtils.isNotNull(sourcePath)) {
								jsonObject.put("path", sourcePath);
								String comletepagepath = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, sourcePath);
								comletepagepath = comletepagepath.replace("/content/texas-instruments/en-us", "");
								comletepagepath = comletepagepath.replace("/content/texas-instruments", "");
								jsonObject.put("CompletePageUrl", comletepagepath);
								Resource contentPageResource = resourceResolver.getResource(sourcePath);
								if (contentPageResource != null) {
									Page contentPage = contentPageResource.adaptTo(Page.class);
									if (daysFilter && null != contentPage) {

										Calendar lastModified = contentPage.getLastModified();
										Calendar currentDate = Calendar.getInstance();
										currentDate.getTime().compareTo(lastModified.getTime());
										long diff = Math.abs(
												currentDate.getTime().getTime() - lastModified.getTime().getTime());
										diffDays = diff / (24 * 60 * 60 * 1000);
										if (diffDays > Long.valueOf(days)) {
											break;

										}
									}
									jsonObject.put("path", sourcePath);
								}

							} else {
								jsonObject.put("path", "NULL");
							}

						} else {
							jsonObject.put("path", "NULL");
							jsonObject.put("CompletePageUrl", "NULL");
						}

						sourcePath = (String) assetsProperties.get("sourcePath");
						if (PROPERTY_ASSET.equalsIgnoreCase(translationFileType)) {
							jsonObject.put("assetPath", sourcePath);

						} else {
							jsonObject.put("assetPath", "NULL");
						}
						if (PROPERTY_CONTENTFRAGMENT.equalsIgnoreCase(translationFileType)) {
							jsonObject.put("fragmentPath", sourcePath);

						} else {
							jsonObject.put("fragmentPath", "NULL");
						}
						if (PROPERTY_I18NDICTIONARY.equalsIgnoreCase(translationFileType)) {
							jsonObject.put("dictionaryPath", sourcePath);

						} else {
							jsonObject.put("dictionaryPath", "NULL");
						}
						if (PROPERTY_TAG.equalsIgnoreCase(translationFileType)) {
							jsonObject.put("tag", sourcePath);

						} else {
							jsonObject.put("tag", "NULL");
						}
						if (!daysFilter || diffDays <= Long.valueOf(days)) {
							String translationProvider = (String) properties.get("translationProvider");
							jsonObject.put("provider", translationProvider);
							String translationMethod = (String) properties.get("translationMethod");
							jsonObject.put("method", translationMethod);

							jsonArray.put(jsonObject);
						}

					}

				}

			}
			translationJSON.put("translations", jsonArray);
			if (StringUtils.equalsIgnoreCase(this.output_type_value, "csv")) {

				CsvListWriter beanWriter = null;
				final String[] header = new String[] { "projectTitle", "status", "dueDate", "TranslationRetrievalDate",
						"initiator", "sourceLanguage", "targetLanguage", "page", "CompletePageUrl", "assets",
						"fragments", "dictionaries", "tags", "provider", "method" };

				String csvFileName = "translations.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);

				JSONArray array = translationJSON.getJSONArray("translations");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);

					if (!json_data.isNull("projectTitle")) {
						myList.add(json_data.getString("projectTitle"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("status")) {
						myList.add(json_data.getString("status"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("dueDate")) {
						myList.add(json_data.getString("dueDate"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("TranslationRetrievalDate")) {
						myList.add(json_data.getString("TranslationRetrievalDate"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("initiator")) {
						myList.add(json_data.getString("initiator"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("sourceLanguage")) {
						myList.add(json_data.getString("sourceLanguage"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("targetLanguage")) {
						myList.add(json_data.getString("targetLanguage"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("path")) {
						myList.add(json_data.getString("path"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("CompletePageUrl")) {
						myList.add(json_data.getString("CompletePageUrl"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("assetPath")) {
						myList.add(json_data.getString("assetPath"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("fragmentPath")) {
						myList.add(json_data.getString("fragmentPath"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("dictionaryPath")) {
						myList.add(json_data.getString("dictionaryPath"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("tag")) {
						myList.add(json_data.getString("tag"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("provider")) {
						myList.add(json_data.getString("provider"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("method")) {
						myList.add(json_data.getString("method"));
					} else {
						myList.add("NULL");
					}

					beanWriter.write(myList);

					myList.clear();
				}
			} else {
				response.getWriter().write(translationJSON.toString());
			}
		} catch (RepositoryException | IOException | JSONException | NullPointerException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}
}