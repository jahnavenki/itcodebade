package com.ti.core.components;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.HomePageFeaturedProduct;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductFamilyNewProducts extends WCMUsePojo {
	protected static final Logger log = LoggerFactory.getLogger(ProductFamilyNewProducts.class);
	private static final String FAMILY_ID = "familyId";
	private static final String HOMEPAGE_TEMPLATE = "/apps/ti/templates/homePage";
	private final List<HomePageFeaturedProduct> productFamilyNewProductsList = new ArrayList<>();
	private boolean isProductFamilyTopLevel;

	public List<HomePageFeaturedProduct> getProductFamilyNewProducts() {
		return productFamilyNewProductsList;
	}

	public boolean hasProductFamilyNewProducts() {
		return !productFamilyNewProductsList.isEmpty();
	}

	public int productFamilyNewProductsCount() {
		return productFamilyNewProductsList.size();
	}

	public boolean getIsProductFamilyTopLevel() {
		return isProductFamilyTopLevel;
	}
	@Override
	public void activate() {
		try {
			String templatePath = getCurrentPage().getTemplate().getPath();
			final JSONObject jsonResponse = getResponseFromWs();
			if(null == jsonResponse) return; // failed to get response, should already be logged
			if (jsonResponse.has("treeLevel") && jsonResponse.getInt("treeLevel") == 0) {
				isProductFamilyTopLevel = true;
			}
			final JSONObject jsonFeaturedProductInfo = jsonResponse.getJSONObject("featuredProductInfo");
			final JSONArray jsonPartNumberInformation = jsonFeaturedProductInfo.getJSONArray("partNumberInformation");
			final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy'T'hh:mm:ss");
			for(int i = 0; i < jsonPartNumberInformation.length(); ++i) {
				final HomePageFeaturedProduct homePageFeaturedProduct = new HomePageFeaturedProduct();
				final JSONObject data = jsonPartNumberInformation.getJSONObject(i);
				homePageFeaturedProduct.setId(data.getInt("id"));
				homePageFeaturedProduct.setGenericPartId(data.getInt("genericPartId"));
				homePageFeaturedProduct.setGenericPartNumber(data.getString("genericPartNumber"));
				homePageFeaturedProduct.setDeviceDescription(data.getString("deviceDescription"));
				homePageFeaturedProduct.setReleaseDate(dateFormat.parse(data.getString("releaseDate")));
				homePageFeaturedProduct.setMarketingStatus(data.getString("marketingStatus"));
				homePageFeaturedProduct.setMarketingStatusId(data.getInt("marketingStatusId"));
				homePageFeaturedProduct.setMarketingStatusDescription(data.getString("marketingStatusDescription"));
				homePageFeaturedProduct.setNewFlag(data.getBoolean("newFlag"));
				homePageFeaturedProduct.setPartImageAvailable(data.getBoolean("partImageAvailable"));
				homePageFeaturedProduct.setPartImageUrl(data.getString("partImageUrl"));
				String gpnUrl = data.getString("gpnUrl");
				if(StringUtils.isNotBlank(gpnUrl) && !HOMEPAGE_TEMPLATE.equals(templatePath)) {
					gpnUrl = gpnUrl.split("\\?")[0];
				}
				homePageFeaturedProduct.setGpnUrl(gpnUrl);
				homePageFeaturedProduct.setLanguage(data.getString("language"));
				homePageFeaturedProduct.setDatasheetUrl(data.getString("datasheetUrl"));
				homePageFeaturedProduct.setFamilyName(data.getString("familyName"));
				homePageFeaturedProduct.setCurrency(data.getString("currency"));
				homePageFeaturedProduct.setDisplayQuantity(data.getString("displayQuantity"));
				homePageFeaturedProduct.setApproximatePrice(data.getString("approximatePrice"));
				homePageFeaturedProduct.setSelectionToolUrl(data.getString("selectionToolUrl"));
				// if required fields are missing, skip product
				if(StringUtils.isBlank(homePageFeaturedProduct.getGenericPartNumber())
				|| StringUtils.isBlank(homePageFeaturedProduct.getDeviceDescription())
				|| StringUtils.isBlank(homePageFeaturedProduct.getGpnUrl())
				) {
					continue;
				}
				productFamilyNewProductsList.add(homePageFeaturedProduct);
			}
		} catch(Exception ex) {
			log.error("activate", ex);
		}
	}	

	private JSONObject getResponseFromWs() {
		try {
			final WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (null == wcmService) {
				throw new NullPointerException("wcmService is null");
			}
			final ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
			if (null == tabsService) {
				throw new NullPointerException("tabsService is null");
			}
			final String language = tabsService.getPageLanguage(getCurrentPage());
			String familyId = null;
			if (null != getPageProperties().get(FAMILY_ID)) {
				familyId = (String) getPageProperties().get(FAMILY_ID);
			}
			final JSONObject jsonResponse = wcmService.getProductFamilyNewProducts(
				familyId, language.equals("ru-ru") ? "en-us" : language);
			if (null == jsonResponse) {
				throw new NullPointerException("jsonResponse is null");
			}
			return jsonResponse;
		} catch(Exception ex) {
			log.error("getResponseFromWs", ex);
			return null;
		}
	}
	
}
