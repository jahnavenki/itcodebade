package com.ti.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class URLHelper extends WCMUsePojo {
	private static final Logger log = LoggerFactory.getLogger(URLHelper.class);

    private String url;

    @Override
    public void activate() throws Exception {
        url = get("url", String.class);
    }

    /**
     * Finds any/all URLs within the input string and replace their protocol to the scheme specified. Exit immediately if scheme is invalid.
     * @param input is a string which may contain contain zero or more URLs
     * @param scheme valid values are "http", "https". Any other values or null are considered invalid for scheme.
     * @return all URLs from input string are replaced with the scheme specified
     */
    public static String toScheme(String input, String scheme) {
        if ("http".equals(scheme) || "https".equals(scheme)) {
            scheme = "https"; // Dispatcher can only store one copy, so let it be https
            return input.replaceAll("(?i)http[s]?(?=://)", scheme);
        }
        return input;
    }

    /**
     * Finds any/all URLs inside the input string, and replace their scheme to https://
     * @param input is a string which may contain contain zero or more URLs
     * @return all URLs from input string are replaced with https:// prefix
     */
    public static String toHttps(String input) {
        return toScheme(input, "https");
    }

    /**
     * Returns the scheme (e.g. 'http', https') of the request. Works with load balancer forwarded requests as well.
     * @param req is the current HTTP request object
     * @return String
     */
    public static String getScheme(SlingHttpServletRequest req) {
        if (Objects.nonNull(req)) {
            return (StringUtils.isNotEmpty(req.getHeader("X-Forwarded-Proto")) ? req.getHeader("X-Forwarded-Proto") : req.getScheme());
        }
        return StringUtils.EMPTY;
    }

    /**
     * URL encode the input string
     * @param input is a string
     * @return the input string URL-encoded
     */
    public static String urlEncode(String input) {
    	try {
        	return URLEncoder.encode(input, "UTF-8").replace("+", "%20");
    	}
    	catch (UnsupportedEncodingException e) {
    		log.error("UTF-8 encoding is unsupported", e);
    	}
    	return input;
    }

    public String getToScheme() {
        return toScheme(url, getScheme(getRequest()));
    }

    public String getToHttps() {
    	return toHttps(url);
    }
	
    public String urlEncode() {
    	return urlEncode(url);
    }
}