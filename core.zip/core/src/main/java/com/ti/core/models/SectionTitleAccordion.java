package com.ti.core.models;

public class SectionTitleAccordion {

  private String sectionTitle;
  private String parsysName;
  private boolean display;

  public String getSectionTitle() {
    return sectionTitle;
  }

  public void setSectionTitle(String sectionTitle) {
    this.sectionTitle = sectionTitle;
  }

  public String getParsysName() {
    return parsysName;
  }

  public void setParsysName(String parsysName) {
    this.parsysName = parsysName;
  }

  public boolean isDisplay() {
    return display;
  }

  public void setDisplay(boolean display) {
    this.display = display;
  }

}
