package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_RESOURCE_TYPES;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_SELECTORS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.ti.core.service.WCMComponents;


@Component(name = "ProductFamilyTechDocCategoriesServlet", immediate=true, service = Servlet.class,  property = {
		SLING_SERVLET_RESOURCE_TYPES + "=ti/components/technicalDocumentInterface",
		SLING_SERVLET_PATHS+"=/bin/ti/producttechdoccategories",
		SLING_SERVLET_METHODS + "=GET",
		SLING_SERVLET_SELECTORS+"=category"})
public class TechDocCategoriesServlet extends SlingSafeMethodsServlet {

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	/** The tech doc categories response. */
	private String techDocCategoriesResponse = "";

	/** The Constant FAMILY_ID. */
	private static final String FAMILY_ID = "familyId";

	/** The Constant APPLICATION_ID. */
	private static final String APPLICATION_ID = "applicationId";

	/**
	 * Do get.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		String familyId = request.getParameter(FAMILY_ID);
		String applicationId = request.getParameter(APPLICATION_ID);
		String path = request.getRequestURI();
		String language = "en-us";
		if (path.contains("ja-jp")) {
			language = "ja-jp";
		} else if (path.contains("zh-cn")) {
			language = "zh-cn";
		}
		if (StringUtils.isNotBlank(familyId)) {
			this.techDocCategoriesResponse = null != wcmService
					? wcmService.getProductTechDocCategories(familyId, language) : "";
		} else if (StringUtils.isNotBlank(applicationId)) {
			this.techDocCategoriesResponse = null != wcmService
					? wcmService.getApplicationTechDocCategories(applicationId, language) : "";
		}
		response.setContentType("text/x-json;charset=UTF-8");
		response.getWriter().write(techDocCategoriesResponse);
	}

}