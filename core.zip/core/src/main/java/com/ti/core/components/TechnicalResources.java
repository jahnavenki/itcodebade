package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.TechnicalResourcesModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TechnicalResources extends WCMUsePojo {

    private static final Logger log = LoggerFactory.getLogger(TechnicalResources.class);

    private static final String PARAM_RESOURCELIST = "resourceList";
    private static final String TECHNICAL_DOCS = "technicalDocs";
    private static final String LITERATURE_NUMBER = "literatureNumber";
    private static final String CONCISE_DESCRIPTION = "conciseDescription";
    private static final String RESOURCE_TYPE = "resourceType";
    private static final String DOCUMENT_CATEGORY = "documentCategory";
    private static final String DOC_CATEGORY = "docCategory";

    private final List<TechnicalResourcesModel> technicalResourceModel = new ArrayList<>();

    public List<TechnicalResourcesModel> getTechnicalResourceModel() {
        return technicalResourceModel;
    }

    @Override
    public void activate() {
        try {
            for (Resource nodeChild : getResource().getChildren()) {
                if (nodeChild != null && nodeChild.getName().equalsIgnoreCase(PARAM_RESOURCELIST)) {
                    for (Resource resourceChild : nodeChild.getChildren()) {
                        ValueMap properties = resourceChild.adaptTo(ValueMap.class);
                        if (null != properties) {
                            addTechnicalResourceToList(properties);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }

    /**
     * Fetch Literature service response and set technical resource fields.
     *
     * @param properties - parameter
     */
    private void fetchLiteratureResponse(ValueMap properties) {
        JSONObject jsonLiterature;
        String pagelanguage = "en-us";
        String resourceUrl;
        WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
        if (null != wcmService) {
            ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
                    .getService(ProductNavigationTabsOrdering.class);
            if (tabsService != null) {
                pagelanguage = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
            }
            LanguageUtils langUtils = new LanguageUtils(getRequest());

            String litNumber = properties.get("litnumber", String.class);
            try {
                String litResponse = wcmService.getFeaturedliterature(litNumber, pagelanguage);
                TechnicalResourcesModel technicalResourcesModelObject = new TechnicalResourcesModel();
                if (StringUtils.isNotEmpty(litResponse)) {
                    jsonLiterature = new JSONObject(litResponse);
                    String litNumberFromDB = jsonLiterature.getString(LITERATURE_NUMBER).substring(0,7);
                    // get the literature number from json response, as it is different for regions
                    resourceUrl = langUtils.getI18nStr("https://www.ti.com/lit/") + litNumberFromDB;
                    String resourceType = properties.get(RESOURCE_TYPE, String.class);
                    technicalResourcesModelObject.setDialogResourceType(resourceType);
                    technicalResourcesModelObject.setResourceType(getTechnicalDocCategory(resourceType, jsonLiterature, langUtils));
                    technicalResourcesModelObject.setTitle(jsonLiterature.getString(CONCISE_DESCRIPTION));
                    technicalResourcesModelObject.setDescription(properties.get("description", String.class));
                    technicalResourcesModelObject.setResourceUrl(resourceUrl);
                    technicalResourcesModelObject.setResourceTypeEnglish(resourceType);
                    technicalResourcesModelObject.setLitNumber(litNumber);

                } else {
                    log.debug("Json response is empty or null");
                }                
                technicalResourceModel.add(technicalResourcesModelObject);
            } catch (Exception e) {
                log.error("Exception : ", e);
            }
        }

    }
    /**
     * Fetch technical resource fields and add to list.
     *
     * @param properties - parameter
     */
    private void addTechnicalResourceToList(ValueMap properties) {
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        String resourceType = properties.get(RESOURCE_TYPE,String.class);
        if (TECHNICAL_DOCS.equals(resourceType)) {
            fetchLiteratureResponse(properties);
        } else {
            TechnicalResourcesModel technicalResourcesModelObject = new TechnicalResourcesModel();
            
            technicalResourcesModelObject.setResourceType(langUtils.getI18nStr( "resourceType:" + resourceType ));
            technicalResourcesModelObject.setTitle(properties.get("title", String.class));
            technicalResourcesModelObject.setDescription(properties.get("description", String.class));
            technicalResourcesModelObject.setResourceUrl(properties.get("resourceUrl", String.class));
            technicalResourcesModelObject.setResourceTypeEnglish(resourceType);
            technicalResourceModel.add(technicalResourcesModelObject);
        }
    }
    
    private String getTechnicalDocCategory(String resourceType, JSONObject jsonLiterature, LanguageUtils langUtils) throws JSONException {
    	if(TECHNICAL_DOCS.equals(resourceType)) {
        	resourceType = jsonLiterature.getJSONObject(DOCUMENT_CATEGORY) != null ? jsonLiterature.getJSONObject(DOCUMENT_CATEGORY).getString(DOC_CATEGORY) : resourceType;
        	return langUtils.getI18nStr(resourceType);
        }                    
        else {
        	return langUtils.getI18nStr( "resourceType:" + resourceType );
        }
    }

}
