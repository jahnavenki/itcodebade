package com.ti.core.util;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

public class PropertiesUtils {

	/**
	 * 
	 * @param values
	 *            StringArray
	 * @param type
	 *            classType
	 * @return list
	 */
	public static <T> List<T> getListFromStringArray(final String[] values, Class<T> type) {
		List<T> items = new ArrayList<>();
		if (null == values) {
			return items;
		}
		for (String value : values) {
			Gson gson = new Gson();
			items.add(gson.fromJson(value, type));
		}
		return items;
	}

	private PropertiesUtils() {

	}
}
