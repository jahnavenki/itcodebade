package com.ti.core.components.models;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.models.HomePageFeaturedProduct;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

/**
 * FeaturedProducts Use class for /apps/ti/components/featuredProducts
 * 
 */
@Model(adaptables = { SlingHttpServletRequest.class, Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FeaturedProducts {
    protected static final Logger log = LoggerFactory.getLogger(FeaturedProducts.class);

    @SlingObject
    SlingHttpServletRequest slingHttpServletRequest;

    @OSGiService
    WCMComponents wcmService;

    @ChildResource
    private List<ValueMap> gpnList;

    private final List<HomePageFeaturedProduct> productsList = new ArrayList<>();
    
    public List<HomePageFeaturedProduct> getGpnList() {
        return productsList;
    }

    @PostConstruct
    protected void init() {
        try {
            LanguageUtils langUtils = new LanguageUtils(slingHttpServletRequest);
            String language = langUtils.getPageLanguageForProductFolder();

            for (ValueMap map : gpnList) {
                JSONObject data = wcmService.getFeaturedProduct(map.get("gpn", String.class), language);
                if (data != null) {
                    HomePageFeaturedProduct product = new HomePageFeaturedProduct();
                    product.setGenericPartId(data.getInt("genericPartId"));
                    product.setGenericPartNumber(data.getString("genericPartNumber"));
                    product.setDeviceDescription(data.getString("deviceDescription"));
                    product.setMarketingStatus(data.getString("marketingStatus"));
                    product.setMarketingStatusId(data.getInt("marketingStatusId"));
                    product.setMarketingStatusDescription(data.getString("marketingStatusDescription"));
                    product.setNewFlag(data.getBoolean("newFlag"));
                    product.setPartImageAvailable(data.getBoolean("partImageAvailable"));
                    product.setFamilyName(data.getString("familyName"));
                    product.setSelectionToolUrl(data.getString("selectionToolUrl"));
		    product.setPartImageUrl(data.getString("partImageUrl"));
                    productsList.add(product);              
                }
            }
        }
        catch (Exception e) {
            log.debug("Exception in Featured Products: {}", e);
        }
    }
}