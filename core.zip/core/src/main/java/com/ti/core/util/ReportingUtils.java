package com.ti.core.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.PropertyType;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.Externalizer;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.replication.ReplicationStatus;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.commons.WCMUtils;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;

/**
 * @author Brindha
 *
 *         General common code within aem java class
 *
 */
public class ReportingUtils extends WCMUsePojo {

	private static final String EXCEPTION_MESSAGE = "Exception: ";
	private static final String PROPERTY_LAST_MODIFIED = "lastModified";
	private transient static QueryManager queryManager;
	private transient static ResourceResolver resourceResolver;
	private static final String DAM_PATH = "/content/dam";
	private static final String DAM_ASSET_TICOM = "/content/dam/ticom";
	private static final String DAM_PATH_TINEWS = "/content/dam/tinews";
	private static final String CONTENT_PATH = "/content/texas-instruments";
	private static final String SLASH = "//";
	private static final String TOOL_PATH = "/tool/";
	private static final String URL_DELIMITER = "/";
	private static final String ORDER_NOW_ANCHOR_TAG = "#buy";
	private static final String HAS_GET_OPTIONS = "hasGetOptions";

	/** The log. */
	protected static final Logger log = LoggerFactory.getLogger(ReportingUtils.class);

	public static JSONObject createComponentJSON(JSONObject compJSON, Node componentNode, ValueMap properties,
												 ResourceResolver resourceResolver) {
		String author = (String) properties.get("jcr:lastModifiedBy");
		String lastModified = properties.get("jcr:lastModified", String.class);
		String resourceType = (String) properties.get("sling:resourceType");

		try {
			compJSON.put("componentType", resourceType);
			compJSON.put("componentPath", componentNode.getPath());
			compJSON.put("author", author);
			compJSON.put(PROPERTY_LAST_MODIFIED, lastModified);
			Node parentNode = componentNode.getParent();
			while (!"cq:Page".equalsIgnoreCase(parentNode.getPrimaryNodeType().getName())) {
				parentNode = parentNode.getParent();
			}
			if (resourceType.contains("/image")) {

				if (ReportingUtils.isNotNull(properties.get("fileReference"))) {
					String image_source = properties.get("fileReference", String.class);
					compJSON.put("image_source", image_source);
				} else {
					compJSON.put("image_source", "");
				}

				if (ReportingUtils.isNotNull(properties.get("altText"))) {
					String altText = properties.get("altText", String.class);
					compJSON.put("altText", altText);
				} else {
					compJSON.put("altText", "");
				}

			}
			Page page = null;
			Resource resource = resourceResolver.getResource(parentNode.getPath());
			if (null != resource) {
				page = resource.adaptTo(Page.class);

			}
			if (null != page) {
				ValueMap pageproperties = null;
				pageproperties = page.getProperties();
				String template = null;
				if (null != pageproperties) {

					if (ReportingUtils.isNotNull(properties.get("cq:template"))) {
						template = properties.get("cq:template", String.class);
					}
					if (ReportingUtils.isNotNull(pageproperties.get("familyId"))) {
						String familyid = pageproperties.get("familyId", String.class);
						compJSON.put("familyid", familyid);

						if (null != familyid) {
							compJSON.put("Category", "Family");
						}
					} else if (ReportingUtils.isNotNull(pageproperties.get("marketId"))) {
						String appid = pageproperties.get("marketId", String.class);
						compJSON.put("applicationid", appid);

						if (null != appid) {
							compJSON.put("Category", "Application");
						}
					} else {
						if (null != template) {
							if (template.toUpperCase().contains("FAMILY")) {
								compJSON.put("Category", "Family");
							} else if (template.contains("/applications")) {
								compJSON.put("Category", "Application");
							} else {
								compJSON.put("Category", "Other");
							}
						} else {
							compJSON.put("Category", "Other");
						}

					}
				}
			}
			String comletepagepath = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, parentNode.getPath());

			comletepagepath = comletepagepath.replace("/content/texas-instruments/en-us", "");
			comletepagepath = comletepagepath.replace("/content/texas-instruments", "");

			if (comletepagepath.contains("content/texas-instruments")) {
				log.debug("page still has full path " + comletepagepath);
			}
			compJSON.put("page", parentNode.getPath());
			compJSON.put("CompletePageUrl", comletepagepath);

		} catch (JSONException | RepositoryException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
		return compJSON;
	}

	/**
	 * This method will return the value of the property name passed
	 *
	 * @param propertyNamePattern
	 * @param componentNode
	 * @return
	 */
	public static String getProperties(String propertyNamePattern, Node componentNode) {
		String property = null;
		try {
			PropertyIterator props = componentNode.getProperties(propertyNamePattern);
			while (ReportingUtils.isNotNull(props) && props.hasNext()) {
				Property prop = (Property) props.next();
				if (PropertyType.DATE == prop.getValue().getType()) {
					Date componentDate = prop.getDate().getTime();
					property = componentDate.toString();
				} else if (PropertyType.PATH == prop.getValue().getType()) {
					property = prop.getPath();
				} else if (PropertyType.STRING == prop.getValue().getType()) {
					property = prop.getString();
				}
			}
		} catch (RepositoryException e) {
			log.error(EXCEPTION_MESSAGE + e);
		}
		return property;
	}

	/**
	 * This method will execute the query and return the NodeIterator
	 *
	 * @param sqlStatement
	 * @return
	 */
	public static NodeIterator executeQuery(String sqlStatement, Session session) {
		NodeIterator nodeResult = null;
		try {
			queryManager = session.getWorkspace().getQueryManager();

			Query query = queryManager.createQuery(sqlStatement, "JCR-SQL2");
			// Execute the query and get the results ...
			QueryResult result = query.execute();
			// Iterate over the nodes in the results ...
			nodeResult = result.getNodes();
		} catch (RepositoryException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
		return nodeResult;
	}

	public static void convertjsonarrytoarraylist(JSONArray array, CsvListWriter beanWriter) {

		ArrayList<String> myList = new ArrayList<>();
		if (array != null) {

			for (int i = 0; i < array.length(); i++) {
				try {
					myList.add(array.getString(i));
					beanWriter.write(myList);
					log.debug("mylist " + myList.toString());
					myList.clear();
				} catch (JSONException | IOException e) {
					log.error(EXCEPTION_MESSAGE, e);
				}
			}
		}

	}

	/**
	 * This method will return a report of the list of aem users in the project
	 * and also the groups that they are a part of
	 *
	 * @param request
	 * @param response
	 */
	public static void getAemUser(SlingHttpServletRequest request, SlingHttpServletResponse response,
								  String outputTypeValue) {
		resourceResolver = request.getResourceResolver();
		UserManager userManager = resourceResolver.adaptTo(UserManager.class);
		JSONObject aemUserJSON = new JSONObject();
		JSONArray userArray = new JSONArray();
		try {
			JSONObject userJSON;
			Iterator<Authorizable> result = null != userManager
					? userManager.findAuthorizables("jcr:primaryType", "rep:User") : null;
			if (null != result) {
				while (result.hasNext()) {
					Authorizable auth = result.next();
					Iterator<Group> iterGroup = auth.memberOf();
					boolean hasGroup = false;
					String userID, useridPattern, groupidPattern;
					userID = auth.getID();

					useridPattern = "[a,x]{1}[0-9]{7}";
					groupidPattern = "^ti-";

					Pattern pattern = Pattern.compile(useridPattern);
					Matcher matcher = pattern.matcher(userID);
					if (!matcher.find()) {
						continue;
					}

					while (ReportingUtils.isNotNull(iterGroup) && iterGroup.hasNext()) {
						userJSON = new JSONObject();

						Group group = iterGroup.next();
						Pattern grouppattern = Pattern.compile(groupidPattern);
						Matcher groupmatcher = grouppattern.matcher(group.getID());
						// taking only ti groups
						if (!groupmatcher.find()) {
							log.debug("userid and group Name " + auth.getID() + group.getID());
							continue;
						}
						userJSON.put("userId", userID);
						userJSON.put("groupName", group.getID());
						userJSON.put("isActive?", !((User) auth).isDisabled());
						hasGroup = true;
						log.debug("userid and group Name " + auth.getID() + group.getID());
						userArray.put(userJSON);
					}
					if (!hasGroup) {
						userJSON = new JSONObject();
						userJSON.put("userId", userID);
						userJSON.put("groupName", "NULL");
						userJSON.put("isActive?", !((User) auth).isDisabled());
						userArray.put(userJSON);

					}

				}
			}
			aemUserJSON.put("Users", userArray);
			if (StringUtils.equalsIgnoreCase(outputTypeValue, "csv")) {
				log.debug("csv output");
				CsvListWriter beanWriter = null;

				final String[] header = new String[] { "userId", "Groups", "isActive?" };

				String csvFileName = "aemusers.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				JSONArray array = aemUserJSON.getJSONArray("Users");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);
					log.debug("json data " + json_data.toString());
					myList.add(json_data.getString("userId"));
					myList.add(json_data.getString("groupName"));
					myList.add(json_data.getString("isActive?"));
					beanWriter.write(myList);
					log.debug("mylist " + myList.toString());
					myList.clear();
				}
				beanWriter.close();
			} else {
				response.getWriter().write(aemUserJSON.toString());
			}

		} catch (RepositoryException | JSONException | NullPointerException | IOException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}
	}

	public static void getMetadataReport(SlingHttpServletRequest request, SlingHttpServletResponse response,
										 String outputTypeValue, Session session) {
		String sqlStatement = "select * from [cq:Page] as s where isdescendantnode(s,'/content/texas-instruments')";
		resourceResolver = request.getResourceResolver();
		JSONObject pageActivityJSON = new JSONObject();
		JSONArray pageActivityArray = new JSONArray();
		try {
			NodeIterator nodeIter = ReportingUtils.executeQuery(sqlStatement, session);
			while (ReportingUtils.isNotNull(nodeIter) && nodeIter.hasNext()) {
				JSONObject pageJSON = new JSONObject();
				ValueMap properties = null;
				String lastModified = null;
				// For each node-- get the path of the node
				Node node = nodeIter.nextNode();
				Page page = null;
				Resource resource = resourceResolver.getResource(node.getPath());
				if (null != resource) {
					page = resource.adaptTo(Page.class);

				}
				if (null != page) {

					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
					if (null != page.getLastModified()) {
						lastModified = format1.format(page.getLastModified().getTime());
					}

					String mappedPath = PathBrowserHelper.addHtmlIfContentPath(resourceResolver, page.getPath());
					mappedPath = mappedPath.replace("/content/texas-instruments/en-us", "");
					mappedPath = mappedPath.replace("/content/texas-instruments", "");
					pageJSON.put("CompletePageUrl", mappedPath);

					properties = page.getProperties();

					Locale locale = page.getLanguage(true);

					if (null != properties) {

						Boolean hideInNav = null;
						String template = null;
						if (ReportingUtils.isNotNull(properties.get("cq:template"))) {
							template = properties.get("cq:template", String.class);
						}
						if (ReportingUtils.isNotNull(properties.get("hideInNav"))) {
							hideInNav = properties.get("hideInNav", Boolean.class);
						}

						if ((hideInNav != null && hideInNav.booleanValue())
								|| (template != null && template.contains("/homePage"))) {
							continue;
						}

						if (ReportingUtils.isNotNull(properties.get("pageTitle"))) {
							String browserTitle = properties.get("pageTitle", String.class);
							pageJSON.put("browserTitle", browserTitle);
						} else {
							pageJSON.put("browserTitle", "");
						}

						if (ReportingUtils.isNotNull(properties.get("navTitle"))) {
							String navTitle = properties.get("navTitle", String.class);
							pageJSON.put("tabName", navTitle);
						} else {
							pageJSON.put("tabName", "");
						}

						if (ReportingUtils.isNotNull(properties.get("jcr:description"))) {
							String metaDescription = properties.get("jcr:description", String.class);
							pageJSON.put("metaDescription", metaDescription);
						} else {
							pageJSON.put("metaDescription", "");
						}

						if (ReportingUtils.isNotNull(properties.get("cq:tags"))) {
							String metaKeyword = WCMUtils.getKeywords(page, false);
							pageJSON.put("metaKeyword", metaKeyword);
						} else {
							pageJSON.put("metaKeyword", "");
						}

						if (ReportingUtils.isNotNull(properties.get("familyId"))) {
							String familyid = properties.get("familyId", String.class);
							pageJSON.put("familyid", familyid);

							if (null != familyid) {
								pageJSON.put("Category", "Family");
							}
						} else if (ReportingUtils.isNotNull(properties.get("marketId"))) {
							String appid = properties.get("marketId", String.class);
							pageJSON.put("applicationid", appid);

							if (null != appid) {
								pageJSON.put("Category", "Application");
							}
						} else {
							if (null != template) {
								if (template.toUpperCase().contains("FAMILY")) {
									pageJSON.put("Category", "Family");
								} else if (template.contains("/applications")) {
									pageJSON.put("Category", "Application");
								} else {
									pageJSON.put("Category", "Other");
								}
							} else {
								pageJSON.put("Category", "Other");
							}

						}
						pageJSON.put("language", locale.getLanguage());
						if (ReportingUtils.isNotNull(properties.get("translationsubmissionDate"))) {
							String translationsubmissionDate = properties.get("translationsubmissionDate",
									String.class);
							pageJSON.put("TranslationsubmissionDate", translationsubmissionDate);
						} else {
							pageJSON.put("TranslationsubmissionDate", "");
						}

						if (ReportingUtils.isNotNull(properties.get("cq:lastTranslationUpdate"))) {
							String TranslationRetrievalDate = properties.get("cq:lastTranslationUpdate", String.class);
							pageJSON.put("TranslationRetrievalDate", TranslationRetrievalDate);
						} else {
							pageJSON.put("TranslationRetrievalDate", "");
						}

						String publishedStatus = null;
						String PublishedDate = null;
						Boolean published = false;
						if (ReportingUtils.isNotNull(properties.get("cq:lastReplicationAction"))) {
							publishedStatus = properties.get("cq:lastReplicationAction", String.class);
							if (StringUtils.equalsIgnoreCase(publishedStatus, "Activate")) {
								pageJSON.put("publishedStatus", "Published");
								published = true;
							} else {
								pageJSON.put("publishedStatus", "Un-Published");
							}
						} else {
							pageJSON.put("publishedStatus", "Never-Published");
						}
						if (ReportingUtils.isNotNull(properties.get("cq:lastReplicated"))) {
							PublishedDate = properties.get("cq:lastReplicated", String.class);
							if (published) {
								pageJSON.put("PublishedDate", PublishedDate);
							} else {
								pageJSON.put("un-PublishedDate", PublishedDate);
							}
						}

						pageJSON.put(PROPERTY_LAST_MODIFIED, lastModified);

					}

				} else {

					pageJSON.put("CompletePageUrl", "NULL");
				}

				pageActivityArray.put(pageJSON);
			}
			pageActivityJSON.put("pages", pageActivityArray);
			response.setContentType("text/x-json;charset=UTF-8");
			if (StringUtils.equalsIgnoreCase(outputTypeValue, "csv")) {
				CsvListWriter beanWriter = null;

				final String[] header = new String[] { "CompletePageUrl", "browserTitle", "tabName", "metaDescription",
						"metaKeyword", "Category", "familyid", "applicationid", "language", "TranslationsubmissionDate",
						"TranslationRetrievalDate", "publishedStatus", "PublishedDate", "Un-PublishedDate",
						"lastModified" };

				String csvFileName = "Metadata.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);

				response.setCharacterEncoding("UTF-8");
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);

				JSONArray array = pageActivityJSON.getJSONArray("pages");
				ArrayList<String> myList = new ArrayList<>();
				for (int i = 0; i < array.length(); i++) {
					JSONObject json_data = array.getJSONObject(i);
					myList.add(json_data.getString("CompletePageUrl"));
					myList.add(json_data.getString("browserTitle"));
					myList.add(json_data.getString("tabName"));
					myList.add(json_data.getString("metaDescription"));
					if (!json_data.isNull("metaKeyword")) {
						myList.add(json_data.getString("metaKeyword"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("Category")) {
						myList.add(json_data.getString("Category"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("familyid")) {
						myList.add(json_data.getString("familyid"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("applicationid")) {
						myList.add(json_data.getString("applicationid"));
					} else {
						myList.add("NULL");
					}
					myList.add(json_data.getString("language"));

					if (!json_data.isNull("TranslationsubmissionDate")) {
						myList.add(json_data.getString("TranslationsubmissionDate"));
					} else {
						myList.add("NULL");
					}

					if (!json_data.isNull("TranslationRetrievalDate")) {
						myList.add(json_data.getString("TranslationRetrievalDate"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("publishedStatus")) {
						myList.add(json_data.getString("publishedStatus"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("PublishedDate")) {
						myList.add(json_data.getString("PublishedDate"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("un-PublishedDate")) {
						myList.add(json_data.getString("un-PublishedDate"));
					} else {
						myList.add("NULL");
					}
					if (!json_data.isNull("lastModified")) {
						myList.add(json_data.getString("lastModified"));
					} else {
						myList.add("NULL");
					}

					beanWriter.write(myList);
					myList.clear();
				}
				beanWriter.close();
			} else {
				response.getWriter().write(pageActivityJSON.toString());
			}
		} catch (RepositoryException | JSONException | IOException | NullPointerException e) {
			log.error(EXCEPTION_MESSAGE, e);
		}

	}

	@Override
	public void activate() throws Exception {
		// TODO Auto-generated method stub

	}

	public static boolean isNotNull(Object object) {
		if (null != object) {
			return true;
		} else {
			return false;
		}
	}

	public static void getAssetReport(SlingHttpServletRequest request, SlingHttpServletResponse response,
									  Externalizer externalizer, String outputType) {
		ArrayList<String> myList = new ArrayList<>();
		getAssetUpload(request, myList);
		List<ArrayList<String>> downlaodedAssetsList = getAssetDownload(request, myList, externalizer);
		getTotalAssets(request, myList);
		generateCSV(response, myList, downlaodedAssetsList, getAssetsCountList(request, externalizer), outputType);
	}

	private static String getAssetDownloadCount(List<ArrayList<String>> downloadedAssetsList, String asset) {
		for (List<String> list : downloadedAssetsList) {
			if (list.contains(asset)) {
				return list.get(1);
			}
		}
		return String.valueOf(0);
	}

	private static void generateCSV(SlingHttpServletResponse response, ArrayList<String> myList,
									List<ArrayList<String>> downloadedAssetsList, List<ArrayList<String>> assetsCount, String outputType) {
		CsvListWriter beanWriter = null;
		try {
			for (List<String> list : assetsCount) {
				String downloadedCount = getAssetDownloadCount(downloadedAssetsList, list.get(0));
				list.add(2, downloadedCount);
			}
			assetsCount.get(0).addAll(myList);
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "ResourcePath", "WebUseCount", "AssetsDownloadedCount",
						"CompleteReferencePath", "Asset Status", "Asset Published URL", "AssetsUpload",
						"TotalAssetsDownloaded", "TotalAssets" };
				String csvFileName = "DamAnalytics.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < assetsCount.size(); i++) {
					beanWriter.write(assetsCount.get(i));
				}
				beanWriter.close();
			} else {
				response.getWriter().println(new Gson().toJson(assetsCount));
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	public static Set<String> downloadedAssets(SlingHttpServletRequest request, Externalizer externalizer) {
		String query = "select * from [cq:AuditEvent] where [cq:type]='DOWNLOADED'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		Set<String> set = new HashSet<>();
		while (queryResult.hasNext()) {
			Resource res = queryResult.next();
			if (isNotNull(res)) {
				ValueMap valueMap = res.getValueMap();
				String path = (String) valueMap.get("cq:path");
				set.add(externalizer.authorLink(request.getResourceResolver(), "/assets.html".concat(path)));
			}
		}
		return set;
	}

	public static List<ArrayList<String>> getNonExistingAssetsList(SlingHttpServletRequest request,
																   Externalizer externalizer) {
		String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		PageManager manager = request.getResourceResolver().adaptTo(PageManager.class);
		List<ArrayList<String>> arrayList = new ArrayList<>();
		while (queryResult.hasNext()) {
			Resource resource = queryResult.next();
			if (isValidPath(resource.getPath())
					&& StringUtils.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
				query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + CONTENT_PATH + "]) and CONTAINS(s.*,'"
						+ resource.getPath() + "')";
				Iterator<Resource> referecesResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
				ArrayList<String> list = new ArrayList<>();
				if (referecesResult.hasNext()) {
					Resource pageRes = referecesResult.next();
					ValueMap map = null;
					if (isNotNull(pageRes) && isNotNull(manager)) {
						map = manager.getContainingPage(pageRes).getProperties();
					}
					if (!(map != null && map.containsKey("cq:lastReplicationAction")
							&& "Activate".equalsIgnoreCase(map.get("cq:lastReplicationAction").toString()))) {
						list.add(externalizer.authorLink(request.getResourceResolver(),
								"/assets.html".concat(resource.getPath())));
					}
				} else {
					list.add(externalizer.authorLink(request.getResourceResolver(),
							"/assets.html".concat(resource.getPath())));
				}
				if (!list.isEmpty()) {
					arrayList.add(list);
				}
			}
		}
		return arrayList;
	}

	private static List<String> getAssetUpload(SlingHttpServletRequest request, List<String> myList) {
		int i = 0;
		String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		while (queryResult.hasNext()) {
			Resource resource = queryResult.next();
			if (isValidPath(resource.getPath())
					&& StringUtils.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
				++i;
			}
		}
		myList.add(0, String.valueOf(i));
		return myList;
	}

	private static List<ArrayList<String>> getAssetDownload(SlingHttpServletRequest request, List<String> myList,
															Externalizer externalizer) {
		resourceResolver = request.getResourceResolver();
		String query = "select * from [cq:AuditEvent] where [cq:type]='DOWNLOADED'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		ArrayList<ArrayList<String>> arrayList = new ArrayList<>();
		Map<String, Integer> map = new HashMap<>();
		int count = 0;
		while (queryResult.hasNext()) {
			count++;
			Resource res = queryResult.next();
			if (isNotNull(res)) {
				ValueMap valueMap = res.getValueMap();
				String key = (String) valueMap.get("cq:path");
				if (map.containsKey(key)) {
					map.put(key, map.get(key) + 1);
				} else {
					map.put(key, 1);
				}
			}
		}
		for (Entry<String, Integer> entry : map.entrySet()) {
			ArrayList<String> list = new ArrayList<>();
			list.add(externalizer.authorLink(request.getResourceResolver(), "/assets.html".concat(entry.getKey())));
			list.add(String.valueOf(entry.getValue()));
			arrayList.add(list);
		}
		myList.add(1, String.valueOf(count));
		return arrayList;
	}

	private static List<String> getTotalAssets(SlingHttpServletRequest request, List<String> myList) {
		String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		int i = 0;
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		while (queryResult.hasNext()) {
			Resource resource = queryResult.next();
			if (isValidPath(resource.getPath())
					&& StringUtils.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
				++i;
			}
		}
		myList.add(2, String.valueOf(i));
		return myList;
	}

	private static List<ArrayList<String>> getAssetsCountList(SlingHttpServletRequest request,
															  Externalizer externalizer) {
		resourceResolver = request.getResourceResolver();
		String query1 = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query1, Query.JCR_SQL2);
		ArrayList<ArrayList<String>> arrayList = new ArrayList<>();
		PageManager manager = request.getResourceResolver().adaptTo(PageManager.class);
		while (queryResult.hasNext()) {
			int count = 0;
			Resource resource = queryResult.next();
			if (isValidPath(resource.getPath())
					&& StringUtils.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
				query1 = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([/content/texas-instruments/en-us]) and CONTAINS(s.*,'"
						+ resource.getPath() + "')";
				Iterator<Resource> referecesResult = request.getResourceResolver().findResources(query1,
						Query.JCR_SQL2);
				ArrayList<String> pagePaths = new ArrayList<>();
				while (referecesResult.hasNext()) {
					Resource pageRes = referecesResult.next();
					if (isNotNull(pageRes) && isNotNull(manager)) {
						String mappedPath = PathBrowserHelper.addHtmlIfContentPath(resourceResolver,
								manager.getContainingPage(pageRes).getPath());
						mappedPath = mappedPath.replace("/content/texas-instruments/en-us", "");
						pagePaths.add(mappedPath);
					}
					count++;
				}
				ArrayList<String> list = new ArrayList<>();
				list.add(externalizer.authorLink(resourceResolver, "/assets.html".concat(resource.getPath())));
				list.add(String.valueOf(count));
				list.add(String.join(",", pagePaths));
				Resource jcrRes = resource.getChild(JcrConstants.JCR_CONTENT);
				if (jcrRes != null) {
					ValueMap valueMap = jcrRes.getValueMap();
					if (StringUtils.equalsIgnoreCase(valueMap.get("cq:lastReplicationAction", String.class),
							"Activate")) {
						list.add("Published");
						String assetPath = StringUtils.remove(StringUtils.remove(resource.getPath(), DAM_ASSET_TICOM),
								DAM_PATH_TINEWS);
						list.add(externalizer.externalLink(resourceResolver, "publish", assetPath));
					} else {
						list.add("Not Published");
						list.add(StringUtils.EMPTY);
					}
				}
				arrayList.add(list);
			}
		}
		return arrayList;
	}

	public static void getDamAnalyticsReport(SlingHttpServletRequest request, SlingHttpServletResponse response,
											 Externalizer externalizer, String outputType) throws IOException {
		List<String> assetsNotDownlaoded = assetsNotDownlaoded(request, externalizer);
		List<ArrayList<String>> listAssets = getNonExistingAssetsList(request, externalizer);
		CsvListWriter beanWriter = null;
		try {
			while (listAssets.size() < assetsNotDownlaoded.size()) {
				ArrayList<String> empty = new ArrayList<>();
				empty.add(StringUtils.EMPTY);
				listAssets.add(empty);
			}
			for (int i = 0; i < assetsNotDownlaoded.size(); i++) {
				listAssets.get(i).add(assetsNotDownlaoded.get(i));
			}
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "Assets - Not In Use", "Assets - Not Downloaded" };
				String csvFileName = "DamAssetsArchive.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < listAssets.size(); i++) {
					beanWriter.write(listAssets.get(i));
				}
				beanWriter.close();
			} else {
				response.getWriter().println(new Gson().toJson(listAssets));
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	private static List<String> assetsNotDownlaoded(SlingHttpServletRequest request, Externalizer externalizer) {
		List<String> totalAssets = getTotalAssetsList(request, externalizer);
		Set<String> downloadedAssets = downloadedAssets(request, externalizer);
		for (String asset : downloadedAssets) {
			totalAssets.remove(asset);
		}
		return totalAssets;
	}

	private static List<String> getTotalAssetsList(SlingHttpServletRequest request, Externalizer externalizer) {
		List<String> list = new ArrayList<>();
		String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		while (queryResult.hasNext()) {
			Resource resource = queryResult.next();
			if (isValidPath(resource.getPath())
					&& StringUtils.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
				list.add(externalizer.authorLink(request.getResourceResolver(),
						"/assets.html".concat(resource.getPath())));
			}
		}
		return list;
	}

	private static List<ArrayList<String>> getDamAssetUplaodedList(SlingHttpServletRequest request,
																   Externalizer externalizer, String startDate, String endDate) {
		DateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		DateFormat jcrFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
		int i = 0;
		String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
				+ "]) and s.[jcr:primaryType]='dam:Asset'";
		List<String> myList = new ArrayList<>();
		List<ArrayList<String>> arrayList = new ArrayList<>();
		try {
			if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
				query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + DAM_PATH
						+ "]) and s.[jcr:primaryType]='dam:Asset' and s.[jcr:created] >= CAST('"
						+ jcrFormat.format(simpleFormat.parse(startDate)) + "' AS DATE) and s.[jcr:created] <= CAST('"
						+ jcrFormat.format(simpleFormat.parse(endDate)) + "' AS DATE)";
			}
			Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
			while (queryResult.hasNext()) {
				Resource resource = queryResult.next();
				if (isValidPath(resource.getPath()) && StringUtils
						.isBlank(resource.getValueMap().get("jcr:content/contentFragment", String.class))) {
					ArrayList<String> list = new ArrayList<>();
					list.add(externalizer.authorLink(request.getResourceResolver(),
							"/assets.html".concat(resource.getPath())));
					arrayList.add(list);
					++i;
				}
			}
			myList.add(String.valueOf(i));
		} catch (ParseException ex) {
			ex.getMessage();
		}
		if (arrayList.isEmpty()) {
			ArrayList<String> emptyList = new ArrayList<>();
			emptyList.add(StringUtils.EMPTY);
			arrayList.add(emptyList);
			arrayList.get(0).addAll(myList);
		} else {
			arrayList.get(0).addAll(myList);
		}
		return arrayList;
	}

	public static void getDAMAssetUploadedReport(SlingHttpServletRequest request, SlingHttpServletResponse response,
												 Externalizer externalizer, String outputType) {
		DateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		if (StringUtils.isNotBlank(startDate) && StringUtils.isBlank(endDate)) {
			endDate = simpleFormat.format(new Date());
		}
		String reportColumn1 = "(" + startDate + " - " + endDate + ")";
		List<ArrayList<String>> listAssets = getDamAssetUplaodedList(request, externalizer, startDate, endDate);
		CsvListWriter beanWriter = null;
		try {
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "Uploaded Assets" + reportColumn1, "Total Assets Count" };
				String csvFileName = "Assetsuploaded.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < listAssets.size(); i++) {
					beanWriter.write(listAssets.get(i));
				}
				beanWriter.close();
			} else {
				response.getWriter().println(new Gson().toJson(listAssets));
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	public static void getDAMAssetEvmboard(SlingHttpServletRequest request, SlingHttpServletResponse response,
										   Externalizer externalizer, String outputType) {
		List<ArrayList<String>> listAssets = getDamAssetEvmList(request, externalizer);
		CsvListWriter beanWriter = null;
		try {
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "filename", "url", "title", "keywords", "SAP material name",
						"GPN" };
				String csvFileName = "DAM_Assets_Evmboard.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < listAssets.size(); i++) {
					beanWriter.write(listAssets.get(i));
				}
				beanWriter.close();
			} else {
				JsonArray array = new JsonArray();
				for (int i = 0; i < listAssets.size(); i++) {
					JsonObject jsonObject = new JsonObject();
					jsonObject.addProperty("filename", listAssets.get(i).get(0));
					jsonObject.addProperty("url", listAssets.get(i).get(1));
					jsonObject.addProperty("title", listAssets.get(i).get(2));
					jsonObject.addProperty("keywords", listAssets.get(i).get(3));
					jsonObject.addProperty("SAP material name", listAssets.get(i).get(4));
					jsonObject.addProperty("GPN", listAssets.get(i).get(5));
					array.add(jsonObject);
				}
				JsonObject object = new JsonObject();
				object.add("evm-board", array);
				response.getWriter().println(object.toString());
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	public static void getAemHierachyPages(SlingHttpServletRequest request, SlingHttpServletResponse response,
										   Externalizer externalizer, String outputType) {
		List<String> pagesList = getAemHierachyPagesList(request, externalizer);
		CsvListWriter beanWriter = null;
		try {
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "Hierarchy Pages" };
				String csvFileName = "aem_hierarchy_pages.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < pagesList.size(); i++) {
					beanWriter.write(pagesList.get(i));
				}
				beanWriter.close();
			} else {
				response.getWriter().println(new Gson().toJson(pagesList));
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	private static List<String> getAemHierachyPagesList(SlingHttpServletRequest request, Externalizer externalizer) {
		List<String> list = new ArrayList<>();
		String query = "SELECT * FROM [cq:Page] AS page WHERE ISDESCENDANTNODE(page, '" + CONTENT_PATH + "')";
		Iterator<Resource> iterator = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		while (iterator.hasNext()) {
			Resource resource = iterator.next();
			if (isHierarchyPageAndPublished(resource)) {
				list.add(externalizer.authorLink(request.getResourceResolver(),
						"/editor.html".concat(resource.getPath()).concat(".html")));
			}
		}
		return list;
	}

	private static boolean isHierarchyPageAndPublished(Resource resource) {
		Page page = Objects.nonNull(resource) ? resource.adaptTo(Page.class) : null;
		if (Objects.nonNull(page) && page.listChildren().hasNext()) {
			ReplicationStatus replicationStatus = page.adaptTo(ReplicationStatus.class);
			if (Objects.nonNull(replicationStatus)) {
				return replicationStatus.isActivated();
			}
		}
		return false;
	}

	private static List<ArrayList<String>> getDamAssetEvmList(SlingHttpServletRequest request,
															  Externalizer externalizer) {
		List<ArrayList<String>> arrayList = new ArrayList<>();
		String folderNameQuery = "SELECT * FROM [sling:Folder] AS page WHERE ISDESCENDANTNODE(page, '/content/dam/ticom/images') AND name() like '%evm-board%'";
		Iterator<Resource> evmFolderResult = request.getResourceResolver().findResources(folderNameQuery,
				Query.JCR_SQL2);
		while (evmFolderResult.hasNext()) {
			Resource folderRes = evmFolderResult.next();
			String query = "SELECT * FROM [nt:base] AS s WHERE ISDESCENDANTNODE([" + folderRes.getPath()
					+ "]) and s.[jcr:primaryType]='dam:Asset'";
			Iterator<Resource> queryResult = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
			while (queryResult.hasNext()) {
				Resource resource = queryResult.next();
				if (Objects.nonNull(resource)) {
					Resource metadata = resource.getChild("jcr:content/metadata");
					ValueMap map = Objects.nonNull(metadata) ? metadata.adaptTo(ValueMap.class) : null;
					if (Objects.nonNull(map)) {
						ArrayList<String> list = new ArrayList<>();
						list.add(map.get("dam:filename", StringUtils.EMPTY));
						list.add(externalizer.publishLink(request.getResourceResolver(), resource.getPath()));
						list.add(map.get("dc:title", StringUtils.EMPTY));
						list.add(map.get("dc:description", StringUtils.EMPTY));
						list.add(map.get("dam:sapMaterialName", StringUtils.EMPTY));
						list.add(map.get("dam:gpn", StringUtils.EMPTY));
						arrayList.add(list);
					}
				}
			}
		}
		return arrayList;
	}

	private static boolean isValidPath(String path) {
		return StringUtils.startsWith(path, DAM_ASSET_TICOM) || StringUtils.startsWith(path, DAM_PATH_TINEWS);
	}

	public static void getAemPageComponentsReport(SlingHttpServletRequest request, SlingHttpServletResponse response,
												  WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, SeoUrlFactoryConfigs factoryConfigs, String outputType) {
		try {
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				PageManager manager = request.getResourceResolver().adaptTo(PageManager.class);
				String componentType = request.getParameter("componentType");
				String[] commonColumns = new String[] {"Language", "Page Path"};
				if (StringUtils.equals("featured-product", componentType)) {
					String[] featuredProduct = new String[]{"ordernowURL", "evaluationmodule",
							"description", "fileReference", "productGPNName", "referencedesigns", "partURL", "textLinkCTA",
							"downloaddatasheet", "ctaOptionsFP", "toolssoftware", "textLinkCTAURL", "onlinedatasheet",
							"cta1title", "cta1URL", "cta2title", "cta2URL", "cta3title", "cta3URL"};
					featuredProduct = ArrayUtils.addAll(commonColumns, featuredProduct);
					getComponentsReport(request, response, wcmService, tabsService, factoryConfigs, componentType, manager, featuredProduct, "ti/components/featuredProduct");
				} else if (StringUtils.equals("featured-ref-design", componentType)) {
					String[] featuredRefDesign = new String[] {"referenceDesignOrderNowURL", "designFilesUrl", "schematicDiagramUrl", "designGuideUrl", "referenceDesignName", "viewDesignURL", "fileReference", "imgAltText",
							"referenceDesignPartNumber", "cta1Title", "cta1Url", "cta2Title", "cta2Url", "cta3Title",
							"cta3Url" };
					featuredRefDesign = ArrayUtils.addAll(commonColumns, featuredRefDesign);
					getComponentsReport(request, response, wcmService, tabsService, factoryConfigs, componentType, manager, featuredRefDesign, "ti/components/featuredReferenceDesign");
				} else if (StringUtils.equals("featured-tool", componentType)) {
					String[] featuredTool = new String[] {"listItems", "fileReference", "imgAltText", "manufacturer",
							"featureToolDesc", "toolInfoCtaLabel", "toolInfoUrl", "orderNowCtaLabel", "orderNowUrl", "toolSoftwareName" };
					featuredTool = ArrayUtils.addAll(commonColumns, featuredTool);
					getComponentsReport(request, response, wcmService, tabsService, factoryConfigs, componentType, manager, featuredTool, "ti/components/featuredTool");
				}
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}


	private static void getComponentsReport(SlingHttpServletRequest request, SlingHttpServletResponse response, WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, SeoUrlFactoryConfigs factoryConfigs,
											String componentType, PageManager manager, String[] header, String componentName) throws IOException {
		String headerKey = "Content-Disposition";
		CsvListWriter beanWriter = null;
		String csvFileName = componentType.concat(".csv");
		String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
		response.setHeader(headerKey, headerValue);
		response.setCharacterEncoding("UTF-8");
		beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		beanWriter.writeHeader(header);
		List<List<String>> componentList = new ArrayList<>();
		String query = "SELECT * FROM [nt:unstructured] AS comp WHERE ISDESCENDANTNODE(comp, '/content/texas-instruments') AND [sling:resourceType] = '" + componentName +"'";
		Iterator<Resource> iterator = request.getResourceResolver().findResources(query, Query.JCR_SQL2);
		while (iterator.hasNext()) {
			List<String> list = new ArrayList<>();
			Resource resource = iterator.next();
			ValueMap valueMap = resource.getValueMap();
			Page page = manager.getContainingPage(resource);
			list.add(page.getLanguage(false).toString().replaceAll("_", "-"));
			String mappedPath = PathBrowserHelper.addHtmlIfContentPath(request.getResourceResolver(), page.getPath());
			mappedPath = mappedPath.replace("/content/texas-instruments/en-us", "").replace("/content/texas-instruments", "");
			list.add(mappedPath);
			int i = 2;
			if (StringUtils.equals(componentName, "ti/components/featuredReferenceDesign")) {
				String referenceDesignPartNumber = valueMap.get("referenceDesignPartNumber", StringUtils.EMPTY);
				list.add(getOrderNowUrl(request, wcmService, tabsService, page, factoryConfigs, referenceDesignPartNumber));
				String techDocUrl = PathBrowserHelper.addHtmlIfContentPath(request.getResourceResolver(), getTechDocUrl(request, wcmService, tabsService, referenceDesignPartNumber, factoryConfigs, page));
				list.add(techDocUrl);
				list.add(techDocUrl);
				list.add(techDocUrl);
				list.add(getReferenceDesignName(request, wcmService, tabsService, referenceDesignPartNumber, page));
				String languageCode = tabsService.getLanguageCodeForPage(page).toLowerCase();
				list.add(URLHelper.toScheme(getReferenceDesignURL(referenceDesignPartNumber, factoryConfigs, page, languageCode), URLHelper.getScheme(request)));
				i = 8;
			} else if (StringUtils.equals(componentName, "ti/components/featuredTool")) {
				String[] listItems = valueMap.get("listItems", String[].class);
				String items = valueMap.get("listItems", String.class);
				if (Objects.isNull(listItems) && StringUtils.isBlank(items)) {
					Resource listItemsRes = resource.getChild("listItems");
					Iterator<Resource> iter = Objects.nonNull(listItemsRes) ? listItemsRes.listChildren() : null;
					List<String> listItemsList = new ArrayList<>();
					while (Objects.nonNull(iter) && iter.hasNext()) {
						listItemsList.add(iter.next().getValueMap().get("itemValue", StringUtils.EMPTY));
					}
					list.add(String.join(",", listItemsList).replaceAll("=", ""));
				} else if (Objects.nonNull(listItems) && listItems.length > 0) {
					list.add(String.join(",", listItems).replaceAll("=", ""));
				} else {
					list.add(valueMap.get("listItems", StringUtils.EMPTY).replaceAll("=", ""));
				}
				i = 3;
			}
			for (;i < header.length; i++) {
				list.add(valueMap.get(header[i], StringUtils.EMPTY).replaceAll("\"", "'"));

			}
			componentList.add(list);
		}
		for (List<String> component : componentList) {
			beanWriter.write(component);
		}
		if (Objects.nonNull(beanWriter)) {
			beanWriter.close();
		}
	}



	private static JSONObject getToolsDetails(SlingHttpServletRequest request, WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, Page page, String referenceDesignPartNumber) {
		try {
			String language = tabsService.getPageLanguage(page);
			String toolDetails = wcmService.getToolDetailService(request, referenceDesignPartNumber, language);
			return new JSONObject(toolDetails);
		} catch (Exception e) {
			log.error("Exception {}", e);
		}
		return null;
	}

	private static String getTechDocUrl(SlingHttpServletRequest request, WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, String referenceDesignPartNumber, SeoUrlFactoryConfigs factoryConfigs, Page page) {
		try {
			JSONObject jsonObject = getToolsDetails(request, wcmService, tabsService, page, referenceDesignPartNumber);
			if(Objects.nonNull(jsonObject)) {
				String hasGetOptions = jsonObject.getString(HAS_GET_OPTIONS);
				if (StringUtils.isNotEmpty(hasGetOptions) && ("Y").equalsIgnoreCase(hasGetOptions)) {
					return generateDomain(factoryConfigs, page) + TOOL_PATH + jsonObject.getString("toolPartNumber") + "#technicaldocuments";
				}
			}
		} catch(Exception e) {
			log.error("Exception {}", e);
		}
		return StringUtils.EMPTY;
	}

	private static String getReferenceDesignName(SlingHttpServletRequest request, WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, String referenceDesignPartNumber, Page page) {
		try {
			JSONObject jsonObject = getToolsDetails(request, wcmService, tabsService, page, referenceDesignPartNumber);
			if(Objects.nonNull(jsonObject)) {
				return jsonObject.getString("description");
			}
		} catch(Exception e) {
			log.error("Exception {}", e);
		}
		return StringUtils.EMPTY;
	}

	private static String getOrderNowUrl(SlingHttpServletRequest request, WCMComponents wcmService, ProductNavigationTabsOrdering tabsService, Page page, SeoUrlFactoryConfigs factoryConfigs, String referenceDesignPartNumber) {
		try {
			String languageCode = tabsService.getLanguageCodeForPage(page).toLowerCase();
			String referenceDesignURL = URLHelper.toScheme(getReferenceDesignURL(referenceDesignPartNumber, factoryConfigs, page, languageCode), URLHelper.getScheme(request));
			JSONObject jsonObject = getToolsDetails(request, wcmService, tabsService, page, referenceDesignPartNumber);
			if (Objects.nonNull(jsonObject)) {
				String hasGetOptions = jsonObject.getString(HAS_GET_OPTIONS);
				if (StringUtils.isNotEmpty(hasGetOptions) && ("Y").equalsIgnoreCase(hasGetOptions)) {
					return referenceDesignURL + ORDER_NOW_ANCHOR_TAG;
				}
			}
		} catch (Exception e) {
			log.error("Exception {}", e);
		}
		return StringUtils.EMPTY;
	}

	private static String getReferenceDesignURL(String referenceDesignPartNumber, SeoUrlFactoryConfigs factoryConfigs, Page page, String languageCode) {

		if (StringUtils.isNotBlank(languageCode) && Constants.LANG_CODE_CN.contains(languageCode)) {
			return generateDomain(factoryConfigs, page) + TOOL_PATH + languageCode + URL_DELIMITER + referenceDesignPartNumber;
		} else {
			return generateDomain(factoryConfigs, page) + TOOL_PATH + referenceDesignPartNumber;
		}
	}

	private static String generateDomain(SeoUrlFactoryConfigs factoryConfigs, Page page) {
		String domain = StringUtils.EMPTY;
		if (Objects.nonNull(factoryConfigs)) {
			List<SeoUrlTagging> listConfig = factoryConfigs.getConfigs();
			for (SeoUrlTagging seoUrlTagging : listConfig) {
				if (StringUtils.containsIgnoreCase(page.getPath(), seoUrlTagging.getContentPath())) {
					domain = seoUrlTagging.getDomainName();
					domain = SLASH.concat(domain);
					break;
				}
			}
		}
		return domain;
	}

	public static void getDAMAssetDetails(SlingHttpServletRequest request, SlingHttpServletResponse response,
			Externalizer externalizer, String outputType) {
		List<ArrayList<String>> listAssets = getDamAssetDetailsList(request, externalizer);
		CsvListWriter beanWriter = null;
		try {
			if (StringUtils.equalsIgnoreCase(outputType, "csv")) {
				final String[] header = new String[] { "Title","FileName","Description","PublicationDate","Status","Perspective","PinCount","PackageDesignator","PackageVariant","AssetType","PublishUrl","SAPMaterialName","GPN","LastReplicationAction","Username" };
				String csvFileName = "DAM_Assets_Details.csv";
				response.setContentType("text/csv");
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
				response.setHeader(headerKey, headerValue);
				beanWriter = new CsvListWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
				// write the header
				beanWriter.writeHeader(header);
				for (int i = 0; i < listAssets.size(); i++) {
					beanWriter.write(listAssets.get(i));
				}
				beanWriter.close();
			} else {
				JsonArray array = new JsonArray();
				for (int i = 0; i < listAssets.size(); i++) {
					JsonObject jsonObject = new JsonObject();
					jsonObject.addProperty("Title", listAssets.get(i).get(0));
					jsonObject.addProperty("FileName", listAssets.get(i).get(1));
					jsonObject.addProperty("Description", listAssets.get(i).get(2));
					jsonObject.addProperty("Status", listAssets.get(i).get(3));
					jsonObject.addProperty("Perspective", listAssets.get(i).get(4));
					jsonObject.addProperty("PinCount", listAssets.get(i).get(5));
					jsonObject.addProperty("PackageDesignator", listAssets.get(i).get(6));
					jsonObject.addProperty("PackageVariant", listAssets.get(i).get(7));
					jsonObject.addProperty("AssetType", listAssets.get(i).get(8));
					jsonObject.addProperty("PublishUrl", listAssets.get(i).get(9));
					jsonObject.addProperty("SAPMaterialName", listAssets.get(i).get(10));
					jsonObject.addProperty("GPN", listAssets.get(i).get(11));
					jsonObject.addProperty("AcquiredDate", listAssets.get(i).get(12));
					jsonObject.addProperty("MarketTree", listAssets.get(i).get(13));
					jsonObject.addProperty("PublicationDate", listAssets.get(i).get(14));
					jsonObject.addProperty("LastReplicationAction", listAssets.get(i).get(15));
					jsonObject.addProperty("Username", listAssets.get(i).get(16));
					array.add(jsonObject);
				}
				JsonObject object = new JsonObject();
				object.add("Image-Details", array);
				response.getWriter().println(object.toString());
			}
		} catch (IOException ex) {
			log.error(EXCEPTION_MESSAGE, ex);
		}
	}

	private static List<ArrayList<String>> getDamAssetDetailsList(SlingHttpServletRequest request,
		Externalizer externalizer) {
	List<ArrayList<String>> arrayList = new ArrayList<>();

	DateFormat jcrFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
	DateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
	String startDate = request.getParameter("startDate");
	String endDate = request.getParameter("endDate");

	String folderNameQuery =
		"SELECT * FROM [dam:Asset] AS page WHERE ("
		  + "("
			+ "("
			  + "ISDESCENDANTNODE(page, '/content/dam/ticom/images/applications')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/radar/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/custom-power-products/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/hival/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/dataconverters/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/dlp-products/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/wireless-connectivity/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/amplifiers/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/space-high-reliability/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/logic/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/sensing-products/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/motor-drivers/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/clock-timing/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/microcontrollers/hercules/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/microcontrollers/performance/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/microcontrollers/simplelink/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/microcontrollers/msp/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/high-voltage/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/non-isolated-dc-dc-switching-regulator/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/digital-power-control-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/sequencer/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/power-management-multi-channel-ic-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/lcd-oled-display-bias-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/offline-isolated-dc-dc-controllers-converters/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/usb-power-charging-port-controllers/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/gallium-nitride-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/battery-management/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/power-modules/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/integrated-load-switches/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/supervisor-reset/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/led-driver/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/linear-regulator/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/mosfet-or-igbt-gate-drivers/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/power-mosfet/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/voltage-reference/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/power-over-ethernet-lan-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/switches-multiplexers/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/isolation/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/interface/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/processors/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/rf-microwave/evm-board')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/audio/evm-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/legacy-boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/mosfet-and-igbt-gate-drivers/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/microcontrollers/tm4c/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/oring-and-smart-diodes/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/ddr-memory-power-solutions/boards')"
			  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/ic/power-management/protection-monitoring-hot-swap/boards')"
			+ ") and ("
			  + "[jcr:content/metadata/dam:perspective] LIKE '%angled'"
			  + " or [jcr:content/metadata/dam:perspective] LIKE '%top'"
			  + " or [jcr:content/metadata/dam:perspective] LIKE '%bottom'"
			  + " or [jcr:content/metadata/dam:perspective] LIKE '%what-is-included'"
			+ ")"
		  + ") or ("
			+ "ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/package')"
			+ " and [jcr:content/metadata/dam:perspective] LIKE '%angled'"
		  + ")"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/third-party/awards')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/themes/certification')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/identities/third-party')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/design-boards')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/design-schematics')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/products/software')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/third-party/products')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/third-party/software')"
		  + " or ISDESCENDANTNODE(page, '/content/dam/ticom/images/third-party/diagrams')"
		  + " or ("
			+ "ISDESCENDANTNODE(page, '/content/dam/ticom/images/end-equipment')"
			+ "and [jcr:content/metadata/dam:perspective] LIKE '%top'"
		  + ")"
		+ ") and page.[jcr:primaryType]='dam:Asset'"
		+ " AND [jcr:path] NOT LIKE '%/subassets/%'";

	try {

	    if (StringUtils.isNotBlank(startDate) && StringUtils.isBlank(endDate)) {
		endDate = simpleFormat.format(new Date());
	    }

	    if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
		folderNameQuery = folderNameQuery + "and [jcr:content/cq:lastReplicated] >= CAST('"+ jcrFormat.format(simpleFormat.parse(startDate))+ "' AS DATE) and [jcr:content/cq:lastReplicated] <= CAST('"+ jcrFormat.format(simpleFormat.parse(endDate)) + "' AS DATE)";
	    }

	log.debug("startDate>>"+startDate);
	log.debug("endDate>>"+endDate);
	log.debug("folderNameQuery>>"+folderNameQuery);
	String[] subpages= null;

	Iterator<Resource> imageFolderResult = request.getResourceResolver().findResources(folderNameQuery,
			Query.JCR_SQL2);
	while (imageFolderResult.hasNext()) {
		Resource folderRes = imageFolderResult.next();
		ArrayList<String> list = new ArrayList<>();
				Resource metadata = folderRes.getChild("jcr:content/metadata");
				Resource jcrContent = folderRes.getChild(JcrConstants.JCR_CONTENT);
				ValueMap jcrMap = Objects.nonNull(jcrContent) ? jcrContent.adaptTo(ValueMap.class) : null;
				ValueMap map = Objects.nonNull(metadata) ? metadata.adaptTo(ValueMap.class) : null;
				ValueMap folderMap = Objects.nonNull(folderRes) ? folderRes.adaptTo(ValueMap.class) : null;

				String marketTree = "NULL";

				if (Objects.nonNull(map)) {
					list.add(map.get("dc:title", StringUtils.EMPTY));
					list.add(map.get("dam:filename", StringUtils.EMPTY));
					list.add(map.get("dc:description", StringUtils.EMPTY));
					list.add(map.get("dam:status", StringUtils.EMPTY));
					list.add(map.get("dam:perspective", StringUtils.EMPTY));
					list.add(map.get("dam:pinCount", StringUtils.EMPTY));
					list.add(map.get("dam:packageDesignator", StringUtils.EMPTY));
					list.add(map.get("dam:epodOrPackageVariant", StringUtils.EMPTY));
					list.add(map.get("dam:assetType", StringUtils.EMPTY));
					list.add(externalizer.publishLink(request.getResourceResolver(), folderRes.getPath()));
					list.add(map.get("dam:sapMaterialName", StringUtils.EMPTY));
					list.add(map.get("dam:gpn", StringUtils.EMPTY));
					list.add(map.get("dam:acquiredDate", StringUtils.EMPTY));
					subpages =  map.get("dam:importedMarket", String[].class);
					if(null!=subpages){
						marketTree=String.join(":", subpages).replaceAll("imported:markets", "");
					}
					 list.add(marketTree);

				}

				if (Objects.nonNull(jcrMap)) {
					list.add(jcrMap.get("cq:lastReplicated", StringUtils.EMPTY));
					list.add(jcrMap.get("cq:lastReplicationAction", StringUtils.EMPTY));
				}

				if (Objects.nonNull(folderMap)) {
					list.add(folderMap.get("jcr:createdBy", StringUtils.EMPTY));
				}
				arrayList.add(list);
	}
	} catch (ParseException ex) {
		log.error(EXCEPTION_MESSAGE, ex);
	}
	return arrayList;
}

}
