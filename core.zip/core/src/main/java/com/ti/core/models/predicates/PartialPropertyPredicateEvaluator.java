package com.ti.core.models.predicates;

import org.osgi.service.component.annotations.Component;

import com.day.cq.search.Predicate;
import com.day.cq.search.eval.AbstractPredicateEvaluator;
import com.day.cq.search.eval.EvaluationContext;
import com.day.cq.search.eval.XPath;
@Component(factory = "com.day.cq.search.eval.PredicateEvaluator/partialproperty")
public class PartialPropertyPredicateEvaluator extends AbstractPredicateEvaluator {
	private static final String PROPERTY = "partialproperty";
	private static final String VALUE = "1_value";

	@Override
	public String getXPathExpression(final Predicate p, final EvaluationContext context) {
		if (!p.hasNonEmptyValue(VALUE)) {
			return null;
		}
		return "jcr:contains(" + p.get(PROPERTY, ".") + ", " + XPath.getFulltextStringLiteral("*" + p.get(VALUE) + "*")
				+ ")";
	}

	@Override
	public boolean canXpath(final Predicate predicate, final EvaluationContext context) {
		return true;
	}

	@Override
	public boolean canFilter(final Predicate predicate, final EvaluationContext context) {
		return true;
	}
}

