package com.ti.core.components;

import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.PathBrowserHelper;

/**
 * PortableQuickSearch WCMUsePojo.
 */
public class PortableQuickSearch extends WCMUsePojo {
  private String familyId;
  private String selToolUrl;
  private String lang = "";
  
  @Override
  public void activate() throws Exception {	  
      Page currentPage = getCurrentPage();
      
      if (currentPage != null) {
    	  // If Family Id is not set by the author, get it from the page properties
    	  familyId = getProperties().get("familyId", String.class);
    	  if (StringUtils.isEmpty(familyId)) {
    		  familyId = currentPage.getProperties().get("familyId", String.class);
    	  }
    	  
    	  // If selToolUrl is not set by the author, attempt to determine it programmatically
    	  selToolUrl = getProperties().get("selToolUrl", String.class);
    	  if (StringUtils.isEmpty(selToolUrl)) {
    		Page parentPage = currentPage.getParent();
    		
    		if (parentPage != null) {
    			Iterator<Page> siblingPages = parentPage.listChildren();
    			Page page;			
    			while (siblingPages.hasNext()) {
    				page = siblingPages.next();
    				if ("products".equalsIgnoreCase(page.getName())) {
    					selToolUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), page.getPath());
    					break;
    				}
    			}			
    		}
    	  }
    	  
    	  ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
    		        .getService(ProductNavigationTabsOrdering.class);    	  
      	  if (tabsService != null)
			lang = tabsService.getLanguageCodeForPage(getCurrentPage()).toLowerCase();
			// bandaid fix for selection tool for mx and tw
			if ("mx".equals(lang) || "tw".equals(lang)) lang = "en";
      }	  
  } 
      
  public String getFamilyId() {
	  return familyId;
  }
  
  public String getSelectionToolUrl() {
	  return selToolUrl;
  }
  
  public String getLang() {
	if ("en".equals(lang))
		return "";
	else
		return lang;
  }
}