package com.ti.core.components;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.Constants;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;

public class FeaturedReferenceDesign extends WCMUsePojo {

	private String referenceDesignPartNumber;
	private String referenceDesignName;
	private String referenceDesignTechnicalDocumentURL;
	private String referenceDesignOrderNowURL;
	private String viewDesignURL;
	private String cta1Url;
	private String cta2Url;
	private String cta3Url;
	private List<SeoUrlTagging> listConfig;

	private static Logger log = LoggerFactory.getLogger(FeaturedReferenceDesign.class);
	private static final String REFERENCE_DESIGN_PART_NUMBER = "referenceDesignPartNumber";
	private static final String REFERENCE_DESIGN_NAME = "description";
	private static final String TOOL_PATH = "/tool/";
	private static final String URL_DELIMITER = "/";
	private static final String SLASH = "//";
	private static final String TECHINICAL_DOCUMENTS_ANCHOR_TAG = "#technicaldocuments";
	private static final String ORDER_NOW_ANCHOR_TAG = "#buy";
	private static final String HAS_GET_OPTIONS = "hasGetOptions";

	@Override
	public void activate() {
		String language = null;
		String languageCode = null;

		ValueMap properties = getProperties();
		cta1Url = URLHelper.toScheme(
				PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get("cta1Url", "")),
				URLHelper.getScheme(getRequest()));
		cta2Url = URLHelper.toScheme(
				PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get("cta2Url", "")),
				URLHelper.getScheme(getRequest()));
		cta3Url = URLHelper.toScheme(
				PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get("cta3Url", "")),
				URLHelper.getScheme(getRequest()));
		referenceDesignPartNumber = properties.get(REFERENCE_DESIGN_PART_NUMBER, "");
		log.debug("referenceDesignPartNumber :" + referenceDesignPartNumber);
		WCMComponents wcmService = getSlingScriptHelper().getService(WCMComponents.class);
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		if (StringUtils.isNotEmpty(referenceDesignPartNumber)) {
			if (null != tabsService) {
				language = tabsService.getPageLanguage(getCurrentPage());
				languageCode = tabsService.getLanguageCodeForPage(getCurrentPage()).toLowerCase();

			}
			if (null != wcmService) {
				String toolDetails = wcmService.getToolDetailService(getRequest(), referenceDesignPartNumber, language);
				if (StringUtils.isNotEmpty(toolDetails)) {
					try {
						log.debug("toolDetails is not null :" + toolDetails);
						JSONObject jsonToolDetails = new JSONObject(toolDetails);
						this.referenceDesignName = jsonToolDetails.getString(REFERENCE_DESIGN_NAME);
						String referenceDesignURL = URLHelper.toScheme(
								getReferenceDesignURL(referenceDesignPartNumber, languageCode),
								URLHelper.getScheme(getRequest()));
						log.debug("referenceDesignURL :" + referenceDesignURL);
						log.debug("generateDomain :" + generateDomain());
						this.viewDesignURL = referenceDesignURL;
						this.referenceDesignTechnicalDocumentURL = referenceDesignURL + TECHINICAL_DOCUMENTS_ANCHOR_TAG;
						String hasGetOptions = jsonToolDetails.getString(HAS_GET_OPTIONS);
						if (StringUtils.isNotEmpty(hasGetOptions) && ("Y").equalsIgnoreCase(hasGetOptions)) {
							this.referenceDesignOrderNowURL = referenceDesignURL + ORDER_NOW_ANCHOR_TAG;
						}
					} catch (JSONException e) {
						log.error("JSONException: " + e);
					}
				}
			}
		}
	}

	private String generateDomain() {
		String domain = "";
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		if (null != factoryConfigs) {
			listConfig = factoryConfigs.getConfigs();
			for (SeoUrlTagging seoUrlTagging : listConfig) {
				if (StringUtils.containsIgnoreCase(getCurrentPage().getPath(), seoUrlTagging.getContentPath())) {
					domain = seoUrlTagging.getDomainName();
					domain = SLASH.concat(domain);
					break;
				}
			}
		}
		return domain;
	}

	private String getReferenceDesignURL(String referenceDesignPartNumber, String languageCode) {
		if (null != languageCode && !(Constants.LANG_CODES_EN_KR_DE.contains(languageCode))) {
			return generateDomain() + TOOL_PATH + languageCode + URL_DELIMITER + referenceDesignPartNumber;
		} else {
			return generateDomain() + TOOL_PATH + referenceDesignPartNumber;
		}
	}

	public String getReferenceDesignPartNumber() {
		return referenceDesignPartNumber;
	}

	public void setReferenceDesignPartNumber(String referenceDesignPartNumber) {
		this.referenceDesignPartNumber = referenceDesignPartNumber;
	}

	public String getReferenceDesignName() {
		return referenceDesignName;
	}

	public void setReferenceDesignName(String referenceDesignName) {
		this.referenceDesignName = referenceDesignName;
	}

	public String getReferenceDesignTechnicalDocumentURL() {
		return referenceDesignTechnicalDocumentURL;
	}

	public void setReferenceDesignTechnicalDocumentURL(String referenceDesignTechnicalDocumentURL) {
		this.referenceDesignTechnicalDocumentURL = referenceDesignTechnicalDocumentURL;
	}

	public String getReferenceDesignOrderNowURL() {
		return referenceDesignOrderNowURL;
	}

	public void setReferenceDesignOrderNowURL(String referenceDesignOrderNowURL) {
		this.referenceDesignOrderNowURL = referenceDesignOrderNowURL;
	}

	public String getViewDesignURL() {
		return viewDesignURL;
	}

	public void setViewDesignURL(String viewDesignURL) {
		this.viewDesignURL = viewDesignURL;
	}

	public String getCta1Url() {
		return cta1Url;
	}

	public String getCta2Url() {
		return cta2Url;
	}

	public String getCta3Url() {
		return cta3Url;
	}

}
