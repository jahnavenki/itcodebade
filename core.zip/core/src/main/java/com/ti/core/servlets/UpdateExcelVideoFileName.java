package com.ti.core.servlets;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.dam.api.Rendition;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

/**
 *
 * @author x1055799
 */
@SuppressWarnings("serial")
@Component(name = "VideoMigrationExcelUpdate", immediate = true, service = Servlet.class, property = {
	SLING_SERVLET_PATHS + "=/bin/ti/updateExcel",
	SLING_SERVLET_METHODS + "=GET",})
    public class UpdateExcelVideoFileName extends SlingSafeMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(UpdateExcelVideoFileName.class);
	/**
	 * The wcm service.
	 */
	@Reference
	private transient WCMComponents wcmService;

    @Reference
    private transient VideoConfigService videoService;

	private transient ResourceResolver resourceResolver;

	private static String EXCEL_PATH = "/content/dam/videos/migration-data/";
	
	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		try {
			log.debug("Update excel script execution started");				
        	resourceResolver = request.getResourceResolver();
			String videoPath = videoService.getVideoPath();
        	if (videoPath == null || videoPath.length() <= 0) {
            	log.debug("Video path not found in the config");
            	return;
        	}
			String fileName = request.getParameter("fileName");
			String excelPath = EXCEL_PATH + fileName + ".xlsx";
			response.getWriter().write("Update excel script execution started with excel "+ excelPath + "\n");
			Resource resource = resourceResolver.getResource(excelPath);
			InputStream stream = createInputStreamFromResource(resource);
			updateExcelAddFileName(videoPath, stream, fileName);
			response.getWriter().write("Update excel script execution ended");
		} catch (Exception e) {
			log.error("Error occurred in UpdateExcelVideoFileName script", e);
		}		
	}

	private void updateExcelAddFileName(String videoPath, InputStream stream,String fileName) {
		try (XSSFWorkbook workbook = new XSSFWorkbook(stream)) {
            XSSFSheet sheet = workbook.getSheetAt(0);
            DataFormatter dataFormatter = new DataFormatter();
            Iterator<Row> rowIterator = sheet.iterator();  
			int count = 0;  
            while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (count == 0) {
					Cell cell = row.createCell(row.getLastCellNum());
            		cell.setCellValue("dam:fileName{{String}}");	
				}
				else {
                	String videoId = StringUtils.EMPTY;
                	if (row.getCell(0) != null) {
				    	videoId  = dataFormatter.formatCellValue(row.getCell(0));
                	}
                	if (StringUtils.isEmpty(videoId)) {
                    	continue;
                	}
					log.debug("Updating excel for video id {}",videoId);
            		Resource resource = AssetUtils.getDamResource(resourceResolver, videoPath, videoId);
					if (resource != null) {
            			ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
						String videoFileName = map.get("dam:fileName",String.class);
						log.debug("Video file name {} for video id {}",videoFileName,videoId);
            			Cell cell = row.createCell(row.getLastCellNum());
            			cell.setCellValue(videoFileName);
					}
				}
				count++;		
            }
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			workbook.write(outputStream);
			byte[] byteArray = outputStream.toByteArray();
			InputStream inputStream = new ByteArrayInputStream(byteArray);
			AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);
            if (assetManager !=null) {
				fileName = fileName + "Updated";
			    assetManager.createAsset(EXCEL_PATH + fileName + ".xlsx", inputStream, "", true);
            }
            outputStream.close();
		} catch (Exception e) {
			log.error("Exception in updateExcelAddFileName", e);
		}	
	}
	private InputStream createInputStreamFromResource(Resource resource) {
        try {
            Asset asset = resource.adaptTo(Asset.class);
            InputStream stream = null;
            if (asset != null) {
                Rendition original = asset.getOriginal();
                if (original != null) {
                    stream = original.getStream();
                }
            }
            return stream;
        } catch (Exception e) {
			log.error("Error occurred in UpdateExcelVideoFileName createInputStreamFromResource", e);
		  } 
        return null;   
    }
}