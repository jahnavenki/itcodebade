package com.ti.core.servlets;

import com.ti.core.service.WCMComponents;

import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_METHODS;
import static org.apache.sling.api.servlets.ServletResolverConstants.SLING_SERVLET_PATHS;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DocCategoriesServlet is used to read the document categories
 * 
 * @author saryu.sukumar
 *
 

*/
@SuppressWarnings("serial")
@Component(service = Servlet.class, immediate=true, property = {
		SLING_SERVLET_PATHS + "=/bin/ti/doccategories", 
		SLING_SERVLET_METHODS + "=GET" })

public class DocCategoriesServlet extends SlingSafeMethodsServlet {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(DocCategoriesServlet.class);
	private static final String CONTENT_TYPE = "text/x-json;charset=UTF-8";

	/** The Constant DBSOURCE. */
	public static final String DBSOURCE = "aem";

	/** The wcm service. */
	@Reference
	private transient WCMComponents wcmService;

	/**
	 * doGet method
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		executeQuery(response);
	}

	/**
	 * Execute query.
	 *
	 * @param response
	 *            the response
	 */
	public void executeQuery(SlingHttpServletResponse response) {

		String doc = null;
		if (null != wcmService)
			doc = wcmService.getAllDocCategories();
		log.debug("all doc categories" + doc);
		if (null != doc) {
			doc = doc.replaceAll("&#034;", "\"");
			int Posstart = doc.indexOf("[");
			int Posend = doc.indexOf("]");
			doc = doc.substring(Posstart - 1, Posend + 1);
			log.debug("all doc categories after encoded value replaced" + doc);
			JSONArray jsondocresponse = null;
			JSONArray json = new JSONArray();
			try {
				jsondocresponse = new JSONArray(doc.trim());
				for (int i = 0; i < jsondocresponse.length(); i++) {
					JSONObject obj = new JSONObject();
					JSONObject json_data = jsondocresponse.getJSONObject(i);
					log.debug("json values " + json_data.getString("label") + json_data.getString("value") + i);
					obj.put("DOC_CATEGORY_ID", json_data.getString("label"));
					obj.put("DOC_CATEGORY", json_data.getString("value"));
					obj.put("SORT_ORDER", i);
					json.put(obj);
				}
				response.setContentType(CONTENT_TYPE);
				response.getWriter().write(json.toString());
			} catch (JSONException e) {
				log.error("JSON Exception: ", e);
			} catch (IOException e) {
				log.error(" Exception while setting response", e);
			}
		}

	}
}