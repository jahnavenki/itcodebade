package com.ti.core.components.video;

import java.util.regex.Pattern;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;
import com.ti.core.util.LanguageUtils;

public class SingleVideoPageMetadata extends WCMUsePojo {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  
    private String browserTitle;
    private String videoTitle;
    private String metaDescription;
    private String keywords;
    
    private static final String DC_TITLE = "dc:title";
    private static final Pattern SINGLE_VIDEO_PATH = Pattern.compile("/video/(\\d+)$", Pattern.CASE_INSENSITIVE);

    public String getBrowserTitle() {
        return browserTitle;
    }

    public String getMetaDescription() {
        return metaDescription;
    }

    public String getKeywords() {
        return keywords;
    }
  
    public String getVideoTitle() {
		return videoTitle;
	}

	@Override
    public void activate() throws Exception {
        final Resource pageResource = getResource();
        if (null == pageResource) {
            logger.debug("resource is null");
            return;
        }
        final var matcher = SINGLE_VIDEO_PATH.matcher(getRequest().getPathInfo());
        final String videoId = matcher.find() ? matcher.group(1) : null;
        VideoConfigService videoService = getSlingScriptHelper().getService(VideoConfigService.class);
        if (videoService == null || videoService.getVideoPath() == null || videoService.getVideoPath().length() <= 0) {
            logger.debug("Video config null or Path not found");
            return;
        }
		Resource damRes = AssetUtils.getDamResource(getResourceResolver(), videoService.getVideoPath(), videoId);

        if (null == damRes)  {
            getResponse().sendError(404);
            return;
        }
        final var map = AssetUtils.getMetadata(damRes);
        if (null == map)  {
            logger.error("Metadata not found for video id: {} ", videoId);
            return;
        }
        final var videoPage = map.get("dam:videoPage", "no");
        if(!"yes".equalsIgnoreCase(videoPage))  {
            getResponse().sendError(404);
            return;
        }
        LanguageUtils langUtils = new LanguageUtils(getRequest());
        keywords = map.get(DC_TITLE, String.class) + "," + langUtils.getI18nStr("video tutorial"); 
        metaDescription = map.get("brc_description", String.class); 
        browserTitle = map.get(DC_TITLE, String.class);
        videoTitle = map.get(DC_TITLE, String.class);
        String titleSuffix = " | TI.com";
        var language = "en-us";
        final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
        if (null != tabsService) {
            language = tabsService.getPageLanguage(getCurrentPage()).toLowerCase();
        }
        if (language.equalsIgnoreCase("zh-cn")) {
            titleSuffix += ".cn";
        }
        this.browserTitle = browserTitle +" | " +langUtils.getI18nStr("Video") + titleSuffix;
    }
}