package com.ti.core.models.productfamilyapplications;

public class KeyProduct {
  
  private String gpnName;
  private String gpnDesc;
  private String gpnUrl;
  
  public String getGpnName() {
    return gpnName;
  }
  
  public void setGpnName(String gpnName) {
    this.gpnName = gpnName;
  }
  
  public String getGpnDesc() {
    return gpnDesc;
  }
  
  public void setGpnDesc(String gpnDesc) {
    this.gpnDesc = gpnDesc;
  }
  
  public String getGpnUrl() {
    return gpnUrl;
  }
  
  public void setGpnUrl(String gpnUrl) {
    this.gpnUrl = gpnUrl;
  }
}
