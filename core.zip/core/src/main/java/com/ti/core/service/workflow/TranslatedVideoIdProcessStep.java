package com.ti.core.service.workflow;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step for Translated Video Id Field.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Translated Video Id" })
public class TranslatedVideoIdProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(TranslatedVideoIdProcessStep.class);
	
	private static final String LANGUAGE = "language";
    private static final String VIDEOIDTRANSLATION = "videoIdTranslation";
	
	@Reference
	private WCMComponents wcmService;
	@Reference
	private VideoConfigService videoService;
	
	private ResourceResolver resourceResolver;
	
	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			String payload = workflowData.getPayload().toString();
			resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
				throw new NullPointerException("resourceResolver");
			}
			Resource videoResource = resourceResolver.getResource(payload);
			if (null == videoResource) {
				throw new NullPointerException("videoResource");
			}
			ModifiableValueMap valueMap = AssetUtils.getModifiableMetadata(videoResource);
			if (valueMap == null) {
				throw new NullPointerException("valueMap");
			}
			String videoLanguage = valueMap.get("videoSpokenLanguage", "");
			String videoId = valueMap.get("brc_id", "");
			Map<String,String> translationMap = new HashMap<>();
			translationMap.put(videoId, videoLanguage);
			// Get translationList node under metadata
			Resource masterTranslationList = videoResource.getChild("jcr:content/metadata/translationList");
			if (null == masterTranslationList) {
				return;
			}
			for (Resource child : masterTranslationList.getChildren())
			{
				ValueMap property = child.adaptTo(ValueMap.class);
				if (property == null) {
					return;
				}
				translationMap.put(property.get(VIDEOIDTRANSLATION, ""), property.get(LANGUAGE, ""));
			}
			generateTranslationNodes(videoId, translationMap);
			resourceResolver.commit();
		} catch (Exception e) {
			log.error("Error occurred in TranslatedVideoIdProcessStep", e);
		}
	}

	private void generateTranslationNodes(String videoId, Map<String,String> translationMap)
	{
		try {
			String videoPath = videoService.getVideoPath();
			if (videoPath == null || videoPath.length() <= 0) {
				log.debug("Video path not found in the config");
				return;
			}
			for (String translationVideoId : translationMap.keySet())
			{
				// for all translation video ids, except itself, create translation nodes
				if (!translationVideoId.equals(videoId)) {
					Resource video = AssetUtils.getDamResource(resourceResolver, videoPath, translationVideoId);
					if (null == video) {
						throw new NullPointerException("video");
					}
					Resource translationListParent = video.getChild("jcr:content/metadata");
					if (null == translationListParent) {
						throw new NullPointerException("jcr:content/metadata");
					}
					Resource translationList = translationListParent.getChild("translationList");
					if (null != translationList) {
						resourceResolver.delete(translationList);
					}
					generateNodes(translationListParent, translationMap, translationVideoId);
				}
			} // end of for loop
		} catch (Exception e) {
			log.error("Error occurred in TranslatedVideoIdProcessStep generateTranslationNodes", e);
		}
	}

	private void generateNodes(Resource translationListParent, 
								Map<String,String> translationMap, String translationVideoId) {	
		try {	
			Map<String, Object> properties = new HashMap<>();
			properties.put("jcr:primaryType", "nt:unstructured");
			Resource translationList = resourceResolver.create(translationListParent, "translationList", properties);
			int count = 0;
			for (Map.Entry<String,String> entry : translationMap.entrySet())
			{ 
				String key = entry.getKey();
				String value = entry.getValue();
				if (!key.equals(translationVideoId)) {
					Map<String, Object> propertiesNode = new HashMap<>();
					propertiesNode.put(VIDEOIDTRANSLATION, key);
					propertiesNode.put(LANGUAGE, value);
					resourceResolver.create(translationList, "item" + count, propertiesNode);
					count++;
				}
			}
		} catch (Exception e) {
			log.error("Error occurred in TranslatedVideoIdProcessStep generateNodes", e);
		}
	}
}