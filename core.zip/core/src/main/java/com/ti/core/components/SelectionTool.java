package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Overview WCMUsePojo.
 */
public class SelectionTool extends WCMUsePojo {
  protected final Logger log = LoggerFactory.getLogger(this.getClass());

  private String lang = "";
  private String productDomain;

  public String getLang() {
		return lang;
  }

  public String getProductDomain() {
    if (productDomain == null) return "www.ti.com";
    else return productDomain.toLowerCase().replace("qa.", "uat.");		// special case: QA env data should point to UAT
  }

  @Override
  public void activate() {
    try {
      final var currentPage = getCurrentPage();
      if (currentPage != null) {
    	  final var tabsService = getSlingScriptHelper().getService(ProductNavigationTabsOrdering.class);
    	  if (tabsService != null) {
          final var langParts = tabsService.getPageLanguage(getCurrentPage()).split("-", 2);
          if (2 == langParts.length) {
            lang = langParts[0] + "-" + langParts[1].toUpperCase();
          } else {
            lang = langParts[0];
          }
        }
      }
      productDomain = get("productDomain", String.class);
    } catch (Exception e) {
      log.error("Exception: ", e);
    }
  }
}
