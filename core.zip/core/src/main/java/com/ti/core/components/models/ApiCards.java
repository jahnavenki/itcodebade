package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(
	adaptables = {SlingHttpServletRequest.class,Resource.class},
	resourceType = ApiCards.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ApiCards {
	protected final Logger log = LoggerFactory.getLogger(getClass());

	public static final String RESOURCE_TYPE = "ti/components/apiCards";

	@ChildResource
	private Collection<ApiCard> apiCards;

	@SlingObject
	private ResourceResolver resourceResolver;

	@PostConstruct
	public void init(){
		try {
			apiCards = CollectionUtils.emptyIfNull(apiCards);
		} catch (Exception e) {
			log.error("Exception in ApiCards", e);
		}
	}

	public Collection<ApiCard> getApiCards() {
		return apiCards;
	}
}
