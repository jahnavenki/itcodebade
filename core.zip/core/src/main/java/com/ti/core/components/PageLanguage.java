package com.ti.core.components;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.ti.core.models.LinkListModel;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.util.PathBrowserHelper;

/**
 * The Class PageLanguage.
 */
public class PageLanguage extends WCMUsePojo {

  private static final String CQ_TEMPLATE = "cq:template";

  private static final String TEMPLATE_HOME_PAGE = "/apps/ti/templates/homePage";

  Map<String, String> urlMap = new HashMap<>();
  /** The log. */
  protected final Logger log = LoggerFactory.getLogger(this.getClass());

  /** The bread crumb links. */
  List<LinkListModel> languageLinks = new ArrayList<>();
  private String  currentLanguageLink = null;

  private String componentName;

  /*
   * (non-Javadoc)
   * 
   * @see com.adobe.cq.sightly.WCMUsePojo#activate()
   */
  @Override
  public void activate() {
    SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper()
        .getService(SeoUrlFactoryConfigs.class);

    if (null != factoryConfigs) {
      List<SeoUrlTagging> listConfig = factoryConfigs.getConfigs();
      
      String pagePath;
      for (SeoUrlTagging langSelector : listConfig) {
    	  pagePath = get("pagepath", String.class);
    	  if (StringUtils.isEmpty(pagePath))
    		  pagePath = getCurrentPage().getPath();

          processPageLanguageLinks(langSelector, pagePath);
      }
      languageLinks.sort((LinkListModel o1, LinkListModel o2)->o1.getOrder()-o2.getOrder());

    }
  }

  private void processPageLanguageLinks(SeoUrlTagging langSelector, String pagePath){
    String contentPath ;
    String selectorLabel ;
    Boolean checkExistingPath;
    String targetPagePath;
    int order; 
    try{
      contentPath = langSelector.getContentPath();
      selectorLabel = langSelector.getSelectorLabel();
      checkExistingPath = langSelector.getCheckExistingPage();
      order = langSelector.getOrder();
      targetPagePath = pagePath.replace(getHomePagePath(), contentPath);
      PageManager pageManager = getResourceResolver().adaptTo(PageManager.class);
      if(targetPagePath.equals(pagePath)) {
			currentLanguageLink = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), pagePath);
      }
      if (checkExistingPath.booleanValue() && null != pageManager) {
        Page page = pageManager.getPage(targetPagePath);
        if (null != page) {
          addLinks(StringUtils.remove(contentPath, "/content/texas-instruments/"), selectorLabel, targetPagePath, order);
        }
      } else {
        addLinks(StringUtils.EMPTY, selectorLabel, targetPagePath, order);
      }

      log.debug("Content Path {}", contentPath);
      log.debug("Selector Label {}", selectorLabel);
      log.debug("target Page path{}", targetPagePath);
      
    } catch(NullPointerException e){
      log.error("Null Pointer Exception: ",e);
    }

  }

  /**
   * @return the currentLanguageLink
   */
  public String getCurrentLanguageLink() {
    return currentLanguageLink;
  }

  private void addLinks(String language, String label, String link, int order) {
    LinkListModel linkList = new LinkListModel();
    linkList.setResolver(getResourceResolver());
    linkList.setLanguage(language);
    linkList.setCtaText(label);
	linkList.setCtaUrl(PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), link));
	linkList.setEditModeUrl("/editor.html" + link + ".html");
    linkList.setOrder(order);
    languageLinks.add(linkList);

  }

  /**
   * Method to get the breadcrumb links.
   *
   * @return List of links
   */
  public List<LinkListModel> getLanguageLinks() {
    return languageLinks;
  }

  public boolean getHasLanguageList(){
    boolean hasLanguageList = false; 
    if(!languageLinks.isEmpty()){
      if(languageLinks.size() == 1){
        Iterator<LinkListModel> iter = languageLinks.iterator();
        while(iter.hasNext()){
          LinkListModel linkListModel = iter.next();
          if(getCurrentPage().getPath().equalsIgnoreCase(linkListModel.getCtaUrl())){
            hasLanguageList = false;
          }
        }
      } else {
        hasLanguageList = true;
      }
    }
    return hasLanguageList;
  }

  /**
   * Builds the web site.
   *
   * @param useAuthoredValue
   *            the use authored value
   * @param bcLinks
   *            the bc links
   */
  public String getHomePagePath() {
    Page currentPage = getCurrentPage();
    while (currentPage.getContentResource()!=null && !TEMPLATE_HOME_PAGE.equalsIgnoreCase(currentPage.getContentResource().getValueMap().get(CQ_TEMPLATE, ""))) {
      currentPage = currentPage.getParent();
    }
    return currentPage.getPath();
  }

  public String getComponentName() {
    Resource rsc = getResource();
    String componentPath = rsc.getPath();
    setComponentName(componentPath.substring(componentPath.lastIndexOf('/')+1,componentPath.length()));
    return componentName;
  }

  public void setComponentName(String componentName) {
    this.componentName = componentName;
  }

}