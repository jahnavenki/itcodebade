package com.ti.core.util;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.adobe.acs.commons.genericlists.GenericList.Item;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

public class EmailUtils {

	private static final Logger log = LoggerFactory.getLogger(EmailUtils.class);

	private static final String REGEX_PREFIX = "^/content/texas-instruments/[^/]*";

	private static final String FAMILY_ID = "familyId";
	private static final String APPLICATION_ID = "applicationId";
	private static final String SILO_ID = "siloId";
	private static final String DEFAULT = "default";

	public static final String FAMILY_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-family-id-approver-mappings";
	public static final String APPLICATION_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-application-id-approver-mappings";
	public static final String CONTENT_LOCATION_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-path-approver-mappings";
	public static final String DEFAULT_APPROVER_MAPPING = "/etc/acs-commons/lists/ti-default-approver-mappings";

	private static final String APPLICATION_SECTOR_ID = "sectorId";
	private static final String APPLICATION_MARKET_ID = "marketId";

	private PageManager pageManager;

	public EmailUtils(PageManager manager) {
		this.pageManager = manager;
	}

	public String getDefaultApprover() {
		return getApprover(DEFAULT, DEFAULT_APPROVER_MAPPING);
	}

	public String getApproverForPagePath(String payload) {
		return getApprover(payload, CONTENT_LOCATION_APPROVER_MAPPING);
	}

	public String getProductForApplicationPages(Node node) throws RepositoryException {
		String approver;
		approver = getApprover(node.getProperty(APPLICATION_ID).getString(), APPLICATION_APPROVER_MAPPING);

		if (StringUtils.isEmpty(approver) && node.hasProperty(APPLICATION_SECTOR_ID)){
			approver = getApprover(node.getProperty(APPLICATION_SECTOR_ID).getString(), APPLICATION_APPROVER_MAPPING);
		}
	    if (StringUtils.isEmpty(approver) && node.hasProperty(APPLICATION_MARKET_ID)) {
			approver = getApprover(node.getProperty(APPLICATION_MARKET_ID).getString(), APPLICATION_APPROVER_MAPPING);
		}
		return approver;
	}

	public String getApproverForProductFamilyPages(Node node) throws RepositoryException {
		String approver;
		approver = getApprover(node.getProperty(FAMILY_ID).getString(), FAMILY_APPROVER_MAPPING);
		log.debug("family id found ---" + approver);
		  if(StringUtils.isEmpty(approver) && node.hasProperty(SILO_ID)){
			approver = getApprover(node.getProperty(SILO_ID).getString(), FAMILY_APPROVER_MAPPING);
			log.debug("silo id found ---" + approver);
		}

		log.debug("approver {}", approver);
		return approver;
	}

	private String getApprover(String authoredProperty, String approverMapping) {
		Page approverList = this.pageManager.getPage(approverMapping);
		String approver = StringUtils.EMPTY;
		
		if (approverList != null) {
			GenericList list = approverList.adaptTo(GenericList.class);
			if (list != null) {
				List<Item> configList = list.getItems();
				approver = getApproverFromConfigurations(configList, authoredProperty);
			}
		}

		return approver;
	}

	private String getApproverFromConfigurations(List<Item> configList, String authoredProperty) {
		String approver = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(authoredProperty) && !DEFAULT.equals(authoredProperty)) {
			approver = searchListForAprover(configList, authoredProperty);
		} else if (DEFAULT.equals(authoredProperty)) {
			approver = configList.get(0).getValue();
		} else {
			return approver;
		}

		return approver;
	}

	private String searchListForAprover(List<Item> configList, String authoredProperty) {
		String approver;
		boolean byPath = authoredProperty.contains("/");
		for (Item object : configList) {
			log.debug(object.getTitle());
			if (byPath)
				approver = matchApproverByPath(authoredProperty, object);
			else
				approver = matchApproverById(authoredProperty, object);
			if (!StringUtils.equals(approver, StringUtils.EMPTY))
				return approver;
		}
		return StringUtils.EMPTY;
	}

	private String matchApproverByPath(String authoredProperty, Item object) {
		String approver = StringUtils.EMPTY;
		if (StringUtils.isNotEmpty(authoredProperty) && StringUtils.isNotEmpty(object.getTitle())) {
			String testPath = authoredProperty.trim();
			Pattern pattern = Pattern.compile(REGEX_PREFIX + object.getTitle());
			Matcher match = pattern.matcher(testPath);
			if (match.find()) {
				approver = StringUtils.isNotEmpty(object.getValue()) ? object.getValue() : null;
			}
		}
		return approver;
	}

	private String matchApproverById(String authoredProperty, Item object) {
		if (StringUtils.equals(authoredProperty.trim(), object.getTitle())) {
			return StringUtils.defaultIfEmpty(object.getValue(), StringUtils.EMPTY);
		}
		return StringUtils.EMPTY;

	}

}