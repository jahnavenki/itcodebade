package com.ti.core.service;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Texas Instruments constructive breadcrumb Config Service",
description = "Texas Instruments constructive breadcrumb Config Service")
public @interface BreadcrumbConfiguration {
	
	   @AttributeDefinition(name = "breadcrumbtype", description = "breadcrumbtype description",type = AttributeType.STRING , cardinality = 50)
	   String breadcrumbtype();
		
	   @AttributeDefinition(name = "breadcrumburl", description = "content path  breadcrumb URL description",type = AttributeType.STRING )
	   String breadcrumburl();
		
	 

	   @AttributeDefinition(name = "homepageurl", description = "homepage URL", type = AttributeType.STRING )
		String homepageurl();
	   
	   @AttributeDefinition(name = "designbreadcrumburl", description = "Design Resources breadcrum URL", type = AttributeType.STRING )
		String designbreadcrumburl();
	  
	  
}
