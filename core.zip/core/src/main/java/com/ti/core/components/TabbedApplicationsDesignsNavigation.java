package com.ti.core.components;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.models.Tab;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.util.PathBrowserHelper;
import com.ti.core.util.URLHelper;

/**
 * TabbedApplicationsDesignsNavigation WCMUsePojo.
 */
public class TabbedApplicationsDesignsNavigation extends WCMUsePojo {

	private static final int MAX_NUM_TABS = 8;

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private Page parent = null;

	private List<Tab> listStandardTab = new ArrayList<>();

	private List<Tab> listCustomTab = new ArrayList<>();

	private String navTitle = "";
	private int subTabsCount = 0;
	private int size = 0;
	private String componentName;
	private static final String HIDE_IN_NAV = "hideInNav";

	private static final int SUB_TABS_COUNT = 12;

	@Override
	public void activate() {
		Resource resource = this.getResource();
		setComponentName(resource.getName());
		Page checkParent = checkNavigationTitle();
		if (checkParent != null) {
			productTabs();
		}
	}

	private Page checkNavigationTitle() {
		Page currentParent = getCurrentPage().getParent();

		if (getCurrentPage().getNavigationTitle() != null && currentParent.getNavigationTitle() == null) {
			Iterator<Page> listChildren = currentParent.listChildren();
			while (listChildren.hasNext()) {
				Page page = listChildren.next();
				if (page.getNavigationTitle() != null) {
					size++;
				}
			}
			if (size == 1 && (!getCurrentPage().listChildren().hasNext()
					|| getCurrentPage().listChildren().next().getNavigationTitle() == null)) {
				return null;
			} else {
				this.parent = currentParent;
			}

		} else {
			if (getCurrentPage().getNavigationTitle() != null
					&& currentParent.getParent().getNavigationTitle() == null) {
				this.parent = currentParent.getParent();
			}
		}
		return parent;
	}

	private void productTabs() {
		ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
				.getService(ProductNavigationTabsOrdering.class);
		this.navTitle = getCurrentPage().getNavigationTitle() != null ? getCurrentPage().getNavigationTitle() : null;
		String tabs = tabsService.getApplicationStandardTabsOrdering();

		if (StringUtils.isNotEmpty(tabs)) {
			String[] tabsArray = StringUtils.split(tabs, ",");
			for (int i = 0; i < tabsArray.length; i++) {
				Iterator<Page> it = parent.listChildren();
				while (it.hasNext()) {
					Page page = it.next();

					int firstChild = 0;

					Resource pageContentResource = page.getContentResource();
					ValueMap pageValueMap = null;
					if (null != pageContentResource) {
						pageValueMap = pageContentResource.adaptTo(ValueMap.class);

						if (null != pageValueMap && null != pageValueMap.get(HIDE_IN_NAV, Boolean.class)) {
							continue;
						}
					}
					if (page.getName() != null && StringUtils.equalsIgnoreCase(StringUtils.trim(tabsArray[i]),
							StringUtils.trim(page.getName()))) {
						Tab stdTab = new Tab();
						List<Tab> listChildTab = new ArrayList<>();
						Map<String, List<Tab>> childTabs = new HashMap<>();

						Iterator<Page> itChildren = page.listChildren();
						while (itChildren.hasNext()) {
							firstChild++;

							Page child = itChildren.next();
							if (firstChild == 1) {

								stdTab.setParentPath(URLHelper.toScheme(
										PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), child.getPath()), URLHelper.getScheme(getRequest())));

							}

							pageContentResource = child.getContentResource();
							if (null != pageContentResource) {
								pageValueMap = pageContentResource.adaptTo(ValueMap.class);

								if (null != pageValueMap && null != pageValueMap.get(HIDE_IN_NAV, Boolean.class)) {
									continue;
								}
							}

							Tab childTab = new Tab();

							if (child.getNavigationTitle() != null && subTabsCount < SUB_TABS_COUNT) {
								subTabsCount++;
								childTab.setPath(URLHelper.toScheme(
										PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), child.getPath()), URLHelper.getScheme(getRequest())));
								childTab.setTitle(child.getNavigationTitle());
								if (navTitle != null && StringUtils.equalsIgnoreCase(
										getCurrentPage().getParent().getNavigationTitle(),
										child.getParent().getNavigationTitle())) {
									Boolean selected = StringUtils.equalsIgnoreCase(navTitle,
											child.getNavigationTitle());
									stdTab.setParentSelected(true);
									childTab.setSelected(selected);
								}

								listChildTab.add(childTab);
							}
						}

						if (CollectionUtils.isNotEmpty(listChildTab)) {
							childTabs.put(page.getNavigationTitle(), listChildTab);
							stdTab.setChildtabs(childTabs);
						}

						if (navTitle != null
								&& StringUtils.equalsIgnoreCase(getCurrentPage().getParent().getNavigationTitle(),
										page.getParent().getNavigationTitle())) {
							Boolean selected = StringUtils.equalsIgnoreCase(navTitle, page.getNavigationTitle());
							stdTab.setSelected(selected);
						}
						subTabsCount = 0;
						stdTab.setPath(URLHelper.toScheme(
								PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), page.getPath()), URLHelper.getScheme(getRequest())));
						stdTab.setTitle(page.getNavigationTitle());

						listStandardTab.add(stdTab);
						break;
					}
				}
			}
			Iterator<Page> it = parent.listChildren();
			while (it.hasNext()) {
				Page page = it.next();

				Resource pageContentResource = page.getContentResource();
				ValueMap pageValueMap = null;
				if (null != pageContentResource) {
					pageValueMap = pageContentResource.adaptTo(ValueMap.class);

					if (null != pageValueMap && null != pageValueMap.get(HIDE_IN_NAV, Boolean.class)) {
						continue;
					}
				}

				for (int i = 0; i < tabsArray.length; i++) {
					if (page.getName() != null && StringUtils.equalsIgnoreCase(StringUtils.trim(tabsArray[i]),
							StringUtils.trim(page.getName()))) {
						break;
					} else {
						if (i == tabsArray.length - 1 && page.getNavigationTitle() != null) {
							Tab customTab = new Tab();

							if (navTitle != null
									&& StringUtils.equalsIgnoreCase(getCurrentPage().getParent().getNavigationTitle(),
											page.getParent().getNavigationTitle())) {

								Boolean selected = StringUtils.equalsIgnoreCase(navTitle, page.getNavigationTitle());
								customTab.setSelected(selected);
							}
							List<Tab> listChildTab = new ArrayList<>();
							Map<String, List<Tab>> childTabs = new HashMap<>();
							int firstChild = 0;

							Iterator<Page> itChildren = page.listChildren();
							while (itChildren.hasNext()) {
								firstChild++;
								Page child = itChildren.next();

								if (firstChild == 1) {
									customTab.setParentPath(URLHelper.toScheme(
											PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), child.getPath()), URLHelper.getScheme(getRequest())));

								}

								pageContentResource = child.getContentResource();
								if (null != pageContentResource) {
									pageValueMap = pageContentResource.adaptTo(ValueMap.class);

									if (null != pageValueMap && null != pageValueMap.get(HIDE_IN_NAV, Boolean.class)) {
										continue;
									}
								}

								Tab childTab = new Tab();
								if (child.getNavigationTitle() != null && subTabsCount < SUB_TABS_COUNT) {
									subTabsCount++;
									childTab.setPath(URLHelper.toScheme(PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),
											child.getPath()), URLHelper.getScheme(getRequest())));
									childTab.setTitle(child.getNavigationTitle());
									if (StringUtils.equalsIgnoreCase(getCurrentPage().getParent().getNavigationTitle(),
											child.getParent().getNavigationTitle())) {
										Boolean selected = StringUtils.equalsIgnoreCase(navTitle,
												child.getNavigationTitle());
										customTab.setParentSelected(true);
										childTab.setSelected(selected);
									}
									listChildTab.add(childTab);
								}
							}
							if (CollectionUtils.isNotEmpty(listChildTab)) {
								childTabs.put(page.getNavigationTitle(), listChildTab);
								customTab.setChildtabs(childTabs);
							}
							subTabsCount = 0;

							customTab.setPath(URLHelper.toScheme(
									PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), page.getPath()), URLHelper.getScheme(getRequest())));
							customTab.setTitle(page.getNavigationTitle());

							listCustomTab.add(customTab);

						}
					}
				}

			}
		}
	}

	public List<Tab> getTab() {
		listStandardTab.addAll(listCustomTab);
		listStandardTab = listStandardTab.subList(0,
				listStandardTab.size() < MAX_NUM_TABS ? listStandardTab.size() : MAX_NUM_TABS);
		return this.listStandardTab;
	}

	public Page getParent() {
		return parent;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

}