package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.LanguageUtils;

import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BE model for pages under Product family -> Products tab (Selection tool)
 */
public class ProductPortfolioProducts extends WCMUsePojo {

	private static final String FAMILY_ID = "familyId";
	private static final String FAMILY_NAME = "familyName";
	protected static final Logger log = LoggerFactory.getLogger(ProductPortfolioProducts.class);

	private String familyName;
	private String browserTitle;
	private String metaDescription;
	private String keywords;

    @Override
    public void activate() throws Exception {       
        try {  
            if (null != getPageProperties().get(FAMILY_ID)) {   
                String language = "en-us";
                ProductNavigationTabsOrdering tabsService = getSlingScriptHelper().getService(
                    ProductNavigationTabsOrdering.class);
                if (tabsService != null) {
                    language = tabsService.getPageLanguage(getCurrentPage());
                }
                setFamilyName(getPageProperties().get(FAMILY_ID).toString(), language);                 
                setMetadata(familyName);
            }
        } catch (Exception e) {
            log.error("Error setting meta data: ", e);
        }    
    }

    /**
     * Each of the below will be auto generated and not authorable: 
            1. Browser title = <Family name> + "product selection + “|” + “TI.com”
                                For CN, it should be <Family name> + “|” + “TI.com.cn”
            2. Meta description = "Select from TI's <family name> family of devices. 
                                <family name> parameters, data sheets, and design resources."
            3. Keywords: <Family name> + "product selection"
    */
    private void setMetadata(String familyName) {   
        LanguageUtils langUtils = new LanguageUtils(getRequest());
		browserTitle = langUtils.getI18nStr("{} product selection | TI.com").replace("{}", familyName);
		metaDescription = langUtils.getI18nStr(
			"Select from TI's {} family of devices. {} parameters, data sheets, and design resources.")
			.replace("{}", familyName);
		keywords = langUtils.getI18nStr("{} product selection").replace("{}", familyName);
    }

	/**
	 * This method calls the service for Family and returns the associated family
	 * name for provided family id.
	 * 
	 * @param familyId family id set from page properties.
	 * @return family name.
	 */
	private void setFamilyName(String familyId, String language) {
		familyName = null;
		try {
			WCMComponents wcmComponents = getSlingScriptHelper().getService(WCMComponents.class);
			if (wcmComponents != null) {
				JSONObject prodData = wcmComponents.getAllProductService(this.getRequest(), 
                    Integer.parseInt(familyId), language);
				if (prodData != null) {
					familyName = prodData.getString(FAMILY_NAME);
				}
			}
		} catch (Exception e) {
			log.error("Could not get family name from json", e);
		}
	}
    
	public String getFamilyName() {
		return familyName;
	}
    
	public String getBrowserTitle() {
		return browserTitle;
	}

    public String getMetaDescription() {
		return metaDescription;
	}

    public String getKeywords() {
		return keywords;
	}  
}