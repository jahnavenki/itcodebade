package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.ProductNavigationTabsOrdering;

/**
 * The Class CustomAdobeHelpLink.
 * Custom Adobe Help Icon link to Pattern Library
 * 
 * @author Prananshu
 */
public class CustomAdobeHelpLink extends WCMUsePojo {
	
	String helpUrl = "";

	@Override
	public void activate(){
		ProductNavigationTabsOrdering service;
		service = getSlingScriptHelper()
		        .getService(ProductNavigationTabsOrdering.class);
		
		if(service != null)
			this.helpUrl = service.getCustomAdobeHelpLink();
		
	}

	public String getHelpUrl() {
		return helpUrl;
	}
	
}
