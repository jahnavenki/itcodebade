package com.ti.core.models;

import java.util.List;
import java.util.Map;

public class Tab {
  private String path;
  private String title;
  private Boolean selected;
  private Boolean parentSelected;
  private String parentPath;

  private Map<String, List<Tab>> childtabs;

  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Boolean getSelected() {
    return selected;
  }

  public void setSelected(Boolean selected) {
    this.selected = selected;
  }

  public Map<String, List<Tab>> getChildtabs() {
    return childtabs;
  }

  public void setChildtabs(Map<String, List<Tab>> childtabs) {
    this.childtabs = childtabs;
  }

  public Boolean getParentSelected() {
    return parentSelected;
  }

  public void setParentSelected(Boolean parentSelected) {
    this.parentSelected = parentSelected;
  }

  public String getParentPath() {
    return parentPath;
  }

  public void setParentPath(String parentPath) {
    this.parentPath = parentPath;
  }
}
