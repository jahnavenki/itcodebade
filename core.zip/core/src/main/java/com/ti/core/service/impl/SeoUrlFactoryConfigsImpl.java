
package com.ti.core.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.FieldOption;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;

/**
 * SeoUrlFactoryConfigsImpl SeoUrlFactoryConfigs
 *
 */

@Component(immediate = true, service = SeoUrlFactoryConfigs.class)
public class SeoUrlFactoryConfigsImpl implements SeoUrlFactoryConfigs {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	@Reference(policy = ReferencePolicy.DYNAMIC, fieldOption = FieldOption.UPDATE, cardinality = ReferenceCardinality.MULTIPLE, service = SeoUrlTagging.class, bind = "bindSeoUrlTagging", unbind = "unbindSeoUrlTagging")
	private Collection<SeoUrlTagging> configs;

	protected synchronized void bindSeoUrlTagging(final SeoUrlTagging config) {
		if (configs == null) {
			configs = new ArrayList<>();
		}
		Set<SeoUrlTagging> seoUrlTaggingSet = new HashSet<>(configs);
		seoUrlTaggingSet.add(config);
	}

	protected synchronized void unbindSeoUrlTagging(final SeoUrlTagging config) {
		Set<SeoUrlTagging> s = new HashSet<>(configs);
		s.remove(config);

	}

	@Override
	public List<SeoUrlTagging> getConfigs() {
		return (new ArrayList<>(configs));
	}

}