package com.ti.core.service.workflow;

import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set values for Long Description metadata.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Long Description Metadata" })
public class LongDescriptionMetadataProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private WCMComponents wcmService;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) throw new NullPointerException("resourceResolver");
			final var resource = resourceResolver.getResource(payload);
			if (null == resource) return;
			final var map = AssetUtils.getModifiableMetadata(resource);
			if (null == map) return;

			// get metadata we need 
			final String publishToYoutube = map.get("dam:youtube", "no");
			final String details = map.get("dam:details", "");
			final String youTubeDescription = map.get("dam:youtube_description", "");

			var longDescription = "";

			// if publishToYoutube is yes, use Youtube Desc
			// else use details field
			if ("yes".equals(publishToYoutube)) {
				longDescription = youTubeDescription;
			} else {
				longDescription = details;
			}

			// Set the value for 'Long description' field in Brightcove tab
			map.put("brc_long_description", longDescription);

		} catch (Exception e) {
			log.error("Error occurred in LongDescriptionMetadataProcessStep", e);
		}
	}
}
