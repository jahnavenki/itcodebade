package com.ti.core.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

public class AppHierarchyNode {
    public AppHierarchyNode( JSONObject jsonObject ) throws JSONException {
        appUrl = jsonObject.getString("appUrl");
        if ("null".equals( appUrl ) ) appUrl = null;
        childId = getInteger( jsonObject, "childId" );
        enSectionName = jsonObject.getString("enSectionName");
        parentAppId = getInteger( jsonObject, "parentAppId" );
        virtualParentId = getInteger( jsonObject, "virtualParentId" );
        sectionName = jsonObject.getString("sectionName");
    }

    private String appUrl;
    private Integer childId;
    private String enSectionName;
    private Integer parentAppId;
    private String sectionName;
    private Integer virtualParentId;
    private AppHierarchyNode parent;
    private final List<AppHierarchyNode> children = new ArrayList<>();

    private static Integer getInteger( JSONObject jsonObject, String key ) throws JSONException {
        if( jsonObject.isNull( key ) ) {
            return null;
        }
        else{
            return jsonObject.getInt( key );
        }
    }

    public String getAppUrl() {
        return appUrl;
    }

    public void setAppUrl( String appUrl ) {
        this.appUrl = appUrl;
    }

    public Integer getChildId() {
        return childId;
    }

    public void setChildId( Integer childId ) {
        this.childId = childId;
    }

    public String getEnSectionName() {
        return enSectionName;
    }

    public void setEnSectionName( String enSectionName ) {
        this.enSectionName = enSectionName;
    }

    public Integer getParentAppId() {
        return parentAppId;
    }

    public void setParentAppId( Integer parentAppId ) {
        this.parentAppId = parentAppId;
    }

    public Integer getVirtualParentId() {
        return virtualParentId;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName( String sectionName ) {
        this.sectionName = sectionName;
    }

    public AppHierarchyNode getParent() {
        return parent;
    }

    public void setParent( AppHierarchyNode parent ) {
        this.parent = parent;
    }

    public List<AppHierarchyNode> getChildren() {
        return children;
    }
}
