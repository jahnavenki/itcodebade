package com.ti.core.errorhandler;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;
import com.ti.core.util.PathBrowserHelper;

/**
 * Response Status WCMUsePojo.
 */
public class ResponseStatus extends WCMUsePojo {
	private static final String BLANK = "";
  private static final String HTTPS = "https://";
  private static final String HTTP = "http://";
  private static final String DIR_404_HTML = "/404";
	private static final String CONTENT_TEXAS_INSTRUMENTS = "/content/texas-instruments/";
	private static final String AUTHOR = "author";
	private static final String EN_US = "en-us";
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final int ERROR_CODE_404 = 404;
	String languageCode = null;

	@Override
	public void activate() throws Exception {
		Set<String> runModes;
		SlingSettingsService slingSettings = this.getSlingScriptHelper().getService(SlingSettingsService.class);
		if (null != slingSettings) {
			runModes = slingSettings.getRunModes();
			if (runModes.contains(AUTHOR)) {
			  getResponse().setStatus(ERROR_CODE_404);
			} else {
				getResponse().setStatus(ERROR_CODE_404);
				String requestUrl = getRequest().getRequestURL().toString();
				if (StringUtils.isNotEmpty(requestUrl)) {
					getLanguageCode(requestUrl);
					redirectToErrorPage(requestUrl);
				}
			}
		}
	}

	protected void redirectToErrorPage(String originalRequestUrl) throws IOException {
		String redirectUrl = CONTENT_TEXAS_INSTRUMENTS + languageCode + DIR_404_HTML;
		ResourceResolver resolver = getRequest().getResourceResolver();
		if (resolver.getResource(redirectUrl) != null && StringUtils.equalsIgnoreCase(redirectUrl, originalRequestUrl)) {
		  getResponse().sendRedirect(PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),redirectUrl));
		} else {
			log.info("Page Not found");
		}
	}

	/**
	 * Returns the languageCode of the request URL
	 */
	private void getLanguageCode(String requestUrl) {
		List<SeoUrlTagging> listConfig;
		SeoUrlFactoryConfigs factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
		String hostName = requestUrl.replace(getRequest().getRequestURI(), BLANK).replace(HTTP, BLANK).replace(HTTPS, BLANK);
		if (null != factoryConfigs) {
			listConfig = factoryConfigs.getConfigs();
			try {
				matchLanguageCodeByDomain(requestUrl, listConfig, hostName);
			} catch (Exception e) {
				log.error("Error in getLanguageCode {} " + e);
			}
		}
	}

	protected void matchLanguageCodeByDomain(String requestUrl, List<SeoUrlTagging> listConfig, String hostName) {
		for (SeoUrlTagging seoUrlTagging : listConfig) {
			if (hostName.equalsIgnoreCase(seoUrlTagging.getDomainName())) {
				languageCode = getLanguageCodeFromUrl(requestUrl, listConfig);
				break;
			}
		}
	}

	protected String getLanguageCodeFromUrl(String requestUrl, List<SeoUrlTagging> listConfig) {
		String langCode = EN_US;
		for (SeoUrlTagging seoUrlTagging : listConfig) {
			String contentPath = seoUrlTagging.getContentPath();
			if (StringUtils.isNotEmpty(contentPath)) {
				String langCodeFormSEO = contentPath.substring(contentPath.lastIndexOf('/') + 1, contentPath.length());
				if (requestUrl.contains("/" + langCodeFormSEO + "/")) {
					langCode = langCodeFormSEO;
				}
			}
		}
		return langCode;
	}

}
