package com.ti.core.util;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.contentloader.ContentImporter;
import org.apache.sling.jcr.contentloader.ImportOptions;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.json.JSONArray;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(service = WorkflowProcess.class, property = { "process.label=Update Multifield" })
public class UpdateMultifieldValues implements WorkflowProcess {

	@Reference
	ResourceResolverFactory resourceResolverFactory;

	@Reference
	ContentImporter contentImporter;

	private static final Logger logger = LoggerFactory.getLogger(UpdateMultifieldValues.class);

	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		final WorkflowData workflowData = workItem.getWorkflowData();
		final String path = workflowData.getPayload().toString();
		String resourceType = null;
		String propertyName = null;
		if (metaDataMap.containsKey("PROCESS_ARGS")) {
			String[] processArguments = metaDataMap.get("PROCESS_ARGS", "").split(",");
			resourceType = processArguments[0];
			propertyName = processArguments[1];
		}
		try (ResourceResolver resourceResolver = getResourceResolver(workflowSession.getSession())) {

			QueryBuilder builder = resourceResolver.adaptTo(QueryBuilder.class);
			Session session = resourceResolver.adaptTo(Session.class);
			Map<String, String> predicates = new HashMap<>();
			predicates.put("path", path);
			predicates.put("1_property", "sling:resourceType");
			predicates.put("1_property.value", resourceType);
			predicates.put("2_property", propertyName);
			predicates.put("2_property.operation", "exists");
			predicates.put("p.limit", "-1");
			if (builder != null) {
				Query query = builder.createQuery(PredicateGroup.create(predicates), session);
				SearchResult result = query.getResult();

				List<Hit> hits = result.getHits();
				logger.debug("Results {} ", hits.size());
				for (Hit hit : hits) {
					Node node = getHitNode(hit);
					getMultiProperty(node, propertyName);
				}
				resourceResolver.commit();
			}

		} catch (Exception e) {
			logger.debug(" Exception in querying {}", e);

		}

	}

	private String[] getMultiProperty(Node node, String propertyName) {

		if (null != node) {
			try {
				Property property = node.getProperty(propertyName);
				Node propertyNode = createPropertyNode(node, propertyName);

				if ("blogtags".equalsIgnoreCase(propertyName)) {
					if (property.isMultiple()) {
						Value[] values = property.getValues();
						for (int i = 0; i < values.length; i++) {
							Value value = values[i];
							importBlogTags(propertyNode, value.getString(), i, propertyName);
						}
					} else {
						Value value = property.getValue();
						importBlogTags(propertyNode, value.getString(), 0, propertyName);
					}
				} else {
					if (property.isMultiple()) {
						Value[] values = property.getValues();
						for (int i = 0; i < values.length; i++) {
							Value value = values[i];
							JSONObject jsonObject = new JSONObject(value.getString());
							if (jsonObject.has("level3MultiFields")) {
								JSONArray level3Array = jsonObject.getJSONArray("level3MultiFields");
								jsonObject.remove("level3MultiFields");
								importContent(propertyNode, jsonObject, i, propertyName);
								Node level3propertyNode = createPropertyNode(propertyNode.getNode("item" + i),
										"level3MultiFields");
								for (int innerIndex = 0; innerIndex < level3Array.length(); innerIndex++) {
									JSONObject level3Json = level3Array.getJSONObject(innerIndex);
									importContent(level3propertyNode, level3Json, innerIndex, "level3MultiFields");
								}

							} else {
								logger.debug("Json values {}", jsonObject);
								importContent(propertyNode, jsonObject, i, propertyName);
							}

						}
					} else {
						Value value = property.getValue();
						JSONObject jsonObject = new JSONObject(value.getString());
						logger.debug("Json values {}", jsonObject);
						importContent(propertyNode, jsonObject, 0, propertyName);
					}
				}
			} catch (Exception e) {
				logger.error("Exception while reading properties {}", e);
			}

		}
		return (new String[0]);
	}

	private void importBlogTags(Node node, String string, int index, String propertyName) throws RepositoryException {
		Node itemNode = createItemNodes(node, index, propertyName);
		itemNode.setProperty(propertyName, string);
		itemNode.getSession().save();
	}

	private void importContent(Node node, JSONObject jsonObject, int index, String propertyName)
			throws IOException, RepositoryException {
		logger.debug("Start Import");
		createItemNodes(node, index, propertyName);
		contentImporter.importContent(node, "item" + index + ".json",
				new ByteArrayInputStream(jsonObject.toString().getBytes(StandardCharsets.UTF_8)), new ImportOptions() {

					@Override
					public boolean isCheckin() {
						return false;
					}

					@Override
					public boolean isIgnoredImportProvider(String arg0) {
						return false;
					}

					@Override
					public boolean isOverwrite() {
						return true;
					}

					@Override
					public boolean isPropertyOverwrite() {
						return true;
					}

				}, null);
		logger.debug("Content Imported");

	}

	private Node createItemNodes(Node node, int index, String propertyName) throws RepositoryException {
		Node itemNode = null;
		if (node.hasNode("item" + index)) {
			itemNode = node.getNode("item" + index);
		} else {
			itemNode = node.addNode("item" + index);
		}
		Node parentNode = node.getParent();
		parentNode.setProperty(propertyName, (Value) null);
		parentNode.getSession().save();
		return itemNode;
	}

	private Node getHitNode(Hit hit) {
		Node node = null;
		try {
			node = hit.getNode();
			logger.debug("Node {}", node.getPath());
		} catch (RepositoryException e) {
			logger.debug("failed to get search result node", e);
		}
		return node;
	}

	private ResourceResolver getResourceResolver(Session session) throws LoginException {
		return resourceResolverFactory.getResourceResolver(
				Collections.<String, Object>singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION, session));
	}

	private Node createPropertyNode(Node node, String propertyName) throws RepositoryException {
		Node propertyNode = null;
		if (node.hasNode(propertyName)) {
			propertyNode = node.getNode(propertyName);
		} else {
			propertyNode = node.addNode(propertyName);
			node.getSession().save();
		}
		return propertyNode;
	}
}