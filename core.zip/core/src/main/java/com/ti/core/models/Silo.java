package com.ti.core.models;

public class Silo {
  private String familyId;
  private String familyName;
  private String familyNameEnglish;
  private String familyUrl;
  private String sortOrder;

  /**
   * get family id.
   * @return the familyId.
   */
  public String getFamilyId() {
    return familyId;
  }

  /**
   * @param familyId
   *          the familyId to set.
   */
  public void setFamilyId(String familyId) {
    this.familyId = familyId;
  }

  /**
   * get the family name.
   * @return the familyName
   */
  public String getFamilyName() {
    return familyName;
  }

  /**
   * @param familyName
   *          the familyName to set.
   */
  public void setFamilyName(String familyName) {
    this.familyName = familyName;
  }

  /**
   * get the family name.
   * @return the familyName
   */
  public String getFamilyNameEnglish() {
    return familyNameEnglish;
  }

  /**
   * @param familyName
   *          the familyName to set.
   */
  public void setFamilyNameEnglish(String familyNameEnglish) {
    this.familyNameEnglish = familyNameEnglish;
  }

  /**
   * get the family url.
   * @return the familyUrl.
   */
  public String getFamilyUrl() {
    return familyUrl;
  }

  /**
   * @param familyUrl
   *          the familyUrl to set.
   */
  public void setFamilyUrl(String familyUrl) {
    this.familyUrl = familyUrl;
  }

  /**
   * get sortOrder.
   * @return the sortOrder.
   */
  public String getSortOrder() {
    return sortOrder;
  }

  /**
   * @param sortOrder
   *          the sortOrder to set.
   */
  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

}
