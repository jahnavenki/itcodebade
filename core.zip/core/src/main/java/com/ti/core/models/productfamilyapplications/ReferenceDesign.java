package com.ti.core.models.productfamilyapplications;

import java.util.List;

public class ReferenceDesign {
  
  private String rdName;
  private String rdTitle;
  private String rdUrl;
  private boolean isFirst;
  private List<KeyProduct> keyProductsList;
  
  public String getRdName() {
    return rdName;
  }
  
  public void setRdName(String rdName) {
    this.rdName = rdName;
  }
  
  public String getRdTitle() {
    return rdTitle;
  }
  
  public void setRdTitle(String rdTitle) {
    this.rdTitle = rdTitle;
  }
  
  public String getRdUrl() {
    return rdUrl;
  }
  
  public void setRdUrl(String rdUrl) {
    this.rdUrl = rdUrl;
  }
  
  public List<KeyProduct> getKeyProductsList() {
    return keyProductsList;
  }
  
  public void setKeyProductsList(List<KeyProduct> keyProductsList) {
    this.keyProductsList = keyProductsList;
  }
  
  public boolean getIsFirst(){
    return isFirst;
  }
  
  public void setIsFirst(boolean isFirst){
    this.isFirst = isFirst;
  }
  

}
