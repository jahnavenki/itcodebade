package com.ti.core.components;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.ti.core.models.ProductTreeModel;
import com.ti.core.service.ProductNavigationTabsOrdering;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.URLHelper;

/**
 * ProductNavigationTree WCMUsePojo.
 */
public class ProductNavigationTree extends WCMUsePojo {

	private boolean familySet = false;

	/** The log. */
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	/** The Constant FAMILYID_PROP. */
	private static final String FAMILYID_PROP = "familyId";

	/** The Constant PRODUCT_TREE. */
	private static final String JSON_NODE_PRODUCT_TREE = "tree";

	/** The Constant FAMILY_NAME. */
	private static final String JSON_NODE_FAMILY_NAME = "familyName";

	/** The Constant PRODUCT_URL. */
	private static final String JSON_NODE_PRODUCT_URL = "productNodeUrl";

	/** The Constant LEVEL. */
	private static final String JSON_NODE_LEVEL = "treelevel";

	/** The Constant Device_Count. */
	private static final String JSON_NODE_DEVICE_COUNT = "deviceCount";

	/** The product tree model. */
	LinkedList<ProductTreeModel> productTreeList = null;

	private static final String JSON_NODE_ALT_PRODUCT_TREE_FLAG = "altProductTreeFlag";

	private static final String JSON_NODE_INPUT_MODE = "inputMode";

	private boolean isTechnologyFamily = false;

	private boolean isEmptyTree;

	public boolean isEmptyTree() {
		return isEmptyTree;
	}

	public void setEmptyTree(boolean isEmptyTree) {
		this.isEmptyTree = isEmptyTree;
	}

	public boolean isTechnologyFamily() {
		return this.isTechnologyFamily;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.adobe.cq.sightly.WCMUsePojo#activate()
	 */
	@Override
	public void activate() {
		productTree();
	}

	public boolean getIsFamilySet() {
		return this.familySet;
	}

	/**
	 * Product tree.
	 */
	private void productTree() {
		try {
			String familyId = null;
			int iFamilyId = -1;
			WCMComponents wcmService;
			JSONObject jsonObject = null;
			ProductNavigationTabsOrdering tabsService = getSlingScriptHelper()
					.getService(ProductNavigationTabsOrdering.class);

			ValueMap prop = getCurrentPage().getProperties();
			wcmService = getSlingScriptHelper().getService(WCMComponents.class);
			if (tabsService != null && wcmService != null) {

				if (prop != null && prop.get(FAMILYID_PROP, String.class) != null) {
					familyId = prop.get(FAMILYID_PROP, String.class);

					if (familyId == null) {
						log.debug("familyId was not set in properties so skipping product tree");
						return;
					}

					try {
						iFamilyId = Integer.parseInt(familyId);
					} catch (NumberFormatException nfe) {
						log.error("could not parse family id [" + familyId + "]. skipping product tree", nfe);
						return;
					}
					this.familySet = true;
					if (tabsService != null) {
						jsonObject = wcmService.getAllProductService(getRequest(), iFamilyId,
								tabsService.getPageLanguage(getCurrentPage()));
					}
				} else {
					log.info("no properties found, skipping product tree generation");
					return;
				}
			} else {
				log.error("Could not initialize wcmService (null)");
				return;
			}

			if (jsonObject == null) {
				log.error("Product service returned null");
				return;
			}

			this.productTreeList = new LinkedList<>();

			JSONArray jsonarr = jsonObject.getJSONArray(JSON_NODE_PRODUCT_TREE);

			if (null != jsonarr && jsonarr.length() <= 1) {
				this.isEmptyTree = true;
			}

			// Ignore top level by starting at second item.
			ProcessProductTree(1, jsonarr, this.productTreeList, getCurrentPage());

		} catch (Exception e) {
			log.error("Exception:", e);
		}
	}

	private int ProcessProductTree(int index, JSONArray jsonarr, List<ProductTreeModel> productTreeList, Page page) {

		if (jsonarr.length() <= index)
			return index;

		JSONObject currentNode;
		ProductTreeModel model = null;
		int currentNodeLevel = -1, startLevel = -1;
		try {

			// Get the current node
			currentNode = jsonarr.getJSONObject(index);

			// Set the start level to the current node level
			startLevel = currentNodeLevel = currentNode.getInt(JSON_NODE_LEVEL);

			// Repeat while we are at the same or deeper node level
			// exit this function if we are now shallower
			while (currentNodeLevel >= startLevel) {
				// If the current node is deeper that the start level dive
				// deeper
				if (currentNodeLevel > startLevel) {
					// This should never be hit on the first time around so
					// throw exception if it is
					if (model == null)
						throw new JSONException("Unexpected level order in JSON");

					// Process deeper and get the new index
					index = ProcessProductTree(index, jsonarr, model.getChildren(), page);
				} else {
					// otherwise this node is at the current level so lets add
					// it to our list
					model = this.createModelFromJsonNode(currentNode, getCurrentPage());
					productTreeList.add(model);
				}

				// Get the next node and its level if next node exists
				if (index + 1 < jsonarr.length()) {
					currentNode = jsonarr.getJSONObject(++index);
					currentNodeLevel = currentNode.getInt(JSON_NODE_LEVEL);
				} else {
					break;
				}

			}

		} catch (JSONException e) {
			log.error("Error processeing json product tree", e);
		}

		if (currentNodeLevel > 0 && currentNodeLevel < startLevel)
			return --index;
		else
			return index;

	}

	public ProductTreeModel createModelFromJsonNode(JSONObject currentNode, Page currentPage) throws JSONException {
		ProductTreeModel retval = new ProductTreeModel();

		retval.setDeviceCount(currentNode.getInt(JSON_NODE_DEVICE_COUNT));
		retval.setFamilyName(currentNode.getString(JSON_NODE_FAMILY_NAME));
		retval.setProductNodeUrl(
				URLHelper.toScheme(currentNode.getString(JSON_NODE_PRODUCT_URL), URLHelper.getScheme(getRequest())));
		retval.setTreelevel(currentNode.getInt(JSON_NODE_LEVEL));
		retval.setSelected(StringUtils.equalsIgnoreCase(StringUtils.EMPTY + currentNode.getInt(FAMILYID_PROP),
				currentPage.getProperties().get(FAMILYID_PROP, String.class)));
		retval.setAltProductTreeFlag(currentNode.getString(JSON_NODE_ALT_PRODUCT_TREE_FLAG));
		String altFamilyTree = currentNode.getString(JSON_NODE_ALT_PRODUCT_TREE_FLAG);
		if ("Y".equalsIgnoreCase(altFamilyTree)) {
			this.isTechnologyFamily = true;
		}

		retval.setInputMode(currentNode.getString(JSON_NODE_INPUT_MODE));

		return retval;

	}

	public List<ProductTreeModel> getProductTree() {
		return this.productTreeList;
	}

}
