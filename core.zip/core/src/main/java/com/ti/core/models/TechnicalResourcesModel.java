package com.ti.core.models;

public class TechnicalResourcesModel
{
    private String resourceType;
    private String resourceTypeEnglish;
    private String dialogResourceType;
    private String title;
    private String description;
    private String resourceUrl;
    private String litNumber;
    private String htmlUrl;

    public String getResourceType() {
        return resourceType;
    }
    public String getResourceTypeEnglish() {
        return resourceTypeEnglish;
    }
    public void setResourceTypeEnglish(String resourceTypeEnglish) {
        this.resourceTypeEnglish = resourceTypeEnglish;
    }
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResourceUrl() {
        return resourceUrl;
    }

    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public void setHtmlUrl(String htmlUrl) {
        this.htmlUrl = htmlUrl;
    }

    public String getDialogResourceType() {
		return dialogResourceType;
	}

	public void setDialogResourceType(String dialogResourceType) {
		this.dialogResourceType = dialogResourceType;
	}
    public String getLitNumber() {
        return litNumber;
    }

    public void setLitNumber(String litNumber) {
        this.litNumber = litNumber;
    }
}
