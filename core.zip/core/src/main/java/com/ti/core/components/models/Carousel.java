package com.ti.core.components.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

@Model(adaptables = Resource.class)
public class Carousel {

	List<CarouselItem> carouselList = null;

	@SlingObject
	private Resource currentResource;

	@SlingObject
	private ResourceResolver resourceResolver;

	private static final String CAROUSEL_LIST = "carouselList";
	private static final String TITLE = "title";
	private static final String PATH = "path";
	private static final String ROOT_PATH = "jcr:content";
	private static final String APPLICATION_STORY = "applicationstory";
	private static final String FEATURED_RESOURCES = "featuredResources";
	private static final String HEADLINE = "headline";
	private static final String FILE_REFERENCE = "fileReference";

	@PostConstruct
	protected void init() {
		if (currentResource != null) {
			Resource carouselItemRes = currentResource.getChild(CAROUSEL_LIST);
			if (carouselItemRes != null && carouselItemRes.hasChildren()) {
				carouselList = new ArrayList<>();
				Iterator<Resource> carouselItemsItr = carouselItemRes.listChildren();
				while (carouselItemsItr.hasNext()) {
					Resource carouselRes = carouselItemsItr.next();
					String title = carouselRes.getValueMap().get(TITLE, StringUtils.EMPTY);
					String path = carouselRes.getValueMap().get(PATH, StringUtils.EMPTY);

					if (StringUtils.isNotBlank(path)) {
						CarouselItem item = getCarouselItem(path, resourceResolver, title);
						if(item != null) {
							carouselList.add(item);
						}
					}
				}

			}
		}
	}
	
	private CarouselItem getCarouselItem(String path, ResourceResolver resourceResolver, String title) {
		Resource rootResource = resourceResolver.getResource(path + "/" + ROOT_PATH);
		if (rootResource != null) {
			Resource applicationstoryRes = rootResource.getChild(APPLICATION_STORY);
			Resource featuredResourcesRes = rootResource.getChild(FEATURED_RESOURCES);
			if (applicationstoryRes != null && featuredResourcesRes != null) {
				ValueMap applicationstoryProps = applicationstoryRes.getValueMap();
				String headline = applicationstoryProps.get(HEADLINE, StringUtils.EMPTY);
				String image = applicationstoryProps.get(FILE_REFERENCE, StringUtils.EMPTY);
				String applicationstoryPath = applicationstoryRes.getPath();
				String featuredResourcesResPath = featuredResourcesRes.getPath();
				return new CarouselItem(title, headline, image,
						applicationstoryPath, featuredResourcesResPath);
			}

		}
		return null;

	}

	public Iterator<CarouselItem> getCarouselList() {
		return carouselList != null ? carouselList.iterator() : null;

	}

}
