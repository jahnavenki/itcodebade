package com.ti.core.components.models;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.api.resource.Resource;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class, Resource.class},
    resourceType = PortfolioVisualizerWithTabs.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class PortfolioVisualizerWithTabs {
    protected final Logger log = LoggerFactory.getLogger(getClass());

    public static final String RESOURCE_TYPE = "ti/components/portfolioVisualizerWithTabs";

    @ChildResource
    private Collection<PortfolioVisualizerWithTabsModel> tabs;

    @ValueMapValue
    private String title;

    @PostConstruct
    public void init(){
		try {
			tabs = CollectionUtils.emptyIfNull(tabs);
		} catch (Exception e) {
			log.error("Exception in portfolioVisualizerWithTabs", e);
		}
	}

    public Collection<PortfolioVisualizerWithTabsModel> getTabs() {
		return tabs;
	}

    public String getTitle(){
        return title;
    }
    
}
