package com.ti.core.util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import javax.jcr.RepositoryException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * AutomatedLinkId WCMUsePojo.
 *
 */
public class AutomatedLinkId extends WCMUsePojo {
	private static final String BLANK = "";
	private static final String MD5 = "MD5";
	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	private String nodeName;

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	@Override
	public void activate() throws RepositoryException {
		Resource resource = getRequest().getResource();		
		String resourceType = resource.getResourceType();
		
		if (StringUtils.isNotEmpty(resourceType)) {
			resourceType = resourceType.substring(resourceType.lastIndexOf('/') + 1).trim();
			setNodeName(resourceType + "_" + getMessageDigest(resource.getPath().substring(resource.getPath().lastIndexOf("jcr:content")+11)));
		}		
		else
			setNodeName(BLANK);
	}

	protected String getMessageDigest(String nodePath) {
		MessageDigest m;
		try {
			m = MessageDigest.getInstance(MD5);
			m.reset();
			m.update(nodePath.getBytes());
			byte[] digest = m.digest();
			BigInteger bigInt = new BigInteger(1, digest);
			return bigInt.toString(16).substring(0,4);
		} catch (NoSuchAlgorithmException e) {
			log.error("Error in Massage Digest", e);
			return BLANK;
		}
	}
}