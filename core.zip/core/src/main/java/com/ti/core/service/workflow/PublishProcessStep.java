package com.ti.core.service.workflow;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.ti.core.util.AssetUtils;
import java.util.Calendar;


@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to publish.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Publish" })
public class PublishProcessStep implements WorkflowProcess {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Reference
	private ResourceResolverFactory resolverFactory;

    @Reference
    private Replicator replicator;

	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		try {
			final var workflowData = item.getWorkflowData();
			final var payload = workflowData.getPayload().toString();
			final var userId= workflowData.getMetaDataMap().get("userId").toString();
			final var fileName= payload.substring(payload.lastIndexOf("/") + 1). trim();
			if(!payload.endsWith(".mp4")) {
				session.terminateWorkflow(item.getWorkflow());
				return;
			}
			final var resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) throw new NullPointerException("resourceResolver");
			final var resource = resourceResolver.getResource(payload);
			if (null == resource) return;
			final var jcrSession = resourceResolver.adaptTo(Session.class);
			final var map = AssetUtils.getModifiableMetadata(resource);
			if (null == map){
				return;
			}
			map.put("jcr:created", Calendar.getInstance()); // Created date
			map.put("dam:fileName", fileName);
			map.put("dam:contentPublisher", userId);
			if (null == jcrSession) return;
			replicator.replicate(jcrSession, ReplicationActionType.ACTIVATE, resource.getPath());
		} catch (Exception e) {
			log.error("Error occurred in PublishProcessStep", e);
		}
	}
}
