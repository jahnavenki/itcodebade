package com.ti.core.schedulers;

import com.day.cq.replication.Replicator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.QueryBuilder;
import com.ti.core.service.WCMComponents;
import com.ti.core.service.config.VideoConfigService;
import com.ti.core.util.AssetUtils;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

@Designate(ocd = VideoTranscriptScheduler.Config.class)
@Component(service = Runnable.class)
public class VideoTranscriptScheduler implements Runnable {
    private static final Logger log = LoggerFactory.getLogger(VideoTranscriptScheduler.class);

    @Reference
    private WCMComponents wcmService;

    @Reference
    private ResourceResolverFactory rrFactory;

    @Reference
    private SlingSettingsService slingSettings;

    @Reference
    private VideoConfigService videoConfigService;

    @Reference
    private Replicator replicator;

    private int schedulerID;

    @Reference
    protected Scheduler scheduler;

    @ObjectClassDefinition(name = "Video Transcript Scheduler", description = "Update the videos that have requested transcripts.")
    public @interface Config {
        @AttributeDefinition(name = "schedulerExpression", description = "cron expression")
        String scheduler_expression() default "0 1 0 * * ?";
    }

    private void processVideo(Resource video, ResourceResolver resourceResolver) {
        try {
            final var map = AssetUtils.getModifiableMetadata(video);
            final var videoId = map.get("brc_id", String.class);
            final var jsonMetadata = wcmService.getBrightcoveVideoMetaData(videoId);
            if (null == jsonMetadata) return;
            final var jsonTags = jsonMetadata.getJSONArray("tags");
            var processed = false;
            for (var i = 0; i < jsonTags.length(); ++i) {
                final var tag = jsonTags.getString(i);
                if ("3play_processed".equalsIgnoreCase(tag)) {
                    processed = true;
                    break;
                }
            }
            if (processed) {
                final var currentTags = map.get("brc_tags", String[].class);
                if (null != currentTags) {
                    final var newTags =
                        Stream.concat(
                            Stream.of(currentTags)
                            .filter(s -> !("3play_processed".equals( s ) || "3play".equals(s))),
                            Stream.of("3play_processed")
                        )
                        .toArray(String[]::new);
                    map.put("brc_tags", newTags);
                }
                map.put("transcript", "yes");
                resourceResolver.commit();
            }
        } catch (Exception ex) {
            log.error("processVideo", ex);
        }
    }

    @Activate
    public void activate(Config config) {
        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        addScheduler(config);
    }

    @Modified
    protected void modified(VideoTranscriptScheduler.Config config) {
        schedulerID = this.getClass().getName().hashCode(); // update schedulerID
        removeScheduler();
        addScheduler(config);
    }

    @Deactivate
    protected void deactivate(VideoTranscriptScheduler.Config config) {
        removeScheduler();
    }

    /**
     * Remove a scheduler based on the scheduler ID
     */
    private void removeScheduler() {
        log.debug("Removing Scheduler Job '{}'", schedulerID);
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    /**
     * Add a scheduler based on the scheduler ID
     */
    private void addScheduler(VideoTranscriptScheduler.Config config) {
        ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
        sopts.name(String.valueOf(schedulerID));
        sopts.canRunConcurrently(false);
        scheduler.schedule(this, sopts);
        log.debug("Scheduler added succesfully");
    }

    private List<Resource> getVideoList(ResourceResolver resourceResolver) {
        final var builder = resourceResolver.adaptTo(QueryBuilder.class);
        if (null == builder) throw new NullPointerException();
        final var jcrSession = resourceResolver.adaptTo(Session.class);
        if (null == jcrSession) throw new NullPointerException();
        final var map = new HashMap<String, String>();
        map.put("path", videoConfigService.getVideoPath());
        map.put("type", "dam:Asset");
        map.put("1_property", "jcr:content/metadata/brc_id");
        map.put("1_property.operation", "exists");
        map.put("group.1_property", "jcr:content/metadata/transcript");
        map.put("group.1_property.value", "requested");
        map.put("group.2_property", "jcr:content/metadata/brc_tags");
        map.put("group.2_property.value", "3play");
        map.put("group.p.or", "true");
        final var query = builder.createQuery(PredicateGroup.create(map), jcrSession);
        final var result = query.getResult();
        final var resourcesItr = result.getResources();
        final var videos = new ArrayList<Resource>();
        while (resourcesItr.hasNext()) {
            videos.add(resourcesItr.next());
        }
        return videos;
    }

    @Override
    public void run() {
        try {
            if (null == slingSettings) return;
            final Set<String> runModes = slingSettings.getRunModes();
            if (null == runModes || !runModes.contains("author")) return;
            final Map<String, Object> authInfo = new HashMap<>();
            authInfo.put(ResourceResolverFactory.SUBSERVICE, "writeService");
            try (final ResourceResolver resourceResolver = rrFactory.getServiceResourceResolver(authInfo)) {
                final var videos = getVideoList(resourceResolver);
                for (final var video : videos) {
                    processVideo(video, resourceResolver);
                }
            }
        } catch (Exception e) {
            log.error("Exception", e);
        }
    }
}
