package com.ti.core.service.workflow;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Set;

import javax.jcr.Node;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.tagging.TagManager;
import com.ti.core.service.WCMComponents;
import com.ti.core.util.AssetUtils;

@Component(service = WorkflowProcess.class, immediate=true, property = {
	Constants.SERVICE_DESCRIPTION + "=Workflow step to set video status on publish.",
	Constants.SERVICE_VENDOR + "=TI",
	"process.label=TI: Update Brightcove Metadata" 	})
public class UpdateBrightcoveMetadataProcessStep implements WorkflowProcess {

    private final Logger log = LoggerFactory.getLogger(getClass());

	private TagManager tagManager;
    private static final String BRC_CUSTOM_FIELDS = "brc_custom_fields";
	private static final String ERROR_MESSAGE = "Error occurred in UpdateBrightcoveMetadataProcessStep";

	@Reference
	private WCMComponents wcmService;

    @Override
    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
        try {
			final WorkflowData workflowData = item.getWorkflowData();
			final String payload = workflowData.getPayload().toString();
			if(!payload.endsWith(".mp4")) {
				session.terminateWorkflow(item.getWorkflow());
				return;
			}
			final ResourceResolver resourceResolver = session.adaptTo(ResourceResolver.class);
			if (null == resourceResolver) {
				throw new NullPointerException("Resource Resolver");
			}
			final Resource resource = resourceResolver.getResource(payload);
			if (null == resource) 
			{
				throw new NullPointerException("Resource " + payload);
			}
			ModifiableValueMap map = AssetUtils.getModifiableMetadata(resource);
			if (null == map) {
				throw new NullPointerException("Metadata map");
			}

			Node brcCustomFieldsNode = getBrcCustomFieldsNode(resource);
			if (brcCustomFieldsNode == null) {
				return;
			}

			setBrightcoveCustomFields(brcCustomFieldsNode, map, resourceResolver);
			
			// set status as published
            map.put("dam:status", "published");
			// set published date as current date
			map.put("dam:published",Calendar.getInstance());


			String[] tags = map.get("brc_tags", String[].class);
            if (null != tags && tags.length > 0) {
                String youtube = tagManager.resolve("youtube").getTitle();
                String youtubeArchive = "youtube_archive";
                for (int i = 0; i < tags.length; i++) {
                    if (youtubeArchive.equals(tags[i])) {
                        tags[i] = youtube;
                    }
                }    
                map.put("brc_tags",tags);        
            } 
			resourceResolver.commit();
        }
        catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
    }

	private void setBrightcoveCustomFields(Node brcCustomFieldsNode, ModifiableValueMap map, ResourceResolver resourceResolver) {	
		try {
			// set language
			final String language = map.get("videoSpokenLanguage", "en");

			// Set SiteCode
			var sitecode = "";
			if ("en".equals(language)) {
				sitecode = "EN, CN, JP";
			} else if ("ja".equals(language)) {
				sitecode = "JP";
			} else if ("zh-cn".equals(language)) {
				sitecode = "CN";
			}
			brcCustomFieldsNode.setProperty("sitecode", sitecode);

			// Set TICOMIDs
			final var languages = Set.of("en", "ja", "zh-cn");
			var ticomids = "";
			if (languages.contains(language)) {
				ticomids = getTicomids(resourceResolver, map);
			}
			brcCustomFieldsNode.setProperty("ticomids", ticomids);

			// Set taxonomy
			final String taxonomy = map.get("taxonomyField", "");
			brcCustomFieldsNode.setProperty("taxonomy", taxonomy);
		} catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
	}
	
	private Node getBrcCustomFieldsNode(Resource resource) {
		Node brcCustomFieldsNode = null;	
		try {			
			Resource metadataRes = resource.getChild("jcr:content/metadata");
			if (metadataRes == null) {
				throw new NullPointerException("metadataNode is null");
			}
			Node metadataNode = metadataRes.adaptTo(Node.class);
			if (metadataNode == null) {
				throw new NullPointerException("metadataNode is null");
			}

			// Can't use metadata map here for fields under the folder 'brc_custom_fields'
			// because AEM doesn't create brc_custom_fields folder automatically
			// So create a folder 'brc_custom_fields' under metadata 	
			if (metadataNode.hasNode(BRC_CUSTOM_FIELDS)) {
				brcCustomFieldsNode = metadataNode.getNode(BRC_CUSTOM_FIELDS);
			} else {
				brcCustomFieldsNode = metadataNode.addNode(BRC_CUSTOM_FIELDS);
			} 
		} catch (Exception e) {
			log.error(ERROR_MESSAGE, e);
		}
		return brcCustomFieldsNode;
	}

	private String getTicomids(ResourceResolver resourceResolver, ValueMap map) {		
		tagManager = resourceResolver.adaptTo(TagManager.class);
		if (null == tagManager) throw new NullPointerException("tagManager");
		var tagsProducts = map.get("dam:tagsProducts", String[].class);
		if(null == tagsProducts) tagsProducts = new String[0];
		var tagsApplications = map.get("dam:tagsApplications", String[].class);
		if(null == tagsApplications) tagsApplications = new String[0];
		var tagsTools = map.get("dam:tagsTools", String[].class);
		if(null == tagsTools) tagsTools = new String[0];
		final var ticomids = new ArrayList<String>(tagsProducts.length + tagsApplications.length + tagsTools.length);
		for(final var tagProduct : tagsProducts) {
			ticomids.add(tagProductToTicomid(tagProduct));
		}
		for(final var tagApplication : tagsApplications) {
			ticomids.add(tagApplicationToTicomid(tagApplication));
		}
		for(final var tagTool : tagsTools) {
			ticomids.add(tagToolToTicomid(tagTool));
		}
		return String.join(",", ticomids);
	}

	private String tagProductToTicomid(String tagProduct) {
		var tag = tagManager.resolve(tagProduct);
		var subtags = tag.listAllSubTags();
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return ( subtags.hasNext() ? "fm_" : "gp_" ) + lastPart;
	}

	private String tagApplicationToTicomid(String tagApplication) {
		var tag = tagManager.resolve(tagApplication);
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return "eq_" + lastPart;
	}

	private String tagToolToTicomid(String tagTool) {
		var tag = tagManager.resolve(tagTool);
		final var parts = tag.getLocalTagID().split("/");
		final var lastPart = parts[parts.length - 1];
		return "tl_" + lastPart;
	}
    
}
