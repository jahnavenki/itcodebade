package com.ti.core.service.config;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "TI WCM Components Service ",
description = "Configure services for TI component services")
public @interface WCMComponentConfiguration {
	
	   @AttributeDefinition(name = "tiTechDocsUrl", description = "Technical Document Categories  URL(Authoring)", type = AttributeType.STRING )
	   String tiTechDocsUrl() default "";
		
	   @AttributeDefinition(name = "featuredLitUrl", description = "Featured Literature Service URL",  type = AttributeType.STRING )
	   String featuredLitUrl();
		
	   @AttributeDefinition(name = "emsgProductAllUrl", description = "EMSG Product Data ALL URL",type = AttributeType.STRING)
	   String emsgProductAllUrl();
	   
	   @AttributeDefinition(name = "emsgToolOpnUrl", description = "EMSG Tool OPN Data ALL URL",  type = AttributeType.STRING )
	   String emsgToolOpnUrl();
	
	   @AttributeDefinition(name = "emsgApplicationAllUrl", description = "EMSG Application Data ALL URL",  type = AttributeType.STRING )
	   String emsgApplicationAllUrl();

	   @AttributeDefinition(name = "emsgApplicationListUrl", description = "EMSG Application Data List URL (For Technical documents)",  type = AttributeType.STRING )
	   String emsgApplicationListUrl();

	   @AttributeDefinition(name = "siloUrl", description = "Silo Service URL",  type = AttributeType.STRING )
	   String siloUrl();

	   @AttributeDefinition(name = "emsgToolPartDetailUrl", description = "EMSG ATool Part detail",  type = AttributeType.STRING )
	   String emsgToolPartDetailUrl();

	   @AttributeDefinition(name = "toolDetailsUrl", description = "Tool Model URL",  type = AttributeType.STRING )
	   String toolDetailsUrl();
	    
	   @AttributeDefinition(name = "percolateuserlistUrl", description = "Percolate User List Service URL",  type = AttributeType.STRING )
	   String percolateuserlistUrl();
	   @AttributeDefinition(name = "productFamilyUrl", description = "Product Family Service URL",  type = AttributeType.STRING )
	   String productFamilyUrl();
	   @AttributeDefinition(name = "apphomepageUrl", description = "Application homepage URL",  type = AttributeType.STRING )
	   String apphomepageUrl();
	  
	 
	   @AttributeDefinition(name = "productTechDocCategoriesUrl", description = "Product Family Technical Document Categories Service URL",  type = AttributeType.STRING )
	   String productTechDocCategoriesUrl();
	   @AttributeDefinition(name = "productTechDocCategoriesUrlSuffix", description = "Product Technical Document Categories Service URL SUFFIX",  type = AttributeType.STRING )
	   String productTechDocCategoriesUrlSuffix();
	   @AttributeDefinition(name = "applicationTechDocCategoriesUrl", description = "Application Technical Document Categories Service URL",  type = AttributeType.STRING )
	   String applicationTechDocCategoriesUrl();
	   
	  
	   @AttributeDefinition(name = "applicationTechDocListingUrl", description = "Product Family Technical Document Listing Service URL Suffix",  type = AttributeType.STRING )
	   String applicationTechDocListingUrl();
	   @AttributeDefinition(name = "productTechDocListingUrl", description = "Technical Document Listing Service URL Count Suffix",  type = AttributeType.STRING )
	   String productTechDocListingUrl();
	  
	   @AttributeDefinition(name = "productTechDocListingCountUrlSuffix", description = "Technical Document Listing Service URL Count Suffix",  type = AttributeType.STRING )
	   String productTechDocListingCountUrlSuffix();
	  
	   @AttributeDefinition(name = "productTechDocListingSearchTermUrlSuffix", description = "Technical Document Listing Service URL Search Term Suffix",  type = AttributeType.STRING )
	   String productTechDocListingSearchTermUrlSuffix();
	   
	   
	   @AttributeDefinition(name = "oauthUrl", description = "OAUTH URL",  type = AttributeType.STRING )
	   String oauthUrl();
	   @AttributeDefinition(name = "oauthAuthentication", description = "OAUTH Authentication",  type = AttributeType.STRING )
	   String oauthAuthentication();
	   @AttributeDefinition(name = "percolateoauthUrl", description = "PERCOLATE OAUTH URL",  type = AttributeType.STRING )
	   String percolateoauthUrl();
	   @AttributeDefinition(name = "percolateoauthAuthentication", description = "PERCOLATE OAUTH Authentication",  type = AttributeType.STRING )
	   String percolateoauthAuthentication();
	   @AttributeDefinition(name = "defaultDocumentCategories", description = "Default Document Categories",  type = AttributeType.STRING )
	   String defaultDocumentCategories();
	   @AttributeDefinition(name = "recommendedAppsUrl", description = "WCM Components Recommended Apps URL",  type = AttributeType.STRING )
	   String recommendedAppsUrl();
	   @AttributeDefinition(name = "boomiToken", description = "Boomi Authorization Token",  type = AttributeType.STRING )
	   String boomiToken();
	   
	   @AttributeDefinition(name = "boomiSiloFamilies", description = "Boomi Silo Families URL",  type = AttributeType.STRING )
	   String boomiSiloFamilies();
	   
	   @AttributeDefinition(name = "boomiProductFamilyAllUrl", description = "Boomi Product Family All URL",  type = AttributeType.STRING )
	   String boomiProductFamilyAllUrl();

	   @AttributeDefinition(name = "boomiProductFamilyGPNsUrl", description = "Boomi Product Family GPNs URL",  type = AttributeType.STRING )
	   String boomiProductFamilyGPNsUrl();

	   @AttributeDefinition(name = "boomiToolTypeUrl", description = "Boomi Tool Type URL",  type = AttributeType.STRING )
	   String boomiToolTypeUrl();

	   @AttributeDefinition(name = "boomiToolTypeTPNsUrl", description = "Boomi Tool Type TPNs URL",  type = AttributeType.STRING )
	   String boomiToolTypeTPNsUrl();

	   @AttributeDefinition(name = "boomiEpodVariantUrl", description = "Boomi ePOD Variant URL",  type = AttributeType.STRING )
	   String boomiEpodVariantUrl();

	   @AttributeDefinition(name = "boomiDamDeleteUrl", description = "Boomi DAM Delete URL",  type = AttributeType.STRING )
	   String boomiDamDeleteUrl();

	   @AttributeDefinition(name = "boomildapUrl", description = "Boomi Ldap URL",  type = AttributeType.STRING )
	   String boomildapUrl();
	   
	   @AttributeDefinition(name = "boomiCategoryListingUrl", description = "Literature category listing service",  type = AttributeType.STRING )
	   String boomiCategoryListingUrl();
	   
	 
	   @AttributeDefinition(name = "boomiApplicationMarketUrl", description = "Boomi Application market service",  type = AttributeType.STRING )
	   String boomiApplicationMarketUrl();
	   @AttributeDefinition(name = "boomiApplicationSectorUrl", description = "Boomi Application sector service",  type = AttributeType.STRING )
	   String boomiApplicationSectorUrl();
	   @AttributeDefinition(name = "boomiApplicationCategoryUrl", description = "Boomi Application category service",  type = AttributeType.STRING )
	   String boomiApplicationCategoryUrl();
	   @AttributeDefinition(name = "boomiApplicationEndEquipmentsUrl", description = "Boomi Application End Equipements service",  type = AttributeType.STRING )
	   String boomiApplicationEndEquipmentsUrl();
	   
	   @AttributeDefinition(name = "productModelUrl", description = "Product Model Url",  type = AttributeType.STRING )
	   String productModelUrl();

	   @AttributeDefinition(name = "supplyFrameUrlDomain", description = "SupplyFrame Url Domain",  type = AttributeType.STRING )
	   String supplyFrameUrlDomain();
	   
	   @AttributeDefinition(name = "jackDefaultTrendingDataUrl", description = "Jack Default Trending Data Url",  type = AttributeType.STRING )
	   String jackDefaultTrendingDataUrl();
	   
	   
	   @AttributeDefinition(name = "homePageFeaturedProductsUrl", description = "Homepage Featured Products Data URL",  type = AttributeType.STRING )
	   String homePageFeaturedProductsUrl();
	   @AttributeDefinition(name = "productFamilyNewProductsUrl", description = "Product Family New Products Data URL",  type = AttributeType.STRING )
	   String productFamilyNewProductsUrl();	   
	   @AttributeDefinition(name = "connectTimeOutValue", description = "Connect Time Out (in milliseconds)",  type = AttributeType.INTEGER )
	   int connectTimeOutValue();
	   @AttributeDefinition(name = "readTimeOutValue", description = "Read Time Out (in milliseconds)",  type = AttributeType.INTEGER )
	   int readTimeOutValue();
	   @AttributeDefinition(name = "defaultRetries", description = "Default Retries (in milliseconds)",  type = AttributeType.INTEGER )
	   int defaultRetries();
	   @AttributeDefinition(name = "defaultWaitTime", description = "Default Wait Time (in milliseconds)",  type = AttributeType.INTEGER )
	   int defaultWaitTime();
	   @AttributeDefinition(name = "brightcoveOauthUrl", description = "BRIGHTCOVE OAUTH URL",  type = AttributeType.STRING )
	   String brightcoveOauthUrl();
	   @AttributeDefinition(name = "brightcoveOauthAuthentication", description = "BRIGHTCOVE OAUTH Authentication",  type = AttributeType.STRING )
	   String brightcoveOauthAuthentication();
	   @AttributeDefinition(name = "brightcoveVideoMetaDataUrl", description = "BRIGHTCOVE METADATA URL",  type = AttributeType.STRING )
	   String brightcoveVideoMetaDataUrl();
	   @AttributeDefinition(name = "brightcoveVideoSourceUrl", description = "BRIGHTCOVE VIDEO SOURCE URL",  type = AttributeType.STRING )
	   String brightcoveVideoSourceUrl();
	  

	   
	 

	


}
