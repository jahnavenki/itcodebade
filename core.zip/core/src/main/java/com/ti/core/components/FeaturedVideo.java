
package com.ti.core.components;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.util.PathBrowserHelper;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FeaturedVideo extends WCMUsePojo {
    
    private static final Logger log = LoggerFactory.getLogger(FeaturedVideo.class);
    
    private String videoId;
    private String title;
    private String description;
    private String ctaText;
    private String ctaUrl;

    public String getVideoId() {
        return videoId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getCtaText() {
        return ctaText;
    }

    public String getCtaUrl() {
        return ctaUrl;
    }
    
    @Override
    public void activate() throws Exception {
        try {
            ValueMap properties = getProperties();
            videoId = properties.get("videoid", "");
            title = properties.get("title", "");
            description = properties.get("description", "");
            ctaText = properties.get("ctaText", "");
            ctaUrl = properties.get("ctaURL", "");
            ctaUrl = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(),ctaUrl);
        } catch (Exception e) {
            log.error("Exception: ", e);
        }
    }
    
}
