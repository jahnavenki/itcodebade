package com.ti.core.components.models;

import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.api.resource.Resource;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

@Model(
	adaptables = {SlingHttpServletRequest.class, Resource.class},
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class PortfolioVisualizerWithTabsModel {
    protected final Logger log = LoggerFactory.getLogger(getClass());

    @ValueMapValue
    private String tabName;

    @ValueMapValue
    private String imageSrc;

    @PostConstruct
	public void init(){
		try {
			tabName = StringUtils.defaultString(tabName);
			imageSrc = StringUtils.defaultString(imageSrc);
		} catch (Exception e) {
			log.error("Exception in portfolioVisualizerWithTabsModel", e);
		}
	}

    public String getTabName() {
        return tabName;
    }

    public String getImageSrc() {
        return imageSrc;
    }

}
