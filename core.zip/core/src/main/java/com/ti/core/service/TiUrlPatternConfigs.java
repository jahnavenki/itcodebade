package com.ti.core.service;

import java.util.List;

public interface TiUrlPatternConfigs {
	List<TiUrlPattern> getConfigs();
}
