package com.ti.core.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.service.SeoUrlTagging;

/**
 * PathBrowserHelper WCMUsePojo.
 *
 */
public class PathBrowserHelper extends WCMUsePojo {
	private static final Logger log = LoggerFactory.getLogger(PathBrowserHelper.class);
	private static final String CONTENT_TI_PATH = "/content";
	private static final Pattern REGEX_LANGUAGE = Pattern
			.compile("^/content/texas-instruments/([a-zA-Z][a-zA-Z]-[a-zA-Z][a-zA-Z])");
	private static final String REGEX_PATH_CONTAINS_COLON = "\\:(?![\\/0-9])";
	private static final String ENCODED_COLON = "%3A";
	private static final String EXTENSION = ".html";
	private static final String TI_DOMAIN_1 = "ti.com";
	private static final String TI_DOMAIN_2 = "tij.co.jp";
	private static final Pattern TI_REGEX_PATTERN = Pattern
			.compile("^http:\\/\\/(www[a-z0-9\\.-]*)?(ti\\.com|tij\\.co\\.jp)");

	private String link;

	private boolean newTab;

	@Override
	public void activate() throws Exception {
		ResourceResolver resolver = getResourceResolver();
		String url = get("url", String.class);
		link = addHtmlIfContentPath(resolver, url);
		newTab = checkDomainName(url);
	}

	private static SeoUrlFactoryConfigs getSeoUrlFactoryService() {
		BundleContext bundleContext = FrameworkUtil.getBundle(PathBrowserHelper.class).getBundleContext();
		ServiceReference factoryRef = bundleContext.getServiceReference(SeoUrlFactoryConfigs.class.getName());
		return (SeoUrlFactoryConfigs) bundleContext.getService(factoryRef);
	}

	/**
	 * This is a method.
	 * 
	 * @param path
	 *            - variable
	 * @return String
	 */
	public static String addHtmlIfContentPath(ResourceResolver resolver, String path) {
		String retval = path;
		if (StringUtils.isNotEmpty(retval)) {

			String language = null;
			boolean startsWithTIPath = retval.startsWith(CONTENT_TI_PATH);
			if (startsWithTIPath) {
				Matcher match = REGEX_LANGUAGE.matcher(path);
				if (match.find()) {
					language = match.group(1);
				}

				retval = resolver.map(retval);
			}

			int queryStringIdx = retval.indexOf('?');
			int hashIdx = retval.indexOf('#');
			if (queryStringIdx < 1) {
				queryStringIdx = hashIdx;
			} else if (hashIdx > 1) {
				queryStringIdx = Math.min(queryStringIdx, hashIdx);
			}
			String suffix = "";
			if (queryStringIdx > 1) {
				suffix = retval.substring(queryStringIdx);
				retval = retval.substring(0, queryStringIdx);
			}

			if (startsWithTIPath) {
				if (!retval.substring(retval.lastIndexOf('/')).contains(".")) {
					retval = retval.concat(EXTENSION);
				}
				if (StringUtils.isNotEmpty(language)) {
					retval = setCorrectDomain(retval, language);
				}
			} else {
				retval = retval.replaceAll(REGEX_PATH_CONTAINS_COLON, ENCODED_COLON);
				Matcher matcher = TI_REGEX_PATTERN.matcher(retval);
				if (matcher.find()) {
					retval = URLHelper.toHttps(retval);
				}
			}
			retval += suffix;
		} else {
			retval = StringUtils.EMPTY;
		}
		return retval;
	}

	/**
	 * Get Domain from SEO Url Tagging for this path
	 * 
	 * @param resolver
	 * @param retval
	 */
	public static String setCorrectDomain(String urlString, String language) {

		String retval = urlString;
		SeoUrlFactoryConfigs factoryConfigs = null;
		try {
			factoryConfigs = getSeoUrlFactoryService();
		} catch (Exception e) {
			log.error("Exception : ", e);
		}

		if (null != factoryConfigs && StringUtils.isNotEmpty(language)) {

			try {
				URI url = new URI(urlString);
				String newDomain = null;
				for (SeoUrlTagging configs : factoryConfigs.getConfigs()) {
					if (configs.getContentPath().contains(language)) {
						newDomain = configs.getDomainName();
						break;
					}
				}

				URI newUrl = new URI("https", newDomain, url.getPath(), url.getFragment());
				retval = newUrl.toString();
			} catch (URISyntaxException e) {
				log.error("Exception : ", e);
			}
		}
		return retval;
	}

	/**
	 * Missing Java Doc.
	 * 
	 * @param path
	 *            contentPath
	 * @return boolean
	 */
	public static boolean checkDomainName(String path) {
		return (StringUtils.isNotEmpty(path) && !path.startsWith(CONTENT_TI_PATH) && !path.contains(TI_DOMAIN_1)
				&& !path.contains(TI_DOMAIN_2));
	}

	public String getLink() {
		return link;
	}

	public boolean isNewTab() {
		return newTab;
	}

}