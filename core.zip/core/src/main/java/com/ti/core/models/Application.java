package com.ti.core.models;

public class Application {
  private String appId;
  private String appName;
  private String appUrl;
  private String sortOrder;

  /**
   * get app id.
   * @return the appId.
   */
  public String getAppId() {
    return appId;
  }

  /**
   * @param appId
   *          the appId to set.
   */
  public void setAppId(String appId) {
    this.appId = appId;
  }

  /**
   * get the app name.
   * @return the appName
   */
  public String getAppName() {
    return appName;
  }

  /**
   * @param appName
   *          the appName to set.
   */
  public void setAppName(String appName) {
    this.appName = appName;
  }

  /**
   * get the app url.
   * @return the appUrl.
   */
  public String getAppUrl() {
    return appUrl;
  }

  /**
   * @param appUrl
   *          the appUrl to set.
   */
  public void setAppUrl(String appUrl) {
    this.appUrl = appUrl;
  }

  /**
   * get sortOrder.
   * @return the sortOrder.
   */
  public String getSortOrder() {
    return sortOrder;
  }

  /**
   * @param sortOrder
   *          the sortOrder to set.
   */
  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

}
