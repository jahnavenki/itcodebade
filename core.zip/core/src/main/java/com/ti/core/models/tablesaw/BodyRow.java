package com.ti.core.models.tablesaw;

import java.util.ArrayList;
import java.util.List;

import com.ti.core.components.TableSawUse;

public class BodyRow {
  private List<Cell> bodyRows = new ArrayList<>();
  
  private String subHeaderRowClass;
  private String style;

  public List<Cell> getBodyRows() {
    return bodyRows;
  }
  
  public String getSubHeaderRowClass(){
    return subHeaderRowClass;
  }
  
  public void setSubHeaderRowClass(String isSubHeaderRow){
    this.subHeaderRowClass = isSubHeaderRow;
  }
  
  public int getBodyRowNumber() {
    if (!this.bodyRows.isEmpty())
      return TableSawUse.getRowNumberFromName(this.bodyRows.get(0).getName());
    else
      return 0;
  }
  
  public String getStyle() {
    return style;
  }

  public void setStyle(String style) {
    this.style = style;
  }
}
