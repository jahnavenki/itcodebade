package com.ti.core.components;

import java.util.ArrayList;
import java.util.List;

import com.adobe.cq.sightly.WCMUsePojo;
import com.ti.core.models.BreadcrumbLink;
import com.ti.core.service.SeoUrlFactoryConfigs;
import com.ti.core.util.LanguageUtils;
import com.ti.core.util.PathBrowserHelper;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthoredBreadcrumb extends WCMUsePojo {

	private static final String BREADCRUMB_NODES = "breadcrumbNodes";
	private static final String URL = "url";
	private static final String LABEL = "label";
	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private List<BreadcrumbLink> breadcrumbLinks = new ArrayList<>();

	public List<BreadcrumbLink> getBreadcrumbLinks() {
		return breadcrumbLinks;
	}

	@Override
	public void activate() {
		try {
			final var factoryConfigs = getSlingScriptHelper().getService(SeoUrlFactoryConfigs.class);
			final var domain = DomainComponent.getDomainFromConfig(factoryConfigs, getCurrentPage().getPath());
			final var langUtils = new LanguageUtils(getRequest());
			final var pageProperties = getPageProperties();
			final String template = pageProperties.get("cq:template", "");
			{
				final var breadcrumb = new BreadcrumbLink();
				breadcrumb.setLink(langUtils.getI18nStr("https://www.ti.com"));
				breadcrumb.setTitle(langUtils.getI18nStr("Home"));
				breadcrumbLinks.add(breadcrumb);
			}
			if ("/conf/ti/settings/wcm/templates/applications-level-page-template".equals(template)) {
				final var breadcrumb = new BreadcrumbLink();
				breadcrumb.setTitle(langUtils.getI18nStr("Applications"));
				breadcrumbLinks.add(breadcrumb);
			}
			if ("/conf/ti/settings/wcm/templates/video-series-page-template".equals(template)) {
				final var breadcrumb = new BreadcrumbLink();
				breadcrumb.setLink(langUtils.getI18nStr("https://{0}/video/library.html", domain));
				breadcrumb.setTitle(langUtils.getI18nStr("Video library"));
				breadcrumbLinks.add(breadcrumb);
			}
			final var nodeChild = getResource().getChild(BREADCRUMB_NODES);
			if (null != nodeChild) {
				for (final var breadcrumbRes : nodeChild.getChildren()) {
					final var properties = breadcrumbRes.adaptTo(ValueMap.class);
					if (null != properties) {
						final var breadcrumb = new BreadcrumbLink();
						final var link = PathBrowserHelper.addHtmlIfContentPath(getResourceResolver(), properties.get(URL, String.class));
						breadcrumb.setLink(link);
						breadcrumb.setTitle(properties.get(LABEL, String.class));
						breadcrumbLinks.add(breadcrumb);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception : ", e);
		}
	}
}
