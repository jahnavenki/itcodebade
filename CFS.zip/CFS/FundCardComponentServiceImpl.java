package au.com.cfs.winged.core.services;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.cfs.winged.core.models.pojo.PerformanceFamily;
import com.google.gson.Gson;

@Component(service = FundCardComponentService.class)
public class FundCardComponentServiceImpl implements FundCardComponentService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FundCardComponentServiceImpl.class);

    @Reference
    private transient ApiGatewayService apiGatewayService;

    // Define other services and references as needed

    @Override
    public PerformanceFamily[] getPerformanceFamilies(Optional<String> language, String marketingName, String companyId, String mainGroup,
                                                      String category, String asset, String risk, String minTimeFrame) {
        Map<String, String> queryParameters = new HashMap<>();
        queryParameters.put(Constants.LANGUAGE, getLanguage(language));
        queryParameters.put(Constants.MARKETING_NAME, marketingName);
        queryParameters.put(Constants.COMPANY_CODE, companyId);
        queryParameters.put(Constants.MAIN_GROUP, mainGroup);
        queryParameters.put(Constants.CATEGORY, category);
        queryParameters.put(Constants.ASSET, asset);
        queryParameters.put(Constants.RISK, risk);
        queryParameters.put(Constants.MIN_TIME_FRAME, minTimeFrame);
        // Add other parameters as needed
        return getPerformanceDetails(queryParameters);
    }

    private PerformanceFamily[] getPerformanceDetails(Map<String, String> queryParameters) {
        PerformanceFamily[] designFamilies = new PerformanceFamily[0];
        String url = apiGatewayService.getDesignFamilyApi(queryParameters);
        try {
            HttpRequest request = HttpRequest.newBuilder().uri(new URI(url)).GET().build();
            HttpResponse<String> response = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofMillis(apiGatewayService.getTimeout())).build()
                    .send(request, HttpResponse.BodyHandlers.ofString());
            String responseJSONStr = response.body();
            if (response.statusCode() == 200) {
                designFamilies = parseResponse(responseJSONStr);
            }
        } catch (URISyntaxException | InterruptedException | IOException e) {
            LOGGER.error("getPerformanceDetails(): IO exception occurred", e);
        }
        return designFamilies;
    }

    private PerformanceFamily[] parseResponse(String responseJSONStr) {
        Gson gson = new Gson();
        // Assuming responseJSONStr is an array of PerformanceFamily objects
        return gson.fromJson(responseJSONStr, PerformanceFamily[].class);
    }

    private String getLanguage(Optional<String> language) {
        return language.orElse("en"); // Default language is English
    }

    @Activate
    public void activate() {
        LOGGER.info("FundCardComponentService activated.");
    }
}
