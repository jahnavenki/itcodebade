package au.com.cfs.winged.core.services;

public final class Constants {

    // Parameter keys
    public static final String LANGUAGE = "language";
    public static final String MARKETING_NAME = "marketingName";
    public static final String COMPANY_CODE = "companyCode";
    public static final String MAIN_GROUP = "mainGroup";
    public static final String CATEGORY = "category";
    public static final String ASSET = "asset";
    public static final String RISK = "risk";
    public static final String MIN_TIME_FRAME = "mintimeframe";

    // Other constants as needed

    private Constants() {
        // Private constructor to prevent instantiation
    }
}
