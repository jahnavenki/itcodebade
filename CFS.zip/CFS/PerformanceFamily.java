package au.com.cfs.winged.core.models.pojo;

import java.util.Date;

public class PerformanceFamily {

    private String companyCode;
    private int ivstGrup;
    private String mainGroup;
    private String marketingName;
    private String apir;
    private String prodStat;
    private String assetClass;
    private boolean sustainable;
    private Date effectiveDate;
    private Double oneYear;
    private Double twoYears;
    private Double threeYears;
    private Double fourYears;
    private Double fiveYears;
    private Double sevenYears;
    private Double tenYears;
    private Double sinceInception;
    private Date inceptionDate;

    // Getters and setters

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public int getIvstGrup() {
        return ivstGrup;
    }

    public void setIvstGrup(int ivstGrup) {
        this.ivstGrup = ivstGrup;
    }

    public String getMainGroup() {
        return mainGroup;
    }

    public void setMainGroup(String mainGroup) {
        this.mainGroup = mainGroup;
    }

    public String getMarketingName() {
        return marketingName;
    }

    public void setMarketingName(String marketingName) {
        this.marketingName = marketingName;
    }

    public String getApir() {
        return apir;
    }

    public void setApir(String apir) {
        this.apir = apir;
    }

    public String getProdStat() {
        return prodStat;
    }

    public void setProdStat(String prodStat) {
        this.prodStat = prodStat;
    }

    public String getAssetClass() {
        return assetClass;
    }

    public void setAssetClass(String assetClass) {
        this.assetClass = assetClass;
    }

    public boolean isSustainable() {
        return sustainable;
    }

    public void setSustainable(boolean sustainable) {
        this.sustainable = sustainable;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Double getOneYear() {
        return oneYear;
    }

    public void setOneYear(Double oneYear) {
        this.oneYear = oneYear;
    }

    public Double getTwoYears() {
        return twoYears;
    }

    public void setTwoYears(Double twoYears) {
        this.twoYears = twoYears;
    }

    public Double getThreeYears() {
        return threeYears;
    }

    public void setThreeYears(Double threeYears) {
        this.threeYears = threeYears;
    }

    public Double getFourYears() {
        return fourYears;
    }

    public void setFourYears(Double fourYears) {
        this.fourYears = fourYears;
    }

    public Double getFiveYears() {
        return fiveYears;
    }

    public void setFiveYears(Double fiveYears) {
        this.fiveYears = fiveYears;
    }

    public Double getSevenYears() {
        return sevenYears;
    }

    public void setSevenYears(Double sevenYears) {
        this.sevenYears = sevenYears;
    }

    public Double getTenYears() {
        return tenYears;
    }

    public void setTenYears(Double tenYears) {
        this.tenYears = tenYears;
    }

    public Double getSinceInception() {
        return sinceInception;
    }

    public void setSinceInception(Double sinceInception) {
        this.sinceInception = sinceInception;
    }

    public Date getInceptionDate() {
        return inceptionDate;
    }

    public void setInceptionDate(Date inceptionDate) {
        this.inceptionDate = inceptionDate;
    }
}
