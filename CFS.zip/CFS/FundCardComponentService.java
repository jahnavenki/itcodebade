package au.com.cfs.winged.core.services;

import java.util.Optional;

import au.com.cfs.winged.core.models.pojo.PerformanceFamily;

public interface FundCardComponentService {

    PerformanceFamily[] getPerformanceFamilies(Optional<String> language, String marketingName, String companyId, String mainGroup,
                                                String category, String asset, String risk, String minTimeFrame);
}
